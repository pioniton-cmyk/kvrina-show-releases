const TIKFINITY_WS_URL = "ws://localhost:21213/";
const KARTON_DNIA_TEXT = "KARTON DNIA";
const KARTON_DNIA_KIND = "karton";

let outputDir = null;


// CZYTNIK PYTAŃ – stan
let autoQuestionsFilePath = null;
let autoQuestionsFileMtime = 0;
let questions = [];
let questionIndex = 0;
let filteredCount = 0;

// ZBIÓRKI (Tipped) – stan
let fundsTotal = 0; // suma PLN w tej sesji
let fundsByGoal = {}; // { "ZBIÓRKA ...": 123.45, ... }


// ZA GIFTY (TikFinity) – stan
let giftCredit = 450; // próg monet na wejście do kolejki (450 monet)
let tikfinityWs = null;
let tikfinityConnected = false;
let giftTotals = new Map(); // user -> total coins
let giftUsed = new Map();   // user -> used credits
let giftNewBlink = new Map(); // user -> blinkUntilTs
let giftFeed = []; // last lines
let selectedGiftUser = null;

// RANKING TAPÓW / LIKEÓW (TikFinity Event API)
let predictionRanking = new Map(); // nick -> liczba like/tapów
let predictionEventsFeed = [];

// KOLEJKA OBSERWUJĄCYCH – nicki z eventów follow TikFinity
const FOLLOW_QUEUE_STORAGE_KEY = "kvrina_follow_queue_v2";
let followQueue = [];
let followQueueKeys = new Set();

// LOSOWANIE KARTONA DNIA — "ładowanie" udające zbieranie punktów widzów, a naprawdę to
// zwykły czas: co losowe 12-17 min pasek się napełnia, wtedy otwiera się 30-sekundowe okno
// "napisz KARTON na czacie", losujemy zwycięzcę spośród piszących w TYM oknie, i cykl
// zaczyna się od nowa. Zastępuje stary system liczenia 15 obserwacji.
const KARTON_CHARGE_MIN_MS = 12 * 60 * 1000;
const KARTON_CHARGE_MAX_MS = 17 * 60 * 1000;
const KARTON_COLLECTION_MS = 30 * 1000;
// W trybie DEMO cykl ładowania/zbierania jest przyspieszony, żeby dało się w podglądzie
// zobaczyć pełny cykl widgetu (ładowanie → zbieranie → wygrana) bez czekania realnych 12-17 min.
const KARTON_DEMO_CHARGE_MIN_MS = 15 * 1000;
const KARTON_DEMO_CHARGE_MAX_MS = 25 * 1000;
const KARTON_DEMO_COLLECTION_MS = 10 * 1000;
let _kartonChargeStartedAt = Date.now(); // kiedy zaczął się bieżący cykl ładowania
let _kartonChargeDurationMs = KARTON_CHARGE_MIN_MS + Math.random() * (KARTON_CHARGE_MAX_MS - KARTON_CHARGE_MIN_MS);
let _kartonCollectionActive = false; // czy trwa 30s okno zbierania "karton" z czatu
let _kartonCollectionEndsAt = null;
let _kartonCollectionWriters = new Map(); // znormalizowany nick -> wyświetlany nick (tylko z BIEŻĄCEGO okna)
let _lastKartonDraw = null; // { nick, ts } | null — do widgetu ogłaszającego zwycięzcę

// LICZNIK CZASU (czytnik) — ustawiany w topbarze (h/min), startuje przy pierwszym
// komentarzu na live. 15 min przed końcem: TOP1 rankingu ląduje w kolejce (pytanie do kart).
const COUNTDOWN_TOP1_LEAD_MS = 15 * 60 * 1000;
let _countdownDurationMs = 0;   // 0 = wyłączony
let _countdownStarted = false;
let _countdownEndsAt = null;     // timestamp końca
let _countdownTop1Fired = false;
let _countdownTop1Nick = null;
let _countdownTop1FiredAt = null;
// ===== UI/Wydajność: rubryczka giftów, eco, animacje =====
const MAX_MAIN_CHAT_LINES = 80; // limit wpisów w rubryczce giftów (optymalizacja RAM)
const CHAT_FLUSH_MS = 60;        // batch DOM dla giftów (mniej szarpania)
let _chatQueue = [];
let _chatFlushTimer = null;

// ---- THROTTLE RENDERÓW KOLEJKI (grupuje wywołania co 200ms) ----
// === DŹWIĘK: powiadomienia + muzyka w tle ===
// Odtwarzane z głównego (ukrytego) okna, bo ono żyje przez cały live — dzięki temu
// muzyka nie urywa się przy zamykaniu czytnika czy paneli.
let _soundSettings = null;
let _soundBaseUrl = "http://127.0.0.1:8750/dzwieki";
let _notifyAudio = null;
let _musicAudio = null;
let _musicList = [];
let _musicIndex = 0;
let _notifyFiles = [];
let _lastNotifyAt = 0;

function _enc(name) { return encodeURIComponent(String(name || "")); }

async function refreshSoundState() {
  if (!window.wbApi || typeof window.wbApi.soundGetState !== "function") return;
  try {
    const r = await window.wbApi.soundGetState();
    if (!r || !r.ok) return;
    _soundSettings = r.settings || {};
    _soundBaseUrl = r.baseUrl || _soundBaseUrl;
    _notifyFiles = r.notifyFiles || [];
    const prev = _musicList.join("|");
    _musicList = r.musicFiles || [];
    if (_musicList.join("|") !== prev) _musicIndex = 0;
    applyMusicState();
  } catch {}
}

// Krótki sygnał, że ktoś dopisał się do kolejki. Świadomie NIE nakładamy dźwięków
// na siebie przy serii donejtów — 400 ms odstępu wystarczy, a nie robi się kakofonia.
function playNotifySound() {
  try {
    const s = _soundSettings;
    if (!s || !s.notifyEnabled) return;
    if (!_notifyFiles.length) return;
    const now = Date.now();
    if (now - _lastNotifyAt < 400) return;
    _lastNotifyAt = now;

    const file = (s.notifyFile && _notifyFiles.includes(s.notifyFile)) ? s.notifyFile : _notifyFiles[0];
    if (!file) return;

    if (!_notifyAudio) _notifyAudio = new Audio();
    _notifyAudio.src = `${_soundBaseUrl}/powiadomienia/${_enc(file)}`;
    _notifyAudio.volume = Math.max(0, Math.min(1, Number(s.notifyVolume) || 0));
    _notifyAudio.currentTime = 0;
    _notifyAudio.play().catch(() => {});
  } catch {}
}

function reportPlaying() {
  try {
    if (!window.wbApi || typeof window.wbApi.soundReportPlaying !== "function") return;
    const track = (_musicAudio && !_musicAudio.paused && _musicList[_musicIndex]) ? _musicList[_musicIndex] : null;
    window.wbApi.soundReportPlaying({ track, playing: !!track });
  } catch {}
}

function playMusicAt(index) {
  if (!_musicList.length) return;
  _musicIndex = ((index % _musicList.length) + _musicList.length) % _musicList.length;
  const file = _musicList[_musicIndex];
  if (!file) return;

  if (!_musicAudio) {
    _musicAudio = new Audio();
    // Po skończonym utworze lecimy dalej — losowo albo po kolei.
    _musicAudio.addEventListener("ended", () => {
      if (!_soundSettings || !_soundSettings.musicEnabled) return;
      if (_soundSettings.musicShuffle && _musicList.length > 1) {
        let next = _musicIndex;
        while (next === _musicIndex) next = Math.floor(Math.random() * _musicList.length);
        playMusicAt(next);
      } else {
        playMusicAt(_musicIndex + 1);
      }
    });
    _musicAudio.addEventListener("error", () => { setTimeout(() => playMusicAt(_musicIndex + 1), 800); });
  }

  _musicAudio.src = `${_soundBaseUrl}/muzyka/${_enc(file)}`;
  _musicAudio.volume = Math.max(0, Math.min(1, Number((_soundSettings || {}).musicVolume) || 0));
  _musicAudio.play().then(reportPlaying).catch(() => {});
}

function applyMusicState() {
  const s = _soundSettings || {};
  if (_musicAudio) {
    _musicAudio.volume = Math.max(0, Math.min(1, Number(s.musicVolume) || 0));
  }
  if (s.musicEnabled && _musicList.length) {
    if (!_musicAudio || _musicAudio.paused) {
      playMusicAt(s.musicShuffle ? Math.floor(Math.random() * _musicList.length) : _musicIndex);
    }
  } else if (_musicAudio && !_musicAudio.paused) {
    _musicAudio.pause();
  }
  reportPlaying();
}

function setupSoundEngine() {
  refreshSoundState();
  // Panel zmienił ustawienia — reagujemy natychmiast.
  try {
    if (window.wbApi && typeof window.wbApi.onSoundSettings === "function") {
      window.wbApi.onSoundSettings((s) => {
        _soundSettings = { ...(_soundSettings || {}), ...(s || {}) };
        applyMusicState();
      });
    }
  } catch {}
  // Przyciski w panelu: test dźwięku, następny utwór, odświeżenie listy plików.
  try {
    if (window.wbApi && typeof window.wbApi.onSoundControl === "function") {
      window.wbApi.onSoundControl(({ action } = {}) => {
        if (action === "test-notify") { _lastNotifyAt = 0; playNotifySound(); }
        else if (action === "next") { if (_musicList.length) playMusicAt(_musicIndex + 1); }
        else if (action === "rescan") { refreshSoundState(); }
      });
    }
  } catch {}
  // Nowe pliki w folderach wykrywamy co pół minuty — bez potrzeby restartu programu.
  setInterval(refreshSoundState, 30000);
}

// Główne okno jest "silnikiem" działającym w tle i prawie zawsze pozostaje ukryte.
// Przebudowa list (kolejka pytań, obserwujący, gifty) przy każdym evencie z live
// kosztowała sporo CPU zupełnie na darmo — gdy okna nie widać, pomijamy rysowanie
// i odtwarzamy je w całości dopiero w momencie pokazania okna.
// Dane w pamięci są aktualizowane niezależnie, więc nic nie ginie.
let _mainWindowVisible = false;
let _renderSkippedWhileHidden = false;

function shouldSkipHeavyRender() {
  if (_mainWindowVisible) return false;
  _renderSkippedWhileHidden = true;
  return true;
}

function refreshAllPanelsAfterShow() {
  if (!_renderSkippedWhileHidden) return;
  _renderSkippedWhileHidden = false;
  try { renderFollowQueue(); } catch {}
  try { renderQuestionOrderQueue(); } catch {}
  try { renderRankingPreviewPanel(); } catch {}
  try { renderGiftFeed(); } catch {}
}

function setupMainVisibilityTracking() {
  try {
    if (window.wbApi && typeof window.wbApi.onMainVisibility === "function") {
      window.wbApi.onMainVisibility(({ visible } = {}) => {
        _mainWindowVisible = !!visible;
        if (_mainWindowVisible) refreshAllPanelsAfterShow();
      });
    }
  } catch {}
}

let _followRenderTimer = null;
let _queueRenderTimer = null;
function scheduleFollowQueueRender() {
  if (shouldSkipHeavyRender()) return;
  if (_followRenderTimer) return;
  _followRenderTimer = setTimeout(() => { _followRenderTimer = null; renderFollowQueue(); }, 200);
}
function scheduleQueueRender() {
  if (shouldSkipHeavyRender()) return;
  if (_queueRenderTimer) return;
  _queueRenderTimer = setTimeout(() => { _queueRenderTimer = null; renderQuestionOrderQueue(); }, 200);
}


// Tryb "brak pytań" (gdy klikniesz DALEJ na ostatnim)
let noQuestionsMode = true;
let noQuestionsLength = 0;


// ROZMIARY CZCIONEK
let chatFontSize = 16;
let chatVisible = true;
let questionFontSize = 30;
let queueFontSize = 18;
let questionQueueFontSize = 16;


// zapamiętywanie ustawień (np. rozmiary czcionek) między uruchomieniami
const WB_PREFS_KEY = "wb_prefs_v1";

const PANEL_LAYOUT_KEY = "kvrina_panel_layout_v1";
const PANEL_LAYOUT_FILE = "layout_paneli.json";
const PANEL_LAYOUT_CONFIG = {
  chat: { label: "GIFTY", target: "#left-column", base: 1.35, min: 0.7, max: 2.8, step: 0.1 },
  followers: { label: "OBSERWUJĄCY", target: "#queue-panel", base: 1.08, min: 0.45, max: 2.4, step: 0.1 },
  ranking: { label: "RANKING", target: "#ranking-preview-panel", base: 0.82, min: 0.35, max: 2.0, step: 0.1 },
  questionQueue: { label: "KOLEJKA", target: "#question-queue-column", base: 0.78, min: 0.45, max: 1.8, step: 0.08 },
  questions: { label: "CZYTNIK", target: "#questions-panel", base: 1.25, min: 0.65, max: 2.7, step: 0.1 },
};
let panelLayoutPrefs = { panels: {}, updatedAt: Date.now() };

function defaultPanelLayoutPrefs() {
  const panels = {};
  Object.entries(PANEL_LAYOUT_CONFIG).forEach(([id, cfg]) => {
    panels[id] = { value: cfg.base, locked: false };
  });
  return { version: 1, updatedAt: Date.now(), panels };
}

function loadPrefs() {
  try {
    const raw = localStorage.getItem(WB_PREFS_KEY);
    if (!raw) return;
    const obj = JSON.parse(raw);
    if (obj && typeof obj.chatFontSize === "number") chatFontSize = obj.chatFontSize;
    if (obj && typeof obj.queueFontSize === "number") queueFontSize = obj.queueFontSize;
    if (obj && typeof obj.questionQueueFontSize === "number") questionQueueFontSize = obj.questionQueueFontSize;
    if (obj && typeof obj.questionFontSize === "number") questionFontSize = obj.questionFontSize;
    if (obj && typeof obj.chatVisible === "boolean") chatVisible = obj.chatVisible;
    if (obj && typeof obj.giftCredit === "number" && Number.isFinite(obj.giftCredit)) {
      const v = Math.max(1, Math.min(100000, Math.floor(obj.giftCredit)));
      giftCredit = v;
    }
  } catch (e) {
    // ignore
  }
}

function savePrefs() {
  try {
    localStorage.setItem(
      WB_PREFS_KEY,
      JSON.stringify({
        chatFontSize,
        chatVisible,
        queueFontSize,
        questionQueueFontSize,
        questionFontSize,
        giftCredit,
      })
    );
  } catch (e) {
    // ignore
  }
}


function clampPanelValue(id, value) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return 1;
  const n = Number(value);
  const safe = Number.isFinite(n) ? n : cfg.base;
  return Math.max(cfg.min, Math.min(cfg.max, Math.round(safe * 100) / 100));
}

async function loadPanelLayoutPrefs() {
  panelLayoutPrefs = defaultPanelLayoutPrefs();
  try {
    const rawLocal = localStorage.getItem(PANEL_LAYOUT_KEY);
    if (rawLocal) {
      const obj = JSON.parse(rawLocal);
      if (obj && obj.panels) panelLayoutPrefs = mergePanelLayoutPrefs(obj);
    }
  } catch {}

  try {
    if (window.wbApi && typeof window.wbApi.readFile === "function") {
      const r = await window.wbApi.readFile(PANEL_LAYOUT_FILE);
      if (r && r.ok && r.data) {
        const obj = JSON.parse(String(r.data));
        if (obj && obj.panels) panelLayoutPrefs = mergePanelLayoutPrefs(obj);
      }
    }
  } catch {}
}

function mergePanelLayoutPrefs(obj) {
  const base = defaultPanelLayoutPrefs();
  if (obj && typeof obj.updatedAt === "number") base.updatedAt = obj.updatedAt;
  Object.keys(PANEL_LAYOUT_CONFIG).forEach((id) => {
    const src = obj && obj.panels ? obj.panels[id] : null;
    if (src) {
      base.panels[id] = {
        value: clampPanelValue(id, src.value),
        locked: !!src.locked,
      };
    }
  });
  return base;
}

function applyPanelLayoutPrefs() {
  Object.entries(PANEL_LAYOUT_CONFIG).forEach(([id, cfg]) => {
    const state = (panelLayoutPrefs.panels && panelLayoutPrefs.panels[id]) || { value: cfg.base, locked: false };
    const el = document.querySelector(cfg.target);
    if (!el) return;
    const value = clampPanelValue(id, state.value);
    el.style.flex = `${value} 1 0`;
    el.style.minHeight = "0";
  });
  refreshPanelLayoutControls();
}

function panelSizeLabel(id) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  const state = panelLayoutPrefs.panels[id] || { value: cfg.base };
  return `${Math.round((clampPanelValue(id, state.value) / cfg.base) * 100)}%`;
}

async function savePanelLayoutPrefs() {
  try {
    panelLayoutPrefs.updatedAt = Date.now();
    const data = JSON.stringify(panelLayoutPrefs, null, 2);
    localStorage.setItem(PANEL_LAYOUT_KEY, data);
    if (window.wbApi && typeof window.wbApi.writeFile === "function") {
      await window.wbApi.writeFile(PANEL_LAYOUT_FILE, data);
    }
  } catch {}
}

function setPanelLayoutValue(id, nextValue) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return;
  const current = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
  if (current.locked) return;
  panelLayoutPrefs.panels[id] = { ...current, value: clampPanelValue(id, nextValue) };
  applyPanelLayoutPrefs();
  savePanelLayoutPrefs();
}

function togglePanelLayoutLock(id) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return;
  const current = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
  panelLayoutPrefs.panels[id] = { ...current, locked: !current.locked };
  applyPanelLayoutPrefs();
  savePanelLayoutPrefs();
}

function refreshPanelLayoutControls() {
  document.querySelectorAll(".panel-scale-controls").forEach((wrap) => {
    const id = wrap.dataset.panelLayoutId;
    const cfg = PANEL_LAYOUT_CONFIG[id];
    const state = cfg && panelLayoutPrefs.panels[id] ? panelLayoutPrefs.panels[id] : null;
    if (!cfg || !state) return;
    const label = wrap.querySelector(".panel-scale-value");
    const lock = wrap.querySelector(".panel-lock-btn");
    const minus = wrap.querySelector(".panel-scale-minus");
    const plus = wrap.querySelector(".panel-scale-plus");
    if (label) label.textContent = panelSizeLabel(id);
    if (lock) {
      lock.textContent = state.locked ? "🔒" : "🔓";
      lock.title = state.locked ? "Układ zablokowany i zapamiętany" : "Kliknij, żeby zablokować układ";
      lock.classList.toggle("locked", !!state.locked);
    }
    if (minus) minus.disabled = !!state.locked;
    if (plus) plus.disabled = !!state.locked;
  });
}

function addPanelLayoutControl(id, header) {
  if (!header || header.querySelector(`[data-panel-layout-id="${id}"]`)) return;
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return;
  const wrap = document.createElement("div");
  wrap.className = "panel-scale-controls";
  wrap.dataset.panelLayoutId = id;
  wrap.innerHTML = `
    <button type="button" class="btn tiny circle panel-scale-minus" title="Zmniejsz panel">−</button>
    <span class="panel-scale-value">${panelSizeLabel(id)}</span>
    <button type="button" class="btn tiny circle panel-scale-plus" title="Powiększ panel">+</button>
    <button type="button" class="btn tiny circle panel-lock-btn" title="Zablokuj układ">🔓</button>
  `;
  header.appendChild(wrap);
  wrap.querySelector(".panel-scale-minus")?.addEventListener("click", () => {
    const state = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
    setPanelLayoutValue(id, state.value - cfg.step);
  });
  wrap.querySelector(".panel-scale-plus")?.addEventListener("click", () => {
    const state = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
    setPanelLayoutValue(id, state.value + cfg.step);
  });
  wrap.querySelector(".panel-lock-btn")?.addEventListener("click", () => togglePanelLayoutLock(id));
}

function setupPanelLayoutControls() {
  addPanelLayoutControl("chat", document.querySelector("#chat-panel .panel-header"));
  addPanelLayoutControl("followers", document.querySelector("#queue-panel .panel-header"));
  addPanelLayoutControl("ranking", document.querySelector("#ranking-preview-panel .panel-header"));
  addPanelLayoutControl("questionQueue", document.querySelector("#question-queue-panel .panel-header"));
  addPanelLayoutControl("questions", document.querySelector("#questions-panel .panel-header"));
  refreshPanelLayoutControls();
}


// TikTok statystyki
let tiktokViewerCount = 0;

// TRYB DEMO LIVE — lokalna symulacja eventów do ustawiania sceny i widgetów
let demoModeActive = false;
let demoInterval = null;
let demoTick = 0;

const DEMO_NICKS = [
  "Wiedźma Basia", "Kasia Tarot", "Luna", "Marta", "Njut", "Ania", "Karolina",
  "Magdalena", "Ola", "Patrycja", "Monika", "Julia", "Natalia", "Agata", "Ewelina",
  "Sylwia", "Klaudia", "Daria", "Weronika", "Maja"
];
const DEMO_QUESTIONS = [
  "Czy on jeszcze o mnie myśli?",
  "Co wydarzy się w miłości w najbliższych dniach?",
  "Czy warto odezwać się jako pierwsza?",
  "Jaka energia jest teraz między nami?",
  "Czy ta relacja ma potencjał na coś poważnego?",
  "Co blokuje mój rozwój i pieniądze?",
  "Czy zmiana pracy będzie dla mnie dobra?",
  "Jaką wiadomość mają dla mnie karty na dziś?",
  "x"
];
const DEMO_GIFTS = [
  { name: "Róża", amount: 1 },
  { name: "Serce", amount: 5 },
  { name: "Kryształ", amount: 10 },
  { name: "Wszechświat", amount: 100 },
  { name: "Złota Kula", amount: 450 },
  { name: "Magiczny Lew", amount: 699 },
  { name: "Galaktyka", amount: 1200 }
];

// PALETA KOLORÓW DLA UŻYTKOWNIKÓW (około 20 odcieni)
const USER_COLORS = [
  "#e74c3c", "#e67e22", "#f1c40f", "#2ecc71", "#1abc9c",
  "#3498db", "#9b59b6", "#16a085", "#27ae60", "#2980b9",
  "#8e44ad", "#d35400", "#c0392b", "#7f8c8d", "#bdc3c7",
  "#f39c12", "#e84393", "#fd79a8", "#00cec9", "#6c5ce7"
];
const userColorMap = new Map();
let userColorIndex = 0;

function getUserColor(username) {
  if (!username) return null;
  if (userColorMap.has(username)) return userColorMap.get(username);
  const color = USER_COLORS[userColorIndex % USER_COLORS.length];
  userColorMap.set(username, color);
  userColorIndex++;
  return color;
}

function isKartonDniaEntry(entry) {
  return !!entry && (entry.kind === KARTON_DNIA_KIND || String(entry.question || "").trim().toUpperCase() === KARTON_DNIA_TEXT);
}

function setKartonDniaUi(active) {
  const box = document.getElementById("question-current");
  if (!box) return;
  box.classList.toggle("karton-dnia-mode", !!active);
}


function getTikTokNickname(payload) {
  // Chcemy WYŁĄCZNIE nazwę wyświetlaną (nickname) – bez @handle/uniqueId
  const name =
    (payload && (payload.nickname || payload.displayName)) ||
    (payload && payload.user && (payload.user.nickname || payload.user.displayName)) ||
    "";
  const cleaned = String(name || "").trim();
  return cleaned || "TT_Anon";
}





function parseHmsToSeconds(s) {
  const str = String(s || "").trim();
  if (!str) return null;
  // Akceptuje: H:MM:SS albo HH:MM:SS
  const m = str.match(/^(\d+):([0-5]\d):([0-5]\d)$/);
  if (!m) return null;
  const h = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  const ss = parseInt(m[3], 10);
  if ([h, mm, ss].some((x) => Number.isNaN(x))) return null;
  return h * 3600 + mm * 60 + ss;
}

function parseMsToSeconds(s) {
  const str = String(s || "").trim();
  if (!str) return null;
  // Akceptuje: M:SS (np. 20:05)
  const m = str.match(/^(\d+):([0-5]\d)$/);
  if (!m) return null;
  const mm = parseInt(m[1], 10);
  const ss = parseInt(m[2], 10);
  if ([mm, ss].some((x) => Number.isNaN(x))) return null;
  return mm * 60 + ss;
}


window.addEventListener("DOMContentLoaded", async () => {
  outputDir = await window.wbApi.getOutputDir();
  // START PUSTO: nie wczytujemy starych TXT ani logów przy starcie.


  loadPrefs();
  await loadPanelLayoutPrefs();
  applyPanelLayoutPrefs();
  applyFontSizes();
  applyChatVisibility();
  setupChatToggle();
  setupChat();
  setupQueue();
  setupRankingPreviewPanel();
  setupQuestionOrderQueue();
  setupQuestions();
  // Przy starcie wracamy do stanu sprzed zamknięcia programu.
  await restoreSessionOnStartup();
  await updateBackupStatusPill();
  setupWebhookStatusPolling();
  setupTikfinityReconnectButton();
  setupTikTokDirectControls();
  connectTikFinity();
  setupTunnelControls();
  setupUtilityControls();
  setupUpdateControls();
  setupDemoControls();
  setupSoundEngine();
  setupMainVisibilityTracking();
  setupWidgetStatePublishing();
  setupPanelLayoutControls();
  setupEntryEditModal();
  setupDiagModal();
  startRamMonitoring();
  setupTopbarMenu();

  window.addEventListener("beforeunload", () => {
    try { writeBackupNow(); } catch {}
    try { savePanelLayoutPrefs(); } catch {}
  });

  // Tipped webhook -> auto questions (optional toast)
  try {
    if (window.wbApi && typeof window.wbApi.onTippedQuestion === "function") {
      window.wbApi.onTippedQuestion((p) => {
        if (!p || !p.nick) return;
        // Nowe pytanie z Tipped -> dopisz do kolejki w pamięci (chronologicznie po ts)
        addIncomingAutoQuestion(p);
      });
    }
  } catch {}

  try {
    if (window.wbApi && typeof window.wbApi.onTippedFund === "function") {
      window.wbApi.onTippedFund((p) => {
        applyFundDonation(p);
      });
    }
  } catch {}

  // Tipped: kwota nie trafiła w żaden próg (Karton Dnia ~10 zł / Pytanie od 30 zł) —
  // zamiast ignorować, wpis na samym dole kolejki z info ile brakuje.
  try {
    if (window.wbApi && typeof window.wbApi.onTippedShortfall === "function") {
      window.wbApi.onTippedShortfall((p) => {
        if (!p || !p.nick) return;
        const shortfallStr = String(p.shortfallToQuestion ?? "").replace(".", ",");
        const msg = `Wpłacono ${String(p.amount).replace(".", ",")} zł — brakuje ${shortfallStr} zł do pytania (30 zł)`;
        insertQuestionSorted({ ts: p.ts || Date.now(), nick: p.nick, question: msg, kind: "shortfall" });
        appendSystem(`[TIPPED] ${msg} (${p.nick})`);
      });
    }
  } catch {}

  // Tryb okienka: przesuwanie i edycja wpisów wysłane z pop-outu — identyfikacja przez "ts",
  // odporne na przesunięcia indeksów; wykonuje dokładnie te same funkcje co przyciski w kolejce.
  try {
    if (window.wbApi && typeof window.wbApi.onReaderQueueMove === "function") {
      window.wbApi.onReaderQueueMove(({ ts, direction } = {}) => {
        const idx = questions.findIndex((q) => q.ts === ts);
        if (idx < 0) return;
        if (direction === "up") swapQuestionQueueItems(idx, idx - 1);
        else if (direction === "down") swapQuestionQueueItems(idx, idx + 1);
      });
    }
  } catch {}

  try {
    if (window.wbApi && typeof window.wbApi.onReaderQueueEdit === "function") {
      window.wbApi.onReaderQueueEdit(({ ts, nick, question, kind } = {}) => {
        const idx = questions.findIndex((q) => q.ts === ts);
        if (idx < 0) return;
        const entry = questions[idx];
        entry.nick = nick;
        entry.question = question;
        entry.kind = kind || null;
        normalizeQuestionQueueAfterMutation();
      });
    }
  } catch {}

  // Kliknięcie w pozycję kolejki (z okienka czytnika) — ta osoba wskakuje do czytania
  // (na pozycję questionIndex), a wszystko co było między nią a starym "TERAZ" (łącznie
  // z nim) ląduje pod nią w kolejce, w zachowanej kolejności.
  try {
    if (window.wbApi && typeof window.wbApi.onReaderQueueJump === "function") {
      window.wbApi.onReaderQueueJump(({ ts } = {}) => {
        const idx = questions.findIndex((q) => q.ts === ts);
        if (idx <= questionIndex) return;
        const [item] = questions.splice(idx, 1);
        questions.splice(questionIndex, 0, item);
        normalizeQuestionQueueAfterMutation();
      });
    }
  } catch {}

  // Ręczne dodanie wpisu wysłane z okienka czytnika (przycisk „+"). Ta sama ścieżka
  // co ręczne dodawanie w głównym oknie — jedno źródło logiki (insertQuestionSorted).
  try {
    if (window.wbApi && typeof window.wbApi.onReaderQueueAdd === "function") {
      window.wbApi.onReaderQueueAdd(({ nick, question, kind, tippedAmount } = {}) => {
        const cleanNick = String(nick || "").trim();
        if (!cleanNick) return;
        const q = String(question || "").trim() || "x";
        insertQuestionSorted({ ts: Date.now(), nick: cleanNick, question: q, source: "manual", kind: kind || null });
        appendSystem(`[RĘCZNIE] Dodano do kolejki: ${cleanNick}${kind === "karton" ? " (Karton Dnia)" : ""}`);
        // Tipped zaznaczony przy dodawaniu → dolicz do kasy (Zbiórki).
        const amt = Number(tippedAmount) || 0;
        if (amt > 0) applyFundDonation({ amount: amt, payer: cleanNick, goal: "Tipped (ręcznie)" });
      });
    }
  } catch {}

  // Ustawienia licznika czasu wysłane z czytnika (topbar h/min).
  try {
    if (window.wbApi && typeof window.wbApi.onReaderSetCountdown === "function") {
      window.wbApi.onReaderSetCountdown(({ hours, minutes } = {}) => {
        setCountdownDuration(hours, minutes);
      });
    }
  } catch {}
  // Tick licznika — 15 min przed końcem wrzuca TOP1 do kolejki.
  setInterval(countdownTick, 1000);
  setInterval(kartonChargeTick, 1000);

  // Menu okienka czytnika → uruchamiamy te same akcje co dawne przyciski ☰ (przeniesione).
  // Reużywamy istniejących handlerów przez .click() ukrytych przycisków — jedno źródło logiki.
  try {
    if (window.wbApi && typeof window.wbApi.onReaderMenuAction === "function") {
      window.wbApi.onReaderMenuAction((action) => {
        if (action === "losuj") { forceKartonCollection(); return; }
        // WIDGETY/AKTUALIZACJE/DIAGNOSTYKA mają teraz własne okienka (routing przez
        // PANEL_ACTIONS w reader_renderer.js) — nie trafiają już tutaj.
        const map = {
          copyurl: "btn-copy-tunnel",
          demo: "btn-toggle-demo",
          reset: "btn-reset-session",
        };
        const id = map[action];
        if (!id) return;
        const btn = document.getElementById(id);
        if (btn) btn.click();
      });
    }
  } catch {}

  // Panel OBSERWUJĄCY jako osobne okienko — te same akcje co przyciski DODAJ/✎/USUŃ w głównym oknie,
  // identyfikacja przez "ts" (stabilne, odporne na przesunięcia indeksów).
  try {
    if (window.wbApi && typeof window.wbApi.onPanelFollowAdd === "function") {
      window.wbApi.onPanelFollowAdd(({ ts } = {}) => {
        const idx = followQueue.findIndex((q) => q.ts === ts);
        if (idx >= 0) addFollowerCandidateToQuestionQueue(idx);
      });
    }
    if (window.wbApi && typeof window.wbApi.onPanelFollowRemove === "function") {
      window.wbApi.onPanelFollowRemove(({ ts } = {}) => {
        const idx = followQueue.findIndex((q) => q.ts === ts);
        if (idx >= 0) removeFollowerFromQueue(idx);
      });
    }
    if (window.wbApi && typeof window.wbApi.onPanelFollowEdit === "function") {
      window.wbApi.onPanelFollowEdit(({ ts, nick } = {}) => {
        const idx = followQueue.findIndex((q) => q.ts === ts);
        if (idx >= 0 && nick) {
          const oldKey = getFollowKey(followQueue[idx].nick);
          followQueueKeys.delete(oldKey);
          followQueue[idx].nick = nick;
          followQueueKeys.add(getFollowKey(nick));
          saveFollowQueue();
          renderFollowQueue();
          scheduleWidgetStateWrite();
        }
      });
    }
  } catch {}

  // Panel RANKING WIDZÓW jako osobne okienko — DODAJ po nicku.
  try {
    if (window.wbApi && typeof window.wbApi.onPanelRankingAdd === "function") {
      window.wbApi.onPanelRankingAdd(({ nick } = {}) => {
        if (nick) addRankingUserToQuestionQueue(nick);
      });
    }
  } catch {}

});

// =========================
// CLOUDLFARED TUNNEL UI
// =========================


let _webhookStatusTimer = null;

function setStatusPill(id, text, cls) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.classList.remove("status-ok", "status-info", "status-warn");
  if (cls) el.classList.add(cls);
}

// === MENU (☰) w topbarze — grupuje WIDGETY / AKTUALIZACJE / DIAGNOSTYKA / DEMO / ZERUJ SESJĘ ===
function setupTopbarMenu() {
  const toggle = document.getElementById("btn-topbar-menu");
  const menu = document.getElementById("topbar-menu");
  if (!toggle || !menu) return;

  const closeMenu = () => {
    menu.classList.add("hidden");
    toggle.setAttribute("aria-expanded", "false");
  };
  const openMenu = () => {
    menu.classList.remove("hidden");
    toggle.setAttribute("aria-expanded", "true");
  };

  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
    if (menu.classList.contains("hidden")) openMenu(); else closeMenu();
  });

  // Zamknij po kliknięciu w dowolny przycisk menu (otwiera modal/wykonuje akcję — nie ma sensu, żeby menu zostawało)
  menu.querySelectorAll(".topbar-menu-btn").forEach((btn) => {
    btn.addEventListener("click", () => closeMenu());
  });

  // Zamknij po kliknięciu poza menu
  document.addEventListener("click", (e) => {
    if (!menu.classList.contains("hidden") && !menu.contains(e.target) && e.target !== toggle) closeMenu();
  });

  // Zamknij na Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeMenu();
  });
}

// === MONITORING RAM ===
async function updateRamPill() {
  try {
    const { freeMB, totalMB, heapMB } = await window.wbApi.getRam();
    const free = Number(freeMB);
    const total = Number(totalMB);
    const text = `RAM: ${free} MB wolne`;
    // Czerwony gdy < 300 MB wolnego — Kvrina ma 8 GB, tak mała rezerwa = żółty sygnał
    const cls = free < 300 ? "status-warn" : "status-info";
    setStatusPill("status-ram", text, cls);
  } catch {
    // API niedostępne w starszej wersji, ukryj pill
  }
}

function startRamMonitoring() {
  if (!window.wbApi || typeof window.wbApi.getRam !== "function") return;
  updateRamPill(); // natychmiast przy starcie
  setInterval(updateRamPill, 30_000); // co 30 sekund
}


function formatPLN(amount) {
  const n = typeof amount === "number" ? amount : parseFloat(String(amount || "").replace(",", "."));
  const v = Number.isFinite(n) ? n : 0;
  // polski format: 1 234,56
  const parts = v.toFixed(2).split(".");
  const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${intPart},${parts[1]} zł`;
}

function updateFundsPill() {
  // pill w topbar: "Zbiórki: 0,00 zł"
  const el = document.getElementById("status-funds");
  if (!el) return;
  el.textContent = `Zbiórki: ${formatPLN(fundsTotal)}`;
  el.classList.remove("status-ok", "status-info", "status-warn");
  // jeśli coś wpadło – OK, jak nie – info
  el.classList.add(fundsTotal > 0 ? "status-ok" : "status-info");
}

async function persistFundsFiles() {
  try {
    if (!window.wbApi || typeof window.wbApi.writeFile !== "function") return;
    await window.wbApi.writeFile("zbiorki_total.txt", `ZBIÓRKI: ${formatPLN(fundsTotal)}\n`);
    await window.wbApi.writeFile("zbiorki_state.json", JSON.stringify({ total: fundsTotal, byGoal: fundsByGoal, savedAt: Date.now() }, null, 2));
  } catch {
    // ignore
  }
}

function parseAmountPLN(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const raw = String(value ?? "").replace(/\s+/g, "").replace("zł", "").replace("PLN", "").replace(",", ".");
  const n = parseFloat(raw);
  return Number.isFinite(n) ? n : 0;
}

function applyFundDonation(payload = {}) {
  try {
    const amount = Math.max(0, parseAmountPLN(payload.amount ?? payload.value ?? payload.total));
    if (!amount) return;
    const goal = String(payload.goal || payload.label || payload.title || "Zbiórka").trim() || "Zbiórka";
    const payer = String(payload.payer || payload.nick || payload.name || "Anon").trim() || "Anon";

    fundsTotal = Math.round((fundsTotal + amount) * 100) / 100;
    fundsByGoal[goal] = Math.round(((parseAmountPLN(fundsByGoal[goal]) || 0) + amount) * 100) / 100;

    updateFundsPill();
    persistFundsFiles();
    appendSystem(`[ZBIÓRKA] ${payer}: ${formatPLN(amount)} → ${goal}`);
    scheduleBackup();
    scheduleWidgetStateWrite();
  } catch (e) {
    console.warn("applyFundDonation failed:", e);
  }
}


let _webhookRunning = false;
let _tiktokConnectedUsername = null;
let _liveConnState = "offline"; // "offline" | "connecting" | "connected" | "error" — do kolorów statusu

async function updateWebhookStatusNow() {
  try {
    if (!window.wbApi || typeof window.wbApi.webhookGetStatus !== "function") return;
    const st = await window.wbApi.webhookGetStatus();
    if (!st || !st.ok) return;
    const on = !!st.running;
    _webhookRunning = on;
    const hashInfo = st.hashOk ? " • hash OK" : " • hash ?";
    const txt = on ? `Webhook: ON (${st.port})${hashInfo} • pending: ${st.pending}` : "Webhook: OFF";
    setStatusPill("status-webhook", txt, on ? "status-ok" : "status-warn");
    if (st.widgetPort) setStatusPill("status-widgets", `Widgety: ON (${st.widgetPort})`, "status-ok");
  } catch {}
}

function setupWebhookStatusPolling() {
  updateWebhookStatusNow();
  if (_webhookStatusTimer) clearInterval(_webhookStatusTimer);
  _webhookStatusTimer = setInterval(updateWebhookStatusNow, 2500);
}

function setupTikfinityReconnectButton() {
  const btn = document.getElementById("btn-tikfinity-reconnect");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    // Najpierw spróbuj bezpośredniego połączenia z zapisanym nickiem TikTok
    let saved = null;
    try { saved = localStorage.getItem("kvrina_tiktok_username"); } catch {}
    if (saved && window.wbApi && typeof window.wbApi.tiktokConnect === "function") {
      setTiktokConnectBtnState("connecting");
      const r = await window.wbApi.tiktokConnect(saved);
      if (r && r.ok) return;
      setTiktokConnectBtnState("idle");
    }
    // W ostateczności spróbuj bota TikFinity
    connectTikFinity(true);
  });
}

// =========================
// Utility controls (topbar)
// =========================


const WIDGET_PREVIEW_ITEMS = [
  { id: "queue", label: "KOLEJKA", desc: "Aktualna osoba wyróżniona + wszyscy następni w dół", url: "http://127.0.0.1:8750/widget-kolejka.html" },
  { id: "ranking", label: "RANKING WIDZÓW", desc: "Punkty za komentarze, tapy, follow i share — gifty 100+ dają 3-min boost +10%", url: "http://127.0.0.1:8750/widget-ranking.html" },
  { id: "karton-dnia", label: "KARTON DNIA (losowanie)", desc: "Karta kwadratowa — ładuje się co 12-17 min, potem 30s na napisanie „karton” na czacie i losuje zwycięzcę", url: "http://127.0.0.1:8750/widget-karton-dnia.html" },
];

let _widgetsPanelSelectedUrl = WIDGET_PREVIEW_ITEMS[0].url;

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function setWidgetsCopyStatus(text, mode = "info") {
  const el = document.getElementById("widgets-copy-status");
  if (!el) return;
  el.textContent = text;
  el.classList.remove("ok", "warn");
  if (mode === "ok") el.classList.add("ok");
  if (mode === "warn") el.classList.add("warn");
}

function selectWidgetPreview(itemId) {
  const item = WIDGET_PREVIEW_ITEMS.find((x) => x.id === itemId) || WIDGET_PREVIEW_ITEMS[0];
  _widgetsPanelSelectedUrl = item.url;

  const frame = document.getElementById("widgets-preview-frame");
  const input = document.getElementById("widgets-active-url");
  const title = document.getElementById("widgets-preview-title");
  if (frame) frame.src = item.url + (item.url.includes("?") ? "&" : "?") + "previewTs=" + Date.now();
  if (input) input.value = item.url;
  if (title) title.textContent = `${item.label} — podgląd`;

  document.querySelectorAll(".widget-url-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.widgetId === item.id);
  });
}

function renderWidgetsUrlList() {
  const list = document.getElementById("widgets-url-list");
  if (!list) return;
  list.innerHTML = "";

  WIDGET_PREVIEW_ITEMS.forEach((item) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "widget-url-item";
    row.dataset.widgetId = item.id;
    row.innerHTML = `
      <span class="widget-url-main">
        <span class="widget-url-label">${escapeHtml(item.label)}</span>
        <span class="widget-url-desc">${escapeHtml(item.desc)}</span>
        <span class="widget-url-path">${escapeHtml(item.url)}</span>
      </span>
      <span class="widget-url-copy">KOPIUJ</span>
    `;

    row.addEventListener("click", async (evt) => {
      selectWidgetPreview(item.id);
      if (evt.target && evt.target.classList && evt.target.classList.contains("widget-url-copy")) {
        try {
          await window.wbApi.clipboardCopy(item.url);
          setWidgetsCopyStatus(`Skopiowano URL: ${item.label}`, "ok");
        } catch {
          setWidgetsCopyStatus("Nie udało się skopiować URL.", "warn");
        }
      }
    });

    list.appendChild(row);
  });
}

function openWidgetsPanel() {
  const modal = document.getElementById("widgets-modal");
  if (!modal) return;
  renderWidgetsUrlList();
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  selectWidgetPreview(WIDGET_PREVIEW_ITEMS[0].id);
  setWidgetsCopyStatus("Kliknij widget po lewej, żeby podejrzeć i skopiować jego adres.", "info");
}

function closeWidgetsPanel() {
  const modal = document.getElementById("widgets-modal");
  const frame = document.getElementById("widgets-preview-frame");
  if (frame) frame.src = "about:blank";
  if (!modal) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

/* ===== DIAGNOSTYKA MODAL ===== */
function openDiagModal() {
  const modal = document.getElementById("diag-modal");
  if (!modal) return;
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  loadDiagLog();
}

function closeDiagModal() {
  const modal = document.getElementById("diag-modal");
  if (!modal) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

function diagLevelClass(level) {
  return `diag-entry diag-${level}`;
}

async function loadDiagLog() {
  if (!window.wbApi || !window.wbApi.diagGetLog) return;
  const { log, fileLines, version, platform, electron, node, perf } = await window.wbApi.diagGetLog();

  const sysinfo = document.getElementById("diag-sysinfo");
  if (sysinfo) {
    const perfStr = perf ? ` · heap ${perf.heapUsedMB}MB · rss ${perf.rssMB}MB · cpu ${perf.cpuPct}% · RAM wolna ${perf.freeRamMB}/${perf.totalRamMB}MB` : "";
    sysinfo.textContent = `v${version} · ${platform} · Electron ${electron}${perfStr}`;
  }

  const box = document.getElementById("diag-log-box");
  const count = document.getElementById("diag-log-count");
  if (!box) return;

  const entries = log && log.length ? log : (fileLines || []).map(l => {
    const m = l.match(/^\[(.+?)\] \[(.+?)\] (.*)$/);
    return m ? { ts: m[1], level: m[2], msg: m[3] } : { ts: "", level: "INFO", msg: l };
  });

  if (count) count.textContent = `${entries.length} wpisów`;
  box.innerHTML = "";
  entries.forEach(e => {
    const row = document.createElement("div");
    row.className = diagLevelClass(e.level || "INFO");
    row.innerHTML = `<span class="diag-ts">${(e.ts || "").slice(11, 23)}</span><span class="diag-lvl">[${e.level}]</span> <span class="diag-msg">${escapeHtml(e.msg || "")}</span>`;
    box.appendChild(row);
  });
  box.scrollTop = box.scrollHeight;
}

function setupDiagModal() {
  const modal = document.getElementById("diag-modal");
  const btnOpen = document.getElementById("btn-diagnostyka");
  const btnClose = document.getElementById("diag-close");
  const btnRefresh = document.getElementById("diag-refresh");
  const btnClear = document.getElementById("diag-clear");
  const btnSend = document.getElementById("diag-send");

  if (btnOpen) btnOpen.addEventListener("click", openDiagModal);
  if (btnClose) btnClose.addEventListener("click", closeDiagModal);
  if (modal) modal.addEventListener("click", (e) => { if (e.target.dataset.diagClose) closeDiagModal(); });

  // Tabs
  document.querySelectorAll(".diag-tab").forEach(tab => {
    tab.addEventListener("click", () => {
      const t = tab.dataset.diagTab;
      document.querySelectorAll(".diag-tab").forEach(b => b.classList.toggle("active", b.dataset.diagTab === t));
      document.querySelectorAll(".diag-tab-content").forEach(c => c.classList.toggle("hidden", c.id !== `diag-tab-${t}`));
    });
  });

  if (btnRefresh) btnRefresh.addEventListener("click", loadDiagLog);

  if (btnClear) {
    btnClear.addEventListener("click", async () => {
      if (!window.wbApi || !window.wbApi.diagClearLog) return;
      await window.wbApi.diagClearLog();
      loadDiagLog();
    });
  }

  // Typ raportu
  document.querySelectorAll(".diag-type-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diag-type-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  if (btnSend) {
    btnSend.addEventListener("click", async () => {
      const text = (document.getElementById("diag-report-text")?.value || "").trim();
      const activeType = document.querySelector(".diag-type-btn.active");
      const rtype = activeType ? activeType.dataset.rtype : "raport";
      const status = document.getElementById("diag-report-status");

      if (!window.wbApi || !window.wbApi.diagSendReport) return;
      if (status) { status.textContent = "Wysyłam…"; status.className = "diag-report-status"; }
      btnSend.disabled = true;

      const result = await window.wbApi.diagSendReport({ message: text, type: rtype });

      btnSend.disabled = false;
      if (result.ok) {
        if (status) { status.textContent = `✓ Wysłano! Issue #${result.number}`; status.className = "diag-report-status ok"; }
        document.getElementById("diag-report-text").value = "";
      } else {
        if (status) { status.textContent = `✗ Błąd: ${result.error || "nieznany"}`; status.className = "diag-report-status err"; }
      }
    });
  }

  // ---- RAPORTY TAB ----
  let _currentReportState = "open";
  let _currentIssueNumber = null;

  async function loadReports() {
    if (!window.wbApi || !window.wbApi.diagGetReports) return;
    const list = document.getElementById("diag-reports-list");
    if (!list) return;
    list.innerHTML = `<div class="diag-reports-empty">Ładuję…</div>`;
    const result = await window.wbApi.diagGetReports({ state: _currentReportState });
    list.innerHTML = "";
    if (!result.ok || !result.issues || !result.issues.length) {
      list.innerHTML = `<div class="diag-reports-empty">Brak raportów (${_currentReportState}).</div>`;
      return;
    }
    result.issues.forEach(issue => {
      const item = document.createElement("div");
      item.className = "diag-report-item";
      const date = new Date(issue.created_at).toLocaleString("pl-PL", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
      const labels = (issue.labels || []).map(l =>
        `<span class="diag-report-label lbl-${l.name}">${escapeHtml(l.name)}</span>`
      ).join("");
      item.innerHTML = `
        <div class="diag-report-item-head">
          <span class="diag-report-num">#${issue.number}</span>
          <span class="diag-report-title">${escapeHtml(issue.title)}</span>
          <span class="diag-report-date">${date}</span>
        </div>
        <div class="diag-report-labels">${labels}</div>`;
      item.addEventListener("click", () => showReportDetail(issue));
      list.appendChild(item);
    });
  }

  function showReportDetail(issue) {
    _currentIssueNumber = issue.number;
    document.getElementById("diag-reports-list").classList.add("hidden");
    const detail = document.getElementById("diag-report-detail");
    detail.classList.remove("hidden");
    document.getElementById("diag-detail-title").textContent = `#${issue.number} ${issue.title}`;
    document.getElementById("diag-detail-body").textContent = issue.body || "(brak treści)";
    const closeBtn = document.getElementById("diag-detail-close-issue");
    if (closeBtn) closeBtn.style.display = issue.state === "open" ? "" : "none";
  }

  document.getElementById("diag-detail-back")?.addEventListener("click", () => {
    document.getElementById("diag-report-detail")?.classList.add("hidden");
    document.getElementById("diag-reports-list")?.classList.remove("hidden");
    _currentIssueNumber = null;
  });

  document.getElementById("diag-detail-close-issue")?.addEventListener("click", async () => {
    if (!_currentIssueNumber || !window.wbApi?.diagCloseIssue) return;
    const btn = document.getElementById("diag-detail-close-issue");
    btn.disabled = true;
    const r = await window.wbApi.diagCloseIssue({ number: _currentIssueNumber });
    btn.disabled = false;
    if (r.ok) {
      btn.style.display = "none";
      document.getElementById("diag-detail-title").textContent += " ✓ ZAMKNIĘTY";
    }
  });

  document.getElementById("diag-reports-refresh")?.addEventListener("click", loadReports);

  document.querySelectorAll(".diag-filter-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diag-filter-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      _currentReportState = btn.dataset.filter;
      document.getElementById("diag-reports-list")?.classList.remove("hidden");
      document.getElementById("diag-report-detail")?.classList.add("hidden");
      loadReports();
    });
  });

  // Auto-load raportów gdy tab aktywny
  document.querySelectorAll(".diag-tab").forEach(tab => {
    if (tab.dataset.diagTab === "reports") {
      tab.addEventListener("click", () => { if (!document.getElementById("diag-reports-list")?.children.length || document.querySelector(".diag-reports-empty")) loadReports(); });
    }
  });

  // Live log entries z main
  if (window.wbApi && window.wbApi.onDiagEntry) {
    window.wbApi.onDiagEntry((entry) => {
      const box = document.getElementById("diag-log-box");
      if (!box || document.getElementById("diag-modal")?.classList.contains("hidden")) return;
      const row = document.createElement("div");
      row.className = diagLevelClass(entry.level || "INFO");
      row.innerHTML = `<span class="diag-ts">${(entry.ts || "").slice(11, 23)}</span><span class="diag-lvl">[${entry.level}]</span> <span class="diag-msg">${escapeHtml(entry.msg || "")}</span>`;
      box.appendChild(row);
      box.scrollTop = box.scrollHeight;
      const count = document.getElementById("diag-log-count");
      if (count) count.textContent = `${box.children.length} wpisów`;
    });
  }
}

function setupWidgetsTabControls() {
  document.querySelectorAll(".widgets-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const targetTab = tab.dataset.tab;
      document.querySelectorAll(".widgets-tab").forEach((t) => t.classList.toggle("active", t.dataset.tab === targetTab));
      document.querySelectorAll(".widgets-tab-content").forEach((c) => {
        c.classList.toggle("hidden", c.id !== `widgets-tab-${targetTab}`);
      });
    });
  });
}

function setupWidgetsPanelControls() {
  const btnClose = document.getElementById("widgets-close");
  const btnCopy = document.getElementById("widgets-copy-active");
  const btnFolder = document.getElementById("widgets-open-folder");
  const btnDemo = document.getElementById("widgets-open-demo");
  const modal = document.getElementById("widgets-modal");

  if (btnClose) btnClose.addEventListener("click", closeWidgetsPanel);
  if (modal) {
    modal.addEventListener("click", (evt) => {
      if (evt.target && evt.target.dataset && evt.target.dataset.widgetsClose) closeWidgetsPanel();
    });
  }
  document.addEventListener("keydown", (evt) => {
    if (evt.key === "Escape") closeWidgetsPanel();
  });

  if (btnCopy) {
    btnCopy.addEventListener("click", async () => {
      try {
        await window.wbApi.clipboardCopy(_widgetsPanelSelectedUrl);
        setWidgetsCopyStatus("Skopiowano URL aktualnie wybranego widgetu.", "ok");
      } catch {
        setWidgetsCopyStatus("Nie udało się skopiować URL.", "warn");
      }
    });
  }

  if (btnFolder) {
    btnFolder.addEventListener("click", async () => {
      try {
        await window.wbApi.openWidgetsDir();
        setWidgetsCopyStatus("Otworzyłem folder z widgetami i plikiem adresy_widgetow.txt.", "ok");
      } catch {
        setWidgetsCopyStatus("Nie udało się otworzyć folderu widgetów.", "warn");
      }
    });
  }

  if (btnDemo) {
    btnDemo.addEventListener("click", () => selectWidgetPreview("demo"));
  }

  setupWidgetsTabControls();
}

function setupUtilityControls() {
  const btnOpen = document.getElementById("btn-open-output");
  if (btnOpen) {
    btnOpen.addEventListener("click", async () => {
      try { await window.wbApi.openOutputDir(); } catch {}
    });
  }

  setupWidgetsPanelControls();

  const btnWidgets = document.getElementById("btn-open-widgets");
  if (btnWidgets) {
    btnWidgets.addEventListener("click", openWidgetsPanel);
  }

  const btnClear = document.getElementById("btn-clear-chat");
  if (btnClear) {
    btnClear.addEventListener("click", () => {
      const box = document.getElementById("chat-box");
      if (box) box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
      _chatQueue = [];
    });
  }


}

let _tikfinityOfflineSince = null;
let _tikfinityOfflineTimer = null;
let _tikfinityUrgentTimer = null; // osobny handle żeby dało się anulować

function updateTikfinityStatusUi() {
  const banner = document.getElementById("tikfinity-offline-banner");

  if (tikfinityConnected) {
    const src = (typeof liveSource !== "undefined" && liveSource) ? liveSource : "TikTok";
    setStatusPill("status-tikfinity", `Live: ✓ ${src}`, "status-ok");
    _tikfinityOfflineSince = null;
    if (_tikfinityOfflineTimer)  { clearTimeout(_tikfinityOfflineTimer);  _tikfinityOfflineTimer = null; }
    if (_tikfinityUrgentTimer)   { clearTimeout(_tikfinityUrgentTimer);   _tikfinityUrgentTimer = null; }
    if (banner) { banner.classList.add("hidden"); banner.classList.remove("tf-urgent"); }
  } else {
    setStatusPill("status-tikfinity", "Live: offline", "status-warn");
    if (!_tikfinityOfflineSince) {
      _tikfinityOfflineSince = Date.now();
      // Pokaż banner po 10 sekundach offline
      _tikfinityOfflineTimer = setTimeout(() => {
        _tikfinityOfflineTimer = null;
        if (!tikfinityConnected && banner) banner.classList.remove("hidden");
      }, 10_000);
      // Po 60 sekundach – tryb pilny (czerwony)
      _tikfinityUrgentTimer = setTimeout(() => {
        _tikfinityUrgentTimer = null;
        if (!tikfinityConnected && banner) banner.classList.add("tf-urgent");
      }, 60_000);
    }
  }
}

function setTunnelUrlUi(webhookUrl) {
  const el = document.getElementById("tunnel-url");
  if (!el) return;
  el.textContent = `Webhook URL: ${webhookUrl || "-"}`;
}


function setupTunnelControls() {
  const btnStart = document.getElementById("btn-start-tunnel"); // stary przycisk ukryty/usunięty — obsługa zostaje awaryjnie
  const btnStop = document.getElementById("btn-stop-tunnel");   // stary przycisk ukryty/usunięty — obsługa zostaje awaryjnie
  const btnCopy = document.getElementById("btn-copy-tunnel");
  const localWebhookUrl = "http://127.0.0.1:8787/webhook";

  // Initial status
  try {
    if (window.wbApi && typeof window.wbApi.tunnelGet === "function") {
      window.wbApi.tunnelGet().then((r) => {
        if (r && r.webhookUrl) setTunnelUrlUi(r.webhookUrl);
      });
    }
  } catch {}

  if (btnStart) {
    btnStart.addEventListener("click", async () => {
      try {
        const r = await window.wbApi.tunnelStart();
        if (r && r.error) {
          appendSystem(`[WEBHOOK] ${r.error}`);
          return;
        }
        appendSystem("[WEBHOOK] Start tunelu… URL skopiuje się automatycznie, jak tylko się pojawi.");
      } catch (e) {
        appendSystem("[WEBHOOK] Nie udało się uruchomić tunelu.");
      }
    });
  }

  if (btnStop) {
    btnStop.addEventListener("click", async () => {
      try {
        await window.wbApi.tunnelStop();
        setTunnelUrlUi(null);
        appendSystem("[WEBHOOK] Tunel zatrzymany.");
      } catch {}
    });
  }

  if (btnCopy) {
    btnCopy.addEventListener("click", async () => {
      try {
        const r = await window.wbApi.tunnelGet();
        if (r && r.webhookUrl) {
          try { await window.wbApi.clipboardCopy(r.webhookUrl); } catch {}
          setTunnelUrlUi(r.webhookUrl);
          appendSystem("[WEBHOOK] Publiczny URL jest w schowku. Wklej go do Tipped.");
          return;
        }

        appendSystem("[WEBHOOK] Nie ma aktywnego publicznego tunelu — uruchamiam go automatycznie. Lokalny URL też skopiowałem awaryjnie.");
        try { await window.wbApi.clipboardCopy(localWebhookUrl); } catch {}
        setTunnelUrlUi(localWebhookUrl);
        try {
          const started = await window.wbApi.tunnelStart();
          if (started && started.error) {
            appendSystem(`[WEBHOOK] Tunel publiczny nie wystartował: ${started.error}. Lokalny webhook działa na 127.0.0.1:8787/webhook.`);
          }
        } catch {
          appendSystem("[WEBHOOK] Nie udało się uruchomić publicznego tunelu. Sprawdź cloudflared, ale lokalny webhook działa na 127.0.0.1:8787/webhook.");
        }
      } catch {}
    });
  }

  // Listen for URL from main
  try {
    if (window.wbApi && typeof window.wbApi.onTunnelUrl === "function") {
      window.wbApi.onTunnelUrl((p) => {
        if (!p || !p.webhookUrl) return;
        setTunnelUrlUi(p.webhookUrl);
        appendSystem(`[WEBHOOK] Tunel gotowy. Skopiowałem URL do schowka.`);
      });
    }
    if (window.wbApi && typeof window.wbApi.onTunnelStopped === "function") {
      window.wbApi.onTunnelStopped(() => {
        setTunnelUrlUi(null);
        appendSystem("[WEBHOOK] Tunel rozłączony.");
      });
    }
  } catch {}
}


function formatZipSize(bytes) {
  const n = Number(bytes || 0);
  if (!Number.isFinite(n) || n <= 0) return "0 MB";
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

async function refreshUpdateStatus() {
  try {
    if (!window.wbApi || typeof window.wbApi.updateCheck !== "function") return;
    const r = await window.wbApi.updateCheck();
    if (!r || !r.ok) {
      setStatusPill("status-update", "Aktualizacja: błąd", "status-warn");
      return;
    }
    const zips = Array.isArray(r.zips) ? r.zips : [];
    if (!zips.length) {
      setStatusPill("status-update", "Aktualizacja: brak ZIP", "status-info");
    } else {
      const newest = zips[0];
      setStatusPill("status-update", `Aktualizacja: ${newest.name} (${formatZipSize(newest.size)})`, "status-ok");
    }
  } catch {
    setStatusPill("status-update", "Aktualizacja: błąd", "status-warn");
  }
}

async function handleUpdateInstallResult(r) {
  if (r && r.ok) {
    setStatusPill("status-update", `Aktualizacja: zainstalowana${r.version ? " " + r.version : ""}`, "status-ok");
    const saved = r.savedTo ? ` Zapisano w aktualizacje/: ${r.savedTo}` : "";
    appendSystem(`[AKTUALIZACJE] Zainstalowano ZIP: ${r.zip}.${saved} Backup: ${r.backupDir}`);
    await refreshUpdateStatus();
    return;
  }
  if (r && r.cancelled) {
    await refreshUpdateStatus();
    return;
  }
  setStatusPill("status-update", "Aktualizacja: błąd", "status-warn");
  appendSystem(`[AKTUALIZACJE] Błąd: ${(r && r.error) || "nieznany"}`);
}

let _githubUpdateInfo = null;

function updatesModalSetStatus(text, type) {
  const el = document.getElementById("updates-status-text");
  if (!el) return;
  el.textContent = text;
  el.className = type === "ok" ? "status-ok" : type === "warn" ? "status-warn" : type === "new" ? "status-new" : "";
  setStatusPill("status-update", text, type === "ok" ? "status-ok" : type === "warn" ? "status-warn" : "status-info");
}

function setupUpdateControls() {
  const modal       = document.getElementById("updates-modal");
  const btnOpen     = document.getElementById("btn-aktualizacje");
  const btnClose    = document.getElementById("updates-close");
  const backdrop    = modal ? modal.querySelector("[data-updates-close]") : null;
  const btnCheck    = document.getElementById("btn-updates-check");
  const btnInstall  = document.getElementById("btn-updates-install");
  const btnRestore  = document.getElementById("btn-updates-restore");
  const verEl       = document.getElementById("updates-current-version");

  // Ustaw wersję w nagłówku modalu
  try {
    if (verEl && window.wbApi) {
      window.wbApi.readFile && window.wbApi.readFile("../package.json")
        .then(txt => { try { verEl.textContent = "Wersja " + JSON.parse(txt).version; } catch {} })
        .catch(() => {});
    }
  } catch {}

  // Pilot GitHub progress
  if (window.wbApi && typeof window.wbApi.onGithubProgress === "function") {
    window.wbApi.onGithubProgress((data) => {
      if (data && data.status === "downloading") updatesModalSetStatus("Pobieranie aktualizacji z GitHub…", "warn");
      if (data && data.status === "installing")  updatesModalSetStatus("Instalowanie aktualizacji…", "warn");
    });
  }

  // Otwórz / zamknij modal
  function openModal() {
    if (!modal) return;
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal() {
    if (!modal) return;
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
  }

  if (btnOpen)    btnOpen.addEventListener("click", openModal);
  if (btnClose)   btnClose.addEventListener("click", closeModal);
  if (backdrop)   backdrop.addEventListener("click", closeModal);

  // SPRAWDŹ AKTUALIZACJE
  if (btnCheck) {
    btnCheck.addEventListener("click", async () => {
      try {
        btnCheck.disabled = true;
        btnCheck.textContent = "SPRAWDZAM…";
        if (btnInstall) btnInstall.disabled = true;
        updatesModalSetStatus("Sprawdzam GitHub…", "warn");

        const r = await window.wbApi.githubCheck();

        if (r && r.available) {
          _githubUpdateInfo = r;
          if (btnInstall) btnInstall.disabled = false;
          updatesModalSetStatus(`Dostępna nowa wersja: ${r.latestVersion}  (aktualna: ${r.currentVersion})`, "new");
          appendSystem(`[AKTUALIZACJE] Nowa wersja na GitHub: ${r.latestVersion}`);
        } else if (r && !r.error) {
          _githubUpdateInfo = null;
          if (btnInstall) btnInstall.disabled = true;
          updatesModalSetStatus(`Masz najnowszą wersję (${r.currentVersion}).`, "ok");
        } else {
          updatesModalSetStatus("Błąd połączenia z GitHub. Sprawdź internet.", "warn");
        }
      } catch (e) {
        updatesModalSetStatus("Błąd sprawdzania aktualizacji.", "warn");
        appendSystem(`[AKTUALIZACJE] Błąd: ${e && e.message ? e.message : e}`);
      } finally {
        btnCheck.disabled = false;
        btnCheck.textContent = "SPRAWDŹ AKTUALIZACJE";
      }
    });
  }

  // AKTUALIZUJ
  if (btnInstall) {
    btnInstall.addEventListener("click", async () => {
      if (!_githubUpdateInfo || !_githubUpdateInfo.available) return;
      const ok = confirm(`Zainstalować wersję ${_githubUpdateInfo.latestVersion}?\n\nProgram zrobi backup i zapyta o restart.`);
      if (!ok) return;
      try {
        btnInstall.disabled = true;
        btnCheck.disabled   = true;
        updatesModalSetStatus("Pobieranie i instalowanie aktualizacji…", "warn");
        const r = await window.wbApi.githubDownloadInstall({
          downloadUrl: _githubUpdateInfo.downloadUrl,
          assetName:   _githubUpdateInfo.assetName
        });
        _githubUpdateInfo = null;
        await handleUpdateInstallResult(r);
        if (r && r.ok) updatesModalSetStatus(`Zainstalowano wersję ${r.version || ""}. Restart zaraz.`, "ok");
      } catch (e) {
        updatesModalSetStatus("Błąd instalacji aktualizacji.", "warn");
        appendSystem(`[AKTUALIZACJE] Błąd: ${e && e.message ? e.message : e}`);
        btnInstall.disabled = false;
      } finally {
        btnCheck.disabled = false;
      }
    });
  }

  // POPRZEDNIA WERSJA
  if (btnRestore) {
    btnRestore.addEventListener("click", async () => {
      try {
        updatesModalSetStatus("Przywracanie poprzedniej wersji…", "warn");
        const r = await window.wbApi.updateRestorePrevious();
        if (r && r.ok) {
          updatesModalSetStatus(`Przywrócono wersję ${r.version || "poprzednią"}.`, "ok");
          appendSystem(`[AKTUALIZACJE] Przywrócono z backupu: ${r.restoredFrom}`);
        } else if (r && r.cancelled) {
          updatesModalSetStatus("Anulowano.", "");
        } else {
          updatesModalSetStatus(`Błąd: ${(r && r.error) || "brak backupu do przywrócenia"}.`, "warn");
        }
      } catch (e) {
        updatesModalSetStatus("Błąd cofania wersji.", "warn");
        appendSystem(`[AKTUALIZACJE] Błąd cofania: ${e && e.message ? e.message : e}`);
      }
    });
  }
}

/* ====== TRYB DEMO LIVE ====== */

function demoPick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function updateDemoStatusUi() {
  setStatusPill("status-demo", demoModeActive ? "Demo: LIVE" : "Demo: OFF", demoModeActive ? "status-ok" : "status-info");
  if (document.body) document.body.classList.toggle("demo-mode", !!demoModeActive);
  const btn = document.getElementById("btn-toggle-demo");
  if (btn) {
    btn.textContent = demoModeActive ? "WYJDŹ Z DEMO" : "DEMO LIVE";
    btn.classList.toggle("red", !!demoModeActive);
    btn.classList.toggle("green", !demoModeActive);
  }
}

function setupDemoControls() {
  const btnToggle = document.getElementById("btn-toggle-demo");
  const btnStart = document.getElementById("btn-start-demo"); // stare ID awaryjnie
  const btnStop = document.getElementById("btn-stop-demo");   // stare ID awaryjnie
  const btnReset = document.getElementById("btn-reset-demo"); // stare ID awaryjnie
  const btnResetSession = document.getElementById("btn-reset-session");

  updateDemoStatusUi();

  if (btnToggle) {
    btnToggle.addEventListener("click", async () => {
      if (demoModeActive) {
        stopDemoMode();
        await resetWholeSession(false, "[DEMO] Wyjście z demo — sesja demo wyczyszczona do zera.");
      } else {
        startDemoMode();
      }
    });
  }
  if (btnResetSession) btnResetSession.addEventListener("click", () => resetWholeSession(true));
  if (btnStart) btnStart.addEventListener("click", () => startDemoMode());
  if (btnStop) btnStop.addEventListener("click", async () => { stopDemoMode(); await resetWholeSession(false, "[DEMO] Stop demo — sesja demo wyczyszczona."); });
  if (btnReset) btnReset.addEventListener("click", () => resetDemoMode());
}

function startDemoMode() {
  if (demoModeActive) return;
  demoModeActive = true;
  demoTick = 0;
  updateDemoStatusUi();

  appendSystem("[DEMO] Start symulacji live: obserwacje, gifty, tapy/like, pytania, zbiórki i losowanie Kartona Dnia. Ranking tapów w widgetach przełącza się na demo.");
  scheduleWidgetStateWrite();

  if (!hasSessionData() && !followQueue.length) {
    seedDemoLive();
  }

  // Przełącz cykl Kartona Dnia na przyspieszone tempo demo (patrz KARTON_DEMO_* wyżej).
  startNewKartonCharge();

  demoInterval = setInterval(runDemoTick, 1250);
}

function stopDemoMode() {
  if (demoInterval) {
    clearInterval(demoInterval);
    demoInterval = null;
  }
  if (demoModeActive) appendSystem("[DEMO] Stop symulacji live.");
  demoModeActive = false;
  updateDemoStatusUi();
  scheduleWidgetStateWrite();
}

function resetDemoMode() {
  stopDemoMode();

  followQueue = [];
  followQueueKeys = new Set();
  saveFollowQueue();
  renderFollowQueue();

  tiktokViewerCount = 0;
  updateQuestionStats();

  const box = document.getElementById("chat-box");
  if (box) box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
  _chatQueue = [];

  resetSessionToEmpty();
  appendSystem("[DEMO] Reset danych demo. Możesz odpalić DEMO LIVE od nowa.");
  scheduleWidgetStateWrite();
}

function seedDemoLive() {
  tiktokViewerCount = 32 + Math.floor(Math.random() * 18);
  updateQuestionStats();

  ["Wiedźma Basia", "Kasia Tarot", "Luna", "Marta", "Njut"].forEach((nick, idx) => {
    addRankingPoints(nick, 40 + idx * 12 + Math.floor(Math.random() * 30), "demo");
  });

  ["Karolina", "Ola", "Monika"].forEach((nick) => addFollowerToQueue(nick, "follow"));
  simulateDemoGift(true);
  simulateDemoGift(false);

  insertQuestionSorted({ ts: Date.now(), nick: "Luna", question: "Czy w tym tygodniu pojawi się przełom?", source: "demo" });
  insertQuestionSorted({ ts: Date.now() + 1, nick: "Marta", question: "x", source: "demo" });
  insertQuestionSorted({ ts: Date.now() + 2, nick: "Kasia Tarot", question: "Co on ukrywa w tej relacji?", source: "demo" });
  insertQuestionSorted({ ts: Date.now() + 3, nick: "Wiedźma Basia", question: KARTON_DNIA_TEXT, source: "demo", kind: KARTON_DNIA_KIND });

  applyFundDonation({ amount: 25, goal: "Świece i talizmany", payer: "Demo Darczyńca" });
}

function runDemoTick() {
  if (!demoModeActive) return;
  demoTick += 1;

  const base = tiktokViewerCount || 25;
  const delta = Math.floor(Math.random() * 11) - 4;
  tiktokViewerCount = Math.max(3, Math.min(320, base + delta));
  updateQuestionStats();

  const nick = demoPick(DEMO_NICKS);
  addRankingPoints(nick, 1 + Math.floor(Math.random() * 35), "demo-like");

  // Pełna emulacja losowania Kartona Dnia: gdy trwa okno zbierania, symulujemy widzów
  // piszących "karton" na czacie, żeby po zakończeniu okna było kogo wylosować.
  if (_kartonCollectionActive && Math.random() < 0.55) {
    const writerNick = demoPick(DEMO_NICKS);
    const key = getFollowKey(writerNick);
    if (key && !_kartonCollectionWriters.has(key)) _kartonCollectionWriters.set(key, writerNick);
  }

  const roll = Math.random();
  if (roll < 0.20) {
    addFollowerToQueue(demoPick(DEMO_NICKS), "follow");
  } else if (roll < 0.43) {
    simulateDemoGift(Math.random() < 0.34);
  } else if (roll < 0.62) {
    simulateDemoQuestion();
  } else if (roll < 0.69) {
    simulateDemoKarton();
  } else if (roll < 0.78) {
    simulateDemoFund();
  }

  if (demoTick % 20 === 0) {
    appendSystem(`[DEMO] Działa — widzowie: ${tiktokViewerCount}, kolejka: ${questions.length}, kandydaci: ${followQueue.length}.`);
  }
}

function simulateDemoGift(forceBig = false) {
  const gift = forceBig ? demoPick(DEMO_GIFTS.filter((g) => g.amount >= 450)) : demoPick(DEMO_GIFTS);
  const username = demoPick(DEMO_NICKS);
  const amount = Number(gift.amount) || 1;

  if (amount > 1) onTikfinityGift(username, amount, gift.name);
  if (amount >= 450) addGiftCandidateToFollowQueue(username, amount, gift.name);

  appendGiftBoardItem({
    username,
    giftName: gift.name,
    amount,
    giftImageUrl: null,
    avatarUrl: null,
    repeatCount: Math.random() < 0.18 ? 2 + Math.floor(Math.random() * 4) : 1,
  });
}

function simulateDemoQuestion() {
  addIncomingAutoQuestion({
    ts: Date.now(),
    nick: demoPick(DEMO_NICKS),
    question: demoPick(DEMO_QUESTIONS),
    source: "demo_tipped",
    questionCount: Math.random() < 0.16 ? 2 : 1,
  });
}

function simulateDemoKarton() {
  insertQuestionSmart({
    ts: Date.now(),
    nick: demoPick(DEMO_NICKS),
    question: KARTON_DNIA_TEXT,
    source: "demo_karton",
    kind: KARTON_DNIA_KIND,
  });
  scheduleWidgetStateWrite();
}

function simulateDemoFund() {
  const amounts = [5, 10, 15, 20, 30, 50];
  const goals = ["Świece i talizmany", "Wsparcie live", "Nowe karty", "Studio KVRINA"];
  applyFundDonation({
    amount: demoPick(amounts),
    goal: demoPick(goals),
    payer: demoPick(DEMO_NICKS),
  });
}

/* ====== FONT SIZES ====== */

function applyFontSizes() {
  document.documentElement.style.setProperty("--chat-font-size", `${chatFontSize}px`);
  document.documentElement.style.setProperty("--question-font-size", `${questionFontSize}px`);
  document.documentElement.style.setProperty("--queue-font-size", `${queueFontSize}px`);
  document.documentElement.style.setProperty("--question-queue-font-size", `${questionQueueFontSize}px`);
}

function applyChatVisibility() {
  const body = document.body;
  if (!body) return;
  if (chatVisible) body.classList.remove("chat-hidden");
  else body.classList.add("chat-hidden");
}

function setupChatToggle() {
  const btn = document.getElementById("btn-toggle-chat");
  const btnPop = document.getElementById("btn-popout-chat");
  if (btn) {
    btn.addEventListener("click", () => {
      chatVisible = !chatVisible;
      applyChatVisibility();
      savePrefs();
    });
  }
  if (btnPop) {
    btnPop.addEventListener("click", async () => {
      try {
        if (window.wbApi?.openChatWindow) {
          await window.wbApi.openChatWindow();
        }
      } catch (e) {
        console.error("openChatWindow failed:", e);
      }
    });
  }
}

/* ====== CHAT ====== */

const chatBoxEl = () => document.getElementById("chat-box");

function setupChat() {
  const plus = document.getElementById("chat-font-plus");
  const minus = document.getElementById("chat-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      chatFontSize = Math.min(chatFontSize + 2, 64);
      applyFontSizes();
      savePrefs();
    });
  }

  if (minus) {
    minus.addEventListener("click", () => {
      chatFontSize = Math.max(chatFontSize - 2, 8);
      applyFontSizes();
      savePrefs();
    });
  }
}

function appendSystem(text) {
  const box = document.getElementById("chat-box");
  if (!box) return;
  const line = document.createElement("div");
  line.className = "chat-line chat-system";
  line.textContent = `[SYSTEM] ${text}`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}

// RUBRYCZKA GIFTÓW Z TIKTOKA
function _pickFirstUrl(...values) {
  for (const v of values) {
    if (typeof v === "string" && /^https?:\/\//i.test(v.trim())) return v.trim();
    if (Array.isArray(v)) {
      const found = _pickFirstUrl(...v);
      if (found) return found;
    }
  }
  return null;
}

function _findLikelyImageUrl(obj, depth = 0) {
  if (!obj || typeof obj !== "object" || depth > 4) return null;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = _findLikelyImageUrl(item, depth + 1);
      if (found) return found;
    }
    return null;
  }

  const priorityKeys = [
    "giftPictureUrl", "giftImageUrl", "giftIconUrl", "giftPicture", "giftImage", "giftIcon",
    "imageUrl", "pictureUrl", "iconUrl", "thumbnailUrl", "url", "src"
  ];
  for (const key of priorityKeys) {
    const v = obj[key];
    const found = _pickFirstUrl(v);
    if (found) return found;
    if (v && typeof v === "object") {
      const nested = _findLikelyImageUrl(v, depth + 1);
      if (nested) return nested;
    }
  }

  // awaryjnie: szukaj po kluczach z image/icon/picture/url, ale nie bierz avatarów użytkownika jako giftu
  for (const [key, value] of Object.entries(obj)) {
    const k = String(key).toLowerCase();
    if (k.includes("avatar") || k.includes("profile")) continue;
    if (k.includes("image") || k.includes("icon") || k.includes("picture") || k.includes("thumb")) {
      const found = _pickFirstUrl(value) || _findLikelyImageUrl(value, depth + 1);
      if (found) return found;
    }
  }
  return null;
}

function getTikTokAvatarUrl(payload) {
  return _pickFirstUrl(
    payload && payload.profilePictureUrl,
    payload && payload.profile_image,
    payload && payload.avatarUrl,
    payload && payload.user && payload.user.avatarThumb,
    payload && payload.user && payload.user.avatarLarger,
    payload && payload.user && payload.user.profilePictureUrl
  );
}

function getTikTokGiftImageUrl(payload) {
  if (!payload) return null;
  return _pickFirstUrl(
    payload.giftPictureUrl,
    payload.giftImageUrl,
    payload.giftIconUrl,
    payload.giftPicture,
    payload.giftImage,
    payload.giftIcon,
    payload.imageUrl,
    payload.iconUrl,
    payload.pictureUrl,
    payload.gift && payload.gift.pictureUrl,
    payload.gift && payload.gift.imageUrl,
    payload.gift && payload.gift.iconUrl,
    payload.gift && payload.gift.image && payload.gift.image.url,
    payload.gift && payload.gift.image && payload.gift.image.urls,
    payload.gift && payload.gift.icon && payload.gift.icon.url,
    payload.giftDetails && payload.giftDetails.imageUrl,
    payload.giftDetails && payload.giftDetails.iconUrl
  ) || _findLikelyImageUrl(payload.gift || payload.giftDetails || payload);
}

function getTikTokGiftRepeat(payload) {
  const raw =
    payload.repeatCount ??
    payload.repeat_count ??
    payload.comboCount ??
    payload.combo_count ??
    payload.giftCount ??
    payload.gift_count ??
    payload.count ??
    (payload.gift && (payload.gift.repeatCount ?? payload.gift.count));
  const n = parseInt(raw || 0, 10);
  return Number.isFinite(n) && n > 1 ? n : 1;
}

function appendChatLine() {
  // Czat tekstowy jest celowo wyłączony w głównym panelu.
  // Lewa kolumna działa teraz jako rubryczka giftów TikToka.
}

function appendGiftBoardItem({ username, giftName, amount, giftImageUrl, avatarUrl, repeatCount }) {
  try {
    const now = new Date();
    const ts = now.toTimeString().slice(0, 8);
    window.wbApi?.sendChatLine?.({
      kind: "gift-board",
      username,
      giftName,
      amount,
      giftImageUrl,
      avatarUrl,
      repeatCount,
      ts,
    });
  } catch {}

  _chatQueue.push({
    kind: "gift-board",
    username,
    giftName,
    amount,
    giftImageUrl,
    avatarUrl,
    repeatCount: repeatCount || 1,
    ts: Date.now(),
  });
  if (_chatFlushTimer) return;

  _chatFlushTimer = setTimeout(() => {
    _chatFlushTimer = null;
    flushChatQueue();
  }, CHAT_FLUSH_MS);
}

function flushChatQueue() {
  const box = document.getElementById("chat-box");
  if (!box) { _chatQueue = []; return; }
  if (!_chatQueue.length) return;

  const threshold = 12;
  const pinned = (box.scrollHeight - box.scrollTop - box.clientHeight) <= threshold;
  const empty = box.querySelector(".gift-board-empty");
  if (empty) empty.remove();

  const frag = document.createDocumentFragment();

  for (const item of _chatQueue) {
    if (!item || item.kind !== "gift-board") continue;

    const line = document.createElement("div");
    line.className = "gift-board-line";
    if ((parseInt(item.amount || 0, 10) || 0) >= giftCredit) line.classList.add("gift-board-big");

    const media = document.createElement("div");
    media.className = "gift-board-media";

    if (item.giftImageUrl) {
      const giftImg = document.createElement("img");
      giftImg.className = "gift-board-icon";
      giftImg.src = item.giftImageUrl;
      giftImg.alt = item.giftName || "gift";
      giftImg.addEventListener("load", () => {
        if (!pinned) return;
        requestAnimationFrame(() => requestAnimationFrame(() => { box.scrollTop = box.scrollHeight; }));
      });
      media.appendChild(giftImg);
    } else {
      const fallback = document.createElement("div");
      fallback.className = "gift-board-icon gift-board-icon-fallback";
      fallback.textContent = "🎁";
      media.appendChild(fallback);
    }

    if (item.avatarUrl) {
      const avatar = document.createElement("img");
      avatar.className = "gift-board-avatar";
      avatar.src = item.avatarUrl;
      avatar.alt = "";
      media.appendChild(avatar);
    }

    const content = document.createElement("div");
    content.className = "gift-board-content";

    const top = document.createElement("div");
    top.className = "gift-board-top";

    const user = document.createElement("span");
    user.className = "gift-board-user";
    user.textContent = item.username || "TikTok";
    const userColor = getUserColor(item.username || "");
    if (userColor) user.style.color = userColor;

    const time = document.createElement("span");
    time.className = "gift-board-time";
    time.textContent = new Date(item.ts).toTimeString().slice(0, 8);

    top.appendChild(user);
    top.appendChild(time);

    const name = document.createElement("div");
    name.className = "gift-board-name";
    name.textContent = item.giftName || "prezent";

    const meta = document.createElement("div");
    meta.className = "gift-board-meta";
    const amount = parseInt(item.amount || 0, 10) || 0;
    const repeat = parseInt(item.repeatCount || 1, 10) || 1;
    meta.textContent = `${amount} monet${repeat > 1 ? ` • x${repeat}` : ""}`;

    content.appendChild(top);
    content.appendChild(name);
    content.appendChild(meta);

    line.appendChild(media);
    line.appendChild(content);
    frag.appendChild(line);
  }

  _chatQueue = [];
  box.appendChild(frag);

  while (box.children.length > MAX_MAIN_CHAT_LINES) {
    box.removeChild(box.firstChild);
  }

  if (pinned) {
    requestAnimationFrame(() => requestAnimationFrame(() => { box.scrollTop = box.scrollHeight; }));
  }
}


/* ====== WIDGETY HTML / TikTok Studio Browser Source ====== */

function entryTypeForWidget(entry) {
  if (!entry) return "empty";
  if (entry.kind === "shortfall") return "shortfall";
  if (isKartonDniaEntry(entry)) return "karton";
  const q = String(entry.question || "").trim().toLowerCase();
  if (!q || q === "x") return "waiting";
  return "question";
}

function entryTitleForWidget(entry) {
  const type = entryTypeForWidget(entry);
  if (type === "shortfall") return "DOPŁATA";
  if (type === "karton") return "KARTON DNIA";
  if (type === "waiting") return "CZEKAM NA PYTANIE";
  if (type === "empty") return "PYTANIE DO KART";
  return "PYTANIE DO KART";
}

function entryTextForWidget(entry) {
  const type = entryTypeForWidget(entry);
  if (type === "karton") return "KARTON DNIA";
  if (type === "waiting") return "CZEKAM NA PYTANIE";
  if (!entry) return "LINK W BIO";
  return String(entry.question || "").trim() || "LINK W BIO";
}

function getRankingArrayForWidget() {
  // Punkty wewnętrznie liczone jako float (np. tapy: 5 = 1pkt) — zaokrąglamy
  // dopiero tutaj, w jedynym miejscu skąd korzysta panel, widget i widget_state.json.
  const arr = Array.from(predictionRanking.entries()).map(([nick, pts]) => ({
    nick,
    likes: Math.round(Number(pts) || 0),
    points: Math.round(Number(pts) || 0),
  }));
  arr.sort((a, b) => b.likes - a.likes || String(a.nick).localeCompare(String(b.nick), "pl"));
  return arr.slice(0, 20);
}

function updateRankingPreviewCount(count) {
  const el = document.getElementById("ranking-preview-count");
  if (!el) return;
  if (count === 1) el.textContent = "1 osoba";
  else el.textContent = `${count} osób`;
}

function renderRankingPreviewPanel() {
  if (shouldSkipHeavyRender()) return;
  const list = document.getElementById("ranking-preview-list");
  if (!list) return;

  const ranking = getRankingArrayForWidget().slice(0, 8);
  list.innerHTML = "";
  updateRankingPreviewCount(ranking.length);

  if (!ranking.length) {
    const empty = document.createElement("div");
    empty.className = "ranking-preview-empty";
    empty.textContent = "Czekam na komentarze, tapy, followy i share…";
    list.appendChild(empty);
    return;
  }

  ranking.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "ranking-preview-item";

    const place = document.createElement("div");
    place.className = "ranking-preview-place";
    place.textContent = `#${idx + 1}`;

    const main = document.createElement("div");
    main.className = "ranking-preview-main";

    const nick = document.createElement("div");
    nick.className = "ranking-preview-nick";
    nick.textContent = String(item.nick || "-");

    const likes = document.createElement("div");
    likes.className = "ranking-preview-likes";
    likes.textContent = `♥ ${Number(item.likes || item.points || 0) || 0} pkt`;

    main.appendChild(nick);
    main.appendChild(likes);

    const add = document.createElement("button");
    add.type = "button";
    add.className = "ranking-preview-add";
    add.textContent = "DODAJ";
    add.title = `Dodaj ${item.nick} do kolejki pytań`;
    add.addEventListener("click", () => addRankingUserToQuestionQueue(item.nick));

    row.appendChild(place);
    row.appendChild(main);
    row.appendChild(add);
    list.appendChild(row);
  });
}

function addRankingUserToQuestionQueue(username) {
  const nick = String(username || "").trim();
  if (!nick) return;
  insertQuestionSorted({
    ts: Date.now(),
    nick,
    question: "x",
    source: "ranking_taps",
  });
  scheduleWidgetStateWrite();
}

function setupRankingPreviewPanel() {
  renderRankingPreviewPanel();
}

function buildWidgetState() {
  const current = (!noQuestionsMode && questions.length && questions[questionIndex]) ? questions[questionIndex] : null;
  const queueStart = current ? questionIndex + 1 : getQuestionQueueStartIndex();
  const queue = questions.slice(Math.max(0, queueStart)).map((q, i) => ({
    position: i + 1,
    ts: typeof q.ts === "number" ? q.ts : null, // stabilny identyfikator do zdalnej edycji/przesuwania z okienka
    nick: String(q.nick || "-"),
    text: entryTextForWidget(q),
    title: entryTitleForWidget(q),
    type: entryTypeForWidget(q),
    source: q.source || null,
  }));

  return {
    updatedAt: Date.now(),
    current: current ? {
      ts: typeof current.ts === "number" ? current.ts : null,
      nick: String(current.nick || "-"),
      title: entryTitleForWidget(current),
      text: entryTextForWidget(current),
      type: entryTypeForWidget(current),
      source: current.source || null,
    } : {
      nick: "PYTANIE DO KART",
      title: "PYTANIE DO KART",
      text: "LINK W BIO",
      type: "empty",
    },
    queue,
    ranking: getRankingArrayForWidget(),
    tikfinityTopLikerUrl: "https://tikfinity.zerody.one/widget/topliker?cid=3197633",
    tikfinityActivityFeedUrl: "https://tikfinity.zerody.one/widget/activity-feed?cid=3197633&did=1",
    demoMode: !!demoModeActive,
    theme: "fire-gold-web",
    liveConnected: !!tikfinityConnected,
    liveState: _liveConnState,
    liveSource: (typeof liveSource !== "undefined" && liveSource) ? liveSource : null,
    tiktokUsername: (typeof _tiktokConnectedUsername !== "undefined" && _tiktokConnectedUsername) ? _tiktokConnectedUsername : null,
    webhookRunning: (typeof _webhookRunning !== "undefined") ? !!_webhookRunning : false,
    viewerCount: Number(tiktokViewerCount) || 0,
    fundsTotal: Number(fundsTotal) || 0,
    fundsByGoal: fundsByGoal || {},
    followQueue: followQueue.map((item) => ({
      ts: typeof item.ts === "number" ? item.ts : null,
      nick: String(item.nick || "-"),
      source: item.source || null,
      giftCoins: Number(item.giftCoins || 0) || 0,
      giftName: item.giftName || "",
    })),
    kartonDraw: _lastKartonDraw ? { nick: _lastKartonDraw.nick, ts: _lastKartonDraw.ts } : null,
    // "Ładowanie" Kartona Dnia — imitacja zbierania punktów widzów (realnie: czas 12-17 min).
    kartonCharge: {
      collecting: !!_kartonCollectionActive,
      progress: _kartonCollectionActive ? 1 : Math.max(0, Math.min(1, (Date.now() - _kartonChargeStartedAt) / _kartonChargeDurationMs)),
      collectionSecondsLeft: _kartonCollectionActive ? Math.max(0, Math.ceil((_kartonCollectionEndsAt - Date.now()) / 1000)) : 0,
    },
    countdown: {
      armed: _countdownDurationMs > 0,
      started: !!_countdownStarted,
      durationMs: _countdownDurationMs,
      endsAt: _countdownEndsAt,
      remainingMs: (_countdownStarted && _countdownEndsAt) ? Math.max(0, _countdownEndsAt - Date.now()) : _countdownDurationMs,
      top1Fired: !!_countdownTop1Fired,
      top1Nick: _countdownTop1Nick || null,
      top1FiredAt: _countdownTop1FiredAt || null,
    },
  };
}

let _widgetWriteTimer = null;
let _lastWidgetStateJson = "";
async function writeWidgetStateNow() {
  try {
    if (!outputDir || !window.wbApi || !window.wbApi.writeFile) return;
    const state = buildWidgetState();
    // updatedAt zmienia się przy każdym budowaniu — porównujemy bez niego,
    // żeby nie zapisywać na dysk (i nie budzić wszystkich widgetów) gdy realnie nic się nie zmieniło.
    const { updatedAt, ...comparable } = state;
    const sig = JSON.stringify(comparable);
    if (sig === _lastWidgetStateJson) return;
    _lastWidgetStateJson = sig;
    await window.wbApi.writeFile("widgety/widget_state.json", JSON.stringify(state, null, 2));
  } catch (e) {
    console.warn("writeWidgetStateNow failed:", e);
  }
}

function scheduleWidgetStateWrite() {
  if (_widgetWriteTimer) return;
  _widgetWriteTimer = setTimeout(async () => {
    _widgetWriteTimer = null;
    await writeWidgetStateNow();
  }, 180);
}

function setupWidgetStatePublishing() {
  scheduleWidgetStateWrite();
  setInterval(() => { scheduleWidgetStateWrite(); }, 1200);

  const statusWidgets = document.getElementById("status-widgets");
  if (statusWidgets) statusWidgets.textContent = "Widgety: :8750";
}

// Na dużym live ranking rósł bez ograniczeń (każdy komentujący widz = trwały wpis),
// a całość trafiała do backupu — po kilku godzinach potrafiło to zjeść sporo RAM-u
// na słabszych maszynach. Widget i tak pokazuje tylko czołówkę, więc trzymamy zapas
// i okazjonalnie przycinamy do najlepszych.
const RANKING_MAX_ENTRIES = 2000;
const RANKING_KEEP_ENTRIES = 1000;

function trimRankingIfNeeded() {
  if (predictionRanking.size <= RANKING_MAX_ENTRIES) return;
  const top = Array.from(predictionRanking.entries())
    .sort((a, b) => (Number(b[1]) || 0) - (Number(a[1]) || 0))
    .slice(0, RANKING_KEEP_ENTRIES);
  predictionRanking = new Map(top);
}

function addRankingPoints(username, points, label) {
  const nick = String(username || "").trim();
  const pts = Number(points) || 0;
  if (!nick || !pts) return;
  const prev = Number(predictionRanking.get(nick) || 0) || 0;
  predictionRanking.set(nick, prev + pts);
  trimRankingIfNeeded();
  predictionEventsFeed.unshift({ ts: Date.now(), nick, points: pts, label: label || "like" });
  predictionEventsFeed = predictionEventsFeed.slice(0, 50);
  renderRankingPreviewPanel();
  scheduleBackup();
  scheduleWidgetStateWrite();
}

// === RANKING WIDZÓW — punkty zasięgowe (komentarz/tap/follow/share) + boost od giftów ===
// Gift ≥100 monet daje widzowi +10% do zdobywanych punktów przez 3 minuty (nie stackuje się —
// kolejny kwalifikujący się gift tylko ODŚWIEŻA czas, nigdy nie przekracza +10%).
// Skutek: trzeba wysyłać 100+ monet co ~3 min, żeby mieć ciągły boost; 200 naraz = tyle samo
// co 100 (jedno okno 3 min); 200, a po 3 min 100 = dwa osobne okna, jak 2×100 z przerwą.
const VIEWER_BOOST_MIN_GIFT_COINS = 100;
const VIEWER_BOOST_DURATION_MS = 3 * 60 * 1000;
const VIEWER_BOOST_MULTIPLIER = 1.10;
let _viewerBoostUntil = new Map(); // znormalizowany nick -> timestamp wygaśnięcia (ms)

function maybeApplyGiftBoost(username, giftCoins) {
  const coins = Number(giftCoins) || 0;
  if (coins < VIEWER_BOOST_MIN_GIFT_COINS) return;
  const key = getFollowKey(username);
  if (!key) return;
  _viewerBoostUntil.set(key, Date.now() + VIEWER_BOOST_DURATION_MS);
}

function getViewerPointMultiplier(username) {
  const key = getFollowKey(username);
  if (!key) return 1;
  const until = _viewerBoostUntil.get(key);
  if (!until) return 1;
  if (Date.now() >= until) { _viewerBoostUntil.delete(key); return 1; }
  return VIEWER_BOOST_MULTIPLIER;
}

// Wspólne wejście dla wszystkich sygnałów budujących zasięg (komentarz/tap/follow/share).
// Gifty NIE dodają punktów bezpośrednio — tylko włączają boost (patrz maybeApplyGiftBoost).
function awardViewerPoints(username, basePoints, label) {
  const mult = getViewerPointMultiplier(username);
  addRankingPoints(username, basePoints * mult, label);
}

function getChatText(payload) {
  if (!payload) return "";
  const candidates = [payload.comment, payload.content, payload.message, payload.text];
  for (const v of candidates) {
    if (typeof v === "string" && v.trim()) return v.trim();
  }
  return "";
}

function getTikFinityLikeDelta(payload) {
  if (!payload) return 1;
  const candidates = [
    payload.likeCount,
    payload.likes,
    payload.count,
    payload.amount,
    payload.repeatCount,
    payload.delta,
    payload.value,
  ];
  for (const v of candidates) {
    const n = Number(v);
    if (Number.isFinite(n) && n > 0 && n < 1000000) return n;
  }
  return 1;
}

function handleTikFinityLikeEvent(payload) {
  const username = getTikTokNickname(payload);
  const delta = getTikFinityLikeDelta(payload);
  // Wagi zasięgowe: 5 tapów = 1 punkt (tapy są tanie/częste, waga niska).
  awardViewerPoints(username, delta / 5, "tap");
}

function handleTikFinityRankingEvent(ev, payload) {
  const name = String(ev || "").toLowerCase();

  // Jeśli TikFinity/strona wyśle gotową tablicę rankingu, bierzemy ją 1:1.
  const ranking = payload && (payload.ranking || payload.rankings || payload.leaderboard || payload.scores);
  if (Array.isArray(ranking)) {
    predictionRanking = new Map();
    ranking.forEach((row) => {
      const nick = String((row && (row.nickname || row.displayName || row.username || row.user || row.name)) || "").trim();
      const pts = Number(row && (row.likes ?? row.likeCount ?? row.points ?? row.score ?? row.value ?? row.correct ?? 0)) || 0;
      if (nick) predictionRanking.set(nick, pts);
    });
    renderRankingPreviewPanel();
    scheduleBackup();
    scheduleWidgetStateWrite();
    return;
  }

  // Elastyczne wykrywanie eventów typowania/punktacji.
  const looksLikePrediction = /predict|prediction|typ|guess|score|points|ranking|leaderboard|vote/i.test(name) ||
    (payload && /predict|prediction|typ|guess|score|points|ranking|leaderboard|vote/i.test(String(payload.type || payload.event || payload.action || "")));
  if (!looksLikePrediction) return;

  const username = getTikTokNickname(payload);
  const rawPts = payload && (payload.points ?? payload.score ?? payload.value ?? payload.correctPoints ?? payload.delta ?? payload.amount);
  let points = Number(rawPts);
  if (!Number.isFinite(points) || points === 0) {
    // jeśli event oznacza poprawny typ, dajemy 1 punkt
    const correct = payload && (payload.correct === true || payload.isCorrect === true || String(payload.result || "").toLowerCase() === "correct");
    points = correct ? 1 : 0;
  }
  if (points) addRankingPoints(username, points, payload && (payload.label || payload.choice || payload.answer));
}

/* ====== TIKTOK LIVE — obsługa eventów (wspólna dla TikFinity WS i połączenia bezpośredniego) ====== */

// Jedna funkcja obsługuje eventy niezależnie od źródła (TikFinity bot lub bezpośrednie
// połączenie z TikTokiem przez bibliotekę tiktok-live-connector).
function handleTikTokEvent(ev, payload) {
  try {
    payload = payload || {};
    handleTikFinityRankingEvent(ev, payload);

    if (ev === "like") {
      handleTikFinityLikeEvent(payload);
    } else if (ev === "roomUser" || ev === "viewer" || ev === "liveInfo") {
      const vc =
        payload.viewerCount ||
        payload.userCount ||
        payload.totalViewerCount ||
        payload.viewers ||
        payload.viewCount;
      if (vc !== undefined && vc !== null) {
        const n = parseInt(vc, 10);
        if (!Number.isNaN(n)) {
          tiktokViewerCount = n;
          updateQuestionStats();
        }
      }
    } else if (isTikFinityFollowEvent(ev, payload)) {
      const username = getTikTokNickname(payload);
      addFollowerToQueue(username);
      // Nowy follow to mocny sygnał zasięgowy — konwersja widza na stałego obserwującego.
      awardViewerPoints(username, 30, "follow");
    } else if (ev === "share") {
      // Udostępnienie live to najsilniejszy sygnał zasięgowy (wychodzi poza obserwujących).
      const username = getTikTokNickname(payload);
      awardViewerPoints(username, 50, "share");
    } else if (ev === "chat") {
      // Lewy panel nie pokazuje już czatu — jest rubryczką giftów, ale komentarz nadal liczy się do punktów.
      const username = getTikTokNickname(payload);
      awardViewerPoints(username, 1, "komentarz");
      // Pierwszy jakikolwiek komentarz uruchamia licznik czasu do wpisania.
      maybeStartCountdownOnComment();
      // Losowanie Kartona Dnia: TYLKO w trakcie 30s okna zbierania liczy się napisanie "karton".
      if (_kartonCollectionActive) {
        const chatText = getChatText(payload);
        if (chatText && /karton/i.test(chatText)) {
          const key = getFollowKey(username);
          if (key && !_kartonCollectionWriters.has(key)) _kartonCollectionWriters.set(key, String(username || "").trim());
        }
      }
    } else if (ev === "gift") {
      const username = getTikTokNickname(payload);
      const giftName = payload.giftName || (payload.gift && payload.gift.name) || "prezent";
      let amount = payload.diamondCount || payload.amount || payload.totalDiamonds || 0;
      amount = parseInt(amount || 0, 10);

      // rubryczka giftów pokazuje również drobne gifty; do kredytów 450+ dalej liczymy sensowne wartości > 1
      if (amount <= 0) return;
      if (amount > 1) onTikfinityGift(username, amount, giftName);
      // 699+ monet -> automatycznie prosto do kolejki pytań (bez klikania DODAJ).
      // 450-698 monet -> tak jak dziś: trafia do listy kandydatów "ZA GIFTY" (ręczne DODAJ).
      if (amount >= 699) {
        insertQuestionSorted({ ts: Date.now(), nick: username, question: "x", source: "gift699" });
      } else if (amount >= 450) {
        addGiftCandidateToFollowQueue(username, amount, giftName);
      }
      // Gifty NIE liczą się bezpośrednio do rankingu — za to ≥100 monet daje 3-minutowy boost +10%.
      maybeApplyGiftBoost(username, amount);

      const avatarUrl = getTikTokAvatarUrl(payload);
      const giftImageUrl = getTikTokGiftImageUrl(payload);
      const repeatCount = getTikTokGiftRepeat(payload);

      appendGiftBoardItem({ username, giftName, amount, giftImageUrl, avatarUrl, repeatCount });
    }
  } catch (err) {
    console.error("Błąd obsługi eventu TikTok:", err);
  }
}

/* ====== TIKFINITY (opcjonalny bot – WebSocket localhost) ====== */

function connectTikFinity(force = false) {
  try {
    // zamknij stare połączenie, jeśli ma sens
    if (tikfinityWs && (tikfinityWs.readyState === WebSocket.OPEN || tikfinityWs.readyState === WebSocket.CONNECTING)) {
      if (!force) return;
      try { tikfinityWs.close(); } catch {}
    }

    const ws = new WebSocket(TIKFINITY_WS_URL);
    tikfinityWs = ws;

    ws.onopen = () => {
      setLiveConnected(true, "TikFinity");
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        handleTikTokEvent(data.event, data.data || {});
      } catch (err) {
        console.error("Błąd parsowania eventu TikFinity:", err);
      }
    };

    ws.onerror = (err) => {
      console.error("[TikFinity WS] error:", err);
    };

    ws.onclose = () => {
      if (liveSource === "TikFinity") setLiveConnected(false, null);
      // auto-reconnect tylko jeśli nie mamy bezpośredniego połączenia z TikTokiem
      setTimeout(() => { if (!tiktokDirectConnected) connectTikFinity(false); }, 3000);
    };
  } catch (err) {
    console.error("Nie udało się utworzyć połączenia WebSocket TikFinity:", err);
  }
}

/* ====== TIKTOK BEZPOŚREDNIO (bez bota – biblioteka tiktok-live-connector w procesie main) ====== */

let tiktokDirectConnected = false;
let liveSource = null; // "TikFinity" | "TikTok" | null

// Ustawia zunifikowany stan "połączono z live" (dowolne źródło).
function setLiveConnected(connected, source) {
  if (connected) {
    liveSource = source || liveSource || "TikTok";
    tikfinityConnected = true;
  } else {
    liveSource = null;
    tikfinityConnected = false;
  }
  updateTikfinityStatusUi();
}

function setupTikTokDirectControls() {
  const btn = document.getElementById("btn-tiktok-connect");
  const input = document.getElementById("tiktok-username-input");
  if (!input) return;

  // Zapamiętany nick
  try {
    const saved = localStorage.getItem("kvrina_tiktok_username");
    if (saved) input.value = saved;
  } catch {}

  if (btn) {
    btn.addEventListener("click", async () => {
      if (tiktokDirectConnected) {
        // Rozłączenie „zapomina" nick — program przestaje się auto-łączyć.
        try { localStorage.removeItem("kvrina_tiktok_username"); } catch {}
        await window.wbApi.tiktokDisconnect();
        return;
      }
      const raw = String(input.value || "").trim().replace(/^@/, "");
      if (!raw) { input.focus(); return; }
      try { localStorage.setItem("kvrina_tiktok_username", raw); } catch {}
      setTiktokConnectBtnState("connecting");
      appendSystem(`[TIKTOK] Łączę z @${raw}…`);
      const r = await window.wbApi.tiktokConnect({ username: raw });
      if (!r || !r.ok) {
        setTiktokConnectBtnState("idle");
        appendSystem(`[TIKTOK] ⚠ ${r && r.error ? r.error : "Nie udało się połączyć."}`);
      }
    });
  }

  // AUTO-ŁĄCZENIE: jeśli nick jest zapisany, przy starcie sam próbujemy się połączyć.
  // Gdy twórca jest offline, reconnect (w main) ponawia co ~15s — więc program łączy się
  // sam, gdy tylko wejdzie na live. Rozłączenie ręczne kasuje nick i wyłącza auto-łączenie.
  try {
    const autoNick = localStorage.getItem("kvrina_tiktok_username");
    if (autoNick && String(autoNick).trim()) {
      const nick = String(autoNick).trim().replace(/^@/, "");
      setTiktokConnectBtnState("connecting");
      appendSystem(`[TIKTOK] Auto-łączenie z @${nick} — czekam aż wejdzie na live…`);
      window.wbApi.tiktokConnect({ username: nick }).then((r) => {
        if (!r || !r.ok) setTiktokConnectBtnState("idle");
      }).catch(() => setTiktokConnectBtnState("idle"));
    }
  } catch {}

  // Enter w polu nicku = połącz
  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && btn && !tiktokDirectConnected) btn.click();
  });

  // Eventy z procesu main (biblioteka tiktok-live-connector)
  if (window.wbApi && typeof window.wbApi.onTiktokEvent === "function") {
    window.wbApi.onTiktokEvent(({ event, data }) => handleTikTokEvent(event, data));
  }
  if (window.wbApi && typeof window.wbApi.onTiktokState === "function") {
    window.wbApi.onTiktokState((st) => {
      if (st && st.connecting) {
        // Trwa próba połączenia (także auto-reconnect z procesu main).
        _liveConnState = "connecting";
        setTiktokConnectBtnState("connecting");
        scheduleWidgetStateWrite();
        return;
      }
      tiktokDirectConnected = !!(st && st.connected);
      if (st && st.connected) {
        _tiktokConnectedUsername = st.username || null;
        _liveConnState = "connected";
        setLiveConnected(true, "TikTok");
        setTiktokConnectBtnState("connected");
        appendSystem(`[TIKTOK] Połączono z live @${st.username || ""} (${st.viewerCount || 0} widzów).`);
      } else {
        _tiktokConnectedUsername = null;
        // Streamer offline vs realny błąd (limit/captcha itd.) — do kolorowania statusu.
        _liveConnState = (st && st.errorType && st.errorType !== "offline") ? "error" : "offline";
        setTiktokConnectBtnState("idle");
        if (liveSource === "TikTok") setLiveConnected(false, null);
        if (st && st.reason) appendSystem(`[TIKTOK] Rozłączono: ${st.reason}`);
      }
      scheduleWidgetStateWrite();
    });
  }
}

function setTiktokConnectBtnState(state) {
  const btn = document.getElementById("btn-tiktok-connect");
  if (!btn) return;
  btn.classList.remove("is-connected", "is-connecting");
  if (state === "connected") {
    btn.textContent = "ROZŁĄCZ";
    btn.classList.add("is-connected");
  } else if (state === "connecting") {
    btn.textContent = "ŁĄCZENIE…";
    btn.classList.add("is-connecting");
  } else {
    btn.textContent = "POŁĄCZ Z TIKTOK";
  }
}


/* ====== PLACEHOLDERS / FILTRY ====== */

function _normNoDiacritics(s) {
  return String(s || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function isJoinPlaceholder(line) {
  const t = _normNoDiacritics(line);
  // DOŁĄCZ / DOLACZ + opcjonalne emoji/punktacja
  return t === "dolacz" || t.startsWith("dolacz ");
}

/* ====== KOLEJKA OBSERWUJĄCYCH ====== */

function getFollowKey(name) {
  return _normNoDiacritics(name).replace(/\s+/g, " ");
}

function isTikFinityFollowEvent(ev, payload) {
  const eventName = String(ev || "").trim().toLowerCase();
  if (eventName === "follow" || eventName === "newfollower") return true;

  // Awaryjnie: niektóre integracje potrafią wrzucać follow jako event social.
  if (eventName === "social") {
    const raw = [
      payload && payload.type,
      payload && payload.socialType,
      payload && payload.action,
      payload && payload.label,
      payload && payload.event,
    ].filter(Boolean).join(" ").toLowerCase();
    return raw.includes("follow") || raw.includes("obserw");
  }

  return false;
}

function loadFollowQueue() {
  try {
    const raw = localStorage.getItem(FOLLOW_QUEUE_STORAGE_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    followQueue = Array.isArray(arr)
      ? arr
          .map((x) => {
            if (typeof x === "string") return { nick: x, ts: Date.now(), source: "follow" };
            return {
              nick: String((x && x.nick) || "").trim(),
              ts: typeof (x && x.ts) === "number" ? x.ts : Date.now(),
              source: String((x && x.source) || "follow"),
              giftCoins: Number((x && x.giftCoins) || 0) || 0,
              giftName: String((x && x.giftName) || ""),
            };
          })
          .filter((x) => x.nick)
      : [];
  } catch {
    followQueue = [];
  }

  followQueueKeys = new Set();
  followQueue = followQueue.filter((item) => {
    const key = getFollowKey(item.nick);
    if (!key || followQueueKeys.has(key)) return false;
    followQueueKeys.add(key);
    return true;
  });
}

function saveFollowQueue() {
  try {
    localStorage.setItem(FOLLOW_QUEUE_STORAGE_KEY, JSON.stringify(followQueue));
  } catch {}
}

function updateFollowQueueCount() {
  const queueCount = document.getElementById("queue-count");
  if (!queueCount) return;
  const count = followQueue.length;
  if (count === 1) queueCount.textContent = "1 kandydat";
  else queueCount.textContent = `${count} kandydatów`;
}

function renderFollowQueue() {
  if (shouldSkipHeavyRender()) return;
  const queueList = document.getElementById("queue-list");
  if (!queueList) return;

  queueList.innerHTML = "";

  if (!followQueue.length) {
    const div = document.createElement("div");
    div.className = "queue-item queue-empty";
    div.textContent = "Czekam na obserwacje i gifty 450+…";
    queueList.appendChild(div);
    updateFollowQueueCount();
    return;
  }

  followQueue.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "queue-item follow-queue-item" + (item.source === "gift450" ? " is-gift-candidate" : "");

    const left = document.createElement("div");
    left.className = "follow-queue-left";

    const nick = document.createElement("span");
    nick.className = "follow-queue-nick";
    nick.textContent = `${idx + 1}. ${item.nick}`;

    const meta = document.createElement("span");
    meta.className = "follow-queue-meta";
    if (item.source === "gift450") meta.textContent = `GIFT ${item.giftCoins || 450}+ monet${item.giftName ? " • " + item.giftName : ""}`;
    else meta.textContent = "OBSERWUJĄCY";

    left.appendChild(nick);
    left.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "follow-queue-actions";

    const addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.className = "follow-add-btn";
    addBtn.textContent = "DODAJ";
    addBtn.title = `Dodaj ${item.nick} do kolejki pytań`;
    addBtn.addEventListener("click", () => addFollowerCandidateToQuestionQueue(idx));

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "follow-remove-btn";
    editBtn.textContent = "✎";
    editBtn.title = `Zmień nick ${item.nick}`;
    editBtn.style.cssText = "padding:0 8px;font-size:14px;";
    editBtn.addEventListener("click", () => editFollowerNick(idx));

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "follow-remove-btn";
    btn.textContent = "USUŃ";
    btn.title = `Usuń ${item.nick} z listy`;
    btn.addEventListener("click", () => removeFollowerFromQueue(idx));

    actions.appendChild(addBtn);
    actions.appendChild(editBtn);
    actions.appendChild(btn);
    row.appendChild(left);
    row.appendChild(actions);
    queueList.appendChild(row);
  });

  queueList.scrollTop = queueList.scrollHeight;
  updateFollowQueueCount();
}

function addFollowerToQueue(username, source = "follow", extra = {}) {
  const nick = String(username || "").trim();
  if (!nick) return;

  const key = getFollowKey(nick);
  if (!key) return;

  const existing = followQueue.find((item) => getFollowKey(item.nick) === key);
  if (existing) {
    if (source === "gift450") {
      existing.source = "gift450";
      existing.giftCoins = Math.max(Number(existing.giftCoins || 0) || 0, Number(extra.giftCoins || 0) || 0);
      existing.giftName = extra.giftName || existing.giftName || "";
      saveFollowQueue();
      scheduleFollowQueueRender(); // throttled — TikFinity events mogą strzelać seriami
      scheduleBackup();
    }
    return;
  }

  followQueue.push({ nick, ts: Date.now(), source, giftCoins: Number(extra.giftCoins || 0) || 0, giftName: extra.giftName || "" });
  followQueueKeys.add(key);
  saveFollowQueue();
  scheduleFollowQueueRender(); // throttled — TikFinity events mogą strzelać seriami
  scheduleBackup();
}

// Zaczyna nowy cykl "ładowania" (losowy czas 12-17 min do następnego okna zbierania).
function startNewKartonCharge() {
  _kartonChargeStartedAt = Date.now();
  _kartonChargeDurationMs = demoModeActive
    ? KARTON_DEMO_CHARGE_MIN_MS + Math.random() * (KARTON_DEMO_CHARGE_MAX_MS - KARTON_DEMO_CHARGE_MIN_MS)
    : KARTON_CHARGE_MIN_MS + Math.random() * (KARTON_CHARGE_MAX_MS - KARTON_CHARGE_MIN_MS);
  scheduleWidgetStateWrite();
}

// Otwiera okno zbierania — kto TERAZ napisze "karton" na czacie, wchodzi do puli.
// W demo krótsze (10s) i dopisywane są symulowani widzowie (patrz runDemoTick).
function startKartonCollection() {
  if (_kartonCollectionActive) return;
  _kartonCollectionActive = true;
  _kartonCollectionEndsAt = Date.now() + (demoModeActive ? KARTON_DEMO_COLLECTION_MS : KARTON_COLLECTION_MS);
  _kartonCollectionWriters = new Map();
  const collectSecs = Math.round((demoModeActive ? KARTON_DEMO_COLLECTION_MS : KARTON_COLLECTION_MS) / 1000);
  appendSystem(`[LOSOWANIE] 🎁 Ładowanie Kartona Dnia gotowe — ${collectSecs}s na napisanie „karton” na czacie!`);
  scheduleWidgetStateWrite();
}

// LOSUJ (ręcznie z czytnika) — natychmiast otwiera okno zbierania, pomijając czekanie na ładowanie.
function forceKartonCollection() {
  if (_kartonCollectionActive) {
    appendSystem("[LOSOWANIE] Okno zbierania już trwa — czekam na jego koniec.");
    return;
  }
  startKartonCollection();
}

// Po 30s: losuje zwycięzcę spośród piszących W TYM oknie i zaczyna nowy cykl ładowania.
function resolveKartonCollection() {
  const pool = Array.from(_kartonCollectionWriters.entries()); // [key, nick][]
  _kartonCollectionActive = false;
  _kartonCollectionEndsAt = null;

  if (!pool.length) {
    appendSystem("[LOSOWANIE] Nikt nie napisał „karton” w wyznaczonym czasie — losowanie pominięte.");
  } else {
    const [, winnerNick] = pool[Math.floor(Math.random() * pool.length)];
    insertQuestionSmart({
      ts: Date.now(),
      nick: winnerNick,
      question: KARTON_DNIA_TEXT,
      source: "losuj",
      kind: KARTON_DNIA_KIND,
    });
    _lastKartonDraw = { nick: winnerNick, ts: Date.now() };
    appendSystem(`[LOSOWANIE] 🎁 ${winnerNick} wygrywa Karton Dnia!`);
  }

  _kartonCollectionWriters = new Map();
  startNewKartonCharge();
}

// Tick co 1s: pilnuje czy ładowanie się napełniło albo czy minęło 30s okna zbierania.
function kartonChargeTick() {
  if (_kartonCollectionActive) {
    if (Date.now() >= _kartonCollectionEndsAt) resolveKartonCollection();
    return;
  }
  if (Date.now() - _kartonChargeStartedAt >= _kartonChargeDurationMs) startKartonCollection();
}

// === LICZNIK CZASU DO WPISANIA ===
// Ustawiany z czytnika (h/min). Startuje przy pierwszym komentarzu na live.
function setCountdownDuration(hours, minutes) {
  const h = Math.max(0, Math.min(23, parseInt(hours, 10) || 0));
  const m = Math.max(0, Math.min(59, parseInt(minutes, 10) || 0));
  _countdownDurationMs = (h * 60 + m) * 60 * 1000;
  // zmiana ustawień = uzbrojenie od nowa (odliczy przy najbliższym komentarzu)
  _countdownStarted = false;
  _countdownEndsAt = null;
  _countdownTop1Fired = false;
  _countdownTop1Nick = null;
  _countdownTop1FiredAt = null;
  scheduleWidgetStateWrite();
}

// Wywoływane przy każdym komentarzu — pierwszy komentarz uruchamia odliczanie.
function maybeStartCountdownOnComment() {
  if (_countdownDurationMs <= 0 || _countdownStarted) return;
  _countdownStarted = true;
  _countdownEndsAt = Date.now() + _countdownDurationMs;
  appendSystem(`[LICZNIK] Start odliczania: ${formatCountdown(_countdownDurationMs)} (pierwszy komentarz).`);
  scheduleWidgetStateWrite();
}

function formatCountdown(ms) {
  const t = Math.max(0, Math.floor(Number(ms) || 0) / 1000);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

// Tick co 1s: 15 min przed końcem wrzuca TOP1 rankingu do kolejki jako pytanie do kart.
function countdownTick() {
  if (!_countdownStarted || !_countdownEndsAt) return;
  const remaining = _countdownEndsAt - Date.now();
  if (!_countdownTop1Fired && remaining <= COUNTDOWN_TOP1_LEAD_MS) {
    const ranking = getRankingArrayForWidget();
    const top1 = ranking.length ? String(ranking[0].nick || "").trim() : "";
    _countdownTop1Fired = true;
    _countdownTop1FiredAt = Date.now();
    if (top1) {
      _countdownTop1Nick = top1;
      insertQuestionSorted({ ts: Date.now(), nick: top1, question: "x", source: "ranking-top1" });
      appendSystem(`[LICZNIK] 15 min do końca — TOP 1 rankingu (${top1}) trafia do kolejki jako pytanie do kart.`);
    } else {
      appendSystem("[LICZNIK] 15 min do końca — ranking pusty, brak TOP 1 do dodania.");
    }
    scheduleWidgetStateWrite();
  }
}

function addGiftCandidateToFollowQueue(username, giftCoins, giftName) {
  if ((Number(giftCoins) || 0) < 450) return;
  addFollowerToQueue(username, "gift450", { giftCoins: Number(giftCoins) || 0, giftName: giftName || "" });
}

function addFollowerCandidateToQuestionQueue(index) {
  if (index < 0 || index >= followQueue.length) return;
  const item = followQueue[index];
  const nick = String(item.nick || "").trim();
  if (!nick) return;

  insertQuestionSorted({
    ts: Date.now(),
    nick,
    question: "x",
    source: item.source === "gift450" ? "gift450" : "follow",
  });

  removeFollowerFromQueue(index);
  scheduleWidgetStateWrite();
}

function removeFollowerFromQueue(index) {
  if (index < 0 || index >= followQueue.length) return;
  followQueue.splice(index, 1);
  followQueueKeys = new Set(followQueue.map((item) => getFollowKey(item.nick)).filter(Boolean));
  saveFollowQueue();
  renderFollowQueue();
  scheduleBackup();
}

function setupQueue() {
  const plus = document.getElementById("queue-font-plus");
  const minus = document.getElementById("queue-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      queueFontSize = Math.min(queueFontSize + 1, 24);
      applyFontSizes();
      savePrefs();
    });
  }
  if (minus) {
    minus.addEventListener("click", () => {
      queueFontSize = Math.max(queueFontSize - 1, 8);
      applyFontSizes();
      savePrefs();
    });
  }

  loadFollowQueue();
  renderFollowQueue();
}

/* ====== PANEL KOLEJKI PYTAŃ / KARTONÓW ====== */

let questionQueueDragIndex = null;

function getQuestionQueueStartIndex() {
  if (!questions.length) return 0;
  if (noQuestionsMode) return Math.min(noQuestionsLength || 0, questions.length);
  return Math.max(0, Math.min(questionIndex, questions.length - 1));
}

function getQuestionQueueMovableStartIndex() {
  if (!questions.length) return 0;
  if (noQuestionsMode) return Math.min(noQuestionsLength || 0, questions.length);
  return Math.min(questionIndex + 1, questions.length);
}

function updateQuestionOrderQueueCount() {
  const el = document.getElementById("question-queue-count");
  if (!el) return;
  const start = getQuestionQueueMovableStartIndex();
  const count = Math.max(0, questions.length - start);
  if (count === 1) el.textContent = "1 pozycja w kolejce";
  else el.textContent = `${count} pozycji w kolejce`;
}

function questionQueuePreview(entry) {
  if (!entry) return "";
  if (isKartonDniaEntry(entry)) return KARTON_DNIA_TEXT;
  const q = String(entry.question || "").trim();
  if (!q || q.toLowerCase() === "x") return "CZEKAM NA PYTANIE";
  return q;
}

function renderQuestionOrderQueue() {
  if (shouldSkipHeavyRender()) return;
  const list = document.getElementById("question-queue-list");
  if (!list) return;
  list.innerHTML = "";

  const movableStart = getQuestionQueueMovableStartIndex();
  updateQuestionOrderQueueCount();

  if (!questions.length) {
    const empty = document.createElement("div");
    empty.className = "question-queue-empty";
    empty.textContent = "Czekam na pytania i kartony…";
    list.appendChild(empty);
    return;
  }

  // Renderujemy CAŁĄ kolejkę od początku — przeczytane mają klasę is-done (wyszarzone)
  for (let i = 0; i < questions.length; i++) {
    const entry = questions[i];
    const isCurrent = !noQuestionsMode && i === questionIndex;
    const isDone = !isCurrent && i < (noQuestionsMode ? noQuestionsLength : questionIndex);
    const isKarton = isKartonDniaEntry(entry);
    const entryType = entryTypeForWidget(entry);
    const isShortfall = entryType === "shortfall";
    const canMove = i >= movableStart;

    const row = document.createElement("div");
    row.className = "question-queue-item"
      + (isCurrent ? " is-current" : "")
      + (isDone ? " is-done" : "")
      + (isKarton ? " is-karton" : "")
      + (isShortfall ? " is-shortfall" : "")
      + (entryType === "waiting" ? " is-waiting" : "");
    row.draggable = canMove;
    row.dataset.index = String(i);

    if (canMove) {
      row.addEventListener("dragstart", (e) => {
        questionQueueDragIndex = i;
        row.classList.add("is-dragging");
        try { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", String(i)); } catch {}
      });
      row.addEventListener("dragend", () => {
        row.classList.remove("is-dragging");
        questionQueueDragIndex = null;
      });
      row.addEventListener("dragover", (e) => {
        e.preventDefault();
        try { e.dataTransfer.dropEffect = "move"; } catch {}
      });
      row.addEventListener("drop", (e) => {
        e.preventDefault();
        const from = questionQueueDragIndex;
        moveQuestionQueueItemTo(from, i);
      });
    }

    const num = document.createElement("div");
    num.className = "question-queue-num";
    num.textContent = isCurrent ? "▶" : (isDone ? "✓" : String(i + 1));

    const main = document.createElement("div");
    main.className = "question-queue-main";

    const badge = document.createElement("div");
    badge.className = "question-queue-badge";
    badge.textContent = isCurrent ? "TERAZ" : (isDone ? "PRZECZYTANE" : (isShortfall ? "DOPŁATA" : (isKarton ? "KARTON" : (entryType === "waiting" ? "CZEKA" : "PYTANIE"))));

    const nick = document.createElement("div");
    nick.className = "question-queue-nick";
    nick.textContent = String(entry.nick || "-");

    const preview = document.createElement("div");
    preview.className = "question-queue-preview";
    preview.textContent = questionQueuePreview(entry);

    main.appendChild(badge);
    main.appendChild(nick);
    main.appendChild(preview);

    const actions = document.createElement("div");
    actions.className = "question-queue-actions";

    const up = document.createElement("button");
    up.type = "button";
    up.className = "question-queue-move";
    up.textContent = "↑";
    up.title = "Przesuń wyżej";
    up.disabled = !canMove || i <= movableStart;
    up.addEventListener("click", () => swapQuestionQueueItems(i, i - 1));

    const down = document.createElement("button");
    down.type = "button";
    down.className = "question-queue-move";
    down.textContent = "↓";
    down.title = "Przesuń niżej";
    down.disabled = !canMove || i >= questions.length - 1;
    down.addEventListener("click", () => swapQuestionQueueItems(i, i + 1));

    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "question-queue-move edit";
    edit.textContent = "✎";
    edit.title = "Edytuj wpis";
    edit.addEventListener("click", () => editQuestionQueueItem(i));

    const del = document.createElement("button");
    del.type = "button";
    del.className = "question-queue-move delete";
    del.textContent = "×";
    del.title = "Usuń z kolejki";
    del.addEventListener("click", () => removeQuestionQueueItem(i));

    actions.appendChild(up);
    actions.appendChild(down);
    actions.appendChild(edit);
    actions.appendChild(del);

    row.appendChild(num);
    row.appendChild(main);
    row.appendChild(actions);
    list.appendChild(row);
  }

  // Przewiń do aktualnego pytania żeby było zawsze widoczne
  const currentEl = list.querySelector(".is-current");
  if (currentEl) currentEl.scrollIntoView({ block: "nearest", behavior: "smooth" });
}

function syncQuestionQueueAfterManualOrder() {
  recalcFilteredCount();
  renderQuestionOrderQueue();

  if (!noQuestionsMode && questions.length && questions[questionIndex]) {
    const cur = questions[questionIndex];
    saveQuestionState(cur.nick, cur.question);
    refreshNextFromQueue();
  } else if (noQuestionsMode) {
    showNoQuestions();
  }

  scheduleBackup();
  scheduleWidgetStateWrite();
}

function swapQuestionQueueItems(a, b) {
  const movableStart = getQuestionQueueMovableStartIndex();
  if (a < movableStart || b < movableStart || a < 0 || b < 0 || a >= questions.length || b >= questions.length) return;
  const tmp = questions[a];
  questions[a] = questions[b];
  questions[b] = tmp;
  syncQuestionQueueAfterManualOrder();
}

function moveQuestionQueueItemTo(fromIndex, toIndex) {
  const movableStart = getQuestionQueueMovableStartIndex();
  const from = parseInt(fromIndex, 10);
  let to = parseInt(toIndex, 10);
  if (!Number.isFinite(from) || !Number.isFinite(to)) return;
  if (from < movableStart || to < movableStart || from < 0 || to < 0 || from >= questions.length || to >= questions.length || from === to) return;

  const [item] = questions.splice(from, 1);
  if (from < to) to -= 1;
  questions.splice(to, 0, item);
  syncQuestionQueueAfterManualOrder();
}


function normalizeQuestionQueueAfterMutation() {
  if (!questions.length) {
    questionIndex = 0;
    showNoQuestions();
    return;
  }
  questionIndex = Math.max(0, Math.min(questionIndex, questions.length - 1));
  if (noQuestionsMode) {
    showNoQuestions();
  } else {
    showCurrentQuestion();
  }
  recalcFilteredCount();
  renderQuestionOrderQueue();
  scheduleBackup();
  scheduleWidgetStateWrite();
}

function removeQuestionQueueItem(index) {
  const i = parseInt(index, 10);
  if (!Number.isFinite(i) || i < 0 || i >= questions.length) return;
  const nick = questions[i] && questions[i].nick ? questions[i].nick : "ten wpis";
  if (!confirm(`Usunąć z kolejki: ${nick}?`)) return;
  questions.splice(i, 1);
  if (i < questionIndex) questionIndex--;
  normalizeQuestionQueueAfterMutation();
}

let _entryEditCallback = null;

function openEntryEditModal({ nick, type, question }, onSave) {
  const modal = document.getElementById("entry-edit-modal");
  if (!modal) return;

  const nickInput = document.getElementById("entry-edit-nick");
  const questionInput = document.getElementById("entry-edit-question");
  const questionRow = document.getElementById("entry-edit-question-row");

  nickInput.value = nick || "";
  questionInput.value = (question && question.toLowerCase() !== "x" && question !== KARTON_DNIA_TEXT) ? question : "";

  document.querySelectorAll(".entry-type-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.type === type);
  });
  questionRow.style.display = (type === "pytanie") ? "" : "none";

  _entryEditCallback = onSave;
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  setTimeout(() => nickInput.focus(), 50);
}

function closeEntryEditModal() {
  const modal = document.getElementById("entry-edit-modal");
  if (modal) { modal.classList.add("hidden"); modal.setAttribute("aria-hidden", "true"); }
  _entryEditCallback = null;
}

function setupEntryEditModal() {
  const modal = document.getElementById("entry-edit-modal");
  const backdrop = document.getElementById("entry-edit-backdrop");
  const cancelBtn = document.getElementById("entry-edit-cancel");
  const saveBtn = document.getElementById("entry-edit-save");
  const questionRow = document.getElementById("entry-edit-question-row");

  if (backdrop) backdrop.addEventListener("click", closeEntryEditModal);
  if (cancelBtn) cancelBtn.addEventListener("click", closeEntryEditModal);

  document.querySelectorAll(".entry-type-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".entry-type-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      if (questionRow) questionRow.style.display = (btn.dataset.type === "pytanie") ? "" : "none";
    });
  });

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      const nick = (document.getElementById("entry-edit-nick").value || "").trim();
      if (!nick) return;
      const activeType = document.querySelector(".entry-type-btn.active");
      const type = activeType ? activeType.dataset.type : "pytanie";
      const questionRaw = (document.getElementById("entry-edit-question").value || "").trim();

      let question, kind;
      if (type === "karton") {
        question = KARTON_DNIA_TEXT;
        kind = KARTON_DNIA_KIND;
      } else if (type === "czekam") {
        question = "x";
        kind = null;
      } else {
        question = questionRaw || "x";
        kind = null;
      }

      if (_entryEditCallback) _entryEditCallback({ nick, question, kind });
      closeEntryEditModal();
    });
  }
}

function editQuestionQueueItem(index) {
  const i = parseInt(index, 10);
  if (!Number.isFinite(i) || i < 0 || i >= questions.length) return;
  const entry = questions[i];
  const currentType = entryTypeForWidget(entry);
  const typeForModal = currentType === "karton" ? "karton" : currentType === "waiting" ? "czekam" : "pytanie";

  openEntryEditModal(
    { nick: entry.nick, type: typeForModal, question: entry.question },
    ({ nick, question, kind }) => {
      entry.nick = nick;
      entry.question = question;
      entry.kind = kind;
      normalizeQuestionQueueAfterMutation();
    }
  );
}

function editFollowerNick(index) {
  const item = followQueue[index];
  if (!item) return;
  openEntryEditModal(
    { nick: item.nick, type: "czekam", question: "" },
    ({ nick }) => {
      const oldKey = getFollowKey(item.nick);
      followQueueKeys.delete(oldKey);
      item.nick = nick;
      followQueueKeys.add(getFollowKey(nick));
      saveFollowQueue();
      renderFollowQueue();
    }
  );
}

function setupQuestionOrderQueue() {
  const plus = document.getElementById("question-queue-font-plus");
  const minus = document.getElementById("question-queue-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      questionQueueFontSize = Math.min(questionQueueFontSize + 1, 24);
      applyFontSizes();
      savePrefs();
    });
  }
  if (minus) {
    minus.addEventListener("click", () => {
      questionQueueFontSize = Math.max(questionQueueFontSize - 1, 8);
      applyFontSizes();
      savePrefs();
    });
  }

  renderQuestionOrderQueue();
}

/* ====== CZYTNIK PYTAŃ ====== */

/* ====== SESJA / BACKUP (JSON, loop 24h) ====== */
const BACKUP_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000; // 1.0.37: stan wraca także po dłuższej przerwie

function dayNumberNow() {
  return Math.floor(Date.now() / 86400000);
}

function backupSlotFile(dayNum = dayNumberNow()) {
  // 2-slot loop: A/B nadpisywane co dobę
  return (dayNum % 2 === 0) ? "session_A.json" : "session_B.json";
}

function hasSessionData() {
  return (questions && questions.length > 0)
    || (giftTotals && giftTotals.size > 0)
    || (giftFeed && giftFeed.length > 0)
    || (followQueue && followQueue.length > 0)
    || (predictionRanking && predictionRanking.size > 0)
    || (typeof fundsTotal === "number" && fundsTotal > 0);
}

function serializeSessionState() {
  return {
    version: 1,
    savedAt: Date.now(),
    dayNum: dayNumberNow(),
    questionIndex,
    noQuestionsMode,
    noQuestionsLength,
    questions: questions.map((q) => ({
      ts: q.ts || Date.now(),
      nick: q.nick,
      question: q.question,
      source: q.source || null,
      priority: !!q.priority,
      kind: q.kind || null,
    })),
    funds: { total: fundsTotal, byGoal: fundsByGoal },
    gifts: {
      totals: Array.from(giftTotals.entries()).map(([u, v]) => [u, String(v)]),
      used: Array.from(giftUsed.entries()).map(([u, v]) => [u, String(v)]),
    },
    giftFeed: Array.isArray(giftFeed) ? giftFeed.slice(-60) : [],
    followQueue: Array.isArray(followQueue) ? followQueue.slice(0, 250) : [],
    ranking: Array.from(predictionRanking.entries()).map(([nick, likes]) => [nick, Number(likes) || 0]),
    viewerCount: tiktokViewerCount,
    // Losowanie Kartona Dnia — żeby po awarii nie gubić postępu "ładowania" (samo 30s okno
    // zbierania i tak jest krótkie, nie warto go przywracać po crashu — zaczyna się po prostu
    // nowy cykl ładowania).
    karton: {
      chargeStartedAt: _kartonChargeStartedAt,
      chargeDurationMs: _kartonChargeDurationMs,
      lastDraw: _lastKartonDraw,
    },
    // Licznik czasu — endsAt to znacznik absolutny, więc po restarcie odliczanie wznawia się poprawnie.
    countdown: {
      durationMs: _countdownDurationMs,
      started: _countdownStarted,
      endsAt: _countdownEndsAt,
      top1Fired: _countdownTop1Fired,
      top1Nick: _countdownTop1Nick,
      top1FiredAt: _countdownTop1FiredAt,
    },
  };
}

async function tryReadJsonFile(name) {
  try {
    const r = await window.wbApi.readFile(name);
    if (!r || !r.ok || !r.data) return null;
    const obj = JSON.parse(String(r.data));
    if (!obj || typeof obj !== "object") return null;
    return obj;
  } catch {
    return null;
  }
}

async function loadBestBackup() {
  const a = await tryReadJsonFile("session_A.json");
  const b = await tryReadJsonFile("session_B.json");

  const list = [];
  if (a && typeof a.savedAt === "number") list.push({ name: "session_A.json", data: a });
  if (b && typeof b.savedAt === "number") list.push({ name: "session_B.json", data: b });

  if (!list.length) return null;

  list.sort((x, y) => (y.data.savedAt || 0) - (x.data.savedAt || 0));
  const best = list[0];
  // Najświeższy backup pochodzi z ZERUJ SESJĘ — nic nie przywracamy (start na czysto).
  if (best.data && best.data.cleared) return null;
  const age = Date.now() - (best.data.savedAt || 0);
  if (age > BACKUP_MAX_AGE_MS) return null;
  return best;
}

let _backupDebounce = null;
async function writeBackupNow() {
  try {
    // Ważne: nie nadpisuj backupu pustą sesją przy starcie.
    if (!hasSessionData()) {
      await updateBackupStatusPill();
      return;
    }
    const state = serializeSessionState();
    const fileName = backupSlotFile(state.dayNum);
    await window.wbApi.writeFile(fileName, JSON.stringify(state));
    await updateBackupStatusPill(state);
  } catch (e) {
    console.warn("writeBackupNow failed:", e);
  }
}

function scheduleBackup() {
  if (_backupDebounce) return;
  _backupDebounce = setTimeout(async () => {
    _backupDebounce = null;
    await writeBackupNow();
  }, 900);
}

async function updateBackupStatusPill(stateOverride) {
  try {
    const pillId = "status-backup";
    if (!document.getElementById(pillId)) return;

    const best = stateOverride ? { data: stateOverride } : await loadBestBackup();
    if (!best) {
      setStatusPill(pillId, "Backup: brak", "status-info");
      return;
    }
    const savedAt = best.data.savedAt || 0;
    const ageMs = Math.max(0, Date.now() - savedAt);
    const ageMin = Math.floor(ageMs / 60000);
    setStatusPill(pillId, `Backup: OK (${ageMin} min temu)`, "status-ok");
  } catch {}
}

function resetSessionToEmpty() {
  questions = [];
  questionIndex = 0;
  filteredCount = 0;
  noQuestionsMode = true;
  noQuestionsLength = 0;

  giftTotals = new Map();
  giftUsed = new Map();
  giftNewBlink = new Map();
  giftFeed = [];
  selectedGiftUser = null;
  predictionRanking = new Map();
  predictionEventsFeed = [];

  // losowanie Kartona Dnia
  startNewKartonCharge();
  _kartonCollectionActive = false;
  _kartonCollectionEndsAt = null;
  _kartonCollectionWriters = new Map();
  _lastKartonDraw = null;

  // licznik czasu do wpisania
  _countdownStarted = false;
  _countdownEndsAt = null;
  _countdownTop1Fired = false;
  _countdownTop1Nick = null;
  _countdownTop1FiredAt = null;

  // zbiórki
  fundsTotal = 0;
  fundsByGoal = {};
  updateFundsPill();
  // zapis do plików dla OBS
  persistFundsFiles();

  renderGiftsPanel();
  renderGiftFeed();
  renderRankingPreviewPanel();
  renderQuestionOrderQueue();
  showNoQuestions();
  scheduleBackup(); // zapisze tylko jeśli coś będzie (hasSessionData)
}

function applySessionState(state) {
  try {
    const q = Array.isArray(state.questions) ? state.questions : [];
    questions = q
      .filter((x) => x && x.nick && (x.question !== undefined))
      .map((x) => ({
        ts: typeof x.ts === "number" ? x.ts : Date.now(),
        nick: String(x.nick),
        question: String(x.question),
        source: x.source || null,
        priority: !!x.priority,
        kind: x.kind || (String(x.question || "").trim().toUpperCase() === KARTON_DNIA_TEXT ? KARTON_DNIA_KIND : null),
      }));

    questionIndex = Math.max(0, Math.min(parseInt(state.questionIndex || 0, 10) || 0, Math.max(0, questions.length - 1)));
    noQuestionsMode = !!state.noQuestionsMode;
    noQuestionsLength = parseInt(state.noQuestionsLength || 0, 10) || 0;

    
    // zbiórki
    try {
      const ft = state && state.funds ? state.funds.total : 0;
      const n = (typeof ft === "number") ? ft : parseFloat(String(ft || "").replace(",", "."));
      fundsTotal = Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
      const bg = state && state.funds && state.funds.byGoal && typeof state.funds.byGoal === "object" ? state.funds.byGoal : {};
      fundsByGoal = bg || {};
    } catch {
      fundsTotal = 0;
      fundsByGoal = {};
    }
    updateFundsPill();
    persistFundsFiles();


    // gifts
    giftTotals = new Map((state.gifts && Array.isArray(state.gifts.totals)) ? state.gifts.totals : []);
    giftUsed = new Map((state.gifts && Array.isArray(state.gifts.used)) ? state.gifts.used : []);
    giftNewBlink = new Map();
    giftFeed = Array.isArray(state.giftFeed) ? state.giftFeed : [];
    selectedGiftUser = null;

    if (Array.isArray(state.followQueue)) {
      followQueue = state.followQueue
        .map((x) => {
          if (typeof x === "string") return { nick: x, ts: Date.now(), source: "follow" };
          return {
            nick: String((x && x.nick) || "").trim(),
            ts: typeof (x && x.ts) === "number" ? x.ts : Date.now(),
            source: String((x && x.source) || "follow"),
            giftCoins: Number((x && x.giftCoins) || 0) || 0,
            giftName: String((x && x.giftName) || ""),
          };
        })
        .filter((x) => x.nick);
      followQueueKeys = new Set();
      followQueue = followQueue.filter((item) => {
        const key = getFollowKey(item.nick);
        if (!key || followQueueKeys.has(key)) return false;
        followQueueKeys.add(key);
        return true;
      });
      saveFollowQueue();
    }

    predictionRanking = new Map(Array.isArray(state.ranking) ? state.ranking.map(([nick, likes]) => [String(nick), Number(likes) || 0]) : []);
    predictionEventsFeed = [];
    tiktokViewerCount = Number.isFinite(Number(state.viewerCount)) ? Number(state.viewerCount) : tiktokViewerCount;

    // Losowanie Kartona Dnia — przywróć postęp "ładowania" po awarii (okno zbierania, jako
    // krótkie 30s, celowo nie jest przywracane — po restarcie po prostu leci dalej ładowanie).
    try {
      const k = state.karton || {};
      _kartonChargeStartedAt = (typeof k.chargeStartedAt === "number") ? k.chargeStartedAt : Date.now();
      _kartonChargeDurationMs = (typeof k.chargeDurationMs === "number" && k.chargeDurationMs > 0)
        ? k.chargeDurationMs
        : KARTON_CHARGE_MIN_MS + Math.random() * (KARTON_CHARGE_MAX_MS - KARTON_CHARGE_MIN_MS);
      _kartonCollectionActive = false;
      _kartonCollectionEndsAt = null;
      _kartonCollectionWriters = new Map();
      _lastKartonDraw = (k.lastDraw && k.lastDraw.nick) ? { nick: String(k.lastDraw.nick), ts: Number(k.lastDraw.ts) || Date.now() } : null;
    } catch {}

    // Licznik czasu — wznów odliczanie (endsAt absolutny).
    try {
      const c = state.countdown || {};
      _countdownDurationMs = Number(c.durationMs) || 0;
      _countdownStarted = !!c.started;
      _countdownEndsAt = (typeof c.endsAt === "number") ? c.endsAt : null;
      _countdownTop1Fired = !!c.top1Fired;
      _countdownTop1Nick = c.top1Nick || null;
      _countdownTop1FiredAt = (typeof c.top1FiredAt === "number") ? c.top1FiredAt : null;
    } catch {}

    recalcFilteredCount();

    renderGiftsPanel();
    renderGiftFeed();
    renderFollowQueue();
    renderRankingPreviewPanel();
    renderQuestionOrderQueue();
    updateQuestionStats();

    if (questions.length) {
      noQuestionsMode = false;
      showCurrentQuestion();
      scheduleBackup();
    } else {
      showNoQuestions();
    }

    scheduleBackup();
  } catch (e) {
    console.warn("applySessionState failed:", e);
  }
}

async function restorePreviousSession() {
  const best = await loadBestBackup();
  if (!best) {
    alert("Nie ma backupu sesji do przywrócenia.");
    return;
  }
  applySessionState(best.data);
}


async function restoreSessionOnStartup() {
  try {
    const best = await loadBestBackup();
    if (best && best.data) {
      applySessionState(best.data);
      appendSystem("[SESJA] Przywrócono stan sprzed ostatniego zamknięcia programu.");
      return;
    }
  } catch (e) {
    console.warn("restoreSessionOnStartup failed:", e);
  }
  resetSessionToEmpty();
  appendSystem("[SESJA] Start na czysto — brak świeżego backupu do przywrócenia.");
}

async function writeSessionStateToBothSlots(state) {
  try {
    const data = JSON.stringify(state || serializeSessionState(), null, 2);
    await window.wbApi.writeFile("session_A.json", data);
    await window.wbApi.writeFile("session_B.json", data);
    await updateBackupStatusPill(state || serializeSessionState());
  } catch (e) {
    console.warn("writeSessionStateToBothSlots failed:", e);
  }
}

async function resetWholeSession(ask = true, message = "[SESJA] Sesja wyzerowana. Nowy live startuje na czysto.") {
  if (ask) {
    // Natywny dialog procesu main (nie renderer `confirm()`) — działa niezależnie od tego,
    // czy główne okno jest w tej chwili ukryte (ZERUJ SESJĘ jest wywoływane też z menu
    // czytnika, gdy główne okno-"silnik" jest schowane; confirm() w ukrytym oknie po cichu
    // zwracał false i reset w ogóle się nie wykonywał).
    let confirmed = false;
    try {
      const r = await window.wbApi.confirmResetSession();
      confirmed = !!(r && r.confirmed);
    } catch {
      confirmed = confirm("Wyzerować całą sesję?\n\nWyczyści pytania, kolejki, ranking, gifty, zbiórki i backup sesji. Układ paneli zostaje bez zmian.");
    }
    if (!confirmed) return;
  }

  if (demoInterval) {
    clearInterval(demoInterval);
    demoInterval = null;
  }
  demoModeActive = false;
  updateDemoStatusUi();

  followQueue = [];
  followQueueKeys = new Set();
  saveFollowQueue();
  renderFollowQueue();

  tiktokViewerCount = 0;
  updateQuestionStats();

  const box = document.getElementById("chat-box");
  if (box) box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
  _chatQueue = [];

  questions = [];
  questionIndex = 0;
  filteredCount = 0;
  noQuestionsMode = true;
  noQuestionsLength = 0;

  giftTotals = new Map();
  giftUsed = new Map();
  giftNewBlink = new Map();
  giftFeed = [];
  selectedGiftUser = null;
  predictionRanking = new Map();
  predictionEventsFeed = [];

  // Losowanie Kartona Dnia — pełny reset ładowania, okna zbierania i zwycięzcy.
  startNewKartonCharge();
  _kartonCollectionActive = false;
  _kartonCollectionEndsAt = null;
  _kartonCollectionWriters = new Map();
  _lastKartonDraw = null;

  // Licznik czasu — zerujemy bieg (start/koniec/TOP1); ustawiony czas (h/min) zostaje uzbrojony.
  _countdownStarted = false;
  _countdownEndsAt = null;
  _countdownTop1Fired = false;
  _countdownTop1Nick = null;
  _countdownTop1FiredAt = null;

  fundsTotal = 0;
  fundsByGoal = {};
  updateFundsPill();
  await persistFundsFiles();

  renderGiftsPanel();
  renderGiftFeed();
  renderRankingPreviewPanel();
  renderQuestionOrderQueue();
  showNoQuestions();

  // Backup: zapisujemy PUSTĄ sesję z flagą `cleared` do obu slotów. Dzięki temu po
  // ponownym uruchomieniu program NIE przywróci starych danych — zacznie od zera.
  const emptyState = Object.assign(serializeSessionState(), { cleared: true });
  await writeSessionStateToBothSlots(emptyState);
  // Natychmiastowy zapis stanu widgetów (bez debounce) — ranking i reszta w OBS
  // czyszczą się od razu po ZERUJ SESJĘ, a nie po chwili.
  try { await writeWidgetStateNow(); } catch { scheduleWidgetStateWrite(); }
  appendSystem(message);
}

/* ====== KOLEJKA PYTAŃ W PAMIĘCI ====== */

function recalcFilteredCount() {

// Priorytety (@WB...): jeśli wśród NADCHODZĄCYCH pytań są oznaczone jako poza kolejką,
// przesuń je zaraz po aktualnym pytaniu (zachowując kolejność).
try {
  const pivot = keepCurrent ? Math.min(questionIndex + 1, questions.length) : 0;
  const head = questions.slice(0, pivot);
  const tail = questions.slice(pivot);
  if (tail.some((q) => q && q.priority)) {
    const pri = tail.filter((q) => q && q.priority);
    const rest = tail.filter((q) => !q || !q.priority);
    questions = head.concat(pri, rest);
  }
} catch {}

filteredCount = questions.reduce((acc, q) => {
    const m = String(q.nick || "").toLowerCase().match(/-(\d+)\s*pyt/);
    return acc + (m ? parseInt(m[1], 10) : 1);
  }, 0);

  const el = document.getElementById("questions-count");
  if (el) el.textContent = `Rozkładów: ${filteredCount}`;
}

function insertQuestionSmart(entry) {
  if (!entry) return;

  // POZAKOLEJKA: wrzucamy jako pierwszą osobę po aktualnym pytaniu
  if (entry.priority) {
    const nick = String(entry.nick || "").trim();
    const question = String(entry.question || "").trim();
    if (!nick || question === "") return;

    const ts = typeof entry.ts === "number" ? entry.ts : Date.now();
    const item = { ts, nick, question, source: entry.source || null, priority: true, kind: entry.kind || null };

    // Jeśli jesteśmy w trakcie czytania – wsuwamy zaraz po aktualnym (po ewentualnych innych priorytetach)
    if (!noQuestionsMode && questions.length) {
      let insertAt = Math.min(questionIndex + 1, questions.length);
      while (insertAt < questions.length && questions[insertAt] && questions[insertAt].priority) {
        insertAt++;
      }
      questions.splice(insertAt, 0, item);
      recalcFilteredCount();
      playNotifySound();

      // Pozostajemy na aktualnym pytaniu, ale odświeżamy export TXT / "kto następny"
      const cur = questions[questionIndex];
      if (cur) saveQuestionState(cur.nick, cur.question);
      refreshNextFromQueue();
      scheduleQueueRender(); // throttled — Tipped events mogą strzelać seriami
      scheduleBackup();
      return;
    }
    // Jeśli jesteśmy w trybie "brak pytań", spadamy do insertQuestionSorted (żeby poprawnie wystartować).
  }

  insertQuestionSorted(entry);
}

function insertQuestionSorted(entry) {
  if (!entry) return;
  const nick = String(entry.nick || "").trim();
  const question = String(entry.question || "").trim();
  if (!nick || question === "") return;

  playNotifySound();

  const ts = typeof entry.ts === "number" ? entry.ts : Date.now();
  const item = { ts, nick, question, source: entry.source || null, priority: !!entry.priority, kind: entry.kind || null };

  // Po dodaniu ręcznego sortowania przez prowadzącą nowe pozycje dopisujemy na koniec.
  // Dzięki temu ręcznie ustawiona kolejność nie rozsypuje się od timestampów.
  const insertAt = questions.length;
  questions.splice(insertAt, 0, item);
  recalcFilteredCount();

  // jeśli nie zmieniamy ekranu, odśwież pliki dla OBS/prowadzącej,
  // żeby nowa osoba była widoczna w "po aktualnym"
  if (noQuestionsMode) {
    // byliśmy w "brak pytań"
    if (questions.length > noQuestionsLength) {
      questionIndex = noQuestionsLength;
      showCurrentQuestion();
      scheduleBackup();
    } else {
      showNoQuestions();
      scheduleBackup();
    }
  } else {
    // pozostajemy na aktualnym pytaniu, ale aktualizujemy export TXT
    const cur = questions[questionIndex];
    if (cur) saveQuestionState(cur.nick, cur.question);
    refreshNextFromQueue();
    scheduleQueueRender(); // throttled — Tipped events mogą strzelać seriami
  }

  scheduleBackup();
}

function addIncomingAutoQuestion(p) {
  const baseTs = typeof p.ts === "number" ? p.ts : Date.now();
  const count = Math.max(1, Math.min(3, parseInt(p.questionCount || 1, 10) || 1));
  for (let i = 0; i < count; i++) {
    insertQuestionSmart({
      ts: baseTs + i,
      nick: p.nick,
      question: i === 0 ? p.question : "x",
      source: "tipped",
      priority: !!p.priority && i === 0,
      kind: i === 0 ? (p.kind || null) : null,
    });
  }
  scheduleWidgetStateWrite();
}




function setupQuestions() {
  const plus = document.getElementById("q-font-plus");
  const minus = document.getElementById("q-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      questionFontSize = Math.min(questionFontSize + 2, 40);
      applyFontSizes();
      savePrefs();
      autoResizeQuestionText();
    });
  }

  if (minus) {
    minus.addEventListener("click", () => {
      questionFontSize = Math.max(questionFontSize - 2, 10);
      applyFontSizes();
      savePrefs();
      autoResizeQuestionText();
    });
  }
  // ZA GIFTY (TikFinity)
  const btnGifts = document.getElementById("btn-load-questions-manual") || document.getElementById("btn-load-questions");
  if (btnGifts) btnGifts.addEventListener("click", async () => {
    toggleGiftsPanel();
  });

  // RĘCZNIE
  const btnManual = document.getElementById("btn-add-manual");
  if (btnManual) btnManual.addEventListener("click", () => {
    toggleManualPanel();
  });

  const btnManualAdd = document.getElementById("manual-add-question");
  const btnManualClear = document.getElementById("manual-clear");
  if (btnManualAdd) btnManualAdd.addEventListener("click", async () => {
    await addManualQuestionToQueue();
  });
  if (btnManualClear) btnManualClear.addEventListener("click", () => {
    const n = document.getElementById("manual-nick-input");
    const q = document.getElementById("manual-question-input");
    const f = document.getElementById("manual-feed");
    if (n) n.value = "";
    if (q) q.value = "";
    if (f) f.textContent = "";
  });

  // Formularz: dodaj pytanie za gifty
  const btnAddGiftQ = document.getElementById("gift-add-question");
  const btnClearGift = document.getElementById("gift-clear-selection");
  if (btnAddGiftQ) btnAddGiftQ.addEventListener("click", async () => {
    await addSelectedGiftQuestionToQueue();
  });
  if (btnClearGift) btnClearGift.addEventListener("click", () => {
    selectedGiftUser = null;
    const sel = document.getElementById("gift-selected-user");
    if (sel) sel.textContent = "-";
  });

  // Próg monet na 1 kredyt (domyślnie 699) – sterowany z UI
  const giftThrInput = document.getElementById("gift-credit-input");
  if (giftThrInput) {
    giftThrInput.value = String(giftCredit);

    const applyGiftThreshold = () => {
      const raw = String(giftThrInput.value || "").trim();
      const n = Math.floor(parseInt(raw, 10));
      if (!Number.isFinite(n) || n <= 0) {
        giftThrInput.value = String(giftCredit);
        return;
      }
      giftCredit = Math.max(1, Math.min(100000, n));
      giftThrInput.value = String(giftCredit);
      savePrefs();
      renderGiftsPanel();
    };

    giftThrInput.addEventListener("change", applyGiftThreshold);
    giftThrInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        applyGiftThreshold();
        giftThrInput.blur();
      }
    });
  }

  // Filtr na liście giftów
  const giftsFilter = document.getElementById("gifts-filter");
  if (giftsFilter) {
    giftsFilter.addEventListener("input", () => {
      renderGiftsPanel();
    });
  }

  // Przywracanie sesji (backup JSON)
  const btnRestore = document.getElementById("btn-restore-session");
  if (btnRestore) btnRestore.addEventListener("click", async () => {
    await restorePreviousSession();
  });

  const btnOpenReader = document.getElementById("btn-open-reader");
  if (btnOpenReader) btnOpenReader.addEventListener("click", async () => {
    try { await window.wbApi.openReaderWindow(); } catch (e) { console.error("openReaderWindow failed:", e); }
  });

  function goPrevQuestion() {
    if (!questions.length) return;
    if (questionIndex > 0) {
      questionIndex--;
    }
    showCurrentQuestion();
    scheduleBackup();
  }

  function goNextQuestion() {
    // jeśli nie ma żadnych pytań – pokaż stan "Brak pytań" i "TERAZ TY"
    if (!questions.length) {
      showNoQuestions();
      scheduleBackup();
      return;
    }
    // jeśli jest kolejne pytanie – przechodzimy dalej
    if (questionIndex < questions.length - 1) {
      questionIndex++;
      showCurrentQuestion();
      scheduleBackup();
    } else {
      // byliśmy na ostatnim pytaniu – przejście do trybu "brak pytań"
      showNoQuestions();
      scheduleBackup();
    }
  }

  // POMIŃ: zamienia aktualne pytanie z następnym w kolejce, bez ruszania wskaźnika
  // pozycji — dzięki temu pominięte pytanie ląduje w kolejce (gdzie już MOŻNA je
  // edytować, bo "TERAZ" celowo nie ma przycisku edycji) zamiast znikać jak przy DALEJ.
  function skipCurrentQuestion() {
    if (!questions.length || questionIndex >= questions.length - 1) return;
    const tmp = questions[questionIndex];
    questions[questionIndex] = questions[questionIndex + 1];
    questions[questionIndex + 1] = tmp;
    showCurrentQuestion();
    scheduleBackup();
  }

  document.getElementById("btn-prev").addEventListener("click", goPrevQuestion);
  document.getElementById("btn-next").addEventListener("click", goNextQuestion);
  const btnSkip = document.getElementById("btn-skip");
  if (btnSkip) btnSkip.addEventListener("click", skipCurrentQuestion);

  // Global skróty (działają nawet gdy okno nie jest aktywne)
  // Ctrl+N, a potem 1 = WSTECZ, 2 = DALEJ (w ciągu ~1s)
  if (window.wbApi && typeof window.wbApi.onQuestionsNext === "function") {
    window.wbApi.onQuestionsNext(goNextQuestion);
  }
  if (window.wbApi && typeof window.wbApi.onQuestionsPrev === "function") {
    window.wbApi.onQuestionsPrev(goPrevQuestion);
  }
  if (window.wbApi && typeof window.wbApi.onQuestionsSkip === "function") {
    window.wbApi.onQuestionsSkip(skipCurrentQuestion);
  }
  // (wyłączone) nie czytamy już pytań z TXT ani z logów w tle.

  showNoQuestions();
  refreshNextFromQueue();
}

// Wczytaj i połącz pytania z dwóch plików TXT.
// Kolejność: najpierw MANUAL (ręczne), potem AUTO (donejty).
async function _readJsonlFromOutput(name) {
  try {
    const r = await window.wbApi.readFile(name);
    if (!r || !r.ok || !r.data) return [];
    const lines = String(r.data || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const out = [];
    for (const line of lines) {
      try {
        const obj = JSON.parse(line);
        if (!obj) continue;
        const ts = typeof obj.ts === "number" ? obj.ts : Date.parse(obj.ts);
        const nick = String(obj.nick || "").trim();
        const question = String(obj.question || "").trim();
        if (!nick || !question) continue;
        out.push({ ts: Number.isFinite(ts) ? ts : Date.now(), nick, question, source: obj.source || null, priority: !!obj.priority, kind: obj.kind || (question.toUpperCase() === KARTON_DNIA_TEXT ? KARTON_DNIA_KIND : null) });
      } catch {}
    }
    return out;
  } catch (e) {
    return [];
  }
}

// Wczytaj pytania CHRONOLOGICZNIE z logów (auto + gifty). Jeśli log jest pusty, fallback: AUTO TXT.
async function reloadQuestionsFromTwoFiles(keepCurrent) {
  const entriesAuto = await _readJsonlFromOutput("pytania_auto_log.jsonl");
  const entriesGift = await _readJsonlFromOutput("pytania_gifty_log.jsonl");

  const mergedEntries = [...entriesAuto, ...entriesGift].filter((e) => e && e.nick && e.question);

  if (mergedEntries.length) {
    mergedEntries.sort((a, b) => (a.ts || 0) - (b.ts || 0));
    const mergedText = mergedEntries
      .map((e) => (e.priority ? `@WB_POZA
${e.nick}
${e.question}
` : `${e.nick}
${e.question}
`))
      .join("\n");
    parseQuestions(mergedText, !!keepCurrent);
    refreshNextFromQueue();
    return;
  }

  // Fallback: wczytaj AUTO TXT (np. jeśli logi są puste)
  let autoText = "";
  if (autoQuestionsFilePath) {
    const r = await window.wbApi.readAbsoluteFile(autoQuestionsFilePath);
    if (r && r.ok) {
      autoText = r.data || "";
      if (r.mtimeMs) autoQuestionsFileMtime = r.mtimeMs;
    }
  }
  parseQuestions(autoText || "", !!keepCurrent);
  refreshNextFromQueue();
}

/**
 * Format pliku:
 * LINIA 1: nick
 * LINIA 2: pytanie
 * PUSTA LINIA
 * LINIA 4: kolejny nick
 * LINIA 5: pytanie
 * ...
 */
function parseQuestions(text, keepCurrent = false) {
  // zapamiętaj aktualne pytanie, jeśli mamy zachować pozycję
  let prevNick = null;
  let prevQuestion = null;
  let prevIndex = questionIndex;
  if (keepCurrent && questions.length && questionIndex >= 0 && questionIndex < questions.length) {
    prevNick = questions[questionIndex].nick;
    prevQuestion = questions[questionIndex].question;
  }

  const rawLines = text.split(/\r?\n/);

  const blocks = [];
  let buf = [];
  for (const line of rawLines) {
    const trimmed = line.trim();
    if (trimmed === "") {
      if (buf.length) {
        blocks.push(buf);
        buf = [];
      }
    } else {
      buf.push(trimmed);
    }
  }
  if (buf.length) blocks.push(buf);

  const parsed = [];
  for (const blk of blocks) {
    if (blk.length >= 2) {
      let priority = false;
let nick = blk[0];
let question = blk[1];

// @WB... nad nickiem = priorytet ("pozakolejka") – linia jest niewidoczna, ale wpływa na kolejkę
if (/^@wb/i.test(String(blk[0] || "").trim())) {
  priority = true;
  nick = blk[1];
  question = blk[2];
}

const nL = String(nick || "").trim().toLowerCase();
const qL = String(question || "").trim().toLowerCase();

// "XX" to placeholder – nie liczymy tego jako rozkład i nie pokazujemy w liście
if (nL === "xx" || qL === "xx") continue;

parsed.push({ nick, question, priority, kind: String(question || "").trim().toUpperCase() === KARTON_DNIA_TEXT ? KARTON_DNIA_KIND : null });

    }
  }

  questions = parsed;

  if (keepCurrent && prevNick !== null) {
    // 0) Najpierw spróbuj zostać na TYM SAMYM indeksie (to rozwiązuje przypadek,
    // gdy ten sam nick jest kilka razy, a zmieniło się tylko pytanie "x" -> treść)
    if (prevIndex >= 0 && prevIndex < questions.length && questions[prevIndex].nick === prevNick) {
      questionIndex = prevIndex;
    } else {
      // 1) idealnie – dopasowanie po nicku + pytaniu
      let foundIndex = questions.findIndex(
        (q) => q.nick === prevNick && q.question === prevQuestion
      );

      // 2) jeśli pytanie zostało zmienione – wybierz NAJBLIŻSZE wystąpienie nicku względem poprzedniego indeksu
      if (foundIndex === -1) {
        let best = -1;
        let bestDist = Number.POSITIVE_INFINITY;
        for (let i = 0; i < questions.length; i++) {
          if (questions[i].nick === prevNick) {
            const d = Math.abs(i - prevIndex);
            if (d < bestDist) {
              best = i;
              bestDist = d;
            }
          }
        }
        foundIndex = best;
      }

      // 3) jeśli nadal nie znaleziono – staramy się zostać przy podobnym indeksie
      if (foundIndex === -1) {
        if (questions.length === 0) {
          questionIndex = 0;
        } else if (prevIndex >= 0 && prevIndex < questions.length) {
          questionIndex = prevIndex;
        } else {
          questionIndex = 0;
        }
      } else {
        questionIndex = foundIndex;
      }
    }
} else {
    // nowe wczytanie pliku – start od pierwszego pytania
    questionIndex = 0;
  }

  filteredCount = questions.reduce((acc, q) => {
    const m = q.nick.toLowerCase().match(/-(\d+)\s*pyt/);
    return acc + (m ? parseInt(m[1], 10) : 1);
  }, 0);

  document.getElementById("questions-count").textContent = `Rozkładów: ${filteredCount}`;
  renderQuestionOrderQueue();
}



function showCurrentQuestion() {
  noQuestionsMode = false;
  const idxBadge = document.getElementById("question-index-badge");
  if (!questions.length) {
    showNoQuestions();
    return;
  }

  const nickDiv = document.getElementById("question-nick");
  const textDiv = document.getElementById("question-text");

  const currentQuestion = questions[questionIndex];
  const { nick, question } = currentQuestion;
  const isKarton = isKartonDniaEntry(currentQuestion);
  nickDiv.textContent = nick;
  setKartonDniaUi(isKarton);

  // w kółku pokazujemy pozostałe rozkłady od aktualnego pytania
  updateRozkladyBadge(calcRemainingCount());

  const qLower = question.trim().toLowerCase();
  if (isKarton) {
    textDiv.textContent = KARTON_DNIA_TEXT;
    textDiv.style.color = "#ffd34d";
  } else if (qLower === "x") {
    textDiv.textContent = "CZEKAM NA PYTANIE";
    textDiv.style.color = "#ffc300";
  } else {
    textDiv.textContent = question;
    textDiv.style.color = "#ffffff";
  }

  document.getElementById("questions-count").textContent = `Rozkładów: ${filteredCount}`;
  autoResizeQuestionText();
  saveQuestionState(nick, question);
  refreshNextFromQueue();
  renderQuestionOrderQueue();
}

function showNoQuestions() {
  noQuestionsMode = true;
  noQuestionsLength = questions.length;
  updateRozkladyBadge(0);
  setKartonDniaUi(false);

  document.getElementById("question-nick").textContent = "Brak pytań";
  const textDiv = document.getElementById("question-text");
  textDiv.textContent = "";
  textDiv.style.color = "#ffc300";
  autoResizeQuestionText();
  renderQuestionOrderQueue();
  // w plikach TXT: nick = "TERAZ TY", pytanie = puste
  saveQuestionState("TERAZ TY", "");
}

function calcRemainingCount() {
  if (noQuestionsMode || !questions.length) return 0;
  const idx = Math.max(0, Math.min(questionIndex, questions.length - 1));
  return questions.slice(idx).reduce((acc, q) => {
    const m = String(q.nick || "").toLowerCase().match(/-(\d+)\s*pyt/);
    return acc + (m ? parseInt(m[1], 10) : 1);
  }, 0);
}

function updateRozkladyBadge(count) {
  const badge = document.getElementById("question-index-badge");
  if (!badge) return;

  const n = Number(count) || 0;
  badge.textContent = String(n);

  // gradient: czerwony -> zielony (0..30)
  const ratio = Math.max(0, Math.min(1, n / 30));
  const hue = Math.round(120 * ratio); // 0=red, 120=green
  const color = `hsl(${hue}, 90%, 50%)`;

  badge.style.borderColor = color;
  badge.style.color = color;
  badge.style.boxShadow = `0 0 14px hsla(${hue}, 90%, 55%, 0.35)`;
}


function renderNextLine(nextName) {
  const el = document.getElementById("question-next-queue");
  if (!el) return;

  // migotanie na czerwono jeśli jest ktoś następny
  const hasNext = Boolean(nextName);
  el.classList.toggle("next-has", hasNext);

  if (!nextName) el.textContent = "NEXT: -";
  else el.textContent = `NEXT: ${nextName}`;
}


/**
 * Dynamiczna czcionka – nick + pytanie skaluje się do boxa,
 * NEXT jest trochę mniejszy i nie psuje środka.
 */
function autoResizeQuestionText() {
  const container = document.getElementById("question-body") || document.getElementById("question-current");
  const nickDiv = document.getElementById("question-nick");
  const textDiv = document.getElementById("question-text");
  const nextDiv = document.getElementById("question-next-queue");
  const statsDiv = document.getElementById("question-stats");
  if (!container || !nickDiv || !textDiv || !nextDiv) return;

  let size = Math.min(Math.max(questionFontSize, 18), 40);
  const minSize = 10;

  let iterations = 0;
  while (iterations < 40) {
    nickDiv.style.fontSize = Math.round(size * 1.15) + "px";
    textDiv.style.fontSize = size + "px";
    nextDiv.style.fontSize = Math.round(size * 0.75) + "px";
    if (statsDiv) {
      statsDiv.style.fontSize = Math.round(size * 0.75) + "px";
    }

    const bottom = document.getElementById("question-bottom");
    const nextH = bottom ? bottom.scrollHeight : (nextDiv ? nextDiv.scrollHeight : 0);
    const available = container.clientHeight - nextH - 12;
    const used = nickDiv.scrollHeight + textDiv.scrollHeight;

    if (used <= available || size <= minSize) {
      break;
    }
    size -= 2;
    iterations++;
  }
}


function updateQuestionStats() {
  const viewers = tiktokViewerCount || 0;
  const viewersEl = document.getElementById("question-viewers");
  if (viewersEl) viewersEl.textContent = `👁 ${viewers}`;

  // Ukryj taps jeśli jeszcze jest w HTML
  const tapsEl = document.getElementById("question-taps");
  if (tapsEl) tapsEl.style.display = "none";


  // animacja "AKTUALIZUJE..." w lewym dolnym rogu boxa
  const upd = document.getElementById("question-update");
  if (upd) {
    upd.classList.remove("show");
    // wymuszenie reflow, żeby animacja mogła się ponowić
    void upd.offsetWidth;
    upd.classList.add("show");
  }
}

// ===== ZA GIFTY (TikFinity) – logika =====

async function loadGiftsState() {
  try {
    const r = await window.wbApi.readFile("gifts_state.json");
    if (!r || !r.ok || !r.data) return;
    const obj = JSON.parse(r.data);
    giftTotals = new Map(Object.entries(obj.totals || {}));
    giftUsed = new Map(Object.entries(obj.used || {}));
  } catch {}
}

async function saveGiftsState() {
  try {
    const totalsObj = {};
    const usedObj = {};
    for (const [k, v] of giftTotals.entries()) totalsObj[k] = Number(v) || 0;
    for (const [k, v] of giftUsed.entries()) usedObj[k] = Number(v) || 0;
    await window.wbApi.writeFile("gifts_state.json", JSON.stringify({ totals: totalsObj, used: usedObj }, null, 2));
  } catch {}
}

function getGiftCreditsTotal(user) {
  const total = parseInt(giftTotals.get(user) || 0, 10) || 0;
  return Math.floor(total / giftCredit);
}

function getGiftCreditsUsed(user) {
  const used = parseInt(giftUsed.get(user) || 0, 10) || 0;
  return used;
}

function getGiftCreditsAvailable(user) {
  return Math.max(0, getGiftCreditsTotal(user) - getGiftCreditsUsed(user));
}

function pushGiftFeedLine(text) {
  const now = new Date();
  const ts = now.toTimeString().slice(0, 8);
  giftFeed.unshift(`[${ts}] ${text}`);
  giftFeed = giftFeed.slice(0, 30);
  renderGiftFeed();
}

function renderGiftFeed() {
  if (shouldSkipHeavyRender()) return;
  const feedEl = document.getElementById("gifts-feed");
  if (!feedEl) return;
  feedEl.innerHTML = "";
  for (const line of giftFeed) {
    const div = document.createElement("div");
    div.className = "feed-line";
    div.textContent = line;
    feedEl.appendChild(div);
  }
}

function renderGiftsPanel() {
  const listEl = document.getElementById("gifts-list");
  const summaryEl = document.getElementById("gifts-summary");
  if (!listEl || !summaryEl) return;

  const filterEl = document.getElementById("gifts-filter");
  const filter = (filterEl && filterEl.value ? String(filterEl.value) : "").trim().toLowerCase();

  let users = Array.from(giftTotals.keys());
  if (filter) {
    users = users.filter(u => String(u).toLowerCase().includes(filter));
  }
  const totals = users.reduce((acc, u) => acc + (parseInt(giftTotals.get(u) || 0, 10) || 0), 0);

  // sort: najpierw z dostępnymi kredytami, potem po sumie monet (desc)
  users.sort((a, b) => {
    const avA = getGiftCreditsAvailable(a);
    const avB = getGiftCreditsAvailable(b);
    if (avA !== avB) return avB - avA;
    const tA = parseInt(giftTotals.get(a) || 0, 10) || 0;
    const tB = parseInt(giftTotals.get(b) || 0, 10) || 0;
    return tB - tA;
  });

  summaryEl.textContent = `${users.length} osób • ${totals} monet • próg: ${giftCredit}`;

  // aktualizuj label w tytule feedu, jeśli jest w HTML
  const thrLabel = document.getElementById("gift-threshold-label");
  if (thrLabel) thrLabel.textContent = String(giftCredit);

  listEl.innerHTML = "";

  if (!users.length) {
    const empty = document.createElement("div");
    empty.style.color = "#aaa";
    empty.style.padding = "6px 2px";
    empty.textContent = "Brak giftów (czekam na TikFinity)";
    listEl.appendChild(empty);
    return;
  }

  const nowTs = Date.now();

  for (const u of users) {
    const total = parseInt(giftTotals.get(u) || 0, 10) || 0;
    const creditsTotal = getGiftCreditsTotal(u);
    const creditsUsed = getGiftCreditsUsed(u);
    const creditsAvail = Math.max(0, creditsTotal - creditsUsed);

    const row = document.createElement("div");
    row.className = "gift-item";

    if (creditsAvail > 0) row.classList.add("gift-eligible");

    const blinkUntil = giftNewBlink.get(u) || 0;
    if (blinkUntil && nowTs < blinkUntil) row.classList.add("gift-new");

    const left = document.createElement("div");
    left.className = "gift-left";

    const userEl = document.createElement("div");
    userEl.className = "gift-user";
    userEl.textContent = u;

    const meta = document.createElement("div");
    meta.className = "gift-meta";
    meta.textContent = `monety: ${total} • kredyty: ${creditsAvail}/${creditsTotal} (użyte: ${creditsUsed})`;

    left.appendChild(userEl);
    left.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "gift-actions";

    const pickBtn = document.createElement("button");
    pickBtn.className = "btn tiny orange";
    pickBtn.textContent = "WYBIERZ";
    pickBtn.addEventListener("click", () => {
      selectedGiftUser = u;
      const sel = document.getElementById("gift-selected-user");
      if (sel) sel.textContent = u;
      const panel = document.getElementById("gifts-panel");
      if (panel && panel.classList.contains("hidden")) {
        panel.classList.remove("hidden");
      }
    });

    actions.appendChild(pickBtn);

    if (creditsAvail > 0) {
      const addBtn = document.createElement("button");
      addBtn.className = "btn tiny green";
      addBtn.textContent = "DODAJ";
      addBtn.addEventListener("click", async () => {
        selectedGiftUser = u;
        const sel = document.getElementById("gift-selected-user");
        if (sel) sel.textContent = u;
        await addSelectedGiftQuestionToQueue();
      });
      actions.appendChild(addBtn);
    }

    row.appendChild(left);
    row.appendChild(actions);
    listEl.appendChild(row);
  }
}

function toggleGiftsPanel() {
  const panel = document.getElementById("gifts-panel");
  if (!panel) return;
  // jeśli otwieramy gift panel, zamknij panel ręczny
  const manual = document.getElementById("manual-panel");
  if (manual && panel.classList.contains("hidden") === true) {
    manual.classList.add("hidden");
  }
  panel.classList.toggle("hidden");
  // zawsze odśwież widok przy otwarciu
  if (!panel.classList.contains("hidden")) {
    renderGiftsPanel();
    renderGiftFeed();
  }
}

function toggleManualPanel() {
  const panel = document.getElementById("manual-panel");
  if (!panel) return;
  // jeśli otwieramy panel ręczny, zamknij panel giftów
  const gifts = document.getElementById("gifts-panel");
  if (gifts && panel.classList.contains("hidden") === true) {
    gifts.classList.add("hidden");
  }
  panel.classList.toggle("hidden");
  if (!panel.classList.contains("hidden")) {
    const f = document.getElementById("manual-feed");
    if (f) f.textContent = "";
    const n = document.getElementById("manual-nick-input");
    if (n) n.focus();
  }
}

async function addManualQuestionToQueue() {
  const nickEl = document.getElementById("manual-nick-input");
  const qEl = document.getElementById("manual-question-input");
  const feedEl = document.getElementById("manual-feed");

  const nick = (nickEl ? String(nickEl.value || "") : "").trim();
  const rawQ = (qEl ? String(qEl.value || "") : "").trim();
  const question = rawQ.length ? rawQ : "x";

  if (!nick) {
    if (feedEl) feedEl.textContent = "Wpisz nick.";
    if (nickEl) nickEl.focus();
    return;
  }

  const ts = Date.now();

  // zapis do logu (chronologia kliknięć)
  try {
    await window.wbApi.appendFile(
      "pytania_recznie_log.jsonl",
      JSON.stringify({ ts, nick, question, source: "manual" }) + "\n"
    );
  } catch (e) {
    console.warn("append manual log failed:", e);
  }

  insertQuestionSorted({ ts, nick, question, source: "manual" });

  if (feedEl) feedEl.textContent = `Dodano: ${nick}`;
  if (qEl) {
    qEl.value = "";
    qEl.focus();
  }
}

async function addSelectedGiftQuestionToQueue() {
  if (!selectedGiftUser) {
    alert("Najpierw wybierz osobę z listy.");
    return;
  }

  const avail = getGiftCreditsAvailable(selectedGiftUser);
  if (avail <= 0) {
    alert(`Ten użytkownik nie ma już dostępnych kredytów (${giftCredit} monet = 1).`);
    return;
  }

  const input = document.getElementById("gift-question-input");
  const q = (input ? input.value : "").trim();
  const question = q.length ? q : "x";

  const ts = Date.now();
  const nick = selectedGiftUser;

  // zapis do logu (chronologia)
  try {
    await window.wbApi.appendFile("pytania_gifty_log.jsonl", JSON.stringify({ ts, nick, question, source: "gifts" }) + "\n");
  } catch (e) {
    console.warn("append gifts log failed:", e);
  }

  // zużyj 1 kredyt
  giftUsed.set(selectedGiftUser, String(getGiftCreditsUsed(selectedGiftUser) + 1));

  // START PUSTO: stan giftów trzymamy w pamięci + backup.

  // UX
  if (input) input.value = "";
  pushGiftFeedLine(`${nick} dodany do kolejki (pytanie: ${question === "x" ? "x" : "treść"})`);

  insertQuestionSorted({ ts, nick, question, source: "gifts" });

  renderGiftsPanel();
}

async function onTikfinityGift(username, amount, giftName) {
  if (!username) return;
  const prev = parseInt(giftTotals.get(username) || 0, 10) || 0;
  const next = prev + (parseInt(amount || 0, 10) || 0);

  giftTotals.set(username, String(next));

  const prevCredits = Math.floor(prev / giftCredit);
  const nextCredits = Math.floor(next / giftCredit);

  if (nextCredits > prevCredits) {
    // nowy próg 450+
    giftNewBlink.set(username, Date.now() + 15000);
    pushGiftFeedLine(`${username} przekroczył ${giftCredit}+ (kredyty: ${nextCredits})`);
  }

  // START PUSTO: stan giftów trzymamy w pamięci + backup.
  scheduleBackup();
  renderGiftsPanel();
  scheduleWidgetStateWrite();
}




// NEXT: osoba z pliku kolejki
async function refreshNextFromQueue() {
  const el = document.getElementById("question-next-queue");
  if (!el) return;

  const res = await window.wbApi.readFile("wszyscy_po_aktualnym.txt");
  if (!res.ok || !res.data.trim()) {
    renderNextLine(null);
    return;
  }
  const first = res.data
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .find((x) => !isJoinPlaceholder(x));
  if (!first) renderNextLine(null);
  else renderNextLine(first);
}

// Zapis plików TXT dla OBS
function wrapTextToLines(text, maxLen) {
  if (!text) return "";
  const words = text.split(/\s+/);
  const lines = [];
  let current = "";

  for (const w of words) {
    if (!current.length) {
      current = w;
      continue;
    }
    if ((current + " " + w).length <= maxLen) {
      current += " " + w;
    } else {
      lines.push(current);
      current = w;
    }
  }
  if (current.length) lines.push(current);
  return lines.join("\n");
}

async function saveQuestionState(nick, question) {
  if (!outputDir) return;

  const qLower = (question || "").trim().toLowerCase();
  let formatted = "";
  if (qLower === "x") formatted = "CZEKAM NA PYTANIE";
  else if (qLower === "xx") formatted = "";
  else formatted = question || "";

  const nickText = nick && nick.toLowerCase() !== "xx" ? nick : "TERAZ TY";

  const remainingNames = [];
  if (questions.length && questionIndex < questions.length - 1) {
    for (let i = questionIndex + 1; i < questions.length; i++) {
      const n = questions[i].nick;
      if (n.toLowerCase() !== "xx") remainingNames.push(n);
    }
  }
  remainingNames.push("DOŁĄCZ");

  await window.wbApi.writeFile("aktualny_nick.txt", nickText);
  await window.wbApi.writeFile("aktualne_pytanie.txt", wrapTextToLines(formatted, 60));
  await window.wbApi.writeFile("wszyscy_po_aktualnym.txt", remainingNames.join("\n"));
  scheduleWidgetStateWrite();
}

