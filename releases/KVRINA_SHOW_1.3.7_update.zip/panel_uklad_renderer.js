// =========================
// KVRINA_SHOW — panel_uklad_renderer.js
// Edytor układu widgetu zbiorczego: makieta 1080x1920, przeciąganie elementów
// i regulacja wielkości. Zapis idzie do programu, a widget w OBS podchwytuje
// zmianę sam — bez przeładowywania źródła.
// =========================

const CANVAS_W = 1080;
const CANVAS_H = 1920;

let _layout = null;
let _labels = {};
let _parts = [];
let _selected = null;
let _comboUrl = "";
let _drag = null;

function canvasScale() {
  const el = document.getElementById("uk-canvas");
  if (!el) return 0.2;
  return el.clientWidth / CANVAS_W;
}

function setStatus(msg) {
  const el = document.getElementById("uk-status");
  if (el) el.textContent = msg;
}

async function pushLayout(part, patch, msg) {
  if (!window.wbApi || typeof window.wbApi.comboSetLayout !== "function") return;
  try {
    const r = await window.wbApi.comboSetLayout({ [part]: patch });
    if (r && r.ok) {
      _layout = r.layout;
      if (msg) setStatus(msg);
    }
  } catch (e) {
    console.error("comboSetLayout:", e);
  }
}

// Elementy mają realne proporcje widgetów (płótno 1080x1920 przeskalowane),
// więc na makiecie widać dokładnie tyle miejsca, ile zajmą w OBS.
function renderCanvas() {
  const canvas = document.getElementById("uk-canvas");
  if (!canvas || !_layout) return;
  const s = canvasScale();

  canvas.querySelectorAll(".uk-item").forEach((n) => n.remove());

  _parts.forEach((key) => {
    const c = _layout[key];
    if (!c) return;

    const box = document.createElement("div");
    box.className = "uk-item" + (key === _selected ? " is-sel" : "") + (c.enabled === false ? " is-off" : "");
    box.dataset.part = key;
    box.style.left = (c.x * s) + "px";
    box.style.top = (c.y * s) + "px";
    box.style.width = (CANVAS_W * c.scale * s) + "px";
    box.style.height = (CANVAS_H * c.scale * s) + "px";

    const tag = document.createElement("span");
    tag.className = "uk-item-tag";
    tag.textContent = _labels[key] || key;
    box.appendChild(tag);

    box.addEventListener("mousedown", (e) => {
      e.preventDefault();
      selectPart(key);
      _drag = {
        part: key,
        startX: e.clientX,
        startY: e.clientY,
        origX: _layout[key].x,
        origY: _layout[key].y,
      };
    });

    canvas.appendChild(box);
  });
}

function renderPartList() {
  const wrap = document.getElementById("uk-parts");
  if (!wrap || !_layout) return;
  wrap.innerHTML = "";
  _parts.forEach((key) => {
    const c = _layout[key];
    const row = document.createElement("div");
    row.className = "uk-part" + (key === _selected ? " is-sel" : "");

    const chk = document.createElement("input");
    chk.type = "checkbox";
    chk.checked = c.enabled !== false;
    chk.title = "Pokaż / ukryj ten element";
    chk.addEventListener("click", (e) => e.stopPropagation());
    chk.addEventListener("change", async () => {
      await pushLayout(key, { enabled: chk.checked },
        `${_labels[key] || key}: ${chk.checked ? "widoczny" : "ukryty"}`);
      renderCanvas();
      renderPartList();
    });

    const name = document.createElement("span");
    name.className = "uk-part-name";
    name.textContent = _labels[key] || key;

    row.appendChild(chk);
    row.appendChild(name);
    row.addEventListener("click", () => selectPart(key));
    wrap.appendChild(row);
  });
}

function renderEditor() {
  const sel = document.getElementById("uk-sel");
  const scale = document.getElementById("uk-scale");
  const scaleVal = document.getElementById("uk-scale-val");
  const xEl = document.getElementById("uk-x");
  const yEl = document.getElementById("uk-y");

  if (!_selected || !_layout || !_layout[_selected]) {
    if (sel) sel.textContent = "— kliknij element, żeby go edytować —";
    [scale, xEl, yEl].forEach((el) => { if (el) el.disabled = true; });
    return;
  }
  const c = _layout[_selected];
  [scale, xEl, yEl].forEach((el) => { if (el) el.disabled = false; });
  if (sel) sel.textContent = _labels[_selected] || _selected;
  if (scale && document.activeElement !== scale) scale.value = Math.round(c.scale * 100);
  if (scaleVal) scaleVal.textContent = Math.round(c.scale * 100) + "%";
  if (xEl && document.activeElement !== xEl) xEl.value = Math.round(c.x);
  if (yEl && document.activeElement !== yEl) yEl.value = Math.round(c.y);
}

function selectPart(key) {
  _selected = key;
  renderCanvas();
  renderPartList();
  renderEditor();
}

async function loadLayout() {
  if (!window.wbApi || typeof window.wbApi.comboGetLayout !== "function") return;
  try {
    const r = await window.wbApi.comboGetLayout();
    if (!r || !r.ok) return;
    _layout = r.layout;
    _parts = r.parts || Object.keys(r.layout);
    _labels = r.labels || {};
    _comboUrl = r.url || "";
    if (!_selected) _selected = _parts[0];
    renderCanvas();
    renderPartList();
    renderEditor();
  } catch (e) {
    console.error("comboGetLayout:", e);
  }
}

function setupDragging() {
  window.addEventListener("mousemove", (e) => {
    if (!_drag || !_layout) return;
    const s = canvasScale();
    const dx = (e.clientX - _drag.startX) / s;
    const dy = (e.clientY - _drag.startY) / s;
    const c = _layout[_drag.part];
    c.x = Math.round(_drag.origX + dx);
    c.y = Math.round(_drag.origY + dy);
    renderCanvas();
    renderEditor();
  });

  // Zapisujemy dopiero po puszczeniu — w trakcie przeciągania byłoby to
  // kilkadziesiąt zapisów na sekundę bez żadnego zysku.
  window.addEventListener("mouseup", async () => {
    if (!_drag) return;
    const part = _drag.part;
    const c = _layout[part];
    _drag = null;
    await pushLayout(part, { x: c.x, y: c.y }, `${_labels[part] || part}: przesunięty`);
  });
}

function setupControls() {
  const scale = document.getElementById("uk-scale");
  if (scale) {
    scale.addEventListener("input", () => {
      if (!_selected || !_layout) return;
      _layout[_selected].scale = Number(scale.value) / 100;
      renderCanvas();
      renderEditor();
    });
    scale.addEventListener("change", () => {
      if (!_selected) return;
      pushLayout(_selected, { scale: Number(scale.value) / 100 },
        `${_labels[_selected] || _selected}: wielkość ${scale.value}%`);
    });
  }

  const xEl = document.getElementById("uk-x");
  const yEl = document.getElementById("uk-y");
  [["x", xEl], ["y", yEl]].forEach(([axis, el]) => {
    if (!el) return;
    el.addEventListener("change", () => {
      if (!_selected || !_layout) return;
      const v = Math.round(Number(el.value) || 0);
      _layout[_selected][axis] = v;
      renderCanvas();
      pushLayout(_selected, { [axis]: v }, `${_labels[_selected] || _selected}: przesunięty`);
    });
  });

  document.querySelectorAll("[data-nudge]").forEach((btn) => {
    btn.addEventListener("click", () => {
      if (!_selected || !_layout) return;
      const d = btn.dataset.nudge;
      const c = _layout[_selected];
      if (d === "up") c.y -= 10;
      else if (d === "down") c.y += 10;
      else if (d === "left") c.x -= 10;
      else if (d === "right") c.x += 10;
      renderCanvas();
      renderEditor();
      pushLayout(_selected, { x: c.x, y: c.y }, `${_labels[_selected] || _selected}: przesunięty`);
    });
  });

  const reset = document.getElementById("uk-reset");
  if (reset) {
    reset.addEventListener("click", async () => {
      if (!window.wbApi || !window.wbApi.comboResetLayout) return;
      const r = await window.wbApi.comboResetLayout();
      if (r && r.ok) {
        _layout = r.layout;
        renderCanvas();
        renderPartList();
        renderEditor();
        setStatus("Przywrócono układ domyślny.");
      }
    });
  }

  const copy = document.getElementById("uk-copy");
  if (copy) {
    copy.addEventListener("click", async () => {
      if (!_comboUrl) return;
      try {
        await window.wbApi.clipboardCopy(_comboUrl);
        setStatus("Skopiowano adres widgetu zbiorczego — wklej go w OBS jako źródło przeglądarki (1080×1920).");
      } catch {
        setStatus(_comboUrl);
      }
    });
  }

  window.addEventListener("resize", renderCanvas);
}

window.addEventListener("DOMContentLoaded", () => {
  setupControls();
  setupDragging();
  loadLayout();
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
