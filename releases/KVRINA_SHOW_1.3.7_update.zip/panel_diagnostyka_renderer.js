// =========================
// KVRINA_SHOW — panel_diagnostyka_renderer.js
// Osobne okienko DIAGNOSTYKA — log, wysyłanie raportów, lista zgłoszeń GitHub.
// Ten sam IPC co wcześniej w głównym oknie (diagGetLog/diagSendReport/diagClearLog/
// diagGetReports/diagCloseIssue/onDiagEntry) — jedno źródło logiki w main.js.
// =========================

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function diagLevelClass(level) {
  return `diag-entry diag-${level}`;
}

async function loadDiagLog() {
  if (!window.wbApi || !window.wbApi.diagGetLog) return;
  const { log, fileLines, version, platform, electron, perf } = await window.wbApi.diagGetLog();

  const sysinfo = document.getElementById("diag-sysinfo");
  if (sysinfo) {
    const perfStr = perf ? ` · heap ${perf.heapUsedMB}MB · rss ${perf.rssMB}MB · cpu ${perf.cpuPct}% · RAM wolna ${perf.freeRamMB}/${perf.totalRamMB}MB` : "";
    sysinfo.textContent = `v${version} · ${platform} · Electron ${electron}${perfStr}`;
  }

  const box = document.getElementById("diag-log-box");
  const count = document.getElementById("diag-log-count");
  if (!box) return;

  const entries = log && log.length ? log : (fileLines || []).map((l) => {
    const m = l.match(/^\[(.+?)\] \[(.+?)\] (.*)$/);
    return m ? { ts: m[1], level: m[2], msg: m[3] } : { ts: "", level: "INFO", msg: l };
  });

  if (count) count.textContent = `${entries.length} wpisów`;
  box.innerHTML = "";
  entries.forEach((e) => {
    const row = document.createElement("div");
    row.className = diagLevelClass(e.level || "INFO");
    row.innerHTML = `<span class="diag-ts">${(e.ts || "").slice(11, 23)}</span><span class="diag-lvl">[${e.level}]</span> <span class="diag-msg">${escapeHtml(e.msg || "")}</span>`;
    box.appendChild(row);
  });
  box.scrollTop = box.scrollHeight;
}

function setupDiag() {
  const btnRefresh = document.getElementById("diag-refresh");
  const btnClear = document.getElementById("diag-clear");
  const btnSend = document.getElementById("diag-send");

  document.querySelectorAll(".diag-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const t = tab.dataset.diagTab;
      document.querySelectorAll(".diag-tab").forEach((b) => b.classList.toggle("active", b.dataset.diagTab === t));
      document.querySelectorAll(".diag-tab-content").forEach((c) => c.classList.toggle("hidden", c.id !== `diag-tab-${t}`));
      if (t === "perf") loadPerf();
    });
  });

  setupPerfTab();

  if (btnRefresh) btnRefresh.addEventListener("click", loadDiagLog);

  if (btnClear) {
    btnClear.addEventListener("click", async () => {
      if (!window.wbApi || !window.wbApi.diagClearLog) return;
      await window.wbApi.diagClearLog();
      loadDiagLog();
    });
  }

  document.querySelectorAll(".diag-type-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diag-type-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  if (btnSend) {
    btnSend.addEventListener("click", async () => {
      const text = (document.getElementById("diag-report-text")?.value || "").trim();
      const activeType = document.querySelector(".diag-type-btn.active");
      const rtype = activeType ? activeType.dataset.rtype : "raport";
      const status = document.getElementById("diag-report-status");

      if (!window.wbApi || !window.wbApi.diagSendReport) return;
      if (status) { status.textContent = "Wysyłam…"; status.className = "diag-report-status"; }
      btnSend.disabled = true;

      const result = await window.wbApi.diagSendReport({ message: text, type: rtype });

      btnSend.disabled = false;
      if (result.ok) {
        if (status) { status.textContent = `✓ Wysłano! Issue #${result.number}`; status.className = "diag-report-status ok"; }
        document.getElementById("diag-report-text").value = "";
      } else {
        if (status) { status.textContent = `✗ Błąd: ${result.error || "nieznany"}`; status.className = "diag-report-status err"; }
      }
    });
  }

  let _currentReportState = "open";
  let _currentIssueNumber = null;

  async function loadReports() {
    if (!window.wbApi || !window.wbApi.diagGetReports) return;
    const list = document.getElementById("diag-reports-list");
    if (!list) return;
    list.innerHTML = `<div class="diag-reports-empty">Ładuję…</div>`;
    const result = await window.wbApi.diagGetReports({ state: _currentReportState });
    list.innerHTML = "";
    if (!result.ok || !result.issues || !result.issues.length) {
      list.innerHTML = `<div class="diag-reports-empty">Brak raportów (${_currentReportState}).</div>`;
      return;
    }
    result.issues.forEach((issue) => {
      const item = document.createElement("div");
      item.className = "diag-report-item";
      const date = new Date(issue.created_at).toLocaleString("pl-PL", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
      const labels = (issue.labels || []).map((l) => `<span class="diag-report-label lbl-${l.name}">${escapeHtml(l.name)}</span>`).join("");
      item.innerHTML = `
        <div class="diag-report-item-head">
          <span class="diag-report-num">#${issue.number}</span>
          <span class="diag-report-title">${escapeHtml(issue.title)}</span>
          <span class="diag-report-date">${date}</span>
        </div>
        <div class="diag-report-labels">${labels}</div>`;
      item.addEventListener("click", () => showReportDetail(issue));
      list.appendChild(item);
    });
  }

  function showReportDetail(issue) {
    _currentIssueNumber = issue.number;
    document.getElementById("diag-reports-list").classList.add("hidden");
    const detail = document.getElementById("diag-report-detail");
    detail.classList.remove("hidden");
    document.getElementById("diag-detail-title").textContent = `#${issue.number} ${issue.title}`;
    document.getElementById("diag-detail-body").textContent = issue.body || "(brak treści)";
    const closeBtn = document.getElementById("diag-detail-close-issue");
    if (closeBtn) closeBtn.style.display = issue.state === "open" ? "" : "none";
  }

  document.getElementById("diag-detail-back")?.addEventListener("click", () => {
    document.getElementById("diag-report-detail")?.classList.add("hidden");
    document.getElementById("diag-reports-list")?.classList.remove("hidden");
    _currentIssueNumber = null;
  });

  document.getElementById("diag-detail-close-issue")?.addEventListener("click", async () => {
    if (!_currentIssueNumber || !window.wbApi?.diagCloseIssue) return;
    const btn = document.getElementById("diag-detail-close-issue");
    btn.disabled = true;
    const r = await window.wbApi.diagCloseIssue({ number: _currentIssueNumber });
    btn.disabled = false;
    if (r.ok) {
      btn.style.display = "none";
      document.getElementById("diag-detail-title").textContent += " ✓ ZAMKNIĘTY";
    }
  });

  document.getElementById("diag-reports-refresh")?.addEventListener("click", loadReports);

  document.querySelectorAll(".diag-filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diag-filter-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      _currentReportState = btn.dataset.filter;
      document.getElementById("diag-reports-list")?.classList.remove("hidden");
      document.getElementById("diag-report-detail")?.classList.add("hidden");
      loadReports();
    });
  });

  document.querySelectorAll(".diag-tab").forEach((tab) => {
    if (tab.dataset.diagTab === "reports") {
      tab.addEventListener("click", () => { if (!document.getElementById("diag-reports-list")?.children.length || document.querySelector(".diag-reports-empty")) loadReports(); });
    }
  });

  if (window.wbApi && window.wbApi.onDiagEntry) {
    window.wbApi.onDiagEntry((entry) => {
      const box = document.getElementById("diag-log-box");
      if (!box) return;
      const row = document.createElement("div");
      row.className = diagLevelClass(entry.level || "INFO");
      row.innerHTML = `<span class="diag-ts">${(entry.ts || "").slice(11, 23)}</span><span class="diag-lvl">[${entry.level}]</span> <span class="diag-msg">${escapeHtml(entry.msg || "")}</span>`;
      box.appendChild(row);
      box.scrollTop = box.scrollHeight;
      const count = document.getElementById("diag-log-count");
      if (count) count.textContent = `${box.children.length} wpisów`;
    });
  }
}

// === ZAKŁADKA WYDAJNOŚĆ ===
// Pokazuje stan maszyny + historię, żeby dało się zobaczyć CO działo się przed
// zacięciem, a nie tylko jak jest w tej chwili.
let _perfTimer = null;

function fmtUptime(sec) {
  const s = Math.max(0, Math.floor(Number(sec) || 0));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  return h > 0 ? `${h} h ${m} min` : `${m} min`;
}

function drawPerfChart(history) {
  const cv = document.getElementById("perf-chart");
  const note = document.getElementById("perf-chart-note");
  if (!cv) return;
  const ctx = cv.getContext("2d");
  const W = cv.width, H = cv.height;
  ctx.clearRect(0, 0, W, H);

  const pts = Array.isArray(history) ? history : [];
  if (pts.length < 2) {
    if (note) note.textContent = "Zbieram dane… wykres pojawi się po kilku minutach.";
    return;
  }
  if (note) {
    const mins = Math.round((pts[pts.length - 1].t - pts[0].t) / 60000);
    note.textContent = `Ostatnie ${mins} min • ${pts.length} próbek`;
  }

  const vals = pts.map((p) => p.rss);
  const max = Math.max(...vals) * 1.15 || 1;
  const x = (i) => (i / (pts.length - 1)) * (W - 8) + 4;
  const y = (v) => H - 12 - (v / max) * (H - 24);

  // siatka
  ctx.strokeStyle = "rgba(255,203,85,0.10)";
  ctx.lineWidth = 1;
  for (let i = 0; i <= 3; i++) {
    const gy = 8 + (i / 3) * (H - 20);
    ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
  }

  // wypełnienie + linia
  const grad = ctx.createLinearGradient(0, 0, 0, H);
  grad.addColorStop(0, "rgba(255,138,32,0.34)");
  grad.addColorStop(1, "rgba(255,138,32,0.02)");
  ctx.beginPath();
  ctx.moveTo(x(0), y(vals[0]));
  vals.forEach((v, i) => ctx.lineTo(x(i), y(v)));
  ctx.lineTo(x(vals.length - 1), H);
  ctx.lineTo(x(0), H);
  ctx.closePath();
  ctx.fillStyle = grad;
  ctx.fill();

  ctx.beginPath();
  ctx.moveTo(x(0), y(vals[0]));
  vals.forEach((v, i) => ctx.lineTo(x(i), y(v)));
  ctx.strokeStyle = "#ffcb55";
  ctx.lineWidth = 2;
  ctx.stroke();

  ctx.fillStyle = "rgba(255,203,85,0.75)";
  ctx.font = "11px Inter, system-ui, sans-serif";
  ctx.fillText(`${Math.round(max)} MB`, 6, 14);
}

async function loadPerf() {
  if (!window.wbApi || typeof window.wbApi.diagGetPerf !== "function") return;
  let r;
  try { r = await window.wbApi.diagGetPerf(); } catch { return; }
  if (!r || !r.ok) return;

  const s = r.snapshot || {};
  const peaks = r.peaks || {};

  const set = (id, txt) => { const el = document.getElementById(id); if (el) el.textContent = txt; };
  set("perf-updated", `Zaktualizowano ${new Date().toLocaleTimeString("pl-PL")}`);
  set("perf-rss", `${s.rssMB} MB`);
  set("perf-rss-peak", `szczyt: ${peaks.maxRssMB || 0} MB`);
  // Na macOS "wolna pamięć" jest zawsze niska (reszta to cache), więc pokazujemy
  // ciśnienie pamięci i swap — dopiero one mówią, czy komputer się dusi.
  const pr = r.pressure || null;
  if (pr && Number.isFinite(pr.freePct)) {
    set("perf-free", `${pr.freePct}%`);
    set("perf-free-min", pr.swapUsedMB > 0 ? `swap: ${pr.swapUsedMB} MB (zrzut na dysk)` : "swap: 0 MB — system nie dusi się");
    const lab = document.querySelector("#perf-free")?.parentElement?.querySelector(".perf-label");
    if (lab) lab.textContent = "WOLNA PAMIĘĆ";
  } else {
    set("perf-free", `${s.freeRamMB} MB`);
    set("perf-free-min", `najmniej: ${peaks.minFreeRamMB ?? "—"} MB z ${Math.round((Number(s.totalRamMB) || 0) / 1024)} GB`);
  }
  set("perf-cpu", `${s.cpuPct}%`);
  set("perf-cpu-peak", `szczyt: ${peaks.maxCpuPct || 0}%`);
  set("perf-uptime", fmtUptime(s.uptime));
  set("perf-load", `obciążenie systemu: ${s.loadAvg}`);

  // Lista najcięższych aplikacji — nasz program podświetlamy, żeby od razu
  // było widać, czy to on obciąża komputer, czy coś zupełnie innego.
  const topBox = document.getElementById("perf-top");
  if (topBox) {
    const list = Array.isArray(r.topMemory) ? r.topMemory : [];
    topBox.innerHTML = "";
    if (!list.length) {
      topBox.textContent = "—";
    } else {
      const max = Math.max(...list.map((p) => p.mb), 1);
      list.forEach((p) => {
        const mine = /KVRINA_SHOW|Electron/i.test(p.name);
        const row = document.createElement("div");
        row.className = "perf-top-row" + (mine ? " is-mine" : "");
        const name = document.createElement("span");
        name.className = "perf-top-name";
        name.textContent = mine ? `${p.name}  ← ten program` : p.name;
        const bar = document.createElement("span");
        bar.className = "perf-top-bar";
        bar.style.width = Math.max(2, Math.round((p.mb / max) * 100)) + "%";
        const val = document.createElement("span");
        val.className = "perf-top-val";
        val.textContent = p.mb + " MB";
        row.appendChild(name);
        row.appendChild(bar);
        row.appendChild(val);
        topBox.appendChild(row);
      });
    }
  }

  // Czy zalecane opcje odciążające są faktycznie włączone na tym komputerze.
  const setBox = document.getElementById("perf-settings");
  if (setBox) {
    const c = r.perfSettings || {};
    setBox.innerHTML = "";
    const add = (label, ok, note) => {
      const row = document.createElement("div");
      row.className = "perf-win-row" + (ok ? "" : " is-hidden");
      const nm = document.createElement("span");
      nm.textContent = label;
      const st = document.createElement("span");
      st.className = "perf-win-state";
      st.textContent = note;
      row.appendChild(nm); row.appendChild(st);
      setBox.appendChild(row);
    };
    add("Tryb oszczędny widgetów", !!c.liteWidgets, c.liteWidgets ? "włączony" : "WYŁĄCZONY — warto włączyć");
    if (c.usesCombo && !c.separateCount) add("Widget zbiorczy w OBS", true, "tak, jedno źródło");
    else if (c.usesCombo) add("Widget zbiorczy w OBS", false, `+ ${c.separateCount} osobnych źródeł`);
    else if (c.separateCount) add("Widget zbiorczy w OBS", false, `NIE — ${c.separateCount} osobnych źródeł`);
    else add("Widgety", false, "żaden nie wczytany");
  }

  // Otwarte okna — niewidoczne oznaczamy, bo to one niepotrzebnie trzymają pamięć.
  const winBox = document.getElementById("perf-windows");
  if (winBox) {
    const ws = Array.isArray(r.windows) ? r.windows : [];
    winBox.innerHTML = "";
    if (!ws.length) {
      winBox.textContent = "—";
    } else {
      ws.forEach((w) => {
        const row = document.createElement("div");
        row.className = "perf-win-row" + (w.visible ? "" : " is-hidden");
        const nm = document.createElement("span");
        nm.textContent = w.name;
        const st = document.createElement("span");
        st.className = "perf-win-state";
        st.textContent = w.visible ? "widoczne" : "otwarte, niewidoczne";
        row.appendChild(nm);
        row.appendChild(st);
        winBox.appendChild(row);
      });
    }
  }

  const auto = document.getElementById("perf-auto-report");
  if (auto && document.activeElement !== auto) auto.checked = r.autoReport !== false;

  const machine = document.getElementById("perf-machine");
  if (machine) {
    machine.textContent = `${r.cpuModel || "?"} • ${r.cpuCount || "?"} rdzeni • ${Math.round((Number(s.totalRamMB) || 0) / 1024)} GB RAM • tunel: ${r.tunnels ?? "?"}`;
  }

  const box = document.getElementById("perf-findings");
  if (box) {
    box.innerHTML = "";
    (r.findings || []).forEach((f) => {
      const d = document.createElement("div");
      d.className = `perf-finding perf-${f.level}`;
      const icon = f.level === "error" ? "🔴" : f.level === "warn" ? "🟡" : f.level === "ok" ? "🟢" : "ℹ️";
      d.textContent = `${icon}  ${f.text}`;
      box.appendChild(d);
    });
  }

  drawPerfChart(r.history);
}

function setupPerfTab() {
  const btn = document.getElementById("perf-refresh");
  if (btn) btn.addEventListener("click", loadPerf);

  const auto = document.getElementById("perf-auto-report");
  if (auto) {
    auto.addEventListener("change", async () => {
      if (!window.wbApi || typeof window.wbApi.diagSetAutoReport !== "function") return;
      try { await window.wbApi.diagSetAutoReport(auto.checked); } catch (e) { console.error("diagSetAutoReport:", e); }
    });
  }

  const send = document.getElementById("perf-send");
  if (send) {
    send.addEventListener("click", async () => {
      if (!window.wbApi || !window.wbApi.diagGetPerfReportText || !window.wbApi.diagSendReport) return;
      const old = send.textContent;
      send.textContent = "WYSYŁAM…";
      send.disabled = true;
      try {
        const t = await window.wbApi.diagGetPerfReportText();
        const res = await window.wbApi.diagSendReport({
          message: `RAPORT WYDAJNOŚCI\n\n${(t && t.text) || "(brak danych)"}`,
          type: "bug",
        });
        send.textContent = res && res.ok ? "WYSŁANO ✓" : "BŁĄD WYSYŁKI";
      } catch {
        send.textContent = "BŁĄD WYSYŁKI";
      }
      setTimeout(() => { send.textContent = old; send.disabled = false; }, 2500);
    });
  }

  // Odświeżaj tylko gdy zakładka jest widoczna — bez sensu mielić w tle.
  if (_perfTimer) clearInterval(_perfTimer);
  _perfTimer = setInterval(() => {
    const tab = document.getElementById("diag-tab-perf");
    if (tab && !tab.classList.contains("hidden")) loadPerf();
  }, 5000);
}

window.addEventListener("DOMContentLoaded", () => {
  loadDiagLog();
  setupDiag();
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
