// =========================
// KVRINA_SHOW — panel_obserwujacy_renderer.js
// Osobne, kompaktowe okienko dla panelu OBSERWUJĄCY. Lekki pop-out: czyta stan
// z lokalnego serwera widgetów (jak widgety OBS), akcje (DODAJ/✎/USUŃ) przekazuje
// do głównego okna przez IPC — identyfikacja przez "ts", zero duplikacji logiki.
// =========================

const WIDGET_STATE_URL = "http://127.0.0.1:8750/widget_state.json";
let lastSignature = "";

async function getState() {
  try {
    const r = await fetch(WIDGET_STATE_URL + "?ts=" + Date.now(), { cache: "no-store" });
    if (!r.ok) throw new Error("state");
    return await r.json();
  } catch (e) {
    return { followQueue: [] };
  }
}

function render(s) {
  const list = Array.isArray(s.followQueue) ? s.followQueue : [];
  const sig = JSON.stringify(list.map((q) => ({ ts: q.ts, nick: q.nick, source: q.source })));
  const countEl = document.getElementById("panel-count");
  countEl.textContent = list.length === 1 ? "1 obserwujący w kolejce" : `${list.length} obserwujących w kolejce`;

  if (sig === lastSignature) return;
  lastSignature = sig;

  const box = document.getElementById("panel-list");
  box.innerHTML = "";

  if (!list.length) {
    const div = document.createElement("div");
    div.className = "queue-item queue-empty";
    div.textContent = "Czekam na obserwacje i gifty 450+…";
    box.appendChild(div);
    return;
  }

  list.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "queue-item follow-queue-item" + (item.source === "gift450" ? " is-gift-candidate" : "");

    const left = document.createElement("div");
    left.className = "follow-queue-left";

    const nick = document.createElement("span");
    nick.className = "follow-queue-nick";
    nick.textContent = `${idx + 1}. ${item.nick}`;

    const meta = document.createElement("span");
    meta.className = "follow-queue-meta";
    if (item.source === "gift450") meta.textContent = `GIFT ${item.giftCoins || 450}+ monet${item.giftName ? " • " + item.giftName : ""}`;
    else meta.textContent = "OBSERWUJĄCY";

    left.appendChild(nick);
    left.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "follow-queue-actions";

    const addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.className = "follow-add-btn";
    addBtn.textContent = "DODAJ";
    addBtn.title = `Dodaj ${item.nick} do kolejki pytań`;
    addBtn.addEventListener("click", () => window.wbApi.panelFollowAdd({ ts: item.ts }));

    const editBtn = document.createElement("button");
    editBtn.type = "button";
    editBtn.className = "follow-remove-btn";
    editBtn.textContent = "✎";
    editBtn.title = `Zmień nick ${item.nick}`;
    editBtn.style.cssText = "padding:0 8px;font-size:14px;";
    editBtn.addEventListener("click", () => {
      const newNick = prompt("Nowy nick:", item.nick);
      if (newNick && newNick.trim()) window.wbApi.panelFollowEdit({ ts: item.ts, nick: newNick.trim() });
    });

    const delBtn = document.createElement("button");
    delBtn.type = "button";
    delBtn.className = "follow-remove-btn";
    delBtn.textContent = "USUŃ";
    delBtn.title = `Usuń ${item.nick} z listy`;
    delBtn.addEventListener("click", () => window.wbApi.panelFollowRemove({ ts: item.ts }));

    actions.appendChild(addBtn);
    actions.appendChild(editBtn);
    actions.appendChild(delBtn);
    row.appendChild(left);
    row.appendChild(actions);
    box.appendChild(row);
  });
}

async function loop() {
  try { render(await getState()); } catch (e) { console.error("panel_obserwujacy render:", e); }
}

window.addEventListener("DOMContentLoaded", () => {
  loop();
  setInterval(loop, 1000);
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
