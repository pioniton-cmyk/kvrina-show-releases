// =========================
// KVRINA_SHOW — reader_renderer.js
// Tryb okienka: lekki pop-out, TYLKO wyświetla dane (czyta z tego samego
// lokalnego serwera co widgety OBS) i przekazuje DALEJ/WSTECZ/przesuwanie/edycję
// do głównego okna. Żadna logika kolejki/pytań nie jest tu duplikowana —
// to zdalny podgląd + pilot.
// =========================

const WIDGET_STATE_URL = "http://127.0.0.1:8750/widget_state_lite.json";
const KARTON_DNIA_TEXT = "KARTON DNIA";

async function getState() {
  try {
    const r = await fetch(WIDGET_STATE_URL + "?ts=" + Date.now(), { cache: "no-store" });
    if (!r.ok) throw new Error("state");
    return await r.json();
  } catch (e) {
    return { current: { nick: "TERAZ TY", text: "LINK W BIO", type: "empty" }, queue: [] };
  }
}

let lastSignature = "";

// 2-4 PYTANIA, 5+ PYTAŃ (i 12-14 też PYTAŃ) — inaczej wychodzi "5 PYTANIA".
function plPytania(n) {
  const num = Math.abs(parseInt(n, 10) || 0);
  const last = num % 10;
  const lastTwo = num % 100;
  if (last >= 2 && last <= 4 && !(lastTwo >= 12 && lastTwo <= 14)) return "PYTANIA";
  return "PYTAŃ";
}

function formatPLN(amount) {
  const n = Number(amount) || 0;
  const parts = n.toFixed(2).split(".");
  const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${intPart},${parts[1]} zł`;
}

function renderStatus(s) {
  const liveEl = document.getElementById("reader-status-live");
  const webhookEl = document.getElementById("reader-status-webhook");
  const fundsValEl = document.getElementById("reader-top-funds-val");

  // Kolory: zielony = połączony, żółty = łączy się, czerwony = błąd / nie połączony.
  const state = s.liveState || (s.liveConnected ? "connected" : "offline");
  if (state === "connected") {
    const src = s.liveSource || "TikTok";
    const who = s.tiktokUsername ? ` @${s.tiktokUsername}` : "";
    liveEl.textContent = `Live: ✓ ${src}${who}`;
    liveEl.className = "status-pill status-ok";
  } else if (state === "connecting") {
    liveEl.textContent = "Live: łączenie…";
    liveEl.className = "status-pill status-warn";
  } else if (state === "error") {
    liveEl.textContent = "Live: błąd połączenia";
    liveEl.className = "status-pill status-err";
  } else {
    liveEl.textContent = "Live: offline";
    liveEl.className = "status-pill status-err";
  }

  if (s.webhookRunning) {
    webhookEl.textContent = "Webhook: ✓ połączony";
    webhookEl.className = "status-pill status-ok";
  } else {
    webhookEl.textContent = "Webhook: offline";
    webhookEl.className = "status-pill status-err";
  }

  if (fundsValEl) fundsValEl.textContent = formatPLN(Number(s.fundsTotal) || 0);

  if (_isDevMode) {
    const toggleEl = document.getElementById("reader-webhook-toggle");
    if (toggleEl) {
      if (s.webhookRunning) {
        toggleEl.textContent = "Webhook DEV: ✓ włączony";
        toggleEl.className = "status-pill status-ok";
      } else {
        toggleEl.textContent = "Webhook DEV: wyłączony";
        toggleEl.className = "status-pill status-info";
      }
    }
  }

  _lastCountdown = s.countdown || null;
  _liveConnected = !!s.liveConnected;
  _liveUsername = s.tiktokUsername || null;
  updateConnectPopState();
}

// === Przełącznik webhooka Tipped — widoczny TYLKO w wersji dev (electron . z folderu źródłowego). ===
// Zapakowane wersje (w tym aktualizacje z GitHub) startują webhook automatycznie jak dotychczas.
let _isDevMode = false;
async function setupReaderWebhookToggle() {
  const toggleEl = document.getElementById("reader-webhook-toggle");
  if (!toggleEl || !window.wbApi || typeof window.wbApi.isDev !== "function") return;
  try {
    const { isDev } = await window.wbApi.isDev();
    _isDevMode = !!isDev;
  } catch {
    _isDevMode = false;
  }
  if (!_isDevMode) return;
  toggleEl.style.display = "";
  toggleEl.addEventListener("click", async () => {
    const currentlyOn = toggleEl.textContent.includes("✓");
    toggleEl.textContent = "Webhook DEV: …";
    try {
      await window.wbApi.webhookSetEnabled(!currentlyOn);
    } catch (e) {
      console.error("webhookSetEnabled:", e);
    }
  });
}

// === Połączenie z TikTok LIVE — wysuwane prawym klikiem na status „Live" ===
const TIKTOK_USER_KEY = "kvrina_tiktok_username";
let _liveConnected = false;
let _liveUsername = null;

function updateConnectPopState() {
  const pop = document.getElementById("reader-connect-pop");
  if (!pop || pop.classList.contains("hidden")) return;
  const statusEl = document.getElementById("rc-status");
  const connectBtn = document.getElementById("rc-connect");
  const disconnectBtn = document.getElementById("rc-disconnect");
  if (_liveConnected) {
    if (statusEl) statusEl.textContent = `Połączony${_liveUsername ? " @" + _liveUsername : ""}`;
    if (statusEl) statusEl.className = "rc-status ok";
    if (connectBtn) connectBtn.textContent = "POŁĄCZ PONOWNIE";
    if (disconnectBtn) disconnectBtn.classList.remove("hidden");
  } else {
    if (statusEl) statusEl.textContent = "Niepołączony";
    if (statusEl) statusEl.className = "rc-status";
    if (connectBtn) connectBtn.textContent = "POŁĄCZ";
    if (disconnectBtn) disconnectBtn.classList.add("hidden");
  }
}

function setupReaderConnect() {
  const pill = document.getElementById("reader-status-live");
  const pop = document.getElementById("reader-connect-pop");
  const input = document.getElementById("rc-username");
  const connectBtn = document.getElementById("rc-connect");
  const disconnectBtn = document.getElementById("rc-disconnect");
  if (!pill || !pop || !input) return;

  // Okienko urosło o sekcję klucza, a czytnik bywa niski i ma własne powiększenie
  // (CSS `zoom`, przez które vh nie odpowiada realnej wysokości okna). Liczymy
  // wysokość sami, żeby dało się dojechać do przycisków na dole bez rozciągania okna.
  const dopasujPop = () => {
    const app = document.getElementById("reader-app");
    if (!app) return;
    const top = pop.offsetTop || 44;
    pop.style.maxHeight = Math.max(160, app.clientHeight - top - 8) + "px";
    pop.style.overflowY = "auto";
    pop.style.width = Math.min(320, Math.max(200, app.clientWidth - 20)) + "px";
  };

  const openPop = () => {
    try { input.value = localStorage.getItem(TIKTOK_USER_KEY) || ""; } catch {}
    pop.classList.remove("hidden");
    pop.scrollTop = 0;
    updateConnectPopState();
    dopasujPop();
    setTimeout(() => input.focus(), 50);
  };

  window.addEventListener("resize", () => { if (!pop.classList.contains("hidden")) dopasujPop(); });
  window.addEventListener("kvrina-reader-zoom", () => { if (!pop.classList.contains("hidden")) dopasujPop(); });
  const closePop = () => pop.classList.add("hidden");

  // Prawy klik na status „Live" otwiera/zamyka okienko połączenia.
  pill.addEventListener("contextmenu", (e) => {
    e.preventDefault();
    if (pop.classList.contains("hidden")) openPop(); else closePop();
  });

  const doConnect = async () => {
    const raw = String(input.value || "").trim().replace(/^@/, "");
    if (!raw) { input.focus(); return; }
    try { localStorage.setItem(TIKTOK_USER_KEY, raw); } catch {}
    const statusEl = document.getElementById("rc-status");
    if (statusEl) { statusEl.textContent = "Łączenie…"; statusEl.className = "rc-status connecting"; }
    try { await window.wbApi.tiktokConnect({ username: raw }); } catch (e) { console.error("tiktokConnect:", e); }
    closePop();
  };

  if (connectBtn) connectBtn.addEventListener("click", doConnect);
  input.addEventListener("keydown", (e) => { if (e.key === "Enter") doConnect(); });

  if (disconnectBtn) disconnectBtn.addEventListener("click", async () => {
    // Rozłączenie „zapomina" nick — program przestaje się auto-łączyć.
    try { localStorage.removeItem(TIKTOK_USER_KEY); } catch {}
    try { await window.wbApi.tiktokDisconnect(); } catch (e) { console.error("tiktokDisconnect:", e); }
    input.value = "";
    closePop();
  });

  // Zamknij po kliknięciu poza okienkiem / Escape.
  document.addEventListener("click", (e) => {
    if (!pop.classList.contains("hidden") && !pop.contains(e.target) && e.target !== pill) closePop();
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape") closePop(); });

  setupReaderEulerKey(openPop);
}

// === KLUCZ EULER STREAM ===
// Bez klucza TikTok odrzuca podpisanie połączenia (darmowy limit przestał wystarczać).
// Pole było dotąd tylko w ukrytym oknie głównym, do którego z czytnika nie ma dojścia —
// dlatego siedzi teraz razem z nickiem twórcy. Cała logika (zapis/test/usunięcie) już
// istniała po stronie programu, tu podpinamy do niej przyciski.
function setupReaderEulerKey(openPop) {
  const input = document.getElementById("rc-key");
  const pill = document.getElementById("rc-key-pill");
  const statusEl = document.getElementById("rc-key-status");
  if (!input || !pill) return;

  const setStatus = (text, kind) => {
    if (!statusEl) return;
    statusEl.textContent = text;
    statusEl.className = "rc-status" + (kind ? " " + kind : "");
  };

  const odswiezStan = async () => {
    if (!window.wbApi || typeof window.wbApi.eulerKeyStatus !== "function") {
      pill.textContent = "niedostępne";
      pill.className = "rc-pill";
      return;
    }
    try {
      const s = await window.wbApi.eulerKeyStatus();
      if (s && s.hasKey) {
        pill.textContent = "zapisany " + (s.masked || "");
        pill.className = "rc-pill ok";
      } else {
        pill.textContent = "BRAK";
        pill.className = "rc-pill err";
      }
    } catch {
      pill.textContent = "—";
      pill.className = "rc-pill";
    }
  };

  const showBtn = document.getElementById("rc-key-show");
  if (showBtn) showBtn.addEventListener("click", () => {
    input.type = input.type === "password" ? "text" : "password";
    input.focus();
  });

  const saveBtn = document.getElementById("rc-key-save");
  if (saveBtn) saveBtn.addEventListener("click", async () => {
    const key = String(input.value || "").trim();
    if (!key) { setStatus("Najpierw wklej klucz.", "err"); input.focus(); return; }
    setStatus("Zapisuję…", "connecting");
    try {
      const r = await window.wbApi.eulerKeySet(key);
      if (r && r.ok) {
        input.value = "";
        input.type = "password";
        setStatus("Zapisany. Połącz się ponownie, żeby go użyć.", "ok");
      } else {
        setStatus((r && r.error) || "Nie udało się zapisać klucza.", "err");
      }
    } catch (e) {
      setStatus("Błąd zapisu: " + (e && e.message ? e.message : e), "err");
    }
    odswiezStan();
  });

  const testBtn = document.getElementById("rc-key-test");
  if (testBtn) testBtn.addEventListener("click", async () => {
    // Puste pole = sprawdzamy klucz już zapisany, a nie nic.
    const key = String(input.value || "").trim();
    setStatus("Sprawdzam w Euler Stream…", "connecting");
    try {
      const r = await window.wbApi.eulerKeyTest(key);
      if (r && r.ok) {
        const d = r.day || {};
        const limit = (d.remaining !== undefined && d.max !== undefined)
          ? ` — dziś zostało ${d.remaining} z ${d.max}` : "";
        setStatus("Klucz działa" + limit + ".", "ok");
      } else {
        setStatus((r && r.error) || "Klucz nie działa.", "err");
      }
    } catch (e) {
      setStatus("Błąd sprawdzania: " + (e && e.message ? e.message : e), "err");
    }
  });

  const clearBtn = document.getElementById("rc-key-clear");
  if (clearBtn) clearBtn.addEventListener("click", async () => {
    if (!confirm("Usunąć zapisany klucz Euler Stream?\n\nBez klucza TikTok odrzuci połączenie.")) return;
    try {
      await window.wbApi.eulerKeyClear();
      input.value = "";
      setStatus("Klucz usunięty.", "err");
    } catch (e) {
      setStatus("Błąd usuwania: " + (e && e.message ? e.message : e), "err");
    }
    odswiezStan();
  });

  // Enter w polu = zapisz (tak jak Enter przy nicku łączy).
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && saveBtn) saveBtn.click(); });

  // Program potrafi zmienić klucz z innego okna — nasłuchujemy, żeby plakietka nie kłamała.
  try {
    if (window.wbApi && typeof window.wbApi.onEulerKeyChanged === "function") {
      window.wbApi.onEulerKeyChanged(() => odswiezStan());
    }
  } catch {}

  odswiezStan();
  // Stan odświeżamy też przy każdym otwarciu okienka — plakietka ma być aktualna.
  if (typeof openPop === "function") {
    const pill2 = document.getElementById("reader-status-live");
    if (pill2) pill2.addEventListener("contextmenu", () => setTimeout(odswiezStan, 0));
  }
}

// === LICZNIK CZASU DO WPISANIA (topbar) ===
const COUNTDOWN_H_KEY = "kvrina_countdown_h";
const COUNTDOWN_M_KEY = "kvrina_countdown_m";
let _lastCountdown = null;

function fmtCountdown(ms) {
  const t = Math.max(0, Math.floor(Number(ms) || 0) / 1000);
  const h = Math.floor(t / 3600);
  const m = Math.floor((t % 3600) / 60);
  const s = Math.floor(t % 60);
  const pad = (n) => String(n).padStart(2, "0");
  return h > 0 ? `${h}:${pad(m)}:${pad(s)}` : `${m}:${pad(s)}`;
}

function updateCountdownDisplay() {
  const disp = document.getElementById("countdown-display");
  if (!disp) return;
  const c = _lastCountdown;
  disp.classList.remove("cd-running", "cd-armed", "cd-soon", "cd-done");
  if (!c || !c.armed) { disp.textContent = "—"; return; }
  if (c.started && c.endsAt) {
    const remaining = Math.max(0, c.endsAt - Date.now());
    disp.textContent = fmtCountdown(remaining);
    if (remaining <= 0) disp.classList.add("cd-done");
    else if (remaining <= 15 * 60 * 1000) disp.classList.add("cd-soon");
    else disp.classList.add("cd-running");
  } else {
    // Uzbrojony, czeka na pierwszy komentarz — pokaż ustawiony czas (przygaszony).
    disp.textContent = fmtCountdown(c.durationMs);
    disp.classList.add("cd-armed");
  }
}

function setupReaderCountdown() {
  const hEl = document.getElementById("countdown-h");
  const mEl = document.getElementById("countdown-m");
  if (!hEl || !mEl) return;

  try {
    const h = localStorage.getItem(COUNTDOWN_H_KEY);
    const m = localStorage.getItem(COUNTDOWN_M_KEY);
    if (h !== null) hEl.value = h;
    if (m !== null) mEl.value = m;
  } catch {}

  const push = () => {
    const hours = Math.max(0, Math.min(23, parseInt(hEl.value, 10) || 0));
    const minutes = Math.max(0, Math.min(59, parseInt(mEl.value, 10) || 0));
    try {
      localStorage.setItem(COUNTDOWN_H_KEY, String(hours));
      localStorage.setItem(COUNTDOWN_M_KEY, String(minutes));
    } catch {}
    try { window.wbApi.readerSetCountdown({ hours, minutes }); } catch (e) { console.error("countdown set:", e); }
  };

  hEl.addEventListener("change", push);
  mEl.addEventListener("change", push);

  // Zsynchronizuj stan początkowy z głównym oknem (silnikiem). Ponawiamy raz po chwili,
  // gdyby okno-silnik nie zdążyło zarejestrować odbioru przy starcie (wyścig).
  push();
  setTimeout(push, 2000);

  // Płynne odliczanie w wyświetlaczu (niezależne od pollingu stanu).
  updateCountdownDisplay();
  setInterval(updateCountdownDisplay, 500);
}

function render(s) {
  const current = s.current || {};
  const isEmpty = current.type === "empty";

  const nickEl = document.getElementById("question-nick");
  const textEl = document.getElementById("question-text");

  nickEl.textContent = isEmpty ? "Brak pytań" : String(current.nickRaw || current.nick || "-");
  if (isEmpty) {
    textEl.textContent = "";
  } else if (String(current.text || "").trim().toLowerCase() === "x") {
    textEl.textContent = "CZEKAM NA PYTANIE";
  } else {
    textEl.textContent = current.text || "";
  }

  // Plakietki nad nickiem czytanej osoby: ile pytań wykupiła i czy to EKSPRES.
  const tagsEl = document.getElementById("question-tags");
  if (tagsEl) {
    const curCount = Math.max(1, parseInt(current.questionCount, 10) || 1);
    const curExpress = !isEmpty && !!current.priority;
    const curTakNie = !isEmpty && current.type === "taknie";
    const want = (curTakNie ? "T" : "") + (curExpress ? "E" : "") + (!isEmpty && curCount > 1 ? curCount : "");
    if (tagsEl.dataset.sig !== want) {
      tagsEl.dataset.sig = want;
      tagsEl.innerHTML = "";
      if (curTakNie) {
        const t = document.createElement("span");
        t.className = "question-tag is-taknie-tag";
        t.textContent = "PYTANIE TAK / NIE — ODPOWIEDZ JEDNYM SŁOWEM";
        tagsEl.appendChild(t);
      }
      if (curExpress) {
        const e = document.createElement("span");
        e.className = "question-tag is-express-tag";
        e.textContent = "⚡ EKSPRES — POZA KOLEJKĄ";
        tagsEl.appendChild(e);
      }
      if (!isEmpty && curCount > 1) {
        const c = document.createElement("span");
        c.className = "question-tag is-count-tag";
        c.textContent = `${curCount} ${plPytania(curCount)} W JEDNYM WPISIE`;
        tagsEl.appendChild(c);
      }
    }
  }

  const queue = Array.isArray(s.queue) ? s.queue : [];

  renderStatus(s);
  renderReaderRanking(s);

  // Etykieta DEMO w menu mówi, co zrobi kliknięcie — bez tego przy włączonym demo
  // dalej było napisane "DEMO LIVE" i nie było widać, że tryb już działa.
  const demoBtn = document.querySelector('#reader-menu .reader-menu-btn[data-action="demo"]');
  if (demoBtn) {
    const label = s.demoMode ? "WYJDŹ Z DEMO" : "DEMO LIVE";
    if (demoBtn.textContent !== label) {
      demoBtn.textContent = label;
      demoBtn.classList.toggle("danger", !!s.demoMode);
      demoBtn.classList.toggle("demo", !s.demoMode);
    }
  }

  const sig = JSON.stringify({ current, queue: queue.map((q) => ({ ts: q.ts, nick: q.nick, text: q.text, type: q.type, priority: !!q.priority, questionCount: q.questionCount })) });
  if (sig === lastSignature) return;
  lastSignature = sig;

  const listEl = document.getElementById("reader-queue-list");

  listEl.innerHTML = "";

  if (!isEmpty) {
    listEl.appendChild(buildRow(current, "TERAZ", true));
  }

  if (!queue.length && isEmpty) {
    const empty = document.createElement("div");
    empty.className = "question-queue-empty";
    empty.textContent = "Czekam na pytania i kartony…";
    listEl.appendChild(empty);
    return;
  }

  queue.forEach((item, i) => {
    listEl.appendChild(buildRow(item, String(i + 1), false, i === 0, i === queue.length - 1));
  });
}

// === RANKING WIDZÓW W CZYTNIKU ===
// Ten sam stan co panel w osobnym okienku — tylko wyświetlany pod kolejką,
// żeby nie trzeba było trzymać drugiego okna (i drugiego procesu) otwartego.
const READER_RANKING_KEY = "kvrina_reader_ranking_open";
let _readerRankingSig = "";

function setupReaderRanking() {
  const wrap = document.getElementById("reader-ranking");
  const head = document.getElementById("reader-ranking-head");
  if (!wrap || !head) return;

  let open = true;
  try {
    const saved = localStorage.getItem(READER_RANKING_KEY);
    if (saved === "0") open = false;
  } catch {}
  const apply = () => {
    wrap.classList.toggle("collapsed", !open);
    head.setAttribute("aria-expanded", open ? "true" : "false");
  };
  apply();

  head.addEventListener("click", () => {
    open = !open;
    apply();
    try { localStorage.setItem(READER_RANKING_KEY, open ? "1" : "0"); } catch {}
  });
}

function renderReaderRanking(s) {
  const box = document.getElementById("reader-ranking-list");
  const countEl = document.getElementById("reader-ranking-count");
  if (!box) return;

  const ranking = Array.isArray(s.ranking) ? s.ranking : [];
  if (countEl) countEl.textContent = ranking.length === 1 ? "1 osoba" : `${ranking.length} osób`;

  const sig = JSON.stringify(ranking.map((r) => [r.nick, r.likes ?? r.points]));
  if (sig === _readerRankingSig) return;
  _readerRankingSig = sig;

  box.innerHTML = "";

  if (!ranking.length) {
    const empty = document.createElement("div");
    empty.className = "ranking-preview-empty";
    empty.textContent = "Czekam na komentarze, tapy, followy i share…";
    box.appendChild(empty);
    return;
  }

  ranking.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "ranking-preview-item";

    const place = document.createElement("div");
    place.className = "ranking-preview-place";
    place.textContent = `#${idx + 1}`;

    const main = document.createElement("div");
    main.className = "ranking-preview-main";

    const nick = document.createElement("div");
    nick.className = "ranking-preview-nick";
    nick.textContent = String(item.nick || "-");

    const likes = document.createElement("div");
    likes.className = "ranking-preview-likes";
    likes.textContent = `♥ ${Number(item.likes || item.points || 0) || 0} pkt`;

    main.appendChild(nick);
    main.appendChild(likes);

    const add = document.createElement("button");
    add.type = "button";
    add.className = "ranking-preview-add";
    add.textContent = "DODAJ";
    add.title = `Dodaj ${item.nick} do kolejki pytań`;
    add.addEventListener("click", () => {
      try { window.wbApi.panelRankingAdd({ nick: item.nick }); } catch (e) { console.error("ranking add:", e); }
    });

    row.appendChild(place);
    row.appendChild(main);
    row.appendChild(add);
    box.appendChild(row);
  });
}

function buildRow(item, label, isCurrent, isFirst, isLast) {
  const isKarton = item.type === "karton";
  const isWaiting = item.type === "waiting";
  const isShortfall = item.type === "shortfall";
  const isTakNie = item.type === "taknie";
  const isExpress = !!item.priority;
  const count = Math.max(1, parseInt(item.questionCount, 10) || 1);

  const row = document.createElement("div");
  row.className = "question-queue-item"
    + (isCurrent ? " is-current" : "")
    + (isKarton ? " is-karton" : "")
    + (isShortfall ? " is-shortfall" : "")
    + (isTakNie ? " is-taknie" : "")
    + (isExpress ? " is-express" : "")
    + (isWaiting ? " is-waiting" : "");

  const num = document.createElement("div");
  num.className = "question-queue-num";
  num.textContent = isCurrent ? "▶" : label;

  const main = document.createElement("div");
  main.className = "question-queue-main";

  const badgeRow = document.createElement("div");
  badgeRow.className = "question-queue-badge-row";

  const badge = document.createElement("div");
  badge.className = "question-queue-badge";
  badge.textContent = isCurrent ? "TERAZ" : (isShortfall ? "DOPŁATA" : (isKarton ? "KARTON" : (isTakNie ? "TAK/NIE" : (isWaiting ? "CZEKA" : "PYTANIE"))));
  badgeRow.appendChild(badge);

  // TAK/NIE (15 zł) — krótkie pytanie zamknięte. Przy czytanym wpisie plakietka typu
  // zamienia się na "TERAZ", więc kategoria dostaje własną, żeby nie zniknęła.
  if (isTakNie && isCurrent) {
    const tn = document.createElement("div");
    tn.className = "question-queue-tag is-taknie-tag";
    tn.textContent = "TAK/NIE";
    tn.title = "Pytanie zamknięte za 15 zł — odpowiedź TAK albo NIE";
    badgeRow.appendChild(tn);
  }

  // EKSPRES — wpłata 100 zł, wchodzi poza kolejką. Ma być widać na pierwszy rzut oka.
  if (isExpress) {
    const exp = document.createElement("div");
    exp.className = "question-queue-tag is-express-tag";
    exp.textContent = "⚡ EKSPRES";
    exp.title = "Pytanie poza kolejką (wpłata 100 zł)";
    badgeRow.appendChild(exp);
  }

  // Ile pytań wykupiła ta osoba — plakietka zamiast dopisku przy nicku.
  if (count > 1) {
    const cnt = document.createElement("div");
    cnt.className = "question-queue-tag is-count-tag";
    cnt.textContent = `${count} PYT`;
    cnt.title = `Ta osoba wykupiła ${count} pytania/pytań`;
    badgeRow.appendChild(cnt);
  }

  const nick = document.createElement("div");
  nick.className = "question-queue-nick";
  // nickRaw = sam nick; starsze wersje stanu miały tylko `nick` z dopiskiem „— 3 PYT".
  nick.textContent = String(item.nickRaw || item.nick || "-");

  const preview = document.createElement("div");
  preview.className = "question-queue-preview";
  preview.textContent = isShortfall ? (item.text || "") : (isKarton ? KARTON_DNIA_TEXT : (String(item.text || "").trim().toLowerCase() === "x" ? "CZEKAM NA PYTANIE" : (item.text || "")));

  main.appendChild(badgeRow);
  main.appendChild(nick);
  main.appendChild(preview);

  row.appendChild(num);
  row.appendChild(main);

  // Przesuwanie — tylko dla pozycji w kolejce (nie dla aktualnie czytanej "TERAZ",
  // której pozycję zmienia się przez WSTECZ/DALEJ/POMIŃ, nie strzałkami).
  // Edycja — dla WSZYSTKICH wpisów, łącznie z aktualnie czytanym.
  if (item.ts) {
    const actions = document.createElement("div");
    actions.className = "question-queue-actions";

    if (!isCurrent) {
      const up = document.createElement("button");
      up.type = "button";
      up.className = "question-queue-move";
      up.textContent = "↑";
      up.title = "Przesuń wyżej";
      up.disabled = !!isFirst;
      up.addEventListener("click", (e) => { e.stopPropagation(); window.wbApi.readerQueueMove({ ts: item.ts, direction: "up" }); });

      const down = document.createElement("button");
      down.type = "button";
      down.className = "question-queue-move";
      down.textContent = "↓";
      down.title = "Przesuń niżej";
      down.disabled = !!isLast;
      down.addEventListener("click", (e) => { e.stopPropagation(); window.wbApi.readerQueueMove({ ts: item.ts, direction: "down" }); });

      actions.appendChild(up);
      actions.appendChild(down);
    }

    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "question-queue-move edit";
    edit.textContent = "✎";
    edit.title = "Edytuj wpis";
    edit.addEventListener("click", (e) => { e.stopPropagation(); openReaderEditModal(item); });

    actions.appendChild(edit);

    // Usuwanie — dla WSZYSTKICH wpisów, także aktualnie czytanego. Potwierdzenie jest tutaj,
    // bo tylko tu wiadomo, w co prowadząca faktycznie kliknęła.
    const del = document.createElement("button");
    del.type = "button";
    del.className = "question-queue-move delete";
    del.textContent = "✕";
    del.title = "Usuń z kolejki";
    del.addEventListener("click", (e) => {
      e.stopPropagation();
      const kto = String(item.nick || "ten wpis");
      if (!confirm(`Usunąć z kolejki: ${kto}?`)) return;
      window.wbApi.readerQueueRemove({ ts: item.ts });
    });
    actions.appendChild(del);

    row.appendChild(actions);
  }

  // Kliknięcie w wiersz kolejki (poza przyciskami) wskakuje z tą osobą do czytania —
  // reszta (łącznie z tym co było TERAZ) spada pod nią, zachowując kolejność.
  if (!isCurrent && item.ts) {
    row.classList.add("is-jumpable");
    row.title = "Kliknij, aby przejść do czytania tej osoby teraz";
    row.addEventListener("click", (e) => {
      if (e.target.closest(".question-queue-actions")) return;
      window.wbApi.readerQueueJump({ ts: item.ts });
    });
  }

  return row;
}

// === Lekki modal edycji/dodawania (własna kopia, działa wyłącznie w tym oknie) ===
let _editingTs = null;
let _readerModalMode = "edit"; // "edit" | "add"

function fillReaderModalType(type) {
  document.querySelectorAll(".entry-type-btn").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.type === type);
  });
  const questionRow = document.getElementById("reader-edit-question-row");
  // TAK/NIE też ma treść pytania — pole musi zostać widoczne.
  if (questionRow) questionRow.style.display = (type === "pytanie" || type === "taknie") ? "" : "none";
}

function openReaderEditModal(item) {
  const modal = document.getElementById("reader-edit-modal");
  if (!modal) return;

  const isKarton = item.type === "karton";
  const isWaiting = item.type === "waiting";
  const isTakNieItem = item.type === "taknie";
  const type = isKarton ? "karton" : (isTakNieItem ? "taknie" : (isWaiting ? "czekam" : "pytanie"));

  _readerModalMode = "edit";
  _editingTs = item.ts;
  const title = document.getElementById("reader-edit-title");
  if (title) title.textContent = "EDYTUJ WPIS";
  document.getElementById("reader-edit-nick").value = item.nick || "";
  const trescWpisu = String(item.text || "");
  // "CZEKAM NA PYTANIE" to podpis zastępczy, nie treść — nie wolno go wstawiać do pola.
  const trescRealna = trescWpisu.trim().toUpperCase() === "CZEKAM NA PYTANIE" ? "" : trescWpisu;
  document.getElementById("reader-edit-question").value = (!isKarton && !isWaiting) ? trescRealna : "";
  fillReaderModalType(type);

  // Tipped tylko przy dodawaniu — w edycji chowamy.
  const tippedRow = document.getElementById("reader-edit-tipped-row");
  if (tippedRow) tippedRow.classList.add("hidden");

  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  setTimeout(() => document.getElementById("reader-edit-nick").focus(), 50);
}

// Ręczne dodanie nowego wpisu do kolejki (przycisk „+" między czytnikiem a kolejką).
function openReaderAddModal() {
  const modal = document.getElementById("reader-edit-modal");
  if (!modal) return;

  _readerModalMode = "add";
  _editingTs = null;
  const title = document.getElementById("reader-edit-title");
  if (title) title.textContent = "DODAJ WPIS RĘCZNIE";
  document.getElementById("reader-edit-nick").value = "";
  document.getElementById("reader-edit-question").value = "";
  fillReaderModalType("pytanie");

  // Tipped — pokazujemy i zerujemy tylko przy ręcznym dodawaniu.
  const tippedRow = document.getElementById("reader-edit-tipped-row");
  const tippedChk = document.getElementById("reader-edit-tipped");
  const tippedAmtRow = document.getElementById("reader-edit-tipped-amount-row");
  const tippedAmt = document.getElementById("reader-edit-tipped-amount");
  if (tippedRow) tippedRow.classList.remove("hidden");
  if (tippedChk) tippedChk.checked = false;
  if (tippedAmt) tippedAmt.value = "";
  if (tippedAmtRow) tippedAmtRow.classList.add("hidden");

  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  setTimeout(() => document.getElementById("reader-edit-nick").focus(), 50);
}

function closeReaderEditModal() {
  const modal = document.getElementById("reader-edit-modal");
  if (modal) { modal.classList.add("hidden"); modal.setAttribute("aria-hidden", "true"); }
  _editingTs = null;
  _readerModalMode = "edit";
}

function setupReaderEditModal() {
  const backdrop = document.getElementById("reader-edit-backdrop");
  const cancelBtn = document.getElementById("reader-edit-cancel");
  const saveBtn = document.getElementById("reader-edit-save");
  const questionRow = document.getElementById("reader-edit-question-row");

  if (backdrop) backdrop.addEventListener("click", closeReaderEditModal);
  if (cancelBtn) cancelBtn.addEventListener("click", closeReaderEditModal);

  document.querySelectorAll(".entry-type-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".entry-type-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      if (questionRow) questionRow.style.display = (btn.dataset.type === "pytanie" || btn.dataset.type === "taknie") ? "" : "none";
    });
  });

  // Zaznaczenie „Tipped" pokazuje pole kwoty.
  const tippedChk = document.getElementById("reader-edit-tipped");
  const tippedAmtRow = document.getElementById("reader-edit-tipped-amount-row");
  const tippedAmt = document.getElementById("reader-edit-tipped-amount");
  if (tippedChk && tippedAmtRow) {
    tippedChk.addEventListener("change", () => {
      tippedAmtRow.classList.toggle("hidden", !tippedChk.checked);
      if (tippedChk.checked && tippedAmt) setTimeout(() => tippedAmt.focus(), 30);
    });
  }

  if (saveBtn) {
    saveBtn.addEventListener("click", () => {
      const nick = (document.getElementById("reader-edit-nick").value || "").trim();
      if (!nick) return;
      if (_readerModalMode === "edit" && !_editingTs) return;
      const activeType = document.querySelector(".entry-type-btn.active");
      const type = activeType ? activeType.dataset.type : "pytanie";
      const questionRaw = (document.getElementById("reader-edit-question").value || "").trim();

      let question, kind;
      if (type === "karton") {
        question = KARTON_DNIA_TEXT;
        kind = "karton";
      } else if (type === "taknie") {
        // TAK/NIE zachowuje się jak pytanie (ma treść), ale niesie własną kategorię.
        question = questionRaw || "x";
        kind = "taknie";
      } else if (type === "czekam") {
        question = "x";
        kind = null;
      } else {
        question = questionRaw || "x";
        kind = null;
      }

      if (_readerModalMode === "add") {
        // Tipped: jeśli zaznaczone i kwota > 0 — doliczamy do kasy (Zbiórki).
        let tippedAmount = 0;
        const chk = document.getElementById("reader-edit-tipped");
        const amt = document.getElementById("reader-edit-tipped-amount");
        if (chk && chk.checked && amt) {
          const n = parseFloat(String(amt.value || "").replace(",", "."));
          if (Number.isFinite(n) && n > 0) tippedAmount = Math.round(n * 100) / 100;
        }
        window.wbApi.readerQueueAdd({ nick, question, kind, tippedAmount });
      } else {
        window.wbApi.readerQueueEdit({ ts: _editingTs, nick, question, kind });
      }
      closeReaderEditModal();
    });
  }
}

async function loop() {
  try {
    render(await getState());
  } catch (e) {
    console.error("reader render:", e);
  }
}

// === Skalowanie okna (powiększ/pomniejsz) — CSS zoom, więc razem z tekstem
// skalują się też przyciski i cała reszta ("wszystko ma się skalować"). ===
const READER_ZOOM_KEY = "kvrina_reader_zoom";
const READER_ZOOM_MIN = 0.6;
const READER_ZOOM_MAX = 1.8;
let _readerZoom = 1;

function applyReaderZoom() {
  const app = document.getElementById("reader-app");
  if (!app) return;
  // Kompensacja wymiarów pod CSS `zoom` — bez tego przy zoomie ≠ 1 zostawała pusta
  // przestrzeń (element 100vh skalował się np. do 60vh). 100/zoom → wypełnia całe okno.
  app.style.zoom = String(_readerZoom);
  app.style.width = (100 / _readerZoom) + "vw";
  app.style.height = (100 / _readerZoom) + "vh";
  // Menu (⧉) liczy swoją wysokość w pikselach — po zmianie zoomu musi to zrobić od nowa.
  try { window.dispatchEvent(new Event("kvrina-reader-zoom")); } catch {}
}

function loadReaderZoom() {
  try {
    const saved = parseFloat(localStorage.getItem(READER_ZOOM_KEY));
    if (Number.isFinite(saved) && saved >= READER_ZOOM_MIN && saved <= READER_ZOOM_MAX) _readerZoom = saved;
  } catch {}
  applyReaderZoom();
}

function saveReaderZoom() {
  try { localStorage.setItem(READER_ZOOM_KEY, String(_readerZoom)); } catch {}
}

function setupReaderZoom() {
  loadReaderZoom();
  const plus = document.getElementById("reader-zoom-plus");
  const minus = document.getElementById("reader-zoom-minus");
  if (plus) plus.addEventListener("click", () => {
    _readerZoom = Math.min(READER_ZOOM_MAX, Math.round((_readerZoom + 0.1) * 100) / 100);
    applyReaderZoom();
    saveReaderZoom();
  });
  if (minus) minus.addEventListener("click", () => {
    _readerZoom = Math.max(READER_ZOOM_MIN, Math.round((_readerZoom - 0.1) * 100) / 100);
    applyReaderZoom();
    saveReaderZoom();
  });
}

// === LOSUJ — na razie sam przycisk bez funkcji (dojdzie później) ===
function setupReaderLosuj() {
  const btn = document.getElementById("btn-reader-losuj");
  if (!btn) return;
  btn.addEventListener("click", async () => {
    try { await window.wbApi.readerMenuAction("losuj"); } catch (e) { console.error("losuj:", e); }
  });
}

// === Menu (⧉) — panele programu + wszystko co było pod ☰ w głównym oknie ===
function setupReaderMenu() {
  const toggle = document.getElementById("reader-menu-toggle");
  const menu = document.getElementById("reader-menu");
  if (!toggle || !menu) return;

  // Menu wisi na #reader-app (nie w karcie pytania), więc pozycję liczymy sami.
  // Na oknie działa CSS `zoom`, przez co vh/vw nie odpowiadają realnym rozmiarom —
  // dlatego wysokość bierzemy z clientHeight, w tym samym układzie współrzędnych.
  const placeMenu = () => {
    const app = document.getElementById("reader-app");
    if (!app) return;
    let left = 0;
    let top = 0;
    for (let el = toggle; el && el !== app; el = el.offsetParent) {
      left += el.offsetLeft;
      top += el.offsetTop;
    }
    const menuTop = top + toggle.offsetHeight + 8;
    const width = Math.min(300, Math.max(180, app.clientWidth - 20));
    menu.style.width = width + "px";
    menu.style.left = Math.max(0, Math.min(left, app.clientWidth - width)) + "px";
    menu.style.top = menuTop + "px";
    menu.style.maxHeight = Math.max(140, app.clientHeight - menuTop - 8) + "px";
  };

  const closeMenu = () => {
    menu.classList.add("hidden");
    toggle.setAttribute("aria-expanded", "false");
  };
  const openMenu = () => {
    menu.classList.remove("hidden");
    toggle.setAttribute("aria-expanded", "true");
    menu.scrollTop = 0; // zawsze od góry, niezależnie od tego, gdzie skończyło się poprzednio
    placeMenu();
  };

  toggle.addEventListener("click", (e) => {
    e.stopPropagation();
    if (menu.classList.contains("hidden")) openMenu(); else closeMenu();
  });

  // Zmiana rozmiaru okna lub zoomu przy otwartym menu — przelicz na nowo.
  window.addEventListener("resize", () => {
    if (!menu.classList.contains("hidden")) placeMenu();
  });
  window.addEventListener("kvrina-reader-zoom", () => {
    if (!menu.classList.contains("hidden")) placeMenu();
  });

  const PANEL_ACTIONS = {
    "panel-gifty": "gifty",
    "panel-obserwujacy": "obserwujacy",
    "panel-ranking": "ranking",
    "panel-kasa": "kasa",
    "panel-widgets": "widgets",
    "panel-aktualizacje": "aktualizacje",
    "panel-diagnostyka": "diagnostyka",
    "panel-dzwiek": "dzwiek",
    "panel-uklad": "uklad",
  };

  menu.querySelectorAll(".reader-menu-btn").forEach((btn) => {
    btn.addEventListener("click", async () => {
      const action = btn.dataset.action;
      closeMenu();
      try {
        if (PANEL_ACTIONS[action]) {
          // Osobne, kompaktowe, skalowalne okienko dla tego panelu (nie duże główne okno).
          await window.wbApi.openPanelWindow(PANEL_ACTIONS[action]);
        } else {
          await window.wbApi.readerMenuAction(action);
        }
      } catch (e) { console.error("reader menu action:", action, e); }
    });
  });

  // Zamknij po kliknięciu poza menu
  document.addEventListener("click", (e) => {
    if (!menu.classList.contains("hidden") && !menu.contains(e.target) && e.target !== toggle) closeMenu();
  });
  // Zamknij na Escape
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeMenu();
  });
}

// === Przycisk „+ DODAJ" — ręczne dodanie wpisu do kolejki (obok LOSUJ) ===
function setupReaderAddEntry() {
  const btn = document.getElementById("reader-add-entry");
  if (!btn) return;
  btn.addEventListener("click", () => openReaderAddModal());
}

// === Splitter — podział szerokości pytanie/kolejka, zapamiętywany ===
const READER_SPLIT_KEY = "kvrina_reader_split"; // frakcja szerokości pytania (0.2–0.8)
const READER_SPLIT_MIN = 0.25;
const READER_SPLIT_MAX = 0.8;

function applyReaderSplit(frac) {
  const main = document.getElementById("reader-main");
  if (!main) return;
  const f = Math.max(READER_SPLIT_MIN, Math.min(READER_SPLIT_MAX, frac));
  main.style.setProperty("--reader-left-grow", String(f));
  main.style.setProperty("--reader-right-grow", String(1 - f));
}

function setupReaderSplit() {
  const main = document.getElementById("reader-main");
  const splitter = document.getElementById("reader-splitter");
  if (!main || !splitter) return;

  let frac = 1.3 / 2.3; // domyślny podział (zgodny ze starym flex 1.3 : 1)
  try {
    const saved = parseFloat(localStorage.getItem(READER_SPLIT_KEY));
    if (Number.isFinite(saved)) frac = saved;
  } catch {}
  applyReaderSplit(frac);

  let dragging = false;

  const onMove = (e) => {
    if (!dragging) return;
    const rect = main.getBoundingClientRect();
    if (rect.width <= 0) return;
    const f = (e.clientX - rect.left) / rect.width;
    frac = Math.max(READER_SPLIT_MIN, Math.min(READER_SPLIT_MAX, f));
    applyReaderSplit(frac);
    e.preventDefault();
  };
  const onUp = () => {
    if (!dragging) return;
    dragging = false;
    splitter.classList.remove("dragging");
    document.body.style.userSelect = "";
    try { localStorage.setItem(READER_SPLIT_KEY, String(frac)); } catch {}
    window.removeEventListener("mousemove", onMove);
    window.removeEventListener("mouseup", onUp);
  };

  splitter.addEventListener("mousedown", (e) => {
    // Klik w „+" nie startuje resize (ma własny stopPropagation), reszta splittera — tak.
    dragging = true;
    splitter.classList.add("dragging");
    document.body.style.userSelect = "none";
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onUp);
    e.preventDefault();
  });
}

// === Zawsze na wierzchu (📌) ===
const READER_PIN_KEY = "kvrina_reader_pinned";

async function setupReaderPin() {
  const btn = document.getElementById("reader-pin-toggle");
  if (!btn) return;

  let pinned = false;
  try { pinned = localStorage.getItem(READER_PIN_KEY) === "1"; } catch {}

  const apply = async (val) => {
    pinned = val;
    btn.classList.toggle("active", pinned);
    try { localStorage.setItem(READER_PIN_KEY, pinned ? "1" : "0"); } catch {}
    try { await window.wbApi.readerSetAlwaysOnTop(pinned); } catch {}
  };

  await apply(pinned);
  btn.addEventListener("click", () => apply(!pinned));
}

window.addEventListener("DOMContentLoaded", () => {
  loop();
  setInterval(loop, 1000);

  setupReaderEditModal();
  setupReaderZoom();
  setupReaderSplit();
  setupReaderAddEntry();
  setupReaderLosuj();
  setupReaderMenu();
  setupReaderRanking();
  setupReaderPin();
  setupReaderCountdown();
  setupReaderConnect();
  setupReaderWebhookToggle();

  const btnPrev = document.getElementById("btn-prev");
  const btnNext = document.getElementById("btn-next");
  const btnSkip = document.getElementById("btn-skip");
  if (btnPrev) btnPrev.addEventListener("click", () => window.wbApi.readerPrev());
  if (btnNext) btnNext.addEventListener("click", () => window.wbApi.readerNext());
  if (btnSkip) btnSkip.addEventListener("click", () => window.wbApi.readerSkip());

  window.addEventListener("keydown", (e) => {
    const modal = document.getElementById("reader-edit-modal");
    const modalOpen = modal && !modal.classList.contains("hidden");
    if (modalOpen) {
      if (e.key === "Escape") closeReaderEditModal();
      return;
    }
    if (e.key === "ArrowRight") window.wbApi.readerNext();
    if (e.key === "ArrowLeft") window.wbApi.readerPrev();
  });
});
