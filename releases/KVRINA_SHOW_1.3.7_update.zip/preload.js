// =========================
// KVRINA_SHOW - preload.js
// =========================

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("wbApi", {
  getOutputDir: () => ipcRenderer.invoke("wb-get-output-dir"),
  openOutputDir: () => ipcRenderer.invoke("wb-open-output-dir"),
  openWidgetsDir: () => ipcRenderer.invoke("wb-open-widgets-dir"),
  openUpdatesDir: () => ipcRenderer.invoke("wb-open-updates-dir"),
  updateCheck: () => ipcRenderer.invoke("wb-update-check"),
  updateInstall: () => ipcRenderer.invoke("wb-update-install"),
  updatePickInstall: () => ipcRenderer.invoke("wb-update-pick-install"),
  updateRestorePrevious: () => ipcRenderer.invoke("wb-update-restore-previous"),
  confirmResetSession: () => ipcRenderer.invoke("wb-confirm-reset-session"),

  writeFile: (name, data) =>
    ipcRenderer.invoke("wb-write-file", { name, data }),

  appendFile: (name, data) =>
    ipcRenderer.invoke("wb-append-file", { name, data }),

  readFile: (name) =>
    ipcRenderer.invoke("wb-read-file", { name }),

  readAbsoluteFile: (fullPath) =>
    ipcRenderer.invoke("wb-read-absolute-file", { fullPath }),

  openQuestionFileDialog: (mode) =>
    ipcRenderer.invoke("wb-open-question-file", { mode }),

  // Inform main process which TXT file is currently used for questions.
  // Enables auto-append from Tipped webhook.
  setQuestionsFilePath: (fullPath, mode) =>
    ipcRenderer.invoke("wb-set-questions-file-path", { fullPath, mode }),

  getLastQuestionsFilePaths: () => ipcRenderer.invoke("wb-get-last-questions-file-paths"),

  // Global shortcuts -> renderer
  onQuestionsNext: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-questions-next");
    ipcRenderer.on("wb-questions-next", () => cb());
  },

  onQuestionsPrev: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-questions-prev");
    ipcRenderer.on("wb-questions-prev", () => cb());
  },

  onQuestionsSkip: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-questions-skip");
    ipcRenderer.on("wb-questions-skip", () => cb());
  },

  onMainVisibility: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-main-visibility");
    ipcRenderer.on("wb-main-visibility", (evt, payload) => cb(payload));
  },

  onTippedQuestion: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tipped-question");
    ipcRenderer.on("wb-tipped-question", (evt, payload) => cb(payload));
  },

  onTippedFund: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tipped-fund");
    ipcRenderer.on("wb-tipped-fund", (evt, payload) => cb(payload));
  },

  onTippedShortfall: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tipped-shortfall");
    ipcRenderer.on("wb-tipped-shortfall", (evt, payload) => cb(payload));
  },


  // Cloudflared quick tunnel controls
  tunnelStart: () => ipcRenderer.invoke("wb-tunnel-start"),
  tunnelStop: () => ipcRenderer.invoke("wb-tunnel-stop"),
  tunnelGet: () => ipcRenderer.invoke("wb-tunnel-get"),
  clipboardCopy: (text) => ipcRenderer.invoke("wb-clipboard-copy", { text }),
  webhookGetStatus: () => ipcRenderer.invoke("wb-webhook-get-status"),
  webhookSetEnabled: (enabled) => ipcRenderer.invoke("wb-webhook-set-enabled", enabled),
  isDev: () => ipcRenderer.invoke("wb-is-dev"),

  onTunnelUrl: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tunnel-url");
    ipcRenderer.on("wb-tunnel-url", (evt, payload) => cb(payload));
  },

  onTunnelStopped: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tunnel-stopped");
    ipcRenderer.on("wb-tunnel-stopped", () => cb());
  },


  onLastQuestionPaths: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-last-question-paths");
    ipcRenderer.on("wb-last-question-paths", (evt, payload) => cb(payload));
  },

  // GitHub auto-aktualizacje
  githubCheck: () => ipcRenderer.invoke("wb-github-check"),
  githubDownloadInstall: (opts) => ipcRenderer.invoke("wb-github-download-install", opts),
  onGithubProgress: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-github-progress");
    ipcRenderer.on("wb-github-progress", (evt, data) => cb(data));
  },

  // RAM monitoring
  getRam: () => ipcRenderer.invoke("wb-get-ram"),
  getAppVersion: () => ipcRenderer.invoke("wb-get-app-version"),

  // TikTok Live bezpośrednio (bez bota TikFinity)
  tiktokConnect: (username) => ipcRenderer.invoke("tiktok-connect", username),
  tiktokDisconnect: () => ipcRenderer.invoke("tiktok-disconnect"),

  // Klucz Euler Stream (podpisywanie połączeń z TikTok LIVE)
  eulerKeyStatus: () => ipcRenderer.invoke("euler-key-status"),
  eulerKeySet: (key) => ipcRenderer.invoke("euler-key-set", key),
  eulerKeyClear: () => ipcRenderer.invoke("euler-key-clear"),
  eulerKeyTest: (key) => ipcRenderer.invoke("euler-key-test", key),
  onEulerKeyChanged: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("euler-key-changed");
    ipcRenderer.on("euler-key-changed", (evt, payload) => cb(payload));
  },
  onTiktokEvent: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("tiktok-event");
    ipcRenderer.on("tiktok-event", (evt, payload) => cb(payload));
  },
  onTiktokState: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("tiktok-state");
    ipcRenderer.on("tiktok-state", (evt, payload) => cb(payload));
  },

  // Diagnostyka
  diagGetLog: () => ipcRenderer.invoke("diag-get-log"),
  diagSendReport: (opts) => ipcRenderer.invoke("diag-send-report", opts),
  diagClearLog: () => ipcRenderer.invoke("diag-clear-log"),
  diagGetReports: (opts) => ipcRenderer.invoke("diag-get-reports", opts),
  // Dźwięki: powiadomienia + muzyka w tle
  soundGetState: () => ipcRenderer.invoke("sound-get-state"),
  soundSetSettings: (patch) => ipcRenderer.invoke("sound-set-settings", patch),
  soundOpenFolder: (which) => ipcRenderer.invoke("sound-open-folder", which),
  soundControl: (payload) => ipcRenderer.invoke("sound-control", payload),
  soundReportPlaying: (payload) => ipcRenderer.invoke("sound-report-playing", payload),
  onSoundSettings: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-sound-settings");
    ipcRenderer.on("wb-sound-settings", (evt, payload) => cb(payload));
  },
  onSoundSettingsChanged: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-sound-settings-changed");
    ipcRenderer.on("wb-sound-settings-changed", (evt, payload) => cb(payload));
  },
  onSoundControl: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-sound-control");
    ipcRenderer.on("wb-sound-control", (evt, payload) => cb(payload));
  },

  diagGetPerf: () => ipcRenderer.invoke("diag-get-perf"),
  diagSetAutoReport: (on) => ipcRenderer.invoke("diag-set-auto-report", on),
  comboGetLayout: () => ipcRenderer.invoke("combo-get-layout"),
  comboSetLayout: (patch) => ipcRenderer.invoke("combo-set-layout", patch),
  comboResetLayout: () => ipcRenderer.invoke("combo-reset-layout"),
  widgetsGetLite: () => ipcRenderer.invoke("widgets-get-lite"),
  widgetsSetLite: (on) => ipcRenderer.invoke("widgets-set-lite", on),
  diagGetPerfReportText: () => ipcRenderer.invoke("diag-get-perf-report-text"),
  diagCloseIssue: (opts) => ipcRenderer.invoke("diag-close-issue", opts),
  onDiagEntry: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("diag-log-entry");
    ipcRenderer.on("diag-log-entry", (evt, entry) => cb(entry));
  },

  // Chat pop-out
  openChatWindow: () => ipcRenderer.invoke("wb-open-chat-window"),
  sendChatLine: (payload) => ipcRenderer.send("wb-chat-line", payload || {}),
  onChatLine: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-chat-line");
    ipcRenderer.on("wb-chat-line", (evt, payload) => cb(payload));
  },

  // Tryb okienka — czytnik pytań + kolejka
  openReaderWindow: () => ipcRenderer.invoke("wb-open-reader-window"),
  readerNext: () => ipcRenderer.invoke("reader-next"),
  readerPrev: () => ipcRenderer.invoke("reader-prev"),
  readerSkip: () => ipcRenderer.invoke("reader-skip"),
  readerQueueMove: (payload) => ipcRenderer.invoke("reader-queue-move", payload),
  readerQueueRemove: (payload) => ipcRenderer.invoke("reader-queue-remove", payload),
  readerQueueEdit: (payload) => ipcRenderer.invoke("reader-queue-edit", payload),
  readerQueueJump: (payload) => ipcRenderer.invoke("reader-queue-jump", payload),
  readerQueueAdd: (payload) => ipcRenderer.invoke("reader-queue-add", payload),
  readerSetCountdown: (payload) => ipcRenderer.invoke("reader-set-countdown", payload),
  readerToggleMainWindow: () => ipcRenderer.invoke("reader-toggle-main-window"),
  readerGetMainVisible: () => ipcRenderer.invoke("reader-get-main-visible"),
  readerMenuAction: (action) => ipcRenderer.invoke("reader-menu-action", action),
  readerSetAlwaysOnTop: (val) => ipcRenderer.invoke("reader-set-always-on-top", !!val),

  // Osobne, kompaktowe okienka paneli programu (gifty/obserwujący/ranking/kasa)
  openPanelWindow: (panel) => ipcRenderer.invoke("wb-open-panel-window", panel),
  panelFollowAdd: (payload) => ipcRenderer.invoke("panel-follow-add", payload),
  panelFollowRemove: (payload) => ipcRenderer.invoke("panel-follow-remove", payload),
  panelFollowEdit: (payload) => ipcRenderer.invoke("panel-follow-edit", payload),
  panelRankingAdd: (payload) => ipcRenderer.invoke("panel-ranking-add", payload),

  // Główne okno: odbiór poleceń z panelu OBSERWUJĄCY / RANKING wysłanych z osobnych okienek
  onPanelFollowAdd: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("panel-cmd-follow-add");
    ipcRenderer.on("panel-cmd-follow-add", (evt, payload) => cb(payload));
  },
  onPanelFollowRemove: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("panel-cmd-follow-remove");
    ipcRenderer.on("panel-cmd-follow-remove", (evt, payload) => cb(payload));
  },
  onPanelFollowEdit: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("panel-cmd-follow-edit");
    ipcRenderer.on("panel-cmd-follow-edit", (evt, payload) => cb(payload));
  },
  onPanelRankingAdd: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("panel-cmd-ranking-add");
    ipcRenderer.on("panel-cmd-ranking-add", (evt, payload) => cb(payload));
  },

  // Główne okno: odbiór poleceń przesuwania/edycji wysłanych z okienka trybu odczytu
  onReaderQueueMove: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-cmd-move");
    ipcRenderer.on("reader-cmd-move", (evt, payload) => cb(payload));
  },
  onReaderQueueRemove: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-cmd-remove");
    ipcRenderer.on("reader-cmd-remove", (evt, payload) => cb(payload));
  },
  onReaderQueueEdit: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-cmd-edit");
    ipcRenderer.on("reader-cmd-edit", (evt, payload) => cb(payload));
  },
  onReaderQueueJump: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-cmd-jump");
    ipcRenderer.on("reader-cmd-jump", (evt, payload) => cb(payload));
  },
  onReaderQueueAdd: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-cmd-add");
    ipcRenderer.on("reader-cmd-add", (evt, payload) => cb(payload));
  },
  onReaderSetCountdown: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-cmd-countdown");
    ipcRenderer.on("reader-cmd-countdown", (evt, payload) => cb(payload));
  },
  onReaderMenuAction: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("reader-menu-cmd");
    ipcRenderer.on("reader-menu-cmd", (evt, action) => cb(action));
  },

});
