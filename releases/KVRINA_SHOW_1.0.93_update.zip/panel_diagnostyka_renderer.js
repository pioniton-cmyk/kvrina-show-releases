// =========================
// KVRINA_SHOW — panel_diagnostyka_renderer.js
// Osobne okienko DIAGNOSTYKA — log, wysyłanie raportów, lista zgłoszeń GitHub.
// Ten sam IPC co wcześniej w głównym oknie (diagGetLog/diagSendReport/diagClearLog/
// diagGetReports/diagCloseIssue/onDiagEntry) — jedno źródło logiki w main.js.
// =========================

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function diagLevelClass(level) {
  return `diag-entry diag-${level}`;
}

async function loadDiagLog() {
  if (!window.wbApi || !window.wbApi.diagGetLog) return;
  const { log, fileLines, version, platform, electron, perf } = await window.wbApi.diagGetLog();

  const sysinfo = document.getElementById("diag-sysinfo");
  if (sysinfo) {
    const perfStr = perf ? ` · heap ${perf.heapUsedMB}MB · rss ${perf.rssMB}MB · cpu ${perf.cpuPct}% · RAM wolna ${perf.freeRamMB}/${perf.totalRamMB}MB` : "";
    sysinfo.textContent = `v${version} · ${platform} · Electron ${electron}${perfStr}`;
  }

  const box = document.getElementById("diag-log-box");
  const count = document.getElementById("diag-log-count");
  if (!box) return;

  const entries = log && log.length ? log : (fileLines || []).map((l) => {
    const m = l.match(/^\[(.+?)\] \[(.+?)\] (.*)$/);
    return m ? { ts: m[1], level: m[2], msg: m[3] } : { ts: "", level: "INFO", msg: l };
  });

  if (count) count.textContent = `${entries.length} wpisów`;
  box.innerHTML = "";
  entries.forEach((e) => {
    const row = document.createElement("div");
    row.className = diagLevelClass(e.level || "INFO");
    row.innerHTML = `<span class="diag-ts">${(e.ts || "").slice(11, 23)}</span><span class="diag-lvl">[${e.level}]</span> <span class="diag-msg">${escapeHtml(e.msg || "")}</span>`;
    box.appendChild(row);
  });
  box.scrollTop = box.scrollHeight;
}

function setupDiag() {
  const btnRefresh = document.getElementById("diag-refresh");
  const btnClear = document.getElementById("diag-clear");
  const btnSend = document.getElementById("diag-send");

  document.querySelectorAll(".diag-tab").forEach((tab) => {
    tab.addEventListener("click", () => {
      const t = tab.dataset.diagTab;
      document.querySelectorAll(".diag-tab").forEach((b) => b.classList.toggle("active", b.dataset.diagTab === t));
      document.querySelectorAll(".diag-tab-content").forEach((c) => c.classList.toggle("hidden", c.id !== `diag-tab-${t}`));
    });
  });

  if (btnRefresh) btnRefresh.addEventListener("click", loadDiagLog);

  if (btnClear) {
    btnClear.addEventListener("click", async () => {
      if (!window.wbApi || !window.wbApi.diagClearLog) return;
      await window.wbApi.diagClearLog();
      loadDiagLog();
    });
  }

  document.querySelectorAll(".diag-type-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diag-type-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
    });
  });

  if (btnSend) {
    btnSend.addEventListener("click", async () => {
      const text = (document.getElementById("diag-report-text")?.value || "").trim();
      const activeType = document.querySelector(".diag-type-btn.active");
      const rtype = activeType ? activeType.dataset.rtype : "raport";
      const status = document.getElementById("diag-report-status");

      if (!window.wbApi || !window.wbApi.diagSendReport) return;
      if (status) { status.textContent = "Wysyłam…"; status.className = "diag-report-status"; }
      btnSend.disabled = true;

      const result = await window.wbApi.diagSendReport({ message: text, type: rtype });

      btnSend.disabled = false;
      if (result.ok) {
        if (status) { status.textContent = `✓ Wysłano! Issue #${result.number}`; status.className = "diag-report-status ok"; }
        document.getElementById("diag-report-text").value = "";
      } else {
        if (status) { status.textContent = `✗ Błąd: ${result.error || "nieznany"}`; status.className = "diag-report-status err"; }
      }
    });
  }

  let _currentReportState = "open";
  let _currentIssueNumber = null;

  async function loadReports() {
    if (!window.wbApi || !window.wbApi.diagGetReports) return;
    const list = document.getElementById("diag-reports-list");
    if (!list) return;
    list.innerHTML = `<div class="diag-reports-empty">Ładuję…</div>`;
    const result = await window.wbApi.diagGetReports({ state: _currentReportState });
    list.innerHTML = "";
    if (!result.ok || !result.issues || !result.issues.length) {
      list.innerHTML = `<div class="diag-reports-empty">Brak raportów (${_currentReportState}).</div>`;
      return;
    }
    result.issues.forEach((issue) => {
      const item = document.createElement("div");
      item.className = "diag-report-item";
      const date = new Date(issue.created_at).toLocaleString("pl-PL", { day: "2-digit", month: "2-digit", year: "2-digit", hour: "2-digit", minute: "2-digit" });
      const labels = (issue.labels || []).map((l) => `<span class="diag-report-label lbl-${l.name}">${escapeHtml(l.name)}</span>`).join("");
      item.innerHTML = `
        <div class="diag-report-item-head">
          <span class="diag-report-num">#${issue.number}</span>
          <span class="diag-report-title">${escapeHtml(issue.title)}</span>
          <span class="diag-report-date">${date}</span>
        </div>
        <div class="diag-report-labels">${labels}</div>`;
      item.addEventListener("click", () => showReportDetail(issue));
      list.appendChild(item);
    });
  }

  function showReportDetail(issue) {
    _currentIssueNumber = issue.number;
    document.getElementById("diag-reports-list").classList.add("hidden");
    const detail = document.getElementById("diag-report-detail");
    detail.classList.remove("hidden");
    document.getElementById("diag-detail-title").textContent = `#${issue.number} ${issue.title}`;
    document.getElementById("diag-detail-body").textContent = issue.body || "(brak treści)";
    const closeBtn = document.getElementById("diag-detail-close-issue");
    if (closeBtn) closeBtn.style.display = issue.state === "open" ? "" : "none";
  }

  document.getElementById("diag-detail-back")?.addEventListener("click", () => {
    document.getElementById("diag-report-detail")?.classList.add("hidden");
    document.getElementById("diag-reports-list")?.classList.remove("hidden");
    _currentIssueNumber = null;
  });

  document.getElementById("diag-detail-close-issue")?.addEventListener("click", async () => {
    if (!_currentIssueNumber || !window.wbApi?.diagCloseIssue) return;
    const btn = document.getElementById("diag-detail-close-issue");
    btn.disabled = true;
    const r = await window.wbApi.diagCloseIssue({ number: _currentIssueNumber });
    btn.disabled = false;
    if (r.ok) {
      btn.style.display = "none";
      document.getElementById("diag-detail-title").textContent += " ✓ ZAMKNIĘTY";
    }
  });

  document.getElementById("diag-reports-refresh")?.addEventListener("click", loadReports);

  document.querySelectorAll(".diag-filter-btn").forEach((btn) => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diag-filter-btn").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      _currentReportState = btn.dataset.filter;
      document.getElementById("diag-reports-list")?.classList.remove("hidden");
      document.getElementById("diag-report-detail")?.classList.add("hidden");
      loadReports();
    });
  });

  document.querySelectorAll(".diag-tab").forEach((tab) => {
    if (tab.dataset.diagTab === "reports") {
      tab.addEventListener("click", () => { if (!document.getElementById("diag-reports-list")?.children.length || document.querySelector(".diag-reports-empty")) loadReports(); });
    }
  });

  if (window.wbApi && window.wbApi.onDiagEntry) {
    window.wbApi.onDiagEntry((entry) => {
      const box = document.getElementById("diag-log-box");
      if (!box) return;
      const row = document.createElement("div");
      row.className = diagLevelClass(entry.level || "INFO");
      row.innerHTML = `<span class="diag-ts">${(entry.ts || "").slice(11, 23)}</span><span class="diag-lvl">[${entry.level}]</span> <span class="diag-msg">${escapeHtml(entry.msg || "")}</span>`;
      box.appendChild(row);
      box.scrollTop = box.scrollHeight;
      const count = document.getElementById("diag-log-count");
      if (count) count.textContent = `${box.children.length} wpisów`;
    });
  }
}

window.addEventListener("DOMContentLoaded", () => {
  loadDiagLog();
  setupDiag();
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
