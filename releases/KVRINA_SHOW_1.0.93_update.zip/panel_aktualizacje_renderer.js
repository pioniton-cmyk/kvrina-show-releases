// =========================
// KVRINA_SHOW — panel_aktualizacje_renderer.js
// Osobne okienko AKTUALIZACJE — sprawdzanie/instalowanie z GitHub, cofanie wersji.
// Ten sam IPC co wcześniej w głównym oknie (window.wbApi.githubCheck/githubDownloadInstall/
// updateRestorePrevious) — jedno źródło logiki, żadnej duplikacji po stronie main.js.
// =========================

let _githubUpdateInfo = null;

function setStatus(text, type) {
  const el = document.getElementById("updates-status-text");
  if (!el) return;
  el.textContent = text;
  el.className = type === "ok" ? "status-ok" : type === "warn" ? "status-warn" : type === "new" ? "status-new" : "";
}

async function loadVersionLabel() {
  const verEl = document.getElementById("updates-current-version");
  if (!verEl || !window.wbApi || !window.wbApi.getAppVersion) return;
  try {
    const r = await window.wbApi.getAppVersion();
    if (r && r.version) verEl.textContent = "Wersja " + r.version;
  } catch {}
}

function setupControls() {
  const btnCheck = document.getElementById("btn-updates-check");
  const btnInstall = document.getElementById("btn-updates-install");
  const btnRestore = document.getElementById("btn-updates-restore");

  if (window.wbApi && typeof window.wbApi.onGithubProgress === "function") {
    window.wbApi.onGithubProgress((data) => {
      if (data && data.status === "downloading") setStatus("Pobieranie aktualizacji z GitHub…", "warn");
      if (data && data.status === "installing") setStatus("Instalowanie aktualizacji…", "warn");
    });
  }

  if (btnCheck) {
    btnCheck.addEventListener("click", async () => {
      try {
        btnCheck.disabled = true;
        btnCheck.textContent = "SPRAWDZAM…";
        if (btnInstall) btnInstall.disabled = true;
        setStatus("Sprawdzam GitHub…", "warn");

        const r = await window.wbApi.githubCheck();

        if (r && r.available) {
          _githubUpdateInfo = r;
          if (btnInstall) btnInstall.disabled = false;
          setStatus(`Dostępna nowa wersja: ${r.latestVersion}  (aktualna: ${r.currentVersion})`, "new");
        } else if (r && !r.error) {
          _githubUpdateInfo = null;
          if (btnInstall) btnInstall.disabled = true;
          setStatus(`Masz najnowszą wersję (${r.currentVersion}).`, "ok");
        } else {
          setStatus("Błąd połączenia z GitHub. Sprawdź internet.", "warn");
        }
      } catch (e) {
        setStatus("Błąd sprawdzania aktualizacji.", "warn");
      } finally {
        btnCheck.disabled = false;
        btnCheck.textContent = "SPRAWDŹ AKTUALIZACJE";
      }
    });
  }

  if (btnInstall) {
    btnInstall.addEventListener("click", async () => {
      if (!_githubUpdateInfo || !_githubUpdateInfo.available) return;
      const ok = confirm(`Zainstalować wersję ${_githubUpdateInfo.latestVersion}?\n\nProgram zrobi backup i zapyta o restart.`);
      if (!ok) return;
      try {
        btnInstall.disabled = true;
        btnCheck.disabled = true;
        setStatus("Pobieranie i instalowanie aktualizacji…", "warn");
        const r = await window.wbApi.githubDownloadInstall({
          downloadUrl: _githubUpdateInfo.downloadUrl,
          assetName: _githubUpdateInfo.assetName,
        });
        _githubUpdateInfo = null;
        if (r && r.ok) {
          setStatus(`Zainstalowano wersję ${r.version || ""}. Restart zaraz.`, "ok");
        } else if (!(r && r.cancelled)) {
          setStatus(`Błąd: ${(r && r.error) || "nieznany"}`, "warn");
        }
      } catch (e) {
        setStatus("Błąd instalacji aktualizacji.", "warn");
        btnInstall.disabled = false;
      } finally {
        btnCheck.disabled = false;
      }
    });
  }

  if (btnRestore) {
    btnRestore.addEventListener("click", async () => {
      try {
        setStatus("Przywracanie poprzedniej wersji…", "warn");
        const r = await window.wbApi.updateRestorePrevious();
        if (r && r.ok) {
          setStatus(`Przywrócono wersję ${r.version || "poprzednią"}.`, "ok");
        } else if (r && r.cancelled) {
          setStatus("Anulowano.", "");
        } else {
          setStatus(`Błąd: ${(r && r.error) || "brak backupu do przywrócenia"}.`, "warn");
        }
      } catch (e) {
        setStatus("Błąd cofania wersji.", "warn");
      }
    });
  }
}

window.addEventListener("DOMContentLoaded", () => {
  loadVersionLabel();
  setupControls();
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
