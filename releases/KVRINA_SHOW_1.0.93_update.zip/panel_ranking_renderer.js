// =========================
// KVRINA_SHOW — panel_ranking_renderer.js
// Osobne, kompaktowe okienko dla panelu RANKING WIDZÓW. Lekki pop-out: czyta stan
// z lokalnego serwera widgetów, DODAJ przekazuje do głównego okna przez IPC (po nicku).
// =========================

const WIDGET_STATE_URL = "http://127.0.0.1:8750/widget_state.json";
let lastSignature = "";

async function getState() {
  try {
    const r = await fetch(WIDGET_STATE_URL + "?ts=" + Date.now(), { cache: "no-store" });
    if (!r.ok) throw new Error("state");
    return await r.json();
  } catch (e) {
    return { ranking: [] };
  }
}

function render(s) {
  const ranking = Array.isArray(s.ranking) ? s.ranking : [];
  const countEl = document.getElementById("panel-count");
  countEl.textContent = ranking.length === 1 ? "1 osoba" : `${ranking.length} osób`;

  const sig = JSON.stringify(ranking.map((r) => ({ nick: r.nick, likes: r.likes })));
  if (sig === lastSignature) return;
  lastSignature = sig;

  const box = document.getElementById("panel-list");
  box.innerHTML = "";

  if (!ranking.length) {
    const empty = document.createElement("div");
    empty.className = "ranking-preview-empty";
    empty.textContent = "Czekam na komentarze, tapy, followy i share…";
    box.appendChild(empty);
    return;
  }

  ranking.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "ranking-preview-item";

    const place = document.createElement("div");
    place.className = "ranking-preview-place";
    place.textContent = `#${idx + 1}`;

    const main = document.createElement("div");
    main.className = "ranking-preview-main";

    const nick = document.createElement("div");
    nick.className = "ranking-preview-nick";
    nick.textContent = String(item.nick || "-");

    const likes = document.createElement("div");
    likes.className = "ranking-preview-likes";
    likes.textContent = `♥ ${Number(item.likes || item.points || 0) || 0} pkt`;

    main.appendChild(nick);
    main.appendChild(likes);

    const add = document.createElement("button");
    add.type = "button";
    add.className = "ranking-preview-add";
    add.textContent = "DODAJ";
    add.title = `Dodaj ${item.nick} do kolejki pytań`;
    add.addEventListener("click", () => window.wbApi.panelRankingAdd({ nick: item.nick }));

    row.appendChild(place);
    row.appendChild(main);
    row.appendChild(add);
    box.appendChild(row);
  });
}

async function loop() {
  try { render(await getState()); } catch (e) { console.error("panel_ranking render:", e); }
}

window.addEventListener("DOMContentLoaded", () => {
  loop();
  setInterval(loop, 700);
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
