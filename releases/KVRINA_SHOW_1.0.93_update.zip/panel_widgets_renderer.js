// =========================
// KVRINA_SHOW — panel_widgets_renderer.js
// Osobne okienko WIDGETY — lista adresów + podgląd na żywo (iframe wskazuje na lokalny
// serwer widgetów 127.0.0.1:8750, niezależnie od głównego okna). Zakładka INTEGRACJE
// nie jest tu potrzebna — połączenie z TikTok ma już własne okienko w czytniku
// (prawy klik na status „Live").
// =========================

const WIDGET_PREVIEW_ITEMS = [
  { id: "pytanie", label: "PYTANIE", desc: "Aktualnie czytana karta/pytanie — w trakcie losowania Kartona Dnia pokazuje tu instrukcję zbierania i wygraną", url: "http://127.0.0.1:8750/widget-pytanie.html" },
  { id: "queue", label: "KOLEJKA", desc: "Aktualna osoba wyróżniona + wszyscy następni w dół", url: "http://127.0.0.1:8750/widget-kolejka.html" },
  { id: "ranking", label: "RANKING WIDZÓW", desc: "Punkty za komentarze, tapy, follow i share — gifty 100+ dają 3-min boost +10%", url: "http://127.0.0.1:8750/widget-ranking.html" },
  { id: "karton-dnia", label: "KARTON DNIA (losowanie)", desc: "Karta tarota — ładuje się co 12-17 min; na czas zbierania/wygranej chowa się, bo te fazy pokazuje wtedy widget PYTANIE", url: "http://127.0.0.1:8750/widget-karton-dnia.html" },
];

let _selectedUrl = WIDGET_PREVIEW_ITEMS[0].url;

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function setCopyStatus(text, mode) {
  const el = document.getElementById("widgets-copy-status");
  if (!el) return;
  el.textContent = text;
  el.classList.remove("ok", "warn");
  if (mode === "ok") el.classList.add("ok");
  if (mode === "warn") el.classList.add("warn");
}

function selectPreview(itemId) {
  const item = WIDGET_PREVIEW_ITEMS.find((x) => x.id === itemId) || WIDGET_PREVIEW_ITEMS[0];
  _selectedUrl = item.url;

  const frame = document.getElementById("widgets-preview-frame");
  const input = document.getElementById("widgets-active-url");
  const title = document.getElementById("widgets-preview-title");
  if (frame) frame.src = item.url + (item.url.includes("?") ? "&" : "?") + "previewTs=" + Date.now();
  if (input) input.value = item.url;
  if (title) title.textContent = `${item.label} — podgląd`;

  document.querySelectorAll(".widget-url-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.widgetId === item.id);
  });
}

function renderUrlList() {
  const list = document.getElementById("widgets-url-list");
  if (!list) return;
  list.innerHTML = "";

  WIDGET_PREVIEW_ITEMS.forEach((item) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "widget-url-item";
    row.dataset.widgetId = item.id;
    row.innerHTML = `
      <span class="widget-url-main">
        <span class="widget-url-label">${escapeHtml(item.label)}</span>
        <span class="widget-url-desc">${escapeHtml(item.desc)}</span>
        <span class="widget-url-path">${escapeHtml(item.url)}</span>
      </span>
      <span class="widget-url-copy">KOPIUJ</span>
    `;

    row.addEventListener("click", async (evt) => {
      selectPreview(item.id);
      if (evt.target && evt.target.classList && evt.target.classList.contains("widget-url-copy")) {
        try {
          await window.wbApi.clipboardCopy(item.url);
          setCopyStatus(`Skopiowano URL: ${item.label}`, "ok");
        } catch {
          setCopyStatus("Nie udało się skopiować URL.", "warn");
        }
      }
    });

    list.appendChild(row);
  });
}

function setupControls() {
  const btnCopy = document.getElementById("widgets-copy-active");
  const btnFolder = document.getElementById("widgets-open-folder");
  const btnDemo = document.getElementById("widgets-open-demo");

  if (btnCopy) {
    btnCopy.addEventListener("click", async () => {
      try {
        await window.wbApi.clipboardCopy(_selectedUrl);
        setCopyStatus("Skopiowano URL aktualnie wybranego widgetu.", "ok");
      } catch {
        setCopyStatus("Nie udało się skopiować URL.", "warn");
      }
    });
  }

  if (btnFolder) {
    btnFolder.addEventListener("click", async () => {
      try {
        await window.wbApi.openWidgetsDir();
        setCopyStatus("Otworzyłem folder z widgetami i plikiem adresy_widgetow.txt.", "ok");
      } catch {
        setCopyStatus("Nie udało się otworzyć folderu widgetów.", "warn");
      }
    });
  }

  if (btnDemo) {
    btnDemo.addEventListener("click", () => {
      const frame = document.getElementById("widgets-preview-frame");
      const title = document.getElementById("widgets-preview-title");
      const input = document.getElementById("widgets-active-url");
      const url = "http://127.0.0.1:8750/demo.html";
      if (frame) frame.src = url + "?previewTs=" + Date.now();
      if (title) title.textContent = "DEMO WSZYSTKICH — podgląd";
      if (input) input.value = url;
      document.querySelectorAll(".widget-url-item").forEach((btn) => btn.classList.remove("active"));
    });
  }
}

window.addEventListener("DOMContentLoaded", () => {
  renderUrlList();
  selectPreview(WIDGET_PREVIEW_ITEMS[0].id);
  setCopyStatus("Kliknij widget po lewej, żeby podejrzeć i skopiować jego adres.", "info");
  setupControls();
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
