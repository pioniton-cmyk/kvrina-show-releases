// =========================
// KVRINA_SHOW — panel_kasa_renderer.js
// Osobne, kompaktowe okienko KASA — czysty podgląd zbiórek Tipped z tej sesji.
// Bez interakcji: tylko odczyt z lokalnego serwera widgetów.
// =========================

const WIDGET_STATE_URL = "http://127.0.0.1:8750/widget_state.json";
let lastSignature = "";

function formatPLN(amount) {
  const n = Number(amount) || 0;
  const parts = n.toFixed(2).split(".");
  const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${intPart},${parts[1]} zł`;
}

async function getState() {
  try {
    const r = await fetch(WIDGET_STATE_URL + "?ts=" + Date.now(), { cache: "no-store" });
    if (!r.ok) throw new Error("state");
    return await r.json();
  } catch (e) {
    return { fundsTotal: 0, fundsByGoal: {} };
  }
}

function render(s) {
  const total = Number(s.fundsTotal) || 0;
  const byGoal = s.fundsByGoal && typeof s.fundsByGoal === "object" ? s.fundsByGoal : {};

  const sig = JSON.stringify({ total, byGoal });
  if (sig === lastSignature) return;
  lastSignature = sig;

  document.getElementById("kasa-total").textContent = formatPLN(total);

  const box = document.getElementById("kasa-breakdown");
  box.innerHTML = "";
  const goals = Object.keys(byGoal);
  if (!goals.length) {
    const empty = document.createElement("div");
    empty.className = "kasa-empty";
    empty.textContent = "Czekam na wpłaty…";
    box.appendChild(empty);
    return;
  }

  goals.forEach((goal) => {
    const row = document.createElement("div");
    row.className = "kasa-row";
    const label = document.createElement("span");
    label.className = "kasa-goal";
    label.textContent = goal;
    const val = document.createElement("span");
    val.className = "kasa-amount";
    val.textContent = formatPLN(byGoal[goal]);
    row.appendChild(label);
    row.appendChild(val);
    box.appendChild(row);
  });
}

async function loop() {
  try { render(await getState()); } catch (e) { console.error("panel_kasa render:", e); }
}

window.addEventListener("DOMContentLoaded", () => {
  loop();
  setInterval(loop, 700);
});
