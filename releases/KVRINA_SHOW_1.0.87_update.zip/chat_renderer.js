// =========================
// KVRINA_SHOW — chat_renderer.js
// Renderer okna pop-out czatu / rubryczki giftów.
// Odbiera payloady "gift-board" z głównego okna przez IPC (onChatLine)
// i renderuje je w #chat-box w tym samym formacie co panel główny.
// =========================

const MAX_POPOUT_LINES = 120;
let popoutFontSize = 16;

function getUserColorLocal(name) {
  const s = String(name || "");
  if (!s) return "";
  let hash = 0;
  for (let i = 0; i < s.length; i++) {
    hash = (hash * 31 + s.charCodeAt(i)) >>> 0;
  }
  const hue = hash % 360;
  return `hsl(${hue}, 70%, 68%)`;
}

function appendGiftPopoutItem(item) {
  const box = document.getElementById("chat-box");
  if (!box || !item || item.kind !== "gift-board") return;

  const empty = box.querySelector(".gift-board-empty");
  if (empty) empty.remove();

  const threshold = 12;
  const pinned = (box.scrollHeight - box.scrollTop - box.clientHeight) <= threshold;

  const line = document.createElement("div");
  line.className = "gift-board-line";
  const amount = parseInt(item.amount || 0, 10) || 0;
  if (amount >= 450) line.classList.add("gift-board-big");

  const media = document.createElement("div");
  media.className = "gift-board-media";

  if (item.giftImageUrl) {
    const giftImg = document.createElement("img");
    giftImg.className = "gift-board-icon";
    giftImg.src = item.giftImageUrl;
    giftImg.alt = item.giftName || "gift";
    giftImg.addEventListener("load", () => {
      if (!pinned) return;
      requestAnimationFrame(() => requestAnimationFrame(() => { box.scrollTop = box.scrollHeight; }));
    });
    media.appendChild(giftImg);
  } else {
    const fallback = document.createElement("div");
    fallback.className = "gift-board-icon gift-board-icon-fallback";
    fallback.textContent = "🎁";
    media.appendChild(fallback);
  }

  if (item.avatarUrl) {
    const avatar = document.createElement("img");
    avatar.className = "gift-board-avatar";
    avatar.src = item.avatarUrl;
    avatar.alt = "";
    media.appendChild(avatar);
  }

  const content = document.createElement("div");
  content.className = "gift-board-content";

  const top = document.createElement("div");
  top.className = "gift-board-top";

  const user = document.createElement("span");
  user.className = "gift-board-user";
  user.textContent = item.username || "TikTok";
  const userColor = getUserColorLocal(item.username || "");
  if (userColor) user.style.color = userColor;

  const time = document.createElement("span");
  time.className = "gift-board-time";
  time.textContent = item.ts || new Date().toTimeString().slice(0, 8);

  top.appendChild(user);
  top.appendChild(time);

  const name = document.createElement("div");
  name.className = "gift-board-name";
  name.textContent = item.giftName || "prezent";

  const meta = document.createElement("div");
  meta.className = "gift-board-meta";
  const repeat = parseInt(item.repeatCount || 1, 10) || 1;
  meta.textContent = `${amount} monet${repeat > 1 ? ` • x${repeat}` : ""}`;

  content.appendChild(top);
  content.appendChild(name);
  content.appendChild(meta);

  line.appendChild(media);
  line.appendChild(content);
  box.appendChild(line);

  // limit wpisów w DOM
  while (box.children.length > MAX_POPOUT_LINES) {
    box.removeChild(box.firstChild);
  }

  if (pinned) {
    requestAnimationFrame(() => { box.scrollTop = box.scrollHeight; });
  }
}

function applyPopoutFontSize() {
  const box = document.getElementById("chat-box");
  if (box) box.style.fontSize = `${popoutFontSize}px`;
}

// Pełne skalowanie okna GIFTY — CSS `zoom` na całym #app skaluje wszystko naraz
// (spójnie z pozostałymi panelami i oknem czytnika). Zapamiętywane w localStorage.
const GIFTY_ZOOM_KEY = "kvrina_panel_zoom_gifty";
const GIFTY_ZOOM_MIN = 0.6;
const GIFTY_ZOOM_MAX = 1.8;
let giftyZoom = 1;

function applyGiftyZoom() {
  const app = document.getElementById("app") || document.body;
  if (!app) return;
  // Kompensacja wymiarów pod CSS `zoom` — inaczej przy zoomie ≠ 1 zostaje pusta przestrzeń.
  app.style.zoom = String(giftyZoom);
  app.style.width = (100 / giftyZoom) + "vw";
  app.style.height = (100 / giftyZoom) + "vh";
}
function saveGiftyZoom() {
  try { localStorage.setItem(GIFTY_ZOOM_KEY, String(giftyZoom)); } catch {}
}
function loadGiftyZoom() {
  try {
    const s = parseFloat(localStorage.getItem(GIFTY_ZOOM_KEY));
    if (Number.isFinite(s) && s >= GIFTY_ZOOM_MIN && s <= GIFTY_ZOOM_MAX) giftyZoom = s;
  } catch {}
}

function setupPopoutControls() {
  loadGiftyZoom();
  applyGiftyZoom();
  const minus = document.getElementById("chat-font-minus");
  const plus = document.getElementById("chat-font-plus");
  if (minus) minus.addEventListener("click", () => {
    giftyZoom = Math.max(GIFTY_ZOOM_MIN, Math.round((giftyZoom - 0.1) * 100) / 100);
    applyGiftyZoom();
    saveGiftyZoom();
  });
  if (plus) plus.addEventListener("click", () => {
    giftyZoom = Math.min(GIFTY_ZOOM_MAX, Math.round((giftyZoom + 0.1) * 100) / 100);
    applyGiftyZoom();
    saveGiftyZoom();
  });
}

window.addEventListener("DOMContentLoaded", () => {
  const box = document.getElementById("chat-box");
  if (box && !box.children.length) {
    box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
  }
  applyPopoutFontSize();
  setupPopoutControls();

  if (window.wbApi && typeof window.wbApi.onChatLine === "function") {
    window.wbApi.onChatLine((payload) => {
      try { appendGiftPopoutItem(payload); } catch (e) { console.error("popout render:", e); }
    });
  }
});
