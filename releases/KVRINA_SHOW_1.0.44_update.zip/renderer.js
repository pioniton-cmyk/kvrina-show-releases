const TIKFINITY_WS_URL = "ws://localhost:21213/";
const KARTON_DNIA_TEXT = "KARTON DNIA";
const KARTON_DNIA_KIND = "karton";

let outputDir = null;


// CZYTNIK PYTAŃ – stan
let autoQuestionsFilePath = null;
let autoQuestionsFileMtime = 0;
let questions = [];
let questionIndex = 0;
let filteredCount = 0;

// ZBIÓRKI (Tipped) – stan
let fundsTotal = 0; // suma PLN w tej sesji
let fundsByGoal = {}; // { "ZBIÓRKA ...": 123.45, ... }


// ZA GIFTY (TikFinity) – stan
let giftCredit = 450; // próg monet na wejście do kolejki (450 monet)
let tikfinityWs = null;
let tikfinityConnected = false;
let giftTotals = new Map(); // user -> total coins
let giftUsed = new Map();   // user -> used credits
let giftNewBlink = new Map(); // user -> blinkUntilTs
let giftFeed = []; // last lines
let selectedGiftUser = null;

// RANKING TAPÓW / LIKEÓW (TikFinity Event API)
let predictionRanking = new Map(); // nick -> liczba like/tapów
let predictionEventsFeed = [];

// KOLEJKA OBSERWUJĄCYCH – nicki z eventów follow TikFinity
const FOLLOW_QUEUE_STORAGE_KEY = "kvrina_follow_queue_v2";
let followQueue = [];
let followQueueKeys = new Set();
// ===== UI/Wydajność: rubryczka giftów, eco, animacje =====
const MAX_MAIN_CHAT_LINES = 800; // limit wpisów w rubryczce giftów w głównym oknie
const CHAT_FLUSH_MS = 60;        // batch DOM dla giftów (mniej szarpania)
let _chatQueue = [];
let _chatFlushTimer = null;

const MAX_FALLING_COINS_PER_PILLAR = 35;
const COIN_RAIN_INTERVAL_MS = 380;
let ecoMode = false;             // tryb oszczędny (animacje OFF)
let _coinRainPausedByHidden = false;


// FILARY MONET – celebracja
const PILLAR_MAX = 30;
let pillarLeftCoins = [];
let pillarRightCoins = [];
let coinRainInterval = null;

// Tryb "brak pytań" (gdy klikniesz DALEJ na ostatnim)
let noQuestionsMode = true;
let noQuestionsLength = 0;


// TIMERY – stan
let timer1Seconds = 3 * 3600;
let timer2Seconds = 20 * 60;
let timer1Interval = null;
let timer2Interval = null;

// ROZMIARY CZCIONEK
let chatFontSize = 16;
let chatVisible = true;
let questionFontSize = 30;
let queueFontSize = 18;
let questionQueueFontSize = 16;


// zapamiętywanie ustawień (np. rozmiary czcionek) między uruchomieniami
const WB_PREFS_KEY = "wb_prefs_v1";

const PANEL_LAYOUT_KEY = "kvrina_panel_layout_v1";
const PANEL_LAYOUT_FILE = "layout_paneli.json";
const PANEL_LAYOUT_CONFIG = {
  chat: { label: "GIFTY", target: "#left-column", base: 1.35, min: 0.7, max: 2.8, step: 0.1 },
  followers: { label: "OBSERWUJĄCY", target: "#queue-panel", base: 1.08, min: 0.45, max: 2.4, step: 0.1 },
  ranking: { label: "RANKING", target: "#ranking-preview-panel", base: 0.82, min: 0.35, max: 2.0, step: 0.1 },
  questionQueue: { label: "KOLEJKA", target: "#question-queue-column", base: 0.78, min: 0.45, max: 1.8, step: 0.08 },
  timers: { label: "TIMERY", target: "#timers-panel", base: 0.55, min: 0.28, max: 1.35, step: 0.08 },
  questions: { label: "CZYTNIK", target: "#questions-panel", base: 1.25, min: 0.65, max: 2.7, step: 0.1 },
};
let panelLayoutPrefs = { panels: {}, updatedAt: Date.now() };

function defaultPanelLayoutPrefs() {
  const panels = {};
  Object.entries(PANEL_LAYOUT_CONFIG).forEach(([id, cfg]) => {
    panels[id] = { value: cfg.base, locked: false };
  });
  return { version: 1, updatedAt: Date.now(), panels };
}

function loadPrefs() {
  try {
    const raw = localStorage.getItem(WB_PREFS_KEY);
    if (!raw) return;
    const obj = JSON.parse(raw);
    if (obj && typeof obj.chatFontSize === "number") chatFontSize = obj.chatFontSize;
    if (obj && typeof obj.queueFontSize === "number") queueFontSize = obj.queueFontSize;
    if (obj && typeof obj.questionQueueFontSize === "number") questionQueueFontSize = obj.questionQueueFontSize;
    if (obj && typeof obj.questionFontSize === "number") questionFontSize = obj.questionFontSize;
    if (obj && typeof obj.chatVisible === "boolean") chatVisible = obj.chatVisible;
    if (obj && typeof obj.giftCredit === "number" && Number.isFinite(obj.giftCredit)) {
      const v = Math.max(1, Math.min(100000, Math.floor(obj.giftCredit)));
      giftCredit = v;
    }
  } catch (e) {
    // ignore
  }
}

function savePrefs() {
  try {
    localStorage.setItem(
      WB_PREFS_KEY,
      JSON.stringify({
        chatFontSize,
        chatVisible,
        queueFontSize,
        questionQueueFontSize,
        questionFontSize,
        giftCredit,
      })
    );
  } catch (e) {
    // ignore
  }
}


function clampPanelValue(id, value) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return 1;
  const n = Number(value);
  const safe = Number.isFinite(n) ? n : cfg.base;
  return Math.max(cfg.min, Math.min(cfg.max, Math.round(safe * 100) / 100));
}

async function loadPanelLayoutPrefs() {
  panelLayoutPrefs = defaultPanelLayoutPrefs();
  try {
    const rawLocal = localStorage.getItem(PANEL_LAYOUT_KEY);
    if (rawLocal) {
      const obj = JSON.parse(rawLocal);
      if (obj && obj.panels) panelLayoutPrefs = mergePanelLayoutPrefs(obj);
    }
  } catch {}

  try {
    if (window.wbApi && typeof window.wbApi.readFile === "function") {
      const r = await window.wbApi.readFile(PANEL_LAYOUT_FILE);
      if (r && r.ok && r.data) {
        const obj = JSON.parse(String(r.data));
        if (obj && obj.panels) panelLayoutPrefs = mergePanelLayoutPrefs(obj);
      }
    }
  } catch {}
}

function mergePanelLayoutPrefs(obj) {
  const base = defaultPanelLayoutPrefs();
  if (obj && typeof obj.updatedAt === "number") base.updatedAt = obj.updatedAt;
  Object.keys(PANEL_LAYOUT_CONFIG).forEach((id) => {
    const src = obj && obj.panels ? obj.panels[id] : null;
    if (src) {
      base.panels[id] = {
        value: clampPanelValue(id, src.value),
        locked: !!src.locked,
      };
    }
  });
  return base;
}

function applyPanelLayoutPrefs() {
  Object.entries(PANEL_LAYOUT_CONFIG).forEach(([id, cfg]) => {
    const state = (panelLayoutPrefs.panels && panelLayoutPrefs.panels[id]) || { value: cfg.base, locked: false };
    const el = document.querySelector(cfg.target);
    if (!el) return;
    const value = clampPanelValue(id, state.value);
    el.style.flex = `${value} 1 0`;
    el.style.minHeight = "0";
  });
  refreshPanelLayoutControls();
}

function panelSizeLabel(id) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  const state = panelLayoutPrefs.panels[id] || { value: cfg.base };
  return `${Math.round((clampPanelValue(id, state.value) / cfg.base) * 100)}%`;
}

async function savePanelLayoutPrefs() {
  try {
    panelLayoutPrefs.updatedAt = Date.now();
    const data = JSON.stringify(panelLayoutPrefs, null, 2);
    localStorage.setItem(PANEL_LAYOUT_KEY, data);
    if (window.wbApi && typeof window.wbApi.writeFile === "function") {
      await window.wbApi.writeFile(PANEL_LAYOUT_FILE, data);
    }
  } catch {}
}

function setPanelLayoutValue(id, nextValue) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return;
  const current = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
  if (current.locked) return;
  panelLayoutPrefs.panels[id] = { ...current, value: clampPanelValue(id, nextValue) };
  applyPanelLayoutPrefs();
  savePanelLayoutPrefs();
}

function togglePanelLayoutLock(id) {
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return;
  const current = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
  panelLayoutPrefs.panels[id] = { ...current, locked: !current.locked };
  applyPanelLayoutPrefs();
  savePanelLayoutPrefs();
}

function refreshPanelLayoutControls() {
  document.querySelectorAll(".panel-scale-controls").forEach((wrap) => {
    const id = wrap.dataset.panelLayoutId;
    const cfg = PANEL_LAYOUT_CONFIG[id];
    const state = cfg && panelLayoutPrefs.panels[id] ? panelLayoutPrefs.panels[id] : null;
    if (!cfg || !state) return;
    const label = wrap.querySelector(".panel-scale-value");
    const lock = wrap.querySelector(".panel-lock-btn");
    const minus = wrap.querySelector(".panel-scale-minus");
    const plus = wrap.querySelector(".panel-scale-plus");
    if (label) label.textContent = panelSizeLabel(id);
    if (lock) {
      lock.textContent = state.locked ? "🔒" : "🔓";
      lock.title = state.locked ? "Układ zablokowany i zapamiętany" : "Kliknij, żeby zablokować układ";
      lock.classList.toggle("locked", !!state.locked);
    }
    if (minus) minus.disabled = !!state.locked;
    if (plus) plus.disabled = !!state.locked;
  });
}

function addPanelLayoutControl(id, header) {
  if (!header || header.querySelector(`[data-panel-layout-id="${id}"]`)) return;
  const cfg = PANEL_LAYOUT_CONFIG[id];
  if (!cfg) return;
  const wrap = document.createElement("div");
  wrap.className = "panel-scale-controls";
  wrap.dataset.panelLayoutId = id;
  wrap.innerHTML = `
    <button type="button" class="btn tiny circle panel-scale-minus" title="Zmniejsz panel">−</button>
    <span class="panel-scale-value">${panelSizeLabel(id)}</span>
    <button type="button" class="btn tiny circle panel-scale-plus" title="Powiększ panel">+</button>
    <button type="button" class="btn tiny circle panel-lock-btn" title="Zablokuj układ">🔓</button>
  `;
  header.appendChild(wrap);
  wrap.querySelector(".panel-scale-minus")?.addEventListener("click", () => {
    const state = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
    setPanelLayoutValue(id, state.value - cfg.step);
  });
  wrap.querySelector(".panel-scale-plus")?.addEventListener("click", () => {
    const state = panelLayoutPrefs.panels[id] || { value: cfg.base, locked: false };
    setPanelLayoutValue(id, state.value + cfg.step);
  });
  wrap.querySelector(".panel-lock-btn")?.addEventListener("click", () => togglePanelLayoutLock(id));
}

function setupPanelLayoutControls() {
  addPanelLayoutControl("chat", document.querySelector("#chat-panel .panel-header"));
  addPanelLayoutControl("followers", document.querySelector("#queue-panel .panel-header"));
  addPanelLayoutControl("ranking", document.querySelector("#ranking-preview-panel .panel-header"));
  addPanelLayoutControl("questionQueue", document.querySelector("#question-queue-panel .panel-header"));
  addPanelLayoutControl("timers", document.querySelector("#timers-panel .panel-header"));
  addPanelLayoutControl("questions", document.querySelector("#questions-panel .panel-header"));
  refreshPanelLayoutControls();
}


// TikTok statystyki
let tiktokViewerCount = 0;

// TRYB DEMO LIVE — lokalna symulacja eventów do ustawiania sceny i widgetów
let demoModeActive = false;
let demoInterval = null;
let demoTick = 0;

const DEMO_NICKS = [
  "Wiedźma Basia", "Kasia Tarot", "Luna", "Marta", "Njut", "Ania", "Karolina",
  "Magdalena", "Ola", "Patrycja", "Monika", "Julia", "Natalia", "Agata", "Ewelina",
  "Sylwia", "Klaudia", "Daria", "Weronika", "Maja"
];
const DEMO_QUESTIONS = [
  "Czy on jeszcze o mnie myśli?",
  "Co wydarzy się w miłości w najbliższych dniach?",
  "Czy warto odezwać się jako pierwsza?",
  "Jaka energia jest teraz między nami?",
  "Czy ta relacja ma potencjał na coś poważnego?",
  "Co blokuje mój rozwój i pieniądze?",
  "Czy zmiana pracy będzie dla mnie dobra?",
  "Jaką wiadomość mają dla mnie karty na dziś?",
  "x"
];
const DEMO_GIFTS = [
  { name: "Róża", amount: 1 },
  { name: "Serce", amount: 5 },
  { name: "Kryształ", amount: 10 },
  { name: "Wszechświat", amount: 100 },
  { name: "Złota Kula", amount: 450 },
  { name: "Magiczny Lew", amount: 699 },
  { name: "Galaktyka", amount: 1200 }
];

// PALETA KOLORÓW DLA UŻYTKOWNIKÓW (około 20 odcieni)
const USER_COLORS = [
  "#e74c3c", "#e67e22", "#f1c40f", "#2ecc71", "#1abc9c",
  "#3498db", "#9b59b6", "#16a085", "#27ae60", "#2980b9",
  "#8e44ad", "#d35400", "#c0392b", "#7f8c8d", "#bdc3c7",
  "#f39c12", "#e84393", "#fd79a8", "#00cec9", "#6c5ce7"
];
const userColorMap = new Map();
let userColorIndex = 0;

function getUserColor(username) {
  if (!username) return null;
  if (userColorMap.has(username)) return userColorMap.get(username);
  const color = USER_COLORS[userColorIndex % USER_COLORS.length];
  userColorMap.set(username, color);
  userColorIndex++;
  return color;
}

function isKartonDniaEntry(entry) {
  return !!entry && (entry.kind === KARTON_DNIA_KIND || String(entry.question || "").trim().toUpperCase() === KARTON_DNIA_TEXT);
}

function setKartonDniaUi(active) {
  const box = document.getElementById("question-current");
  if (!box) return;
  box.classList.toggle("karton-dnia-mode", !!active);
}


function getTikTokNickname(payload) {
  // Chcemy WYŁĄCZNIE nazwę wyświetlaną (nickname) – bez @handle/uniqueId
  const name =
    (payload && (payload.nickname || payload.displayName)) ||
    (payload && payload.user && (payload.user.nickname || payload.user.displayName)) ||
    "";
  const cleaned = String(name || "").trim();
  return cleaned || "TT_Anon";
}





function parseHmsToSeconds(s) {
  const str = String(s || "").trim();
  if (!str) return null;
  // Akceptuje: H:MM:SS albo HH:MM:SS
  const m = str.match(/^(\d+):([0-5]\d):([0-5]\d)$/);
  if (!m) return null;
  const h = parseInt(m[1], 10);
  const mm = parseInt(m[2], 10);
  const ss = parseInt(m[3], 10);
  if ([h, mm, ss].some((x) => Number.isNaN(x))) return null;
  return h * 3600 + mm * 60 + ss;
}

function parseMsToSeconds(s) {
  const str = String(s || "").trim();
  if (!str) return null;
  // Akceptuje: M:SS (np. 20:05)
  const m = str.match(/^(\d+):([0-5]\d)$/);
  if (!m) return null;
  const mm = parseInt(m[1], 10);
  const ss = parseInt(m[2], 10);
  if ([mm, ss].some((x) => Number.isNaN(x))) return null;
  return mm * 60 + ss;
}

async function hydrateTimersFromFiles() {
  try {
    const r1 = await window.wbApi.readFile("odliczanie1.txt");
    const r2 = await window.wbApi.readFile("odliczanie2.txt");

    if (r1 && r1.ok && r1.data) {
      const sec = parseHmsToSeconds(r1.data.trim());
      timer1Seconds = typeof sec === "number" ? sec : 0;
    }

    if (r2 && r2.ok && r2.data) {
      const sec = parseMsToSeconds(r2.data.trim());
      timer2Seconds = typeof sec === "number" ? sec : 0;
    }
  } catch (err) {
    console.error("hydrateTimersFromFiles error:", err);
  }
}

window.addEventListener("DOMContentLoaded", async () => {
  outputDir = await window.wbApi.getOutputDir();
  // START PUSTO: nie wczytujemy starych TXT ani logów przy starcie.


  loadPrefs();
  await loadPanelLayoutPrefs();
  applyPanelLayoutPrefs();
  applyFontSizes();
  applyChatVisibility();
  setupChatToggle();
  setupChat();
  setupQueue();
  setupRankingPreviewPanel();
  setupQuestionOrderQueue();
  setupQuestions();
  await hydrateTimersFromFiles();
  setupTimers();
  // Przy starcie wracamy do stanu sprzed zamknięcia programu.
  await restoreSessionOnStartup();
  await updateBackupStatusPill();
  setupWebhookStatusPolling();
  setupTikfinityReconnectButton();
  connectTikFinity();
  setupTunnelControls();
  setupUtilityControls();
  setupUpdateControls();
  setupDemoControls();
  setupWidgetStatePublishing();
  setupPanelLayoutControls();

  window.addEventListener("beforeunload", () => {
    try { writeBackupNow(); } catch {}
    try { savePanelLayoutPrefs(); } catch {}
  });

  // Tipped webhook -> auto questions (optional toast)
  try {
    if (window.wbApi && typeof window.wbApi.onTippedQuestion === "function") {
      window.wbApi.onTippedQuestion((p) => {
        if (!p || !p.nick) return;
        // Nowe pytanie z Tipped -> dopisz do kolejki w pamięci (chronologicznie po ts)
        addIncomingAutoQuestion(p);
      });
    }
  } catch {}

  try {
    if (window.wbApi && typeof window.wbApi.onTippedFund === "function") {
      window.wbApi.onTippedFund((p) => {
        applyFundDonation(p);
      });
    }
  } catch {}

});

// =========================
// CLOUDLFARED TUNNEL UI
// =========================


let _webhookStatusTimer = null;

function setStatusPill(id, text, cls) {
  const el = document.getElementById(id);
  if (!el) return;
  el.textContent = text;
  el.classList.remove("status-ok", "status-info", "status-warn");
  if (cls) el.classList.add(cls);
}


function formatPLN(amount) {
  const n = typeof amount === "number" ? amount : parseFloat(String(amount || "").replace(",", "."));
  const v = Number.isFinite(n) ? n : 0;
  // polski format: 1 234,56
  const parts = v.toFixed(2).split(".");
  const intPart = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, " ");
  return `${intPart},${parts[1]} zł`;
}

function updateFundsPill() {
  // pill w topbar: "Zbiórki: 0,00 zł"
  const el = document.getElementById("status-funds");
  if (!el) return;
  el.textContent = `Zbiórki: ${formatPLN(fundsTotal)}`;
  el.classList.remove("status-ok", "status-info", "status-warn");
  // jeśli coś wpadło – OK, jak nie – info
  el.classList.add(fundsTotal > 0 ? "status-ok" : "status-info");
}

async function persistFundsFiles() {
  try {
    if (!window.wbApi || typeof window.wbApi.writeFile !== "function") return;
    await window.wbApi.writeFile("zbiorki_total.txt", `ZBIÓRKI: ${formatPLN(fundsTotal)}\n`);
    await window.wbApi.writeFile("zbiorki_state.json", JSON.stringify({ total: fundsTotal, byGoal: fundsByGoal, savedAt: Date.now() }, null, 2));
  } catch {
    // ignore
  }
}

function parseAmountPLN(value) {
  if (typeof value === "number") return Number.isFinite(value) ? value : 0;
  const raw = String(value ?? "").replace(/\s+/g, "").replace("zł", "").replace("PLN", "").replace(",", ".");
  const n = parseFloat(raw);
  return Number.isFinite(n) ? n : 0;
}

function applyFundDonation(payload = {}) {
  try {
    const amount = Math.max(0, parseAmountPLN(payload.amount ?? payload.value ?? payload.total));
    if (!amount) return;
    const goal = String(payload.goal || payload.label || payload.title || "Zbiórka").trim() || "Zbiórka";
    const payer = String(payload.payer || payload.nick || payload.name || "Anon").trim() || "Anon";

    fundsTotal = Math.round((fundsTotal + amount) * 100) / 100;
    fundsByGoal[goal] = Math.round(((parseAmountPLN(fundsByGoal[goal]) || 0) + amount) * 100) / 100;

    updateFundsPill();
    persistFundsFiles();
    appendSystem(`[ZBIÓRKA] ${payer}: ${formatPLN(amount)} → ${goal}`);
    scheduleBackup();
    scheduleWidgetStateWrite();
  } catch (e) {
    console.warn("applyFundDonation failed:", e);
  }
}


async function updateWebhookStatusNow() {
  try {
    if (!window.wbApi || typeof window.wbApi.webhookGetStatus !== "function") return;
    const st = await window.wbApi.webhookGetStatus();
    if (!st || !st.ok) return;
    const on = !!st.running;
    const hashInfo = st.hashOk ? " • hash OK" : " • hash ?";
    const txt = on ? `Webhook: ON (${st.port})${hashInfo} • pending: ${st.pending}` : "Webhook: OFF";
    setStatusPill("status-webhook", txt, on ? "status-ok" : "status-warn");
    if (st.widgetPort) setStatusPill("status-widgets", `Widgety: ON (${st.widgetPort})`, "status-ok");
  } catch {}
}

function setupWebhookStatusPolling() {
  updateWebhookStatusNow();
  if (_webhookStatusTimer) clearInterval(_webhookStatusTimer);
  _webhookStatusTimer = setInterval(updateWebhookStatusNow, 2500);
}

function setupTikfinityReconnectButton() {
  const btn = document.getElementById("btn-tikfinity-reconnect");
  if (!btn) return;
  btn.addEventListener("click", () => {
    connectTikFinity(true);
  });
}

// =========================
// Utility controls (topbar)
// =========================


const WIDGET_PREVIEW_ITEMS = [
  { id: "question", label: "PYTANIE DO KART", desc: "Aktualny wpis / pytanie / Karton Dnia", url: "http://127.0.0.1:8750/widget-pytanie.html" },
  { id: "queue", label: "KOLEJKA PYTAŃ", desc: "Aktualna osoba + kolejne pozycje", url: "http://127.0.0.1:8750/widget-kolejka.html" },
  { id: "ranking", label: "RANKING TAPÓW", desc: "Jedyny oficjalny adres: TikFinity Web Top Liker", url: "http://127.0.0.1:8750/widget-ranking.html" },
  { id: "activity", label: "AKTYWNOŚCI", desc: "Feed aktywności TikFinity Web", url: "http://127.0.0.1:8750/widget-aktywnosci.html" },
  { id: "demo", label: "DEMO WSZYSTKICH", desc: "Podgląd wszystkich widgetów w jednej planszy", url: "http://127.0.0.1:8750/demo.html" },
];

let _widgetsPanelSelectedUrl = WIDGET_PREVIEW_ITEMS[0].url;

function escapeHtml(value) {
  return String(value ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function setWidgetsCopyStatus(text, mode = "info") {
  const el = document.getElementById("widgets-copy-status");
  if (!el) return;
  el.textContent = text;
  el.classList.remove("ok", "warn");
  if (mode === "ok") el.classList.add("ok");
  if (mode === "warn") el.classList.add("warn");
}

function selectWidgetPreview(itemId) {
  const item = WIDGET_PREVIEW_ITEMS.find((x) => x.id === itemId) || WIDGET_PREVIEW_ITEMS[0];
  _widgetsPanelSelectedUrl = item.url;

  const frame = document.getElementById("widgets-preview-frame");
  const input = document.getElementById("widgets-active-url");
  const title = document.getElementById("widgets-preview-title");
  if (frame) frame.src = item.url + (item.url.includes("?") ? "&" : "?") + "previewTs=" + Date.now();
  if (input) input.value = item.url;
  if (title) title.textContent = `${item.label} — podgląd`;

  document.querySelectorAll(".widget-url-item").forEach((btn) => {
    btn.classList.toggle("active", btn.dataset.widgetId === item.id);
  });
}

function renderWidgetsUrlList() {
  const list = document.getElementById("widgets-url-list");
  if (!list) return;
  list.innerHTML = "";

  WIDGET_PREVIEW_ITEMS.forEach((item) => {
    const row = document.createElement("button");
    row.type = "button";
    row.className = "widget-url-item";
    row.dataset.widgetId = item.id;
    row.innerHTML = `
      <span class="widget-url-main">
        <span class="widget-url-label">${escapeHtml(item.label)}</span>
        <span class="widget-url-desc">${escapeHtml(item.desc)}</span>
        <span class="widget-url-path">${escapeHtml(item.url)}</span>
      </span>
      <span class="widget-url-copy">KOPIUJ</span>
    `;

    row.addEventListener("click", async (evt) => {
      selectWidgetPreview(item.id);
      if (evt.target && evt.target.classList && evt.target.classList.contains("widget-url-copy")) {
        try {
          await window.wbApi.clipboardCopy(item.url);
          setWidgetsCopyStatus(`Skopiowano URL: ${item.label}`, "ok");
        } catch {
          setWidgetsCopyStatus("Nie udało się skopiować URL.", "warn");
        }
      }
    });

    list.appendChild(row);
  });
}

function openWidgetsPanel() {
  const modal = document.getElementById("widgets-modal");
  if (!modal) return;
  renderWidgetsUrlList();
  modal.classList.remove("hidden");
  modal.setAttribute("aria-hidden", "false");
  selectWidgetPreview(WIDGET_PREVIEW_ITEMS[0].id);
  setWidgetsCopyStatus("Kliknij widget po lewej, żeby podejrzeć i skopiować jego adres.", "info");
}

function closeWidgetsPanel() {
  const modal = document.getElementById("widgets-modal");
  const frame = document.getElementById("widgets-preview-frame");
  if (frame) frame.src = "about:blank";
  if (!modal) return;
  modal.classList.add("hidden");
  modal.setAttribute("aria-hidden", "true");
}

function setupWidgetsPanelControls() {
  const btnClose = document.getElementById("widgets-close");
  const btnCopy = document.getElementById("widgets-copy-active");
  const btnFolder = document.getElementById("widgets-open-folder");
  const btnDemo = document.getElementById("widgets-open-demo");
  const modal = document.getElementById("widgets-modal");

  if (btnClose) btnClose.addEventListener("click", closeWidgetsPanel);
  if (modal) {
    modal.addEventListener("click", (evt) => {
      if (evt.target && evt.target.dataset && evt.target.dataset.widgetsClose) closeWidgetsPanel();
    });
  }
  document.addEventListener("keydown", (evt) => {
    if (evt.key === "Escape") closeWidgetsPanel();
  });

  if (btnCopy) {
    btnCopy.addEventListener("click", async () => {
      try {
        await window.wbApi.clipboardCopy(_widgetsPanelSelectedUrl);
        setWidgetsCopyStatus("Skopiowano URL aktualnie wybranego widgetu.", "ok");
      } catch {
        setWidgetsCopyStatus("Nie udało się skopiować URL.", "warn");
      }
    });
  }

  if (btnFolder) {
    btnFolder.addEventListener("click", async () => {
      try {
        await window.wbApi.openWidgetsDir();
        setWidgetsCopyStatus("Otworzyłem folder z widgetami i plikiem adresy_widgetow.txt.", "ok");
      } catch {
        setWidgetsCopyStatus("Nie udało się otworzyć folderu widgetów.", "warn");
      }
    });
  }

  if (btnDemo) {
    btnDemo.addEventListener("click", () => selectWidgetPreview("demo"));
  }
}

function setupUtilityControls() {
  // ECO / PANIC usunięte: zawsze normalny tryb
  ecoMode = false;
  try { localStorage.removeItem("wbEcoMode"); } catch {}

  const btnOpen = document.getElementById("btn-open-output");
  if (btnOpen) {
    btnOpen.addEventListener("click", async () => {
      try { await window.wbApi.openOutputDir(); } catch {}
    });
  }

  setupWidgetsPanelControls();

  const btnWidgets = document.getElementById("btn-open-widgets");
  if (btnWidgets) {
    btnWidgets.addEventListener("click", openWidgetsPanel);
  }

  const btnClear = document.getElementById("btn-clear-chat");
  if (btnClear) {
    btnClear.addEventListener("click", () => {
      const box = document.getElementById("chat-box");
      if (box) box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
      _chatQueue = [];
    });
  }


  // pauza animacji gdy okno jest w tle (oszczędność i stabilność)
  document.addEventListener("visibilitychange", () => {
    if (document.hidden) {
      if (coinRainInterval) _coinRainPausedByHidden = true;
      stopCoinRain();
    } else {
      if (_coinRainPausedByHidden) {
        _coinRainPausedByHidden = false;
        try { updateTunnelAndPillars(); } catch {}
      }
    }
  });
}

function updateTikfinityStatusUi() {
  if (tikfinityConnected) {
    setStatusPill("status-tikfinity", "TikFinity: connected", "status-ok");
  } else {
    setStatusPill("status-tikfinity", "TikFinity: offline", "status-warn");
  }
}

function setTunnelUrlUi(webhookUrl) {
  const el = document.getElementById("tunnel-url");
  if (!el) return;
  el.textContent = `Webhook URL: ${webhookUrl || "-"}`;
}


function setupTunnelControls() {
  const btnStart = document.getElementById("btn-start-tunnel"); // stary przycisk ukryty/usunięty — obsługa zostaje awaryjnie
  const btnStop = document.getElementById("btn-stop-tunnel");   // stary przycisk ukryty/usunięty — obsługa zostaje awaryjnie
  const btnCopy = document.getElementById("btn-copy-tunnel");
  const localWebhookUrl = "http://127.0.0.1:8787/webhook";

  // Initial status
  try {
    if (window.wbApi && typeof window.wbApi.tunnelGet === "function") {
      window.wbApi.tunnelGet().then((r) => {
        if (r && r.webhookUrl) setTunnelUrlUi(r.webhookUrl);
      });
    }
  } catch {}

  if (btnStart) {
    btnStart.addEventListener("click", async () => {
      try {
        const r = await window.wbApi.tunnelStart();
        if (r && r.error) {
          appendSystem(`[WEBHOOK] ${r.error}`);
          return;
        }
        appendSystem("[WEBHOOK] Start tunelu… URL skopiuje się automatycznie, jak tylko się pojawi.");
      } catch (e) {
        appendSystem("[WEBHOOK] Nie udało się uruchomić tunelu.");
      }
    });
  }

  if (btnStop) {
    btnStop.addEventListener("click", async () => {
      try {
        await window.wbApi.tunnelStop();
        setTunnelUrlUi(null);
        appendSystem("[WEBHOOK] Tunel zatrzymany.");
      } catch {}
    });
  }

  if (btnCopy) {
    btnCopy.addEventListener("click", async () => {
      try {
        const r = await window.wbApi.tunnelGet();
        if (r && r.webhookUrl) {
          try { await window.wbApi.clipboardCopy(r.webhookUrl); } catch {}
          setTunnelUrlUi(r.webhookUrl);
          appendSystem("[WEBHOOK] Publiczny URL jest w schowku. Wklej go do Tipped.");
          return;
        }

        appendSystem("[WEBHOOK] Nie ma aktywnego publicznego tunelu — uruchamiam go automatycznie. Lokalny URL też skopiowałem awaryjnie.");
        try { await window.wbApi.clipboardCopy(localWebhookUrl); } catch {}
        setTunnelUrlUi(localWebhookUrl);
        try {
          const started = await window.wbApi.tunnelStart();
          if (started && started.error) {
            appendSystem(`[WEBHOOK] Tunel publiczny nie wystartował: ${started.error}. Lokalny webhook działa na 127.0.0.1:8787/webhook.`);
          }
        } catch {
          appendSystem("[WEBHOOK] Nie udało się uruchomić publicznego tunelu. Sprawdź cloudflared, ale lokalny webhook działa na 127.0.0.1:8787/webhook.");
        }
      } catch {}
    });
  }

  // Listen for URL from main
  try {
    if (window.wbApi && typeof window.wbApi.onTunnelUrl === "function") {
      window.wbApi.onTunnelUrl((p) => {
        if (!p || !p.webhookUrl) return;
        setTunnelUrlUi(p.webhookUrl);
        appendSystem(`[WEBHOOK] Tunel gotowy. Skopiowałem URL do schowka.`);
      });
    }
    if (window.wbApi && typeof window.wbApi.onTunnelStopped === "function") {
      window.wbApi.onTunnelStopped(() => {
        setTunnelUrlUi(null);
        appendSystem("[WEBHOOK] Tunel rozłączony.");
      });
    }
  } catch {}
}


function formatZipSize(bytes) {
  const n = Number(bytes || 0);
  if (!Number.isFinite(n) || n <= 0) return "0 MB";
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

async function refreshUpdateStatus() {
  try {
    if (!window.wbApi || typeof window.wbApi.updateCheck !== "function") return;
    const r = await window.wbApi.updateCheck();
    if (!r || !r.ok) {
      setStatusPill("status-update", "Aktualizacja: błąd", "status-warn");
      return;
    }
    const zips = Array.isArray(r.zips) ? r.zips : [];
    if (!zips.length) {
      setStatusPill("status-update", "Aktualizacja: brak ZIP", "status-info");
    } else {
      const newest = zips[0];
      setStatusPill("status-update", `Aktualizacja: ${newest.name} (${formatZipSize(newest.size)})`, "status-ok");
    }
  } catch {
    setStatusPill("status-update", "Aktualizacja: błąd", "status-warn");
  }
}

async function handleUpdateInstallResult(r) {
  if (r && r.ok) {
    setStatusPill("status-update", `Aktualizacja: zainstalowana${r.version ? " " + r.version : ""}`, "status-ok");
    const saved = r.savedTo ? ` Zapisano w aktualizacje/: ${r.savedTo}` : "";
    appendSystem(`[AKTUALIZACJE] Zainstalowano ZIP: ${r.zip}.${saved} Backup: ${r.backupDir}`);
    await refreshUpdateStatus();
    return;
  }
  if (r && r.cancelled) {
    await refreshUpdateStatus();
    return;
  }
  setStatusPill("status-update", "Aktualizacja: błąd", "status-warn");
  appendSystem(`[AKTUALIZACJE] Błąd: ${(r && r.error) || "nieznany"}`);
}

let _githubUpdateInfo = null;

function updatesModalSetStatus(text, type) {
  const el = document.getElementById("updates-status-text");
  if (!el) return;
  el.textContent = text;
  el.className = type === "ok" ? "status-ok" : type === "warn" ? "status-warn" : type === "new" ? "status-new" : "";
  setStatusPill("status-update", text, type === "ok" ? "status-ok" : type === "warn" ? "status-warn" : "status-info");
}

function setupUpdateControls() {
  const modal       = document.getElementById("updates-modal");
  const btnOpen     = document.getElementById("btn-aktualizacje");
  const btnClose    = document.getElementById("updates-close");
  const backdrop    = modal ? modal.querySelector("[data-updates-close]") : null;
  const btnCheck    = document.getElementById("btn-updates-check");
  const btnInstall  = document.getElementById("btn-updates-install");
  const btnRestore  = document.getElementById("btn-updates-restore");
  const verEl       = document.getElementById("updates-current-version");

  // Ustaw wersję w nagłówku modalu
  try {
    if (verEl && window.wbApi) {
      window.wbApi.readFile && window.wbApi.readFile("../package.json")
        .then(txt => { try { verEl.textContent = "Wersja " + JSON.parse(txt).version; } catch {} })
        .catch(() => {});
    }
  } catch {}

  // Pilot GitHub progress
  if (window.wbApi && typeof window.wbApi.onGithubProgress === "function") {
    window.wbApi.onGithubProgress((data) => {
      if (data && data.status === "downloading") updatesModalSetStatus("Pobieranie aktualizacji z GitHub…", "warn");
      if (data && data.status === "installing")  updatesModalSetStatus("Instalowanie aktualizacji…", "warn");
    });
  }

  // Otwórz / zamknij modal
  function openModal() {
    if (!modal) return;
    modal.classList.remove("hidden");
    modal.setAttribute("aria-hidden", "false");
  }
  function closeModal() {
    if (!modal) return;
    modal.classList.add("hidden");
    modal.setAttribute("aria-hidden", "true");
  }

  if (btnOpen)    btnOpen.addEventListener("click", openModal);
  if (btnClose)   btnClose.addEventListener("click", closeModal);
  if (backdrop)   backdrop.addEventListener("click", closeModal);

  // SPRAWDŹ AKTUALIZACJE
  if (btnCheck) {
    btnCheck.addEventListener("click", async () => {
      try {
        btnCheck.disabled = true;
        btnCheck.textContent = "SPRAWDZAM…";
        if (btnInstall) btnInstall.disabled = true;
        updatesModalSetStatus("Sprawdzam GitHub…", "warn");

        const r = await window.wbApi.githubCheck();

        if (r && r.available) {
          _githubUpdateInfo = r;
          if (btnInstall) btnInstall.disabled = false;
          updatesModalSetStatus(`Dostępna nowa wersja: ${r.latestVersion}  (aktualna: ${r.currentVersion})`, "new");
          appendSystem(`[AKTUALIZACJE] Nowa wersja na GitHub: ${r.latestVersion}`);
        } else if (r && !r.error) {
          _githubUpdateInfo = null;
          if (btnInstall) btnInstall.disabled = true;
          updatesModalSetStatus(`Masz najnowszą wersję (${r.currentVersion}).`, "ok");
        } else {
          updatesModalSetStatus("Błąd połączenia z GitHub. Sprawdź internet.", "warn");
        }
      } catch (e) {
        updatesModalSetStatus("Błąd sprawdzania aktualizacji.", "warn");
        appendSystem(`[AKTUALIZACJE] Błąd: ${e && e.message ? e.message : e}`);
      } finally {
        btnCheck.disabled = false;
        btnCheck.textContent = "SPRAWDŹ AKTUALIZACJE";
      }
    });
  }

  // AKTUALIZUJ
  if (btnInstall) {
    btnInstall.addEventListener("click", async () => {
      if (!_githubUpdateInfo || !_githubUpdateInfo.available) return;
      const ok = confirm(`Zainstalować wersję ${_githubUpdateInfo.latestVersion}?\n\nProgram zrobi backup i zapyta o restart.`);
      if (!ok) return;
      try {
        btnInstall.disabled = true;
        btnCheck.disabled   = true;
        updatesModalSetStatus("Pobieranie i instalowanie aktualizacji…", "warn");
        const r = await window.wbApi.githubDownloadInstall({
          downloadUrl: _githubUpdateInfo.downloadUrl,
          assetName:   _githubUpdateInfo.assetName
        });
        _githubUpdateInfo = null;
        await handleUpdateInstallResult(r);
        if (r && r.ok) updatesModalSetStatus(`Zainstalowano wersję ${r.version || ""}. Restart zaraz.`, "ok");
      } catch (e) {
        updatesModalSetStatus("Błąd instalacji aktualizacji.", "warn");
        appendSystem(`[AKTUALIZACJE] Błąd: ${e && e.message ? e.message : e}`);
        btnInstall.disabled = false;
      } finally {
        btnCheck.disabled = false;
      }
    });
  }

  // POPRZEDNIA WERSJA
  if (btnRestore) {
    btnRestore.addEventListener("click", async () => {
      try {
        updatesModalSetStatus("Przywracanie poprzedniej wersji…", "warn");
        const r = await window.wbApi.updateRestorePrevious();
        if (r && r.ok) {
          updatesModalSetStatus(`Przywrócono wersję ${r.version || "poprzednią"}.`, "ok");
          appendSystem(`[AKTUALIZACJE] Przywrócono z backupu: ${r.restoredFrom}`);
        } else if (r && r.cancelled) {
          updatesModalSetStatus("Anulowano.", "");
        } else {
          updatesModalSetStatus(`Błąd: ${(r && r.error) || "brak backupu do przywrócenia"}.`, "warn");
        }
      } catch (e) {
        updatesModalSetStatus("Błąd cofania wersji.", "warn");
        appendSystem(`[AKTUALIZACJE] Błąd cofania: ${e && e.message ? e.message : e}`);
      }
    });
  }
}

/* ====== TRYB DEMO LIVE ====== */

function demoPick(arr) {
  return arr[Math.floor(Math.random() * arr.length)];
}

function updateDemoStatusUi() {
  setStatusPill("status-demo", demoModeActive ? "Demo: LIVE" : "Demo: OFF", demoModeActive ? "status-ok" : "status-info");
  if (document.body) document.body.classList.toggle("demo-mode", !!demoModeActive);
  const btn = document.getElementById("btn-toggle-demo");
  if (btn) {
    btn.textContent = demoModeActive ? "WYJDŹ Z DEMO" : "DEMO LIVE";
    btn.classList.toggle("red", !!demoModeActive);
    btn.classList.toggle("green", !demoModeActive);
  }
}

function setupDemoControls() {
  const btnToggle = document.getElementById("btn-toggle-demo");
  const btnStart = document.getElementById("btn-start-demo"); // stare ID awaryjnie
  const btnStop = document.getElementById("btn-stop-demo");   // stare ID awaryjnie
  const btnReset = document.getElementById("btn-reset-demo"); // stare ID awaryjnie
  const btnResetSession = document.getElementById("btn-reset-session");

  updateDemoStatusUi();

  if (btnToggle) {
    btnToggle.addEventListener("click", async () => {
      if (demoModeActive) {
        stopDemoMode();
        await resetWholeSession(false, "[DEMO] Wyjście z demo — sesja demo wyczyszczona do zera.");
      } else {
        startDemoMode();
      }
    });
  }
  if (btnResetSession) btnResetSession.addEventListener("click", () => resetWholeSession(true));
  if (btnStart) btnStart.addEventListener("click", () => startDemoMode());
  if (btnStop) btnStop.addEventListener("click", async () => { stopDemoMode(); await resetWholeSession(false, "[DEMO] Stop demo — sesja demo wyczyszczona."); });
  if (btnReset) btnReset.addEventListener("click", () => resetDemoMode());
}

function startDemoMode() {
  if (demoModeActive) return;
  demoModeActive = true;
  demoTick = 0;
  updateDemoStatusUi();

  appendSystem("[DEMO] Start symulacji live: obserwacje, gifty, tapy/like, pytania i zbiórki. Ranking tapów w widgetach przełącza się na demo.");
  scheduleWidgetStateWrite();

  if (!hasSessionData() && !followQueue.length) {
    seedDemoLive();
  }

  demoInterval = setInterval(runDemoTick, 1250);
}

function stopDemoMode() {
  if (demoInterval) {
    clearInterval(demoInterval);
    demoInterval = null;
  }
  if (demoModeActive) appendSystem("[DEMO] Stop symulacji live.");
  demoModeActive = false;
  updateDemoStatusUi();
  scheduleWidgetStateWrite();
}

function resetDemoMode() {
  stopDemoMode();

  followQueue = [];
  followQueueKeys = new Set();
  saveFollowQueue();
  renderFollowQueue();

  tiktokViewerCount = 0;
  updateQuestionStats();

  const box = document.getElementById("chat-box");
  if (box) box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
  _chatQueue = [];

  resetSessionToEmpty();
  appendSystem("[DEMO] Reset danych demo. Możesz odpalić DEMO LIVE od nowa.");
  scheduleWidgetStateWrite();
}

function seedDemoLive() {
  tiktokViewerCount = 32 + Math.floor(Math.random() * 18);
  updateQuestionStats();

  ["Wiedźma Basia", "Kasia Tarot", "Luna", "Marta", "Njut"].forEach((nick, idx) => {
    addRankingPoints(nick, 40 + idx * 12 + Math.floor(Math.random() * 30), "demo");
  });

  ["Karolina", "Ola", "Monika"].forEach((nick) => addFollowerToQueue(nick, "follow"));
  simulateDemoGift(true);
  simulateDemoGift(false);

  insertQuestionSorted({ ts: Date.now(), nick: "Luna", question: "Czy w tym tygodniu pojawi się przełom?", source: "demo" });
  insertQuestionSorted({ ts: Date.now() + 1, nick: "Marta", question: "x", source: "demo" });
  insertQuestionSorted({ ts: Date.now() + 2, nick: "Kasia Tarot", question: "Co on ukrywa w tej relacji?", source: "demo" });
  insertQuestionSorted({ ts: Date.now() + 3, nick: "Wiedźma Basia", question: KARTON_DNIA_TEXT, source: "demo", kind: KARTON_DNIA_KIND });

  applyFundDonation({ amount: 25, goal: "Świece i talizmany", payer: "Demo Darczyńca" });
}

function runDemoTick() {
  if (!demoModeActive) return;
  demoTick += 1;

  const base = tiktokViewerCount || 25;
  const delta = Math.floor(Math.random() * 11) - 4;
  tiktokViewerCount = Math.max(3, Math.min(320, base + delta));
  updateQuestionStats();

  const nick = demoPick(DEMO_NICKS);
  addRankingPoints(nick, 1 + Math.floor(Math.random() * 35), "demo-like");

  const roll = Math.random();
  if (roll < 0.20) {
    addFollowerToQueue(demoPick(DEMO_NICKS), "follow");
  } else if (roll < 0.43) {
    simulateDemoGift(Math.random() < 0.34);
  } else if (roll < 0.62) {
    simulateDemoQuestion();
  } else if (roll < 0.69) {
    simulateDemoKarton();
  } else if (roll < 0.78) {
    simulateDemoFund();
  }

  if (demoTick % 20 === 0) {
    appendSystem(`[DEMO] Działa — widzowie: ${tiktokViewerCount}, kolejka: ${questions.length}, kandydaci: ${followQueue.length}.`);
  }
}

function simulateDemoGift(forceBig = false) {
  const gift = forceBig ? demoPick(DEMO_GIFTS.filter((g) => g.amount >= 450)) : demoPick(DEMO_GIFTS);
  const username = demoPick(DEMO_NICKS);
  const amount = Number(gift.amount) || 1;

  if (amount > 1) onTikfinityGift(username, amount, gift.name);
  if (amount >= 450) addGiftCandidateToFollowQueue(username, amount, gift.name);

  appendGiftBoardItem({
    username,
    giftName: gift.name,
    amount,
    giftImageUrl: null,
    avatarUrl: null,
    repeatCount: Math.random() < 0.18 ? 2 + Math.floor(Math.random() * 4) : 1,
  });
}

function simulateDemoQuestion() {
  addIncomingAutoQuestion({
    ts: Date.now(),
    nick: demoPick(DEMO_NICKS),
    question: demoPick(DEMO_QUESTIONS),
    source: "demo_tipped",
    questionCount: Math.random() < 0.16 ? 2 : 1,
  });
}

function simulateDemoKarton() {
  insertQuestionSmart({
    ts: Date.now(),
    nick: demoPick(DEMO_NICKS),
    question: KARTON_DNIA_TEXT,
    source: "demo_karton",
    kind: KARTON_DNIA_KIND,
  });
  scheduleWidgetStateWrite();
}

function simulateDemoFund() {
  const amounts = [5, 10, 15, 20, 30, 50];
  const goals = ["Świece i talizmany", "Wsparcie live", "Nowe karty", "Studio KVRINA"];
  applyFundDonation({
    amount: demoPick(amounts),
    goal: demoPick(goals),
    payer: demoPick(DEMO_NICKS),
  });
}

/* ====== FONT SIZES ====== */

function applyFontSizes() {
  document.documentElement.style.setProperty("--chat-font-size", `${chatFontSize}px`);
  document.documentElement.style.setProperty("--question-font-size", `${questionFontSize}px`);
  document.documentElement.style.setProperty("--queue-font-size", `${queueFontSize}px`);
  document.documentElement.style.setProperty("--question-queue-font-size", `${questionQueueFontSize}px`);
}

function applyChatVisibility() {
  const body = document.body;
  if (!body) return;
  if (chatVisible) body.classList.remove("chat-hidden");
  else body.classList.add("chat-hidden");
}

function setupChatToggle() {
  const btn = document.getElementById("btn-toggle-chat");
  const btnPop = document.getElementById("btn-popout-chat");
  if (btn) {
    btn.addEventListener("click", () => {
      chatVisible = !chatVisible;
      applyChatVisibility();
      savePrefs();
    });
  }
  if (btnPop) {
    btnPop.addEventListener("click", async () => {
      try {
        if (window.wbApi?.openChatWindow) {
          await window.wbApi.openChatWindow();
        }
      } catch (e) {
        console.error("openChatWindow failed:", e);
      }
    });
  }
}

/* ====== CHAT ====== */

const chatBoxEl = () => document.getElementById("chat-box");

function setupChat() {
  const plus = document.getElementById("chat-font-plus");
  const minus = document.getElementById("chat-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      chatFontSize = Math.min(chatFontSize + 2, 64);
      applyFontSizes();
      savePrefs();
    });
  }

  if (minus) {
    minus.addEventListener("click", () => {
      chatFontSize = Math.max(chatFontSize - 2, 8);
      applyFontSizes();
      savePrefs();
    });
  }
}

function appendSystem(text) {
  const box = document.getElementById("chat-box");
  if (!box) return;
  const line = document.createElement("div");
  line.className = "chat-line chat-system";
  line.textContent = `[SYSTEM] ${text}`;
  box.appendChild(line);
  box.scrollTop = box.scrollHeight;
}

// RUBRYCZKA GIFTÓW Z TIKTOKA
function _pickFirstUrl(...values) {
  for (const v of values) {
    if (typeof v === "string" && /^https?:\/\//i.test(v.trim())) return v.trim();
    if (Array.isArray(v)) {
      const found = _pickFirstUrl(...v);
      if (found) return found;
    }
  }
  return null;
}

function _findLikelyImageUrl(obj, depth = 0) {
  if (!obj || typeof obj !== "object" || depth > 4) return null;
  if (Array.isArray(obj)) {
    for (const item of obj) {
      const found = _findLikelyImageUrl(item, depth + 1);
      if (found) return found;
    }
    return null;
  }

  const priorityKeys = [
    "giftPictureUrl", "giftImageUrl", "giftIconUrl", "giftPicture", "giftImage", "giftIcon",
    "imageUrl", "pictureUrl", "iconUrl", "thumbnailUrl", "url", "src"
  ];
  for (const key of priorityKeys) {
    const v = obj[key];
    const found = _pickFirstUrl(v);
    if (found) return found;
    if (v && typeof v === "object") {
      const nested = _findLikelyImageUrl(v, depth + 1);
      if (nested) return nested;
    }
  }

  // awaryjnie: szukaj po kluczach z image/icon/picture/url, ale nie bierz avatarów użytkownika jako giftu
  for (const [key, value] of Object.entries(obj)) {
    const k = String(key).toLowerCase();
    if (k.includes("avatar") || k.includes("profile")) continue;
    if (k.includes("image") || k.includes("icon") || k.includes("picture") || k.includes("thumb")) {
      const found = _pickFirstUrl(value) || _findLikelyImageUrl(value, depth + 1);
      if (found) return found;
    }
  }
  return null;
}

function getTikTokAvatarUrl(payload) {
  return _pickFirstUrl(
    payload && payload.profilePictureUrl,
    payload && payload.profile_image,
    payload && payload.avatarUrl,
    payload && payload.user && payload.user.avatarThumb,
    payload && payload.user && payload.user.avatarLarger,
    payload && payload.user && payload.user.profilePictureUrl
  );
}

function getTikTokGiftImageUrl(payload) {
  if (!payload) return null;
  return _pickFirstUrl(
    payload.giftPictureUrl,
    payload.giftImageUrl,
    payload.giftIconUrl,
    payload.giftPicture,
    payload.giftImage,
    payload.giftIcon,
    payload.imageUrl,
    payload.iconUrl,
    payload.pictureUrl,
    payload.gift && payload.gift.pictureUrl,
    payload.gift && payload.gift.imageUrl,
    payload.gift && payload.gift.iconUrl,
    payload.gift && payload.gift.image && payload.gift.image.url,
    payload.gift && payload.gift.image && payload.gift.image.urls,
    payload.gift && payload.gift.icon && payload.gift.icon.url,
    payload.giftDetails && payload.giftDetails.imageUrl,
    payload.giftDetails && payload.giftDetails.iconUrl
  ) || _findLikelyImageUrl(payload.gift || payload.giftDetails || payload);
}

function getTikTokGiftRepeat(payload) {
  const raw =
    payload.repeatCount ??
    payload.repeat_count ??
    payload.comboCount ??
    payload.combo_count ??
    payload.giftCount ??
    payload.gift_count ??
    payload.count ??
    (payload.gift && (payload.gift.repeatCount ?? payload.gift.count));
  const n = parseInt(raw || 0, 10);
  return Number.isFinite(n) && n > 1 ? n : 1;
}

function appendChatLine() {
  // Czat tekstowy jest celowo wyłączony w głównym panelu.
  // Lewa kolumna działa teraz jako rubryczka giftów TikToka.
}

function appendGiftBoardItem({ username, giftName, amount, giftImageUrl, avatarUrl, repeatCount }) {
  try {
    const now = new Date();
    const ts = now.toTimeString().slice(0, 8);
    window.wbApi?.sendChatLine?.({
      kind: "gift-board",
      username,
      giftName,
      amount,
      giftImageUrl,
      avatarUrl,
      repeatCount,
      ts,
    });
  } catch {}

  _chatQueue.push({
    kind: "gift-board",
    username,
    giftName,
    amount,
    giftImageUrl,
    avatarUrl,
    repeatCount: repeatCount || 1,
    ts: Date.now(),
  });
  if (_chatFlushTimer) return;

  _chatFlushTimer = setTimeout(() => {
    _chatFlushTimer = null;
    flushChatQueue();
  }, CHAT_FLUSH_MS);
}

function flushChatQueue() {
  const box = document.getElementById("chat-box");
  if (!box) { _chatQueue = []; return; }
  if (!_chatQueue.length) return;

  const threshold = 12;
  const pinned = (box.scrollHeight - box.scrollTop - box.clientHeight) <= threshold;
  const empty = box.querySelector(".gift-board-empty");
  if (empty) empty.remove();

  const frag = document.createDocumentFragment();

  for (const item of _chatQueue) {
    if (!item || item.kind !== "gift-board") continue;

    const line = document.createElement("div");
    line.className = "gift-board-line";
    if ((parseInt(item.amount || 0, 10) || 0) >= giftCredit) line.classList.add("gift-board-big");

    const media = document.createElement("div");
    media.className = "gift-board-media";

    if (item.giftImageUrl) {
      const giftImg = document.createElement("img");
      giftImg.className = "gift-board-icon";
      giftImg.src = item.giftImageUrl;
      giftImg.alt = item.giftName || "gift";
      giftImg.addEventListener("load", () => {
        if (!pinned) return;
        requestAnimationFrame(() => requestAnimationFrame(() => { box.scrollTop = box.scrollHeight; }));
      });
      media.appendChild(giftImg);
    } else {
      const fallback = document.createElement("div");
      fallback.className = "gift-board-icon gift-board-icon-fallback";
      fallback.textContent = "🎁";
      media.appendChild(fallback);
    }

    if (item.avatarUrl) {
      const avatar = document.createElement("img");
      avatar.className = "gift-board-avatar";
      avatar.src = item.avatarUrl;
      avatar.alt = "";
      media.appendChild(avatar);
    }

    const content = document.createElement("div");
    content.className = "gift-board-content";

    const top = document.createElement("div");
    top.className = "gift-board-top";

    const user = document.createElement("span");
    user.className = "gift-board-user";
    user.textContent = item.username || "TikTok";
    const userColor = getUserColor(item.username || "");
    if (userColor) user.style.color = userColor;

    const time = document.createElement("span");
    time.className = "gift-board-time";
    time.textContent = new Date(item.ts).toTimeString().slice(0, 8);

    top.appendChild(user);
    top.appendChild(time);

    const name = document.createElement("div");
    name.className = "gift-board-name";
    name.textContent = item.giftName || "prezent";

    const meta = document.createElement("div");
    meta.className = "gift-board-meta";
    const amount = parseInt(item.amount || 0, 10) || 0;
    const repeat = parseInt(item.repeatCount || 1, 10) || 1;
    meta.textContent = `${amount} monet${repeat > 1 ? ` • x${repeat}` : ""}`;

    content.appendChild(top);
    content.appendChild(name);
    content.appendChild(meta);

    line.appendChild(media);
    line.appendChild(content);
    frag.appendChild(line);
  }

  _chatQueue = [];
  box.appendChild(frag);

  while (box.children.length > MAX_MAIN_CHAT_LINES) {
    box.removeChild(box.firstChild);
  }

  if (pinned) {
    requestAnimationFrame(() => requestAnimationFrame(() => { box.scrollTop = box.scrollHeight; }));
  }
}


/* ====== WIDGETY HTML / TikTok Studio Browser Source ====== */

function entryTypeForWidget(entry) {
  if (!entry) return "empty";
  if (isKartonDniaEntry(entry)) return "karton";
  const q = String(entry.question || "").trim().toLowerCase();
  if (!q || q === "x") return "waiting";
  return "question";
}

function entryTitleForWidget(entry) {
  const type = entryTypeForWidget(entry);
  if (type === "karton") return "KARTON DNIA";
  if (type === "waiting") return "CZEKAM NA PYTANIE";
  if (type === "empty") return "PYTANIE DO KART";
  return "PYTANIE DO KART";
}

function entryTextForWidget(entry) {
  const type = entryTypeForWidget(entry);
  if (type === "karton") return "KARTON DNIA";
  if (type === "waiting") return "CZEKAM NA PYTANIE";
  if (!entry) return "LINK W BIO";
  return String(entry.question || "").trim() || "LINK W BIO";
}

function getRankingArrayForWidget() {
  const arr = Array.from(predictionRanking.entries()).map(([nick, likes]) => ({
    nick,
    likes: Number(likes) || 0,
    points: Number(likes) || 0,
  }));
  arr.sort((a, b) => b.likes - a.likes || String(a.nick).localeCompare(String(b.nick), "pl"));
  return arr.slice(0, 20);
}

function updateRankingPreviewCount(count) {
  const el = document.getElementById("ranking-preview-count");
  if (!el) return;
  if (count === 1) el.textContent = "1 osoba";
  else el.textContent = `${count} osób`;
}

function renderRankingPreviewPanel() {
  const list = document.getElementById("ranking-preview-list");
  if (!list) return;

  const ranking = getRankingArrayForWidget().slice(0, 8);
  list.innerHTML = "";
  updateRankingPreviewCount(ranking.length);

  if (!ranking.length) {
    const empty = document.createElement("div");
    empty.className = "ranking-preview-empty";
    empty.textContent = "Czekam na tapy / dane rankingu…";
    list.appendChild(empty);
    return;
  }

  ranking.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "ranking-preview-item";

    const place = document.createElement("div");
    place.className = "ranking-preview-place";
    place.textContent = `#${idx + 1}`;

    const main = document.createElement("div");
    main.className = "ranking-preview-main";

    const nick = document.createElement("div");
    nick.className = "ranking-preview-nick";
    nick.textContent = String(item.nick || "-");

    const likes = document.createElement("div");
    likes.className = "ranking-preview-likes";
    likes.textContent = `♥ ${Number(item.likes || item.points || 0) || 0} like`;

    main.appendChild(nick);
    main.appendChild(likes);

    const add = document.createElement("button");
    add.type = "button";
    add.className = "ranking-preview-add";
    add.textContent = "DODAJ";
    add.title = `Dodaj ${item.nick} do kolejki pytań`;
    add.addEventListener("click", () => addRankingUserToQuestionQueue(item.nick));

    row.appendChild(place);
    row.appendChild(main);
    row.appendChild(add);
    list.appendChild(row);
  });
}

function addRankingUserToQuestionQueue(username) {
  const nick = String(username || "").trim();
  if (!nick) return;
  insertQuestionSorted({
    ts: Date.now(),
    nick,
    question: "x",
    source: "ranking_taps",
  });
  scheduleWidgetStateWrite();
}

function setupRankingPreviewPanel() {
  renderRankingPreviewPanel();
}

function buildWidgetState() {
  const current = (!noQuestionsMode && questions.length && questions[questionIndex]) ? questions[questionIndex] : null;
  const queueStart = current ? questionIndex + 1 : getQuestionQueueStartIndex();
  const queue = questions.slice(Math.max(0, queueStart)).map((q, i) => ({
    position: i + 1,
    nick: String(q.nick || "-"),
    text: entryTextForWidget(q),
    title: entryTitleForWidget(q),
    type: entryTypeForWidget(q),
    source: q.source || null,
  }));

  return {
    updatedAt: Date.now(),
    current: current ? {
      nick: String(current.nick || "-"),
      title: entryTitleForWidget(current),
      text: entryTextForWidget(current),
      type: entryTypeForWidget(current),
      source: current.source || null,
    } : {
      nick: "TERAZ TY",
      title: "PYTANIE DO KART",
      text: "LINK W BIO",
      type: "empty",
    },
    queue,
    ranking: getRankingArrayForWidget(),
    tikfinityTopLikerUrl: "https://tikfinity.zerody.one/widget/topliker?cid=3197633",
    tikfinityActivityFeedUrl: "https://tikfinity.zerody.one/widget/activity-feed?cid=3197633&did=1",
    demoMode: !!demoModeActive,
    theme: "fire-gold-web",
  };
}

let _widgetWriteTimer = null;
async function writeWidgetStateNow() {
  try {
    if (!outputDir || !window.wbApi || !window.wbApi.writeFile) return;
    await window.wbApi.writeFile("widgety/widget_state.json", JSON.stringify(buildWidgetState(), null, 2));
  } catch (e) {
    console.warn("writeWidgetStateNow failed:", e);
  }
}

function scheduleWidgetStateWrite() {
  if (_widgetWriteTimer) return;
  _widgetWriteTimer = setTimeout(async () => {
    _widgetWriteTimer = null;
    await writeWidgetStateNow();
  }, 180);
}

function setupWidgetStatePublishing() {
  scheduleWidgetStateWrite();
  setInterval(() => { scheduleWidgetStateWrite(); }, 1200);

  const statusWidgets = document.getElementById("status-widgets");
  if (statusWidgets) statusWidgets.textContent = "Widgety: :8750";
}

function addRankingPoints(username, points, label) {
  const nick = String(username || "").trim();
  const pts = Number(points) || 0;
  if (!nick || !pts) return;
  const prev = Number(predictionRanking.get(nick) || 0) || 0;
  predictionRanking.set(nick, prev + pts);
  predictionEventsFeed.unshift({ ts: Date.now(), nick, points: pts, label: label || "like" });
  predictionEventsFeed = predictionEventsFeed.slice(0, 50);
  renderRankingPreviewPanel();
  scheduleBackup();
  scheduleWidgetStateWrite();
}

function getTikFinityLikeDelta(payload) {
  if (!payload) return 1;
  const candidates = [
    payload.likeCount,
    payload.likes,
    payload.count,
    payload.amount,
    payload.repeatCount,
    payload.delta,
    payload.value,
  ];
  for (const v of candidates) {
    const n = Number(v);
    if (Number.isFinite(n) && n > 0 && n < 1000000) return n;
  }
  return 1;
}

function handleTikFinityLikeEvent(payload) {
  const username = getTikTokNickname(payload);
  const delta = getTikFinityLikeDelta(payload);
  addRankingPoints(username, delta, "like");
}

function handleTikFinityRankingEvent(ev, payload) {
  const name = String(ev || "").toLowerCase();

  // Jeśli TikFinity/strona wyśle gotową tablicę rankingu, bierzemy ją 1:1.
  const ranking = payload && (payload.ranking || payload.rankings || payload.leaderboard || payload.scores);
  if (Array.isArray(ranking)) {
    predictionRanking = new Map();
    ranking.forEach((row) => {
      const nick = String((row && (row.nickname || row.displayName || row.username || row.user || row.name)) || "").trim();
      const pts = Number(row && (row.likes ?? row.likeCount ?? row.points ?? row.score ?? row.value ?? row.correct ?? 0)) || 0;
      if (nick) predictionRanking.set(nick, pts);
    });
    renderRankingPreviewPanel();
    scheduleBackup();
    scheduleWidgetStateWrite();
    return;
  }

  // Elastyczne wykrywanie eventów typowania/punktacji.
  const looksLikePrediction = /predict|prediction|typ|guess|score|points|ranking|leaderboard|vote/i.test(name) ||
    (payload && /predict|prediction|typ|guess|score|points|ranking|leaderboard|vote/i.test(String(payload.type || payload.event || payload.action || "")));
  if (!looksLikePrediction) return;

  const username = getTikTokNickname(payload);
  const rawPts = payload && (payload.points ?? payload.score ?? payload.value ?? payload.correctPoints ?? payload.delta ?? payload.amount);
  let points = Number(rawPts);
  if (!Number.isFinite(points) || points === 0) {
    // jeśli event oznacza poprawny typ, dajemy 1 punkt
    const correct = payload && (payload.correct === true || payload.isCorrect === true || String(payload.result || "").toLowerCase() === "correct");
    points = correct ? 1 : 0;
  }
  if (points) addRankingPoints(username, points, payload && (payload.label || payload.choice || payload.answer));
}

/* ====== TIKFINITY (TikTok) ====== */

function connectTikFinity(force = false) {
  try {
    // zamknij stare połączenie, jeśli ma sens
    if (tikfinityWs && (tikfinityWs.readyState === WebSocket.OPEN || tikfinityWs.readyState === WebSocket.CONNECTING)) {
      if (!force) return;
      try { tikfinityWs.close(); } catch {}
    }

    tikfinityConnected = false;
    updateTikfinityStatusUi();

    const ws = new WebSocket(TIKFINITY_WS_URL);
    tikfinityWs = ws;

    ws.onopen = () => {
      tikfinityConnected = true;
      updateTikfinityStatusUi();
    };

    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        const ev = data.event;
        const payload = data.data || {};
        handleTikFinityRankingEvent(ev, payload);

        if (ev === "like") {
          handleTikFinityLikeEvent(payload);
        } else if (ev === "roomUser" || ev === "viewer" || ev === "liveInfo") {
          const vc =
            payload.viewerCount ||
            payload.userCount ||
            payload.totalViewerCount ||
            payload.viewers ||
            payload.viewCount;
          if (vc !== undefined && vc !== null) {
            const n = parseInt(vc, 10);
            if (!Number.isNaN(n)) {
              tiktokViewerCount = n;
              updateQuestionStats();
            }
          }
        } else if (isTikFinityFollowEvent(ev, payload)) {
          const username = getTikTokNickname(payload);
          addFollowerToQueue(username);
        } else if (ev === "chat") {
          // Lewy panel nie pokazuje już czatu — jest rubryczką giftów.
        } else if (ev === "gift") {
          const username = getTikTokNickname(payload);
          const giftName = payload.giftName || (payload.gift && payload.gift.name) || "prezent";
          let amount = payload.diamondCount || payload.amount || payload.totalDiamonds || 0;
          amount = parseInt(amount || 0, 10);

          // rubryczka giftów pokazuje również drobne gifty; do kredytów 699+ dalej liczymy sensowne wartości > 1
          if (amount <= 0) return;
          if (amount > 1) onTikfinityGift(username, amount, giftName);
          if (amount >= 450) addGiftCandidateToFollowQueue(username, amount, giftName);

          const avatarUrl = getTikTokAvatarUrl(payload);
          const giftImageUrl = getTikTokGiftImageUrl(payload);
          const repeatCount = getTikTokGiftRepeat(payload);

          appendGiftBoardItem({ username, giftName, amount, giftImageUrl, avatarUrl, repeatCount });
        }
      } catch (err) {
        console.error("Błąd parsowania eventu TikFinity:", err);
      }
    };

    ws.onerror = (err) => {
      tikfinityConnected = false;
      updateTikfinityStatusUi();
      console.error("[TikFinity WS] error:", err);
    };

    ws.onclose = () => {
      tikfinityConnected = false;
      updateTikfinityStatusUi();
      // auto-reconnect
      setTimeout(() => connectTikFinity(false), 3000);
    };
  } catch (err) {
    tikfinityConnected = false;
    updateTikfinityStatusUi();
    console.error("Nie udało się utworzyć połączenia WebSocket:", err);
  }
}


/* ====== PLACEHOLDERS / FILTRY ====== */

function _normNoDiacritics(s) {
  return String(s || "")
    .trim()
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

function isJoinPlaceholder(line) {
  const t = _normNoDiacritics(line);
  // DOŁĄCZ / DOLACZ + opcjonalne emoji/punktacja
  return t === "dolacz" || t.startsWith("dolacz ");
}

/* ====== KOLEJKA OBSERWUJĄCYCH ====== */

function getFollowKey(name) {
  return _normNoDiacritics(name).replace(/\s+/g, " ");
}

function isTikFinityFollowEvent(ev, payload) {
  const eventName = String(ev || "").trim().toLowerCase();
  if (eventName === "follow" || eventName === "newfollower") return true;

  // Awaryjnie: niektóre integracje potrafią wrzucać follow jako event social.
  if (eventName === "social") {
    const raw = [
      payload && payload.type,
      payload && payload.socialType,
      payload && payload.action,
      payload && payload.label,
      payload && payload.event,
    ].filter(Boolean).join(" ").toLowerCase();
    return raw.includes("follow") || raw.includes("obserw");
  }

  return false;
}

function loadFollowQueue() {
  try {
    const raw = localStorage.getItem(FOLLOW_QUEUE_STORAGE_KEY);
    const arr = raw ? JSON.parse(raw) : [];
    followQueue = Array.isArray(arr)
      ? arr
          .map((x) => {
            if (typeof x === "string") return { nick: x, ts: Date.now(), source: "follow" };
            return {
              nick: String((x && x.nick) || "").trim(),
              ts: typeof (x && x.ts) === "number" ? x.ts : Date.now(),
              source: String((x && x.source) || "follow"),
              giftCoins: Number((x && x.giftCoins) || 0) || 0,
              giftName: String((x && x.giftName) || ""),
            };
          })
          .filter((x) => x.nick)
      : [];
  } catch {
    followQueue = [];
  }

  followQueueKeys = new Set();
  followQueue = followQueue.filter((item) => {
    const key = getFollowKey(item.nick);
    if (!key || followQueueKeys.has(key)) return false;
    followQueueKeys.add(key);
    return true;
  });
}

function saveFollowQueue() {
  try {
    localStorage.setItem(FOLLOW_QUEUE_STORAGE_KEY, JSON.stringify(followQueue));
  } catch {}
}

function updateFollowQueueCount() {
  const queueCount = document.getElementById("queue-count");
  if (!queueCount) return;
  const count = followQueue.length;
  if (count === 1) queueCount.textContent = "1 kandydat";
  else queueCount.textContent = `${count} kandydatów`;
}

function renderFollowQueue() {
  const queueList = document.getElementById("queue-list");
  if (!queueList) return;

  queueList.innerHTML = "";

  if (!followQueue.length) {
    const div = document.createElement("div");
    div.className = "queue-item queue-empty";
    div.textContent = "Czekam na obserwacje i gifty 450+…";
    queueList.appendChild(div);
    updateFollowQueueCount();
    return;
  }

  followQueue.forEach((item, idx) => {
    const row = document.createElement("div");
    row.className = "queue-item follow-queue-item" + (item.source === "gift450" ? " is-gift-candidate" : "");

    const left = document.createElement("div");
    left.className = "follow-queue-left";

    const nick = document.createElement("span");
    nick.className = "follow-queue-nick";
    nick.textContent = `${idx + 1}. ${item.nick}`;

    const meta = document.createElement("span");
    meta.className = "follow-queue-meta";
    if (item.source === "gift450") meta.textContent = `GIFT ${item.giftCoins || 450}+ monet${item.giftName ? " • " + item.giftName : ""}`;
    else meta.textContent = "OBSERWUJĄCY";

    left.appendChild(nick);
    left.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "follow-queue-actions";

    const addBtn = document.createElement("button");
    addBtn.type = "button";
    addBtn.className = "follow-add-btn";
    addBtn.textContent = "DODAJ";
    addBtn.title = `Dodaj ${item.nick} do kolejki pytań`;
    addBtn.addEventListener("click", () => addFollowerCandidateToQuestionQueue(idx));

    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "follow-remove-btn";
    btn.textContent = "USUŃ";
    btn.title = `Usuń ${item.nick} z listy`;
    btn.addEventListener("click", () => removeFollowerFromQueue(idx));

    actions.appendChild(addBtn);
    actions.appendChild(btn);
    row.appendChild(left);
    row.appendChild(actions);
    queueList.appendChild(row);
  });

  queueList.scrollTop = queueList.scrollHeight;
  updateFollowQueueCount();
}

function addFollowerToQueue(username, source = "follow", extra = {}) {
  const nick = String(username || "").trim();
  if (!nick) return;

  const key = getFollowKey(nick);
  if (!key) return;

  const existing = followQueue.find((item) => getFollowKey(item.nick) === key);
  if (existing) {
    if (source === "gift450") {
      existing.source = "gift450";
      existing.giftCoins = Math.max(Number(existing.giftCoins || 0) || 0, Number(extra.giftCoins || 0) || 0);
      existing.giftName = extra.giftName || existing.giftName || "";
      saveFollowQueue();
      renderFollowQueue();
      scheduleBackup();
    }
    return;
  }

  followQueue.push({ nick, ts: Date.now(), source, giftCoins: Number(extra.giftCoins || 0) || 0, giftName: extra.giftName || "" });
  followQueueKeys.add(key);
  saveFollowQueue();
  renderFollowQueue();
  scheduleBackup();
}

function addGiftCandidateToFollowQueue(username, giftCoins, giftName) {
  if ((Number(giftCoins) || 0) < 450) return;
  addFollowerToQueue(username, "gift450", { giftCoins: Number(giftCoins) || 0, giftName: giftName || "" });
}

function addFollowerCandidateToQuestionQueue(index) {
  if (index < 0 || index >= followQueue.length) return;
  const item = followQueue[index];
  const nick = String(item.nick || "").trim();
  if (!nick) return;

  insertQuestionSorted({
    ts: Date.now(),
    nick,
    question: "x",
    source: item.source === "gift450" ? "gift450" : "follow",
  });

  removeFollowerFromQueue(index);
  scheduleWidgetStateWrite();
}

function removeFollowerFromQueue(index) {
  if (index < 0 || index >= followQueue.length) return;
  followQueue.splice(index, 1);
  followQueueKeys = new Set(followQueue.map((item) => getFollowKey(item.nick)).filter(Boolean));
  saveFollowQueue();
  renderFollowQueue();
  scheduleBackup();
}

function setupQueue() {
  const plus = document.getElementById("queue-font-plus");
  const minus = document.getElementById("queue-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      queueFontSize = Math.min(queueFontSize + 1, 24);
      applyFontSizes();
      savePrefs();
    });
  }
  if (minus) {
    minus.addEventListener("click", () => {
      queueFontSize = Math.max(queueFontSize - 1, 8);
      applyFontSizes();
      savePrefs();
    });
  }

  loadFollowQueue();
  renderFollowQueue();
}

/* ====== PANEL KOLEJKI PYTAŃ / KARTONÓW ====== */

let questionQueueDragIndex = null;

function getQuestionQueueStartIndex() {
  if (!questions.length) return 0;
  if (noQuestionsMode) return Math.min(noQuestionsLength || 0, questions.length);
  return Math.max(0, Math.min(questionIndex, questions.length - 1));
}

function getQuestionQueueMovableStartIndex() {
  if (!questions.length) return 0;
  if (noQuestionsMode) return Math.min(noQuestionsLength || 0, questions.length);
  return Math.min(questionIndex + 1, questions.length);
}

function updateQuestionOrderQueueCount() {
  const el = document.getElementById("question-queue-count");
  if (!el) return;
  const start = getQuestionQueueMovableStartIndex();
  const count = Math.max(0, questions.length - start);
  if (count === 1) el.textContent = "1 pozycja w kolejce";
  else el.textContent = `${count} pozycji w kolejce`;
}

function questionQueuePreview(entry) {
  if (!entry) return "";
  if (isKartonDniaEntry(entry)) return KARTON_DNIA_TEXT;
  const q = String(entry.question || "").trim();
  if (!q || q.toLowerCase() === "x") return "CZEKAM NA PYTANIE";
  return q;
}

function renderQuestionOrderQueue() {
  const list = document.getElementById("question-queue-list");
  if (!list) return;
  list.innerHTML = "";

  const start = getQuestionQueueStartIndex();
  const movableStart = getQuestionQueueMovableStartIndex();
  updateQuestionOrderQueueCount();

  if (!questions.length || start >= questions.length) {
    const empty = document.createElement("div");
    empty.className = "question-queue-empty";
    empty.textContent = "Czekam na pytania i kartony…";
    list.appendChild(empty);
    return;
  }

  for (let i = start; i < questions.length; i++) {
    const entry = questions[i];
    const isCurrent = !noQuestionsMode && i === questionIndex;
    const isKarton = isKartonDniaEntry(entry);
    const entryType = entryTypeForWidget(entry);
    const canMove = i >= movableStart;

    const row = document.createElement("div");
    row.className = "question-queue-item" + (isCurrent ? " is-current" : "") + (isKarton ? " is-karton" : "") + (entryType === "waiting" ? " is-waiting" : "");
    row.draggable = canMove;
    row.dataset.index = String(i);

    if (canMove) {
      row.addEventListener("dragstart", (e) => {
        questionQueueDragIndex = i;
        row.classList.add("is-dragging");
        try { e.dataTransfer.effectAllowed = "move"; e.dataTransfer.setData("text/plain", String(i)); } catch {}
      });
      row.addEventListener("dragend", () => {
        row.classList.remove("is-dragging");
        questionQueueDragIndex = null;
      });
      row.addEventListener("dragover", (e) => {
        e.preventDefault();
        try { e.dataTransfer.dropEffect = "move"; } catch {}
      });
      row.addEventListener("drop", (e) => {
        e.preventDefault();
        const from = questionQueueDragIndex;
        moveQuestionQueueItemTo(from, i);
      });
    }

    const num = document.createElement("div");
    num.className = "question-queue-num";
    num.textContent = isCurrent ? "▶" : String(i + 1);

    const main = document.createElement("div");
    main.className = "question-queue-main";

    const badge = document.createElement("div");
    badge.className = "question-queue-badge";
    badge.textContent = isCurrent ? "TERAZ" : (isKarton ? "KARTON" : (entryType === "waiting" ? "CZEKA" : "PYTANIE"));

    const nick = document.createElement("div");
    nick.className = "question-queue-nick";
    nick.textContent = String(entry.nick || "-");

    const preview = document.createElement("div");
    preview.className = "question-queue-preview";
    preview.textContent = questionQueuePreview(entry);

    main.appendChild(badge);
    main.appendChild(nick);
    main.appendChild(preview);

    const actions = document.createElement("div");
    actions.className = "question-queue-actions";

    const up = document.createElement("button");
    up.type = "button";
    up.className = "question-queue-move";
    up.textContent = "↑";
    up.title = "Przesuń wyżej";
    up.disabled = !canMove || i <= movableStart;
    up.addEventListener("click", () => swapQuestionQueueItems(i, i - 1));

    const down = document.createElement("button");
    down.type = "button";
    down.className = "question-queue-move";
    down.textContent = "↓";
    down.title = "Przesuń niżej";
    down.disabled = !canMove || i >= questions.length - 1;
    down.addEventListener("click", () => swapQuestionQueueItems(i, i + 1));

    const edit = document.createElement("button");
    edit.type = "button";
    edit.className = "question-queue-move edit";
    edit.textContent = "✎";
    edit.title = "Edytuj wpis";
    edit.addEventListener("click", () => editQuestionQueueItem(i));

    const del = document.createElement("button");
    del.type = "button";
    del.className = "question-queue-move delete";
    del.textContent = "×";
    del.title = "Usuń z kolejki";
    del.addEventListener("click", () => removeQuestionQueueItem(i));

    actions.appendChild(up);
    actions.appendChild(down);
    actions.appendChild(edit);
    actions.appendChild(del);

    row.appendChild(num);
    row.appendChild(main);
    row.appendChild(actions);
    list.appendChild(row);
  }
}

function syncQuestionQueueAfterManualOrder() {
  recalcFilteredCount();
  renderQuestionOrderQueue();

  if (!noQuestionsMode && questions.length && questions[questionIndex]) {
    const cur = questions[questionIndex];
    saveQuestionState(cur.nick, cur.question);
    refreshNextFromQueue();
  } else if (noQuestionsMode) {
    showNoQuestions();
  }

  scheduleBackup();
  scheduleWidgetStateWrite();
}

function swapQuestionQueueItems(a, b) {
  const movableStart = getQuestionQueueMovableStartIndex();
  if (a < movableStart || b < movableStart || a < 0 || b < 0 || a >= questions.length || b >= questions.length) return;
  const tmp = questions[a];
  questions[a] = questions[b];
  questions[b] = tmp;
  syncQuestionQueueAfterManualOrder();
}

function moveQuestionQueueItemTo(fromIndex, toIndex) {
  const movableStart = getQuestionQueueMovableStartIndex();
  const from = parseInt(fromIndex, 10);
  let to = parseInt(toIndex, 10);
  if (!Number.isFinite(from) || !Number.isFinite(to)) return;
  if (from < movableStart || to < movableStart || from < 0 || to < 0 || from >= questions.length || to >= questions.length || from === to) return;

  const [item] = questions.splice(from, 1);
  if (from < to) to -= 1;
  questions.splice(to, 0, item);
  syncQuestionQueueAfterManualOrder();
}


function normalizeQuestionQueueAfterMutation() {
  if (!questions.length) {
    questionIndex = 0;
    showNoQuestions();
    return;
  }
  questionIndex = Math.max(0, Math.min(questionIndex, questions.length - 1));
  if (noQuestionsMode) {
    showNoQuestions();
  } else {
    showCurrentQuestion();
  }
  recalcFilteredCount();
  renderQuestionOrderQueue();
  scheduleBackup();
  scheduleWidgetStateWrite();
}

function removeQuestionQueueItem(index) {
  const i = parseInt(index, 10);
  if (!Number.isFinite(i) || i < 0 || i >= questions.length) return;
  const nick = questions[i] && questions[i].nick ? questions[i].nick : "ten wpis";
  if (!confirm(`Usunąć z kolejki: ${nick}?`)) return;
  questions.splice(i, 1);
  if (i < questionIndex) questionIndex--;
  normalizeQuestionQueueAfterMutation();
}

function editQuestionQueueItem(index) {
  const i = parseInt(index, 10);
  if (!Number.isFinite(i) || i < 0 || i >= questions.length) return;
  const entry = questions[i];
  const nick = prompt("Nick:", entry.nick || "");
  if (nick === null) return;
  const cleanNick = String(nick || "").trim();
  if (!cleanNick) return;

  const currentType = entryTypeForWidget(entry);
  const type = prompt("Typ wpisu: pytanie / karton / czekam", currentType === "karton" ? "karton" : currentType === "waiting" ? "czekam" : "pytanie");
  if (type === null) return;
  const t = String(type || "").trim().toLowerCase();

  entry.nick = cleanNick;
  if (t.startsWith("kart")) {
    entry.kind = KARTON_DNIA_KIND;
    entry.question = KARTON_DNIA_TEXT;
  } else if (t.startsWith("czek") || t === "x") {
    entry.kind = null;
    entry.question = "x";
  } else {
    entry.kind = null;
    const q = prompt("Pytanie:", entry.question && String(entry.question).toLowerCase() !== "x" ? entry.question : "");
    if (q === null) return;
    entry.question = String(q || "").trim() || "x";
  }
  normalizeQuestionQueueAfterMutation();
}

function setupQuestionOrderQueue() {
  const plus = document.getElementById("question-queue-font-plus");
  const minus = document.getElementById("question-queue-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      questionQueueFontSize = Math.min(questionQueueFontSize + 1, 24);
      applyFontSizes();
      savePrefs();
    });
  }
  if (minus) {
    minus.addEventListener("click", () => {
      questionQueueFontSize = Math.max(questionQueueFontSize - 1, 8);
      applyFontSizes();
      savePrefs();
    });
  }

  renderQuestionOrderQueue();
}

/* ====== CZYTNIK PYTAŃ ====== */

/* ====== SESJA / BACKUP (JSON, loop 24h) ====== */
const BACKUP_MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000; // 1.0.37: stan wraca także po dłuższej przerwie

function dayNumberNow() {
  return Math.floor(Date.now() / 86400000);
}

function backupSlotFile(dayNum = dayNumberNow()) {
  // 2-slot loop: A/B nadpisywane co dobę
  return (dayNum % 2 === 0) ? "session_A.json" : "session_B.json";
}

function hasSessionData() {
  return (questions && questions.length > 0)
    || (giftTotals && giftTotals.size > 0)
    || (giftFeed && giftFeed.length > 0)
    || (followQueue && followQueue.length > 0)
    || (predictionRanking && predictionRanking.size > 0)
    || (typeof fundsTotal === "number" && fundsTotal > 0);
}

function serializeSessionState() {
  return {
    version: 1,
    savedAt: Date.now(),
    dayNum: dayNumberNow(),
    questionIndex,
    noQuestionsMode,
    noQuestionsLength,
    questions: questions.map((q) => ({
      ts: q.ts || Date.now(),
      nick: q.nick,
      question: q.question,
      source: q.source || null,
      priority: !!q.priority,
      kind: q.kind || null,
    })),
    funds: { total: fundsTotal, byGoal: fundsByGoal },
    gifts: {
      totals: Array.from(giftTotals.entries()).map(([u, v]) => [u, String(v)]),
      used: Array.from(giftUsed.entries()).map(([u, v]) => [u, String(v)]),
    },
    giftFeed: Array.isArray(giftFeed) ? giftFeed.slice(-60) : [],
    followQueue: Array.isArray(followQueue) ? followQueue.slice(0, 250) : [],
    ranking: Array.from(predictionRanking.entries()).map(([nick, likes]) => [nick, Number(likes) || 0]),
    viewerCount: tiktokViewerCount,
  };
}

async function tryReadJsonFile(name) {
  try {
    const r = await window.wbApi.readFile(name);
    if (!r || !r.ok || !r.data) return null;
    const obj = JSON.parse(String(r.data));
    if (!obj || typeof obj !== "object") return null;
    return obj;
  } catch {
    return null;
  }
}

async function loadBestBackup() {
  const a = await tryReadJsonFile("session_A.json");
  const b = await tryReadJsonFile("session_B.json");

  const list = [];
  if (a && typeof a.savedAt === "number") list.push({ name: "session_A.json", data: a });
  if (b && typeof b.savedAt === "number") list.push({ name: "session_B.json", data: b });

  if (!list.length) return null;

  list.sort((x, y) => (y.data.savedAt || 0) - (x.data.savedAt || 0));
  const best = list[0];
  const age = Date.now() - (best.data.savedAt || 0);
  if (age > BACKUP_MAX_AGE_MS) return null;
  return best;
}

let _backupDebounce = null;
async function writeBackupNow() {
  try {
    // Ważne: nie nadpisuj backupu pustą sesją przy starcie.
    if (!hasSessionData()) {
      await updateBackupStatusPill();
      return;
    }
    const state = serializeSessionState();
    const fileName = backupSlotFile(state.dayNum);
    await window.wbApi.writeFile(fileName, JSON.stringify(state));
    await updateBackupStatusPill(state);
  } catch (e) {
    console.warn("writeBackupNow failed:", e);
  }
}

function scheduleBackup() {
  if (_backupDebounce) return;
  _backupDebounce = setTimeout(async () => {
    _backupDebounce = null;
    await writeBackupNow();
  }, 900);
}

async function updateBackupStatusPill(stateOverride) {
  try {
    const pillId = "status-backup";
    if (!document.getElementById(pillId)) return;

    const best = stateOverride ? { data: stateOverride } : await loadBestBackup();
    if (!best) {
      setStatusPill(pillId, "Backup: brak", "status-info");
      return;
    }
    const savedAt = best.data.savedAt || 0;
    const ageMs = Math.max(0, Date.now() - savedAt);
    const ageMin = Math.floor(ageMs / 60000);
    setStatusPill(pillId, `Backup: OK (${ageMin} min temu)`, "status-ok");
  } catch {}
}

function resetSessionToEmpty() {
  questions = [];
  questionIndex = 0;
  filteredCount = 0;
  noQuestionsMode = true;
  noQuestionsLength = 0;

  giftTotals = new Map();
  giftUsed = new Map();
  giftNewBlink = new Map();
  giftFeed = [];
  selectedGiftUser = null;
  predictionRanking = new Map();
  predictionEventsFeed = [];

  // zbiórki
  fundsTotal = 0;
  fundsByGoal = {};
  updateFundsPill();
  // zapis do plików dla OBS
  persistFundsFiles();

  renderGiftsPanel();
  renderGiftFeed();
  renderRankingPreviewPanel();
  renderQuestionOrderQueue();
  showNoQuestions();
  scheduleBackup(); // zapisze tylko jeśli coś będzie (hasSessionData)
}

function applySessionState(state) {
  try {
    const q = Array.isArray(state.questions) ? state.questions : [];
    questions = q
      .filter((x) => x && x.nick && (x.question !== undefined))
      .map((x) => ({
        ts: typeof x.ts === "number" ? x.ts : Date.now(),
        nick: String(x.nick),
        question: String(x.question),
        source: x.source || null,
        priority: !!x.priority,
        kind: x.kind || (String(x.question || "").trim().toUpperCase() === KARTON_DNIA_TEXT ? KARTON_DNIA_KIND : null),
      }));

    questionIndex = Math.max(0, Math.min(parseInt(state.questionIndex || 0, 10) || 0, Math.max(0, questions.length - 1)));
    noQuestionsMode = !!state.noQuestionsMode;
    noQuestionsLength = parseInt(state.noQuestionsLength || 0, 10) || 0;

    
    // zbiórki
    try {
      const ft = state && state.funds ? state.funds.total : 0;
      const n = (typeof ft === "number") ? ft : parseFloat(String(ft || "").replace(",", "."));
      fundsTotal = Number.isFinite(n) ? Math.round(n * 100) / 100 : 0;
      const bg = state && state.funds && state.funds.byGoal && typeof state.funds.byGoal === "object" ? state.funds.byGoal : {};
      fundsByGoal = bg || {};
    } catch {
      fundsTotal = 0;
      fundsByGoal = {};
    }
    updateFundsPill();
    persistFundsFiles();


    // gifts
    giftTotals = new Map((state.gifts && Array.isArray(state.gifts.totals)) ? state.gifts.totals : []);
    giftUsed = new Map((state.gifts && Array.isArray(state.gifts.used)) ? state.gifts.used : []);
    giftNewBlink = new Map();
    giftFeed = Array.isArray(state.giftFeed) ? state.giftFeed : [];
    selectedGiftUser = null;

    if (Array.isArray(state.followQueue)) {
      followQueue = state.followQueue
        .map((x) => {
          if (typeof x === "string") return { nick: x, ts: Date.now(), source: "follow" };
          return {
            nick: String((x && x.nick) || "").trim(),
            ts: typeof (x && x.ts) === "number" ? x.ts : Date.now(),
            source: String((x && x.source) || "follow"),
            giftCoins: Number((x && x.giftCoins) || 0) || 0,
            giftName: String((x && x.giftName) || ""),
          };
        })
        .filter((x) => x.nick);
      followQueueKeys = new Set();
      followQueue = followQueue.filter((item) => {
        const key = getFollowKey(item.nick);
        if (!key || followQueueKeys.has(key)) return false;
        followQueueKeys.add(key);
        return true;
      });
      saveFollowQueue();
    }

    predictionRanking = new Map(Array.isArray(state.ranking) ? state.ranking.map(([nick, likes]) => [String(nick), Number(likes) || 0]) : []);
    predictionEventsFeed = [];
    tiktokViewerCount = Number.isFinite(Number(state.viewerCount)) ? Number(state.viewerCount) : tiktokViewerCount;

    recalcFilteredCount();

    renderGiftsPanel();
    renderGiftFeed();
    renderFollowQueue();
    renderRankingPreviewPanel();
    renderQuestionOrderQueue();
    updateQuestionStats();

    if (questions.length) {
      noQuestionsMode = false;
      showCurrentQuestion();
      scheduleBackup();
    } else {
      showNoQuestions();
    }

    scheduleBackup();
  } catch (e) {
    console.warn("applySessionState failed:", e);
  }
}

async function restorePreviousSession() {
  const best = await loadBestBackup();
  if (!best) {
    alert("Nie ma backupu sesji do przywrócenia.");
    return;
  }
  applySessionState(best.data);
}


async function restoreSessionOnStartup() {
  try {
    const best = await loadBestBackup();
    if (best && best.data) {
      applySessionState(best.data);
      appendSystem("[SESJA] Przywrócono stan sprzed ostatniego zamknięcia programu.");
      return;
    }
  } catch (e) {
    console.warn("restoreSessionOnStartup failed:", e);
  }
  resetSessionToEmpty();
  appendSystem("[SESJA] Start na czysto — brak świeżego backupu do przywrócenia.");
}

async function writeSessionStateToBothSlots(state) {
  try {
    const data = JSON.stringify(state || serializeSessionState(), null, 2);
    await window.wbApi.writeFile("session_A.json", data);
    await window.wbApi.writeFile("session_B.json", data);
    await updateBackupStatusPill(state || serializeSessionState());
  } catch (e) {
    console.warn("writeSessionStateToBothSlots failed:", e);
  }
}

async function resetWholeSession(ask = true, message = "[SESJA] Sesja wyzerowana. Nowy live startuje na czysto.") {
  if (ask) {
    const ok = confirm("Wyzerować całą sesję?\n\nWyczyści pytania, kolejki, ranking demo, gifty, zbiórki i backup sesji. Układ paneli zostaje bez zmian.");
    if (!ok) return;
  }

  if (demoInterval) {
    clearInterval(demoInterval);
    demoInterval = null;
  }
  demoModeActive = false;
  updateDemoStatusUi();

  followQueue = [];
  followQueueKeys = new Set();
  saveFollowQueue();
  renderFollowQueue();

  tiktokViewerCount = 0;
  updateQuestionStats();

  const box = document.getElementById("chat-box");
  if (box) box.innerHTML = '<div class="gift-board-empty">Czekam na gifty z TikToka…</div>';
  _chatQueue = [];

  questions = [];
  questionIndex = 0;
  filteredCount = 0;
  noQuestionsMode = true;
  noQuestionsLength = 0;

  giftTotals = new Map();
  giftUsed = new Map();
  giftNewBlink = new Map();
  giftFeed = [];
  selectedGiftUser = null;
  predictionRanking = new Map();
  predictionEventsFeed = [];

  fundsTotal = 0;
  fundsByGoal = {};
  updateFundsPill();
  await persistFundsFiles();

  renderGiftsPanel();
  renderGiftFeed();
  renderRankingPreviewPanel();
  renderQuestionOrderQueue();
  showNoQuestions();

  const emptyState = serializeSessionState();
  await writeSessionStateToBothSlots(emptyState);
  scheduleWidgetStateWrite();
  appendSystem(message);
}

/* ====== KOLEJKA PYTAŃ W PAMIĘCI ====== */

function recalcFilteredCount() {

// Priorytety (@WB...): jeśli wśród NADCHODZĄCYCH pytań są oznaczone jako poza kolejką,
// przesuń je zaraz po aktualnym pytaniu (zachowując kolejność).
try {
  const pivot = keepCurrent ? Math.min(questionIndex + 1, questions.length) : 0;
  const head = questions.slice(0, pivot);
  const tail = questions.slice(pivot);
  if (tail.some((q) => q && q.priority)) {
    const pri = tail.filter((q) => q && q.priority);
    const rest = tail.filter((q) => !q || !q.priority);
    questions = head.concat(pri, rest);
  }
} catch {}

filteredCount = questions.reduce((acc, q) => {
    const m = String(q.nick || "").toLowerCase().match(/-(\d+)\s*pyt/);
    return acc + (m ? parseInt(m[1], 10) : 1);
  }, 0);

  const el = document.getElementById("questions-count");
  if (el) el.textContent = `Rozkładów: ${filteredCount}`;
}

function insertQuestionSmart(entry) {
  if (!entry) return;

  // POZAKOLEJKA: wrzucamy jako pierwszą osobę po aktualnym pytaniu
  if (entry.priority) {
    const nick = String(entry.nick || "").trim();
    const question = String(entry.question || "").trim();
    if (!nick || question === "") return;

    const ts = typeof entry.ts === "number" ? entry.ts : Date.now();
    const item = { ts, nick, question, source: entry.source || null, priority: true, kind: entry.kind || null };

    // Jeśli jesteśmy w trakcie czytania – wsuwamy zaraz po aktualnym (po ewentualnych innych priorytetach)
    if (!noQuestionsMode && questions.length) {
      let insertAt = Math.min(questionIndex + 1, questions.length);
      while (insertAt < questions.length && questions[insertAt] && questions[insertAt].priority) {
        insertAt++;
      }
      questions.splice(insertAt, 0, item);
      recalcFilteredCount();

      // Pozostajemy na aktualnym pytaniu, ale odświeżamy export TXT / "kto następny"
      const cur = questions[questionIndex];
      if (cur) saveQuestionState(cur.nick, cur.question);
      refreshNextFromQueue();
      renderQuestionOrderQueue();
      scheduleBackup();
      return;
    }
    // Jeśli jesteśmy w trybie "brak pytań", spadamy do insertQuestionSorted (żeby poprawnie wystartować).
  }

  insertQuestionSorted(entry);
}

function insertQuestionSorted(entry) {
  if (!entry) return;
  const nick = String(entry.nick || "").trim();
  const question = String(entry.question || "").trim();
  if (!nick || question === "") return;

  const ts = typeof entry.ts === "number" ? entry.ts : Date.now();
  const item = { ts, nick, question, source: entry.source || null, priority: !!entry.priority, kind: entry.kind || null };

  // Po dodaniu ręcznego sortowania przez prowadzącą nowe pozycje dopisujemy na koniec.
  // Dzięki temu ręcznie ustawiona kolejność nie rozsypuje się od timestampów.
  const insertAt = questions.length;
  questions.splice(insertAt, 0, item);
  recalcFilteredCount();

  // jeśli nie zmieniamy ekranu, odśwież pliki dla OBS/prowadzącej,
  // żeby nowa osoba była widoczna w "po aktualnym"
  if (noQuestionsMode) {
    // byliśmy w "brak pytań"
    if (questions.length > noQuestionsLength) {
      questionIndex = noQuestionsLength;
      showCurrentQuestion();
      scheduleBackup();
    } else {
      showNoQuestions();
      scheduleBackup();
    }
  } else {
    // pozostajemy na aktualnym pytaniu, ale aktualizujemy export TXT
    const cur = questions[questionIndex];
    if (cur) saveQuestionState(cur.nick, cur.question);
    refreshNextFromQueue();
    renderQuestionOrderQueue();
  }

  scheduleBackup();
}

function addIncomingAutoQuestion(p) {
  const baseTs = typeof p.ts === "number" ? p.ts : Date.now();
  const count = Math.max(1, Math.min(3, parseInt(p.questionCount || 1, 10) || 1));
  for (let i = 0; i < count; i++) {
    insertQuestionSmart({
      ts: baseTs + i,
      nick: p.nick,
      question: i === 0 ? p.question : "x",
      source: "tipped",
      priority: !!p.priority && i === 0,
      kind: i === 0 ? (p.kind || null) : null,
    });
  }
  scheduleWidgetStateWrite();
}




function setupQuestions() {
  const plus = document.getElementById("q-font-plus");
  const minus = document.getElementById("q-font-minus");

  if (plus) {
    plus.addEventListener("click", () => {
      questionFontSize = Math.min(questionFontSize + 2, 40);
      applyFontSizes();
      savePrefs();
      autoResizeQuestionText();
    });
  }

  if (minus) {
    minus.addEventListener("click", () => {
      questionFontSize = Math.max(questionFontSize - 2, 10);
      applyFontSizes();
      savePrefs();
      autoResizeQuestionText();
    });
  }
  // ZA GIFTY (TikFinity)
  const btnGifts = document.getElementById("btn-load-questions-manual") || document.getElementById("btn-load-questions");
  if (btnGifts) btnGifts.addEventListener("click", async () => {
    toggleGiftsPanel();
  });

  // RĘCZNIE
  const btnManual = document.getElementById("btn-add-manual");
  if (btnManual) btnManual.addEventListener("click", () => {
    toggleManualPanel();
  });

  const btnManualAdd = document.getElementById("manual-add-question");
  const btnManualClear = document.getElementById("manual-clear");
  if (btnManualAdd) btnManualAdd.addEventListener("click", async () => {
    await addManualQuestionToQueue();
  });
  if (btnManualClear) btnManualClear.addEventListener("click", () => {
    const n = document.getElementById("manual-nick-input");
    const q = document.getElementById("manual-question-input");
    const f = document.getElementById("manual-feed");
    if (n) n.value = "";
    if (q) q.value = "";
    if (f) f.textContent = "";
  });

  // Formularz: dodaj pytanie za gifty
  const btnAddGiftQ = document.getElementById("gift-add-question");
  const btnClearGift = document.getElementById("gift-clear-selection");
  if (btnAddGiftQ) btnAddGiftQ.addEventListener("click", async () => {
    await addSelectedGiftQuestionToQueue();
  });
  if (btnClearGift) btnClearGift.addEventListener("click", () => {
    selectedGiftUser = null;
    const sel = document.getElementById("gift-selected-user");
    if (sel) sel.textContent = "-";
  });

  // Próg monet na 1 kredyt (domyślnie 699) – sterowany z UI
  const giftThrInput = document.getElementById("gift-credit-input");
  if (giftThrInput) {
    giftThrInput.value = String(giftCredit);

    const applyGiftThreshold = () => {
      const raw = String(giftThrInput.value || "").trim();
      const n = Math.floor(parseInt(raw, 10));
      if (!Number.isFinite(n) || n <= 0) {
        giftThrInput.value = String(giftCredit);
        return;
      }
      giftCredit = Math.max(1, Math.min(100000, n));
      giftThrInput.value = String(giftCredit);
      savePrefs();
      renderGiftsPanel();
    };

    giftThrInput.addEventListener("change", applyGiftThreshold);
    giftThrInput.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        applyGiftThreshold();
        giftThrInput.blur();
      }
    });
  }

  // Filtr na liście giftów
  const giftsFilter = document.getElementById("gifts-filter");
  if (giftsFilter) {
    giftsFilter.addEventListener("input", () => {
      renderGiftsPanel();
    });
  }

  // Przywracanie sesji (backup JSON)
  const btnRestore = document.getElementById("btn-restore-session");
  if (btnRestore) btnRestore.addEventListener("click", async () => {
    await restorePreviousSession();
  });

  function goPrevQuestion() {
    if (!questions.length) return;
    if (questionIndex > 0) {
      questionIndex--;
    }
    showCurrentQuestion();
    scheduleBackup();
  }

  function goNextQuestion() {
    // jeśli nie ma żadnych pytań – pokaż stan "Brak pytań" i "TERAZ TY"
    if (!questions.length) {
      showNoQuestions();
      scheduleBackup();
      return;
    }
    // jeśli jest kolejne pytanie – przechodzimy dalej
    if (questionIndex < questions.length - 1) {
      questionIndex++;
      showCurrentQuestion();
      scheduleBackup();
    } else {
      // byliśmy na ostatnim pytaniu – przejście do trybu "brak pytań"
      showNoQuestions();
      scheduleBackup();
    }
  }

  document.getElementById("btn-prev").addEventListener("click", goPrevQuestion);
  document.getElementById("btn-next").addEventListener("click", goNextQuestion);

  // Global skróty (działają nawet gdy okno nie jest aktywne)
  // Ctrl+N, a potem 1 = WSTECZ, 2 = DALEJ (w ciągu ~1s)
  if (window.wbApi && typeof window.wbApi.onQuestionsNext === "function") {
    window.wbApi.onQuestionsNext(goNextQuestion);
  }
  if (window.wbApi && typeof window.wbApi.onQuestionsPrev === "function") {
    window.wbApi.onQuestionsPrev(goPrevQuestion);
  }
  // (wyłączone) nie czytamy już pytań z TXT ani z logów w tle.

  showNoQuestions();
  refreshNextFromQueue();
}

// Wczytaj i połącz pytania z dwóch plików TXT.
// Kolejność: najpierw MANUAL (ręczne), potem AUTO (donejty).
async function _readJsonlFromOutput(name) {
  try {
    const r = await window.wbApi.readFile(name);
    if (!r || !r.ok || !r.data) return [];
    const lines = String(r.data || "").split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
    const out = [];
    for (const line of lines) {
      try {
        const obj = JSON.parse(line);
        if (!obj) continue;
        const ts = typeof obj.ts === "number" ? obj.ts : Date.parse(obj.ts);
        const nick = String(obj.nick || "").trim();
        const question = String(obj.question || "").trim();
        if (!nick || !question) continue;
        out.push({ ts: Number.isFinite(ts) ? ts : Date.now(), nick, question, source: obj.source || null, priority: !!obj.priority, kind: obj.kind || (question.toUpperCase() === KARTON_DNIA_TEXT ? KARTON_DNIA_KIND : null) });
      } catch {}
    }
    return out;
  } catch (e) {
    return [];
  }
}

// Wczytaj pytania CHRONOLOGICZNIE z logów (auto + gifty). Jeśli log jest pusty, fallback: AUTO TXT.
async function reloadQuestionsFromTwoFiles(keepCurrent) {
  const entriesAuto = await _readJsonlFromOutput("pytania_auto_log.jsonl");
  const entriesGift = await _readJsonlFromOutput("pytania_gifty_log.jsonl");

  const mergedEntries = [...entriesAuto, ...entriesGift].filter((e) => e && e.nick && e.question);

  if (mergedEntries.length) {
    mergedEntries.sort((a, b) => (a.ts || 0) - (b.ts || 0));
    const mergedText = mergedEntries
      .map((e) => (e.priority ? `@WB_POZA
${e.nick}
${e.question}
` : `${e.nick}
${e.question}
`))
      .join("\n");
    parseQuestions(mergedText, !!keepCurrent);
    refreshNextFromQueue();
    return;
  }

  // Fallback: wczytaj AUTO TXT (np. jeśli logi są puste)
  let autoText = "";
  if (autoQuestionsFilePath) {
    const r = await window.wbApi.readAbsoluteFile(autoQuestionsFilePath);
    if (r && r.ok) {
      autoText = r.data || "";
      if (r.mtimeMs) autoQuestionsFileMtime = r.mtimeMs;
    }
  }
  parseQuestions(autoText || "", !!keepCurrent);
  refreshNextFromQueue();
}

/**
 * Format pliku:
 * LINIA 1: nick
 * LINIA 2: pytanie
 * PUSTA LINIA
 * LINIA 4: kolejny nick
 * LINIA 5: pytanie
 * ...
 */
function parseQuestions(text, keepCurrent = false) {
  // zapamiętaj aktualne pytanie, jeśli mamy zachować pozycję
  let prevNick = null;
  let prevQuestion = null;
  let prevIndex = questionIndex;
  if (keepCurrent && questions.length && questionIndex >= 0 && questionIndex < questions.length) {
    prevNick = questions[questionIndex].nick;
    prevQuestion = questions[questionIndex].question;
  }

  const rawLines = text.split(/\r?\n/);

  const blocks = [];
  let buf = [];
  for (const line of rawLines) {
    const trimmed = line.trim();
    if (trimmed === "") {
      if (buf.length) {
        blocks.push(buf);
        buf = [];
      }
    } else {
      buf.push(trimmed);
    }
  }
  if (buf.length) blocks.push(buf);

  const parsed = [];
  for (const blk of blocks) {
    if (blk.length >= 2) {
      let priority = false;
let nick = blk[0];
let question = blk[1];

// @WB... nad nickiem = priorytet ("pozakolejka") – linia jest niewidoczna, ale wpływa na kolejkę
if (/^@wb/i.test(String(blk[0] || "").trim())) {
  priority = true;
  nick = blk[1];
  question = blk[2];
}

const nL = String(nick || "").trim().toLowerCase();
const qL = String(question || "").trim().toLowerCase();

// "XX" to placeholder – nie liczymy tego jako rozkład i nie pokazujemy w liście
if (nL === "xx" || qL === "xx") continue;

parsed.push({ nick, question, priority, kind: String(question || "").trim().toUpperCase() === KARTON_DNIA_TEXT ? KARTON_DNIA_KIND : null });

    }
  }

  questions = parsed;

  if (keepCurrent && prevNick !== null) {
    // 0) Najpierw spróbuj zostać na TYM SAMYM indeksie (to rozwiązuje przypadek,
    // gdy ten sam nick jest kilka razy, a zmieniło się tylko pytanie "x" -> treść)
    if (prevIndex >= 0 && prevIndex < questions.length && questions[prevIndex].nick === prevNick) {
      questionIndex = prevIndex;
    } else {
      // 1) idealnie – dopasowanie po nicku + pytaniu
      let foundIndex = questions.findIndex(
        (q) => q.nick === prevNick && q.question === prevQuestion
      );

      // 2) jeśli pytanie zostało zmienione – wybierz NAJBLIŻSZE wystąpienie nicku względem poprzedniego indeksu
      if (foundIndex === -1) {
        let best = -1;
        let bestDist = Number.POSITIVE_INFINITY;
        for (let i = 0; i < questions.length; i++) {
          if (questions[i].nick === prevNick) {
            const d = Math.abs(i - prevIndex);
            if (d < bestDist) {
              best = i;
              bestDist = d;
            }
          }
        }
        foundIndex = best;
      }

      // 3) jeśli nadal nie znaleziono – staramy się zostać przy podobnym indeksie
      if (foundIndex === -1) {
        if (questions.length === 0) {
          questionIndex = 0;
        } else if (prevIndex >= 0 && prevIndex < questions.length) {
          questionIndex = prevIndex;
        } else {
          questionIndex = 0;
        }
      } else {
        questionIndex = foundIndex;
      }
    }
} else {
    // nowe wczytanie pliku – start od pierwszego pytania
    questionIndex = 0;
  }

  filteredCount = questions.reduce((acc, q) => {
    const m = q.nick.toLowerCase().match(/-(\d+)\s*pyt/);
    return acc + (m ? parseInt(m[1], 10) : 1);
  }, 0);

  document.getElementById("questions-count").textContent = `Rozkładów: ${filteredCount}`;
  renderQuestionOrderQueue();
}



function showCurrentQuestion() {
  noQuestionsMode = false;
  const idxBadge = document.getElementById("question-index-badge");
  if (!questions.length) {
    showNoQuestions();
    return;
  }

  const nickDiv = document.getElementById("question-nick");
  const textDiv = document.getElementById("question-text");

  const currentQuestion = questions[questionIndex];
  const { nick, question } = currentQuestion;
  const isKarton = isKartonDniaEntry(currentQuestion);
  nickDiv.textContent = nick;
  setKartonDniaUi(isKarton);

  // w kółku pokazujemy liczbę ROZKŁADÓW (uwzględnia -2pyt, -3pyt itd.)
  updateRozkladyBadge(filteredCount);

  const qLower = question.trim().toLowerCase();
  if (isKarton) {
    textDiv.textContent = KARTON_DNIA_TEXT;
    textDiv.style.color = "#ffd34d";
  } else if (qLower === "x") {
    textDiv.textContent = "CZEKAM NA PYTANIE";
    textDiv.style.color = "#ffc300";
  } else {
    textDiv.textContent = question;
    textDiv.style.color = "#ffffff";
  }

  document.getElementById("questions-count").textContent = `Rozkładów: ${filteredCount}`;
  autoResizeQuestionText();
  saveQuestionState(nick, question);
  refreshNextFromQueue();
  renderQuestionOrderQueue();
}

function showNoQuestions() {
  noQuestionsMode = true;
  noQuestionsLength = questions.length;
  updateRozkladyBadge(filteredCount);
  setKartonDniaUi(false);

  document.getElementById("question-nick").textContent = "Brak pytań";
  const textDiv = document.getElementById("question-text");
  textDiv.textContent = "";
  textDiv.style.color = "#ffc300";
  autoResizeQuestionText();
  renderQuestionOrderQueue();
  // w plikach TXT: nick = "TERAZ TY", pytanie = puste
  saveQuestionState("TERAZ TY", "");
}

function updateRozkladyBadge(count) {
  const badge = document.getElementById("question-index-badge");
  if (!badge) return;

  const n = Number(count) || 0;
  badge.textContent = String(n);

  // gradient: czerwony -> zielony (0..30)
  const ratio = Math.max(0, Math.min(1, n / 30));
  const hue = Math.round(120 * ratio); // 0=red, 120=green
  const color = `hsl(${hue}, 90%, 50%)`;

  badge.style.borderColor = color;
  badge.style.color = color;
  badge.style.boxShadow = `0 0 14px hsla(${hue}, 90%, 55%, 0.35)`;

  // aktualizuj banner + filary monet
  updateKvrinaBanner(n);
  updateCoinPillars(n, hue);
}


function updateKvrinaBanner(count) {
  const banner = document.getElementById("kvrina-banner");
  if (!banner) return;
  const on = Number(count) > 30;
  banner.classList.toggle("show", on);
  banner.classList.toggle("hidden", !on);
}

function ensureCoinPillarsInitialized() {
  const left = document.getElementById("pillar-left");
  const right = document.getElementById("pillar-right");
  if (!left || !right) return false;

  if (!pillarLeftCoins.length || !pillarRightCoins.length) {
    left.innerHTML = "";
    right.innerHTML = "";

    const leftStack = document.createElement("div");
    leftStack.className = "coin-stack";
    const rightStack = document.createElement("div");
    rightStack.className = "coin-stack";

    pillarLeftCoins = [];
    pillarRightCoins = [];

    for (let i = 0; i < PILLAR_MAX; i++) {
      const c1 = document.createElement("div");
      c1.className = "coin";
      const c2 = document.createElement("div");
      c2.className = "coin";

      pillarLeftCoins.push(c1);
      pillarRightCoins.push(c2);

      leftStack.appendChild(c1);
      rightStack.appendChild(c2);
    }

    left.appendChild(leftStack);
    right.appendChild(rightStack);
  }
  return true;
}

function updateCoinPillars(count, hue) {
  if (!ensureCoinPillarsInitialized()) return;

  const left = document.getElementById("pillar-left");
  const right = document.getElementById("pillar-right");

  const n = Number(count) || 0;
  const filled = Math.max(0, Math.min(PILLAR_MAX, Math.floor(n)));

  const qc = document.getElementById("question-current");
  if (qc) qc.style.setProperty("--pill-hue", String(hue));

  for (let i = 0; i < PILLAR_MAX; i++) {
    const on = i < filled;
    if (pillarLeftCoins[i]) pillarLeftCoins[i].classList.toggle("filled", on);
    if (pillarRightCoins[i]) pillarRightCoins[i].classList.toggle("filled", on);
  }

  if (n > 30) startCoinRain();
  else stopCoinRain();

  // gdyby animacja była zbyt krótka względem wysokości – aktualizuj zmienną w CSS
  if (qc) qc.style.setProperty("--pill-height", String(qc.clientHeight || 420));
}

function spawnFallingCoins(pillarEl) {
  if (!pillarEl) return;
  // ECO / limit elementów (stabilność)
  if (ecoMode) return;
  const existing = pillarEl.querySelectorAll('.falling-coin').length;
  if (existing >= MAX_FALLING_COINS_PER_PILLAR) return;
  const w = Math.max(10, pillarEl.clientWidth || 46);
  let amount = 1 + Math.floor(Math.random() * 2);
  const spaceLeft = Math.max(0, MAX_FALLING_COINS_PER_PILLAR - existing);
  amount = Math.min(amount, spaceLeft);

  for (let k = 0; k < amount; k++) {
    const coin = document.createElement("div");
    coin.className = "falling-coin";

    const left = Math.random() * Math.max(2, w - 18);
    coin.style.left = `${left}px`;

    const dur = 1.2 + Math.random() * 1.1;
    coin.style.animationDuration = `${dur}s`;

    const delay = Math.random() * 0.25;
    coin.style.animationDelay = `${delay}s`;

    coin.addEventListener("animationend", () => coin.remove());
    pillarEl.appendChild(coin);
  }
}

function startCoinRain() {
  if (coinRainInterval) return;
  const left = document.getElementById("pillar-left");
  const right = document.getElementById("pillar-right");

  coinRainInterval = setInterval(() => {
    if (document.hidden) return;
    spawnFallingCoins(left);
    spawnFallingCoins(right);
  }, 380);
}

function stopCoinRain() {
  if (coinRainInterval) {
    clearInterval(coinRainInterval);
    coinRainInterval = null;
  }
  const left = document.getElementById("pillar-left");
  const right = document.getElementById("pillar-right");
  if (left) left.querySelectorAll(".falling-coin").forEach((el) => el.remove());
  if (right) right.querySelectorAll(".falling-coin").forEach((el) => el.remove());
}


function renderNextLine(nextName) {
  const el = document.getElementById("question-next-queue");
  if (!el) return;

  // migotanie na czerwono jeśli jest ktoś następny
  const hasNext = Boolean(nextName);
  el.classList.toggle("next-has", hasNext);

  if (!nextName) el.textContent = "NEXT: -";
  else el.textContent = `NEXT: ${nextName}`;
}


/**
 * Dynamiczna czcionka – nick + pytanie skaluje się do boxa,
 * NEXT jest trochę mniejszy i nie psuje środka.
 */
function autoResizeQuestionText() {
  const container = document.getElementById("question-body") || document.getElementById("question-current");
  const nickDiv = document.getElementById("question-nick");
  const textDiv = document.getElementById("question-text");
  const nextDiv = document.getElementById("question-next-queue");
  const statsDiv = document.getElementById("question-stats");
  if (!container || !nickDiv || !textDiv || !nextDiv) return;

  let size = Math.min(Math.max(questionFontSize, 18), 40);
  const minSize = 10;

  let iterations = 0;
  while (iterations < 40) {
    nickDiv.style.fontSize = Math.round(size * 1.15) + "px";
    textDiv.style.fontSize = size + "px";
    nextDiv.style.fontSize = Math.round(size * 0.75) + "px";
    if (statsDiv) {
      statsDiv.style.fontSize = Math.round(size * 0.75) + "px";
    }

    const bottom = document.getElementById("question-bottom");
    const nextH = bottom ? bottom.scrollHeight : (nextDiv ? nextDiv.scrollHeight : 0);
    const available = container.clientHeight - nextH - 12;
    const used = nickDiv.scrollHeight + textDiv.scrollHeight;

    if (used <= available || size <= minSize) {
      break;
    }
    size -= 2;
    iterations++;
  }
}


function updateQuestionStats() {
  const viewers = tiktokViewerCount || 0;
  const viewersEl = document.getElementById("question-viewers");
  if (viewersEl) viewersEl.textContent = `👁 ${viewers}`;

  // Ukryj taps jeśli jeszcze jest w HTML
  const tapsEl = document.getElementById("question-taps");
  if (tapsEl) tapsEl.style.display = "none";


  // animacja "AKTUALIZUJE..." w lewym dolnym rogu boxa
  const upd = document.getElementById("question-update");
  if (upd) {
    upd.classList.remove("show");
    // wymuszenie reflow, żeby animacja mogła się ponowić
    void upd.offsetWidth;
    upd.classList.add("show");
  }
}

// ===== ZA GIFTY (TikFinity) – logika =====

async function loadGiftsState() {
  try {
    const r = await window.wbApi.readFile("gifts_state.json");
    if (!r || !r.ok || !r.data) return;
    const obj = JSON.parse(r.data);
    giftTotals = new Map(Object.entries(obj.totals || {}));
    giftUsed = new Map(Object.entries(obj.used || {}));
  } catch {}
}

async function saveGiftsState() {
  try {
    const totalsObj = {};
    const usedObj = {};
    for (const [k, v] of giftTotals.entries()) totalsObj[k] = Number(v) || 0;
    for (const [k, v] of giftUsed.entries()) usedObj[k] = Number(v) || 0;
    await window.wbApi.writeFile("gifts_state.json", JSON.stringify({ totals: totalsObj, used: usedObj }, null, 2));
  } catch {}
}

function getGiftCreditsTotal(user) {
  const total = parseInt(giftTotals.get(user) || 0, 10) || 0;
  return Math.floor(total / giftCredit);
}

function getGiftCreditsUsed(user) {
  const used = parseInt(giftUsed.get(user) || 0, 10) || 0;
  return used;
}

function getGiftCreditsAvailable(user) {
  return Math.max(0, getGiftCreditsTotal(user) - getGiftCreditsUsed(user));
}

function pushGiftFeedLine(text) {
  const now = new Date();
  const ts = now.toTimeString().slice(0, 8);
  giftFeed.unshift(`[${ts}] ${text}`);
  giftFeed = giftFeed.slice(0, 30);
  renderGiftFeed();
}

function renderGiftFeed() {
  const feedEl = document.getElementById("gifts-feed");
  if (!feedEl) return;
  feedEl.innerHTML = "";
  for (const line of giftFeed) {
    const div = document.createElement("div");
    div.className = "feed-line";
    div.textContent = line;
    feedEl.appendChild(div);
  }
}

function renderGiftsPanel() {
  const listEl = document.getElementById("gifts-list");
  const summaryEl = document.getElementById("gifts-summary");
  if (!listEl || !summaryEl) return;

  const filterEl = document.getElementById("gifts-filter");
  const filter = (filterEl && filterEl.value ? String(filterEl.value) : "").trim().toLowerCase();

  let users = Array.from(giftTotals.keys());
  if (filter) {
    users = users.filter(u => String(u).toLowerCase().includes(filter));
  }
  const totals = users.reduce((acc, u) => acc + (parseInt(giftTotals.get(u) || 0, 10) || 0), 0);

  // sort: najpierw z dostępnymi kredytami, potem po sumie monet (desc)
  users.sort((a, b) => {
    const avA = getGiftCreditsAvailable(a);
    const avB = getGiftCreditsAvailable(b);
    if (avA !== avB) return avB - avA;
    const tA = parseInt(giftTotals.get(a) || 0, 10) || 0;
    const tB = parseInt(giftTotals.get(b) || 0, 10) || 0;
    return tB - tA;
  });

  summaryEl.textContent = `${users.length} osób • ${totals} monet • próg: ${giftCredit}`;

  // aktualizuj label w tytule feedu, jeśli jest w HTML
  const thrLabel = document.getElementById("gift-threshold-label");
  if (thrLabel) thrLabel.textContent = String(giftCredit);

  listEl.innerHTML = "";

  if (!users.length) {
    const empty = document.createElement("div");
    empty.style.color = "#aaa";
    empty.style.padding = "6px 2px";
    empty.textContent = "Brak giftów (czekam na TikFinity)";
    listEl.appendChild(empty);
    return;
  }

  const nowTs = Date.now();

  for (const u of users) {
    const total = parseInt(giftTotals.get(u) || 0, 10) || 0;
    const creditsTotal = getGiftCreditsTotal(u);
    const creditsUsed = getGiftCreditsUsed(u);
    const creditsAvail = Math.max(0, creditsTotal - creditsUsed);

    const row = document.createElement("div");
    row.className = "gift-item";

    if (creditsAvail > 0) row.classList.add("gift-eligible");

    const blinkUntil = giftNewBlink.get(u) || 0;
    if (blinkUntil && nowTs < blinkUntil) row.classList.add("gift-new");

    const left = document.createElement("div");
    left.className = "gift-left";

    const userEl = document.createElement("div");
    userEl.className = "gift-user";
    userEl.textContent = u;

    const meta = document.createElement("div");
    meta.className = "gift-meta";
    meta.textContent = `monety: ${total} • kredyty: ${creditsAvail}/${creditsTotal} (użyte: ${creditsUsed})`;

    left.appendChild(userEl);
    left.appendChild(meta);

    const actions = document.createElement("div");
    actions.className = "gift-actions";

    const pickBtn = document.createElement("button");
    pickBtn.className = "btn tiny orange";
    pickBtn.textContent = "WYBIERZ";
    pickBtn.addEventListener("click", () => {
      selectedGiftUser = u;
      const sel = document.getElementById("gift-selected-user");
      if (sel) sel.textContent = u;
      const panel = document.getElementById("gifts-panel");
      if (panel && panel.classList.contains("hidden")) {
        panel.classList.remove("hidden");
      }
    });

    actions.appendChild(pickBtn);

    if (creditsAvail > 0) {
      const addBtn = document.createElement("button");
      addBtn.className = "btn tiny green";
      addBtn.textContent = "DODAJ";
      addBtn.addEventListener("click", async () => {
        selectedGiftUser = u;
        const sel = document.getElementById("gift-selected-user");
        if (sel) sel.textContent = u;
        await addSelectedGiftQuestionToQueue();
      });
      actions.appendChild(addBtn);
    }

    row.appendChild(left);
    row.appendChild(actions);
    listEl.appendChild(row);
  }
}

function toggleGiftsPanel() {
  const panel = document.getElementById("gifts-panel");
  if (!panel) return;
  // jeśli otwieramy gift panel, zamknij panel ręczny
  const manual = document.getElementById("manual-panel");
  if (manual && panel.classList.contains("hidden") === true) {
    manual.classList.add("hidden");
  }
  panel.classList.toggle("hidden");
  // zawsze odśwież widok przy otwarciu
  if (!panel.classList.contains("hidden")) {
    renderGiftsPanel();
    renderGiftFeed();
  }
}

function toggleManualPanel() {
  const panel = document.getElementById("manual-panel");
  if (!panel) return;
  // jeśli otwieramy panel ręczny, zamknij panel giftów
  const gifts = document.getElementById("gifts-panel");
  if (gifts && panel.classList.contains("hidden") === true) {
    gifts.classList.add("hidden");
  }
  panel.classList.toggle("hidden");
  if (!panel.classList.contains("hidden")) {
    const f = document.getElementById("manual-feed");
    if (f) f.textContent = "";
    const n = document.getElementById("manual-nick-input");
    if (n) n.focus();
  }
}

async function addManualQuestionToQueue() {
  const nickEl = document.getElementById("manual-nick-input");
  const qEl = document.getElementById("manual-question-input");
  const feedEl = document.getElementById("manual-feed");

  const nick = (nickEl ? String(nickEl.value || "") : "").trim();
  const rawQ = (qEl ? String(qEl.value || "") : "").trim();
  const question = rawQ.length ? rawQ : "x";

  if (!nick) {
    if (feedEl) feedEl.textContent = "Wpisz nick.";
    if (nickEl) nickEl.focus();
    return;
  }

  const ts = Date.now();

  // zapis do logu (chronologia kliknięć)
  try {
    await window.wbApi.appendFile(
      "pytania_recznie_log.jsonl",
      JSON.stringify({ ts, nick, question, source: "manual" }) + "\n"
    );
  } catch (e) {
    console.warn("append manual log failed:", e);
  }

  insertQuestionSorted({ ts, nick, question, source: "manual" });

  if (feedEl) feedEl.textContent = `Dodano: ${nick}`;
  if (qEl) {
    qEl.value = "";
    qEl.focus();
  }
}

async function addSelectedGiftQuestionToQueue() {
  if (!selectedGiftUser) {
    alert("Najpierw wybierz osobę z listy.");
    return;
  }

  const avail = getGiftCreditsAvailable(selectedGiftUser);
  if (avail <= 0) {
    alert(`Ten użytkownik nie ma już dostępnych kredytów (${giftCredit} monet = 1).`);
    return;
  }

  const input = document.getElementById("gift-question-input");
  const q = (input ? input.value : "").trim();
  const question = q.length ? q : "x";

  const ts = Date.now();
  const nick = selectedGiftUser;

  // zapis do logu (chronologia)
  try {
    await window.wbApi.appendFile("pytania_gifty_log.jsonl", JSON.stringify({ ts, nick, question, source: "gifts" }) + "\n");
  } catch (e) {
    console.warn("append gifts log failed:", e);
  }

  // zużyj 1 kredyt
  giftUsed.set(selectedGiftUser, String(getGiftCreditsUsed(selectedGiftUser) + 1));

  // START PUSTO: stan giftów trzymamy w pamięci + backup.

  // UX
  if (input) input.value = "";
  pushGiftFeedLine(`${nick} dodany do kolejki (pytanie: ${question === "x" ? "x" : "treść"})`);

  insertQuestionSorted({ ts, nick, question, source: "gifts" });

  renderGiftsPanel();
}

async function onTikfinityGift(username, amount, giftName) {
  if (!username) return;
  const prev = parseInt(giftTotals.get(username) || 0, 10) || 0;
  const next = prev + (parseInt(amount || 0, 10) || 0);

  giftTotals.set(username, String(next));

  const prevCredits = Math.floor(prev / giftCredit);
  const nextCredits = Math.floor(next / giftCredit);

  if (nextCredits > prevCredits) {
    // nowy próg 450+
    giftNewBlink.set(username, Date.now() + 15000);
    pushGiftFeedLine(`${username} przekroczył ${giftCredit}+ (kredyty: ${nextCredits})`);
  }

  // START PUSTO: stan giftów trzymamy w pamięci + backup.
  scheduleBackup();
  renderGiftsPanel();
  scheduleWidgetStateWrite();
}




// NEXT: osoba z pliku kolejki
async function refreshNextFromQueue() {
  const el = document.getElementById("question-next-queue");
  if (!el) return;

  const res = await window.wbApi.readFile("wszyscy_po_aktualnym.txt");
  if (!res.ok || !res.data.trim()) {
    renderNextLine(null);
    return;
  }
  const first = res.data
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .find((x) => !isJoinPlaceholder(x));
  if (!first) renderNextLine(null);
  else renderNextLine(first);
}

// Zapis plików TXT dla OBS
function wrapTextToLines(text, maxLen) {
  if (!text) return "";
  const words = text.split(/\s+/);
  const lines = [];
  let current = "";

  for (const w of words) {
    if (!current.length) {
      current = w;
      continue;
    }
    if ((current + " " + w).length <= maxLen) {
      current += " " + w;
    } else {
      lines.push(current);
      current = w;
    }
  }
  if (current.length) lines.push(current);
  return lines.join("\n");
}

async function saveQuestionState(nick, question) {
  if (!outputDir) return;

  const qLower = (question || "").trim().toLowerCase();
  let formatted = "";
  if (qLower === "x") formatted = "CZEKAM NA PYTANIE";
  else if (qLower === "xx") formatted = "";
  else formatted = question || "";

  const nickText = nick && nick.toLowerCase() !== "xx" ? nick : "TERAZ TY";

  const remainingNames = [];
  if (questions.length && questionIndex < questions.length - 1) {
    for (let i = questionIndex + 1; i < questions.length; i++) {
      const n = questions[i].nick;
      if (n.toLowerCase() !== "xx") remainingNames.push(n);
    }
  }
  remainingNames.push("DOŁĄCZ");

  await window.wbApi.writeFile("aktualny_nick.txt", nickText);
  await window.wbApi.writeFile("aktualne_pytanie.txt", wrapTextToLines(formatted, 60));
  await window.wbApi.writeFile("wszyscy_po_aktualnym.txt", remainingNames.join("\n"));
  scheduleWidgetStateWrite();
}

/* ====== TIMERY ====== */

function setupTimers() {
  const timer1Display = document.getElementById("timer1-display");
  const timer2Display = document.getElementById("timer2-display");

  function fmtGui(sec) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  function fmtHmsBroadcast(sec) {
    const h = Math.floor(sec / 3600);
    const m = Math.floor((sec % 3600) / 60);
    const s = sec % 60;
    return `${h}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
  }
  function fmtMsBroadcast(sec) {
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}:${String(s).padStart(2, "0")}`;
  }

  async function writeTimerFiles() {
    const t1 = timer1Seconds > 0 ? fmtHmsBroadcast(timer1Seconds) : "00:00:00";
    const t2 = timer2Seconds > 0 ? fmtMsBroadcast(timer2Seconds) : "00:00";

    // zapisuj tylko gdy się zmieniło (mniej IO / mniej mikro-lagów)
    if (writeTimerFiles._lastT1 !== t1) {
      await window.wbApi.writeFile("odliczanie1.txt", t1);
      writeTimerFiles._lastT1 = t1;
    }
    if (writeTimerFiles._lastT2 !== t2) {
      await window.wbApi.writeFile("odliczanie2.txt", t2);
      writeTimerFiles._lastT2 = t2;
    }
  }

  function updateDisplays() {
    timer1Display.textContent = timer1Seconds > 0 ? fmtGui(timer1Seconds) : "00:00:00";
    timer2Display.textContent = timer2Seconds > 0 ? fmtGui(timer2Seconds) : "00:00:00";
  }

  function resetTimer1FromInputs() {
    const h = parseInt(document.getElementById("timer1-hours").value || "0", 10) || 0;
    let m = parseInt(document.getElementById("timer1-minutes").value || "0", 10) || 0;
    if (m < 0) m = 0;
    if (m > 59) m = 59;
    timer1Seconds = h * 3600 + m * 60;
    updateDisplays();
    writeTimerFiles();
  }

  function resetTimer2FromInputs() {
    let m = parseInt(document.getElementById("timer2-minutes").value || "0", 10) || 0;
    if (m < 0) m = 0;
    timer2Seconds = m * 60;
    updateDisplays();
    writeTimerFiles();
  }

  function startTimer1() {
    if (timer1Interval) return;
    if (timer1Seconds <= 0) resetTimer1FromInputs();
    timer1Interval = setInterval(() => {
      if (timer1Seconds > 0) timer1Seconds--;
      else clearInterval(timer1Interval);
      updateDisplays();
      writeTimerFiles();
    }, 1000);
  }

  function stopTimer1() {
    if (timer1Interval) {
      clearInterval(timer1Interval);
      timer1Interval = null;
    }
  }

  function startTimer2() {
    if (timer2Interval) return;
    if (timer2Seconds <= 0) resetTimer2FromInputs();
    timer2Interval = setInterval(() => {
      if (timer2Seconds > 0) timer2Seconds--;
      else clearInterval(timer2Interval);
      updateDisplays();
      writeTimerFiles();
    }, 1000);
  }

  function stopTimer2() {
    if (timer2Interval) {
      clearInterval(timer2Interval);
      timer2Interval = null;
    }
  }

  document.getElementById("timer1-start").addEventListener("click", startTimer1);
  document.getElementById("timer1-stop").addEventListener("click", stopTimer1);
  document.getElementById("timer1-reset").addEventListener("click", () => {
    stopTimer1();
    resetTimer1FromInputs();
  });

  document.getElementById("timer2-start").addEventListener("click", startTimer2);
  document.getElementById("timer2-stop").addEventListener("click", stopTimer2);
  document.getElementById("timer2-reset").addEventListener("click", () => {
    stopTimer2();
    resetTimer2FromInputs();
  });

  window.addEventListener("keydown", (e) => {
    if (e.ctrlKey && e.key === "0") {
      e.preventDefault();
      stopTimer2();
      resetTimer2FromInputs();
    } else if (e.ctrlKey && e.key === "9") {
      e.preventDefault();
      startTimer2();
    }
  });

  updateDisplays();
  writeTimerFiles();
}
