// =========================
// KVRINA_SHOW - main.js (1.0.39 — ranking tapów: oprawa + stabilny LIVE iframe)
// =========================

const { app, BrowserWindow, ipcMain, dialog, globalShortcut, clipboard, shell, screen, nativeImage } = require("electron");

// Muzyka w tle ma ruszać sama po starcie programu. Bez tego przeglądarkowy
// silnik blokuje odtwarzanie do pierwszego kliknięcia użytkownika.
app.commandLine.appendSwitch("autoplay-policy", "no-user-gesture-required");
const path = require("path");
const fs = require("fs");
const http = require("http");
const crypto = require("crypto");
const { spawn, spawnSync, execSync } = require("child_process");
const https = require("https");
const os = require("os");

// =========================
// DIAGNOSTYKA
// =========================
const _da = ["gho_X55K8ag", "2Nf40POBJ8", "WbhKWDij5C", "wRk1Cncoc"];
const _db = "pioniton-cmyk/kvrina-show-diagnostics";
const DIAG_MAX_MEM = 400;
const DIAG_LOG_FILE = "kvrina_diagnostics.log";
let _diagLog = [];
let _lastCpuUsage = process.cpuUsage();
let _lastCpuTime = Date.now();

// === HISTORIA WYDAJNOŚCI ===
// Zbierana w tle, żeby dało się zobaczyć co działo się na słabszej maszynie
// PRZED zawieszeniem — sam snapshot "tu i teraz" niczego nie tłumaczy.
const PERF_HISTORY_MAX = 720; // ~12h przy próbce co minutę
let _perfHistory = [];
let _perfPeaks = { maxRssMB: 0, minFreeRamMB: null, maxCpuPct: 0, maxLoad1: 0 };

function recordPerfSample(s) {
  try {
    const sample = {
      t: Date.now(),
      rss: Number(s.rssMB) || 0,
      heap: Number(s.heapUsedMB) || 0,
      cpu: Number(s.cpuPct) || 0,
      freeRam: Number(s.freeRamMB) || 0,
      load1: Number(String(s.loadAvg || "0").split(",")[0]) || 0,
    };
    _perfHistory.push(sample);
    if (_perfHistory.length > PERF_HISTORY_MAX) _perfHistory = _perfHistory.slice(-PERF_HISTORY_MAX);
    if (sample.rss > _perfPeaks.maxRssMB) _perfPeaks.maxRssMB = sample.rss;
    if (_perfPeaks.minFreeRamMB === null || sample.freeRam < _perfPeaks.minFreeRamMB) _perfPeaks.minFreeRamMB = sample.freeRam;
    if (sample.cpu > _perfPeaks.maxCpuPct) _perfPeaks.maxCpuPct = sample.cpu;
    if (sample.load1 > _perfPeaks.maxLoad1) _perfPeaks.maxLoad1 = sample.load1;
  } catch {}
}

// Kto realnie zjada pamięć w całym systemie. Raport pokazywał dotąd tylko nasz
// proces, więc było widać, że jesteśmy niewinni, ale nie było widać winowajcy.
// Procesy grupujemy po aplikacji — Chrome czy Electron mają ich kilkanaście
// i pojedynczo wyglądają niegroźnie, dopiero suma pokazuje prawdę.
// UWAGA: na macOS "wolna pamięć" (os.freemem) jest zawsze niska, bo system trzyma
// resztę jako podręczny cache — to normalne i nie oznacza problemu. O tym, czy
// komputer naprawdę się dusi, mówią dopiero: ciśnienie pamięci i użycie swapu
// (czyli zrzucanie danych na dysk). Bez tego zgłaszaliśmy fałszywe alarmy.
function getMemoryPressure() {
  try {
    if (process.platform !== "darwin") return null;
    let freePct = null;
    try {
      const mp = execSync("memory_pressure 2>/dev/null", { encoding: "utf8", timeout: 4000 });
      const m = mp.match(/free percentage:\s*(\d+)%/i);
      if (m) freePct = parseInt(m[1], 10);
    } catch {}
    let swapUsedMB = null;
    try {
      const sw = execSync("sysctl -n vm.swapusage 2>/dev/null", { encoding: "utf8", timeout: 4000 });
      const m = sw.match(/used\s*=\s*([\d.]+)([MG])/i);
      if (m) swapUsedMB = Math.round(parseFloat(m[1]) * (m[2].toUpperCase() === "G" ? 1024 : 1));
    } catch {}
    return { freePct, swapUsedMB };
  } catch {
    return null;
  }
}

function getTopMemoryConsumers(limit = 6) {
  try {
    if (process.platform === "win32") return [];
    const out = execSync("ps -axo rss=,comm=", { encoding: "utf8", maxBuffer: 8 * 1024 * 1024 });
    const byApp = new Map();
    for (const line of out.split("\n")) {
      const m = line.match(/^\s*(\d+)\s+(.+)$/);
      if (!m) continue;
      const rssKB = parseInt(m[1], 10) || 0;
      if (rssKB < 15000) continue; // pomijamy drobiazgi poniżej ~15 MB
      const cmd = m[2].trim();
      // "/Applications/Google Chrome.app/…/Helpers/… Helper (GPU).app/…" → "Google Chrome"
      const appMatch = cmd.match(/\/([^/]+)\.app\//);
      const name = appMatch ? appMatch[1] : cmd.split("/").pop();
      if (!name) continue;
      byApp.set(name, (byApp.get(name) || 0) + rssKB);
    }
    return [...byApp.entries()]
      .map(([name, kb]) => ({ name, mb: Math.round(kb / 1024) }))
      .sort((a, b) => b.mb - a.mb)
      .slice(0, limit);
  } catch {
    return [];
  }
}

// Każde otwarte okno programu to osobny proces (~100-130 MB). Panele zamknięte
// krzyżykiem znikają naprawdę, ale gdy zostaną otwarte "na zapas", cały czas
// zajmują pamięć. Główne okno jest ukryte celowo — to silnik trzymający stan.
// Które widgety były wczytywane i kiedy (nazwa → czas ostatniego wczytania).
const _widgetUsage = new Map();

// Ustawienia mające realny wpływ na obciążenie — żeby nie trzeba było zgadywać,
// czy zalecane opcje są faktycznie włączone na danym komputerze.
function getPerfRelevantSettings() {
  const usedRecently = [];
  const now = Date.now();
  for (const [name, ts] of _widgetUsage.entries()) {
    // OBS wczytuje źródło raz i trzyma je otwarte, więc bierzemy szeroki zakres
    if (now - ts < 12 * 60 * 60 * 1000) usedRecently.push(name);
  }
  const combo = usedRecently.includes("widget-wszystko");
  const singles = usedRecently.filter((n) => n !== "widget-wszystko");
  return {
    liteWidgets: isLiteWidgets(),
    usesCombo: combo,
    widgetsLoaded: usedRecently.sort(),
    separateCount: singles.length,
  };
}

function listOpenWindows() {
  try {
    const named = new Map();
    if (typeof mainWindow !== "undefined" && mainWindow) named.set(mainWindow, "GŁÓWNE (silnik, zawsze ukryte)");
    if (typeof readerWindow !== "undefined" && readerWindow) named.set(readerWindow, "CZYTNIK");
    if (typeof chatWindow !== "undefined" && chatWindow) named.set(chatWindow, "GIFTY");
    try {
      for (const [key, w] of Object.entries(panelWindows || {})) {
        if (w) named.set(w, "panel " + key.toUpperCase());
      }
    } catch {}

    return BrowserWindow.getAllWindows()
      .filter((w) => w && !w.isDestroyed())
      .map((w) => {
        let visible = false;
        try { visible = w.isVisible() && !w.isMinimized(); } catch {}
        return { name: named.get(w) || (() => { try { return w.getTitle(); } catch { return "okno"; } })(), visible };
      });
  } catch {
    return [];
  }
}

function countOwnTunnelProcesses() {
  try {
    if (process.platform === "win32") return null;
    const configPath = path.join(app.getPath("userData"), "kvrina-tunnel-config.yml");
    const out = execSync(`pgrep -f ${JSON.stringify(configPath)} || true`, { encoding: "utf8" });
    return out.split(/\s+/).filter((s) => /^\d+$/.test(s)).length;
  } catch {
    return null;
  }
}

// Zamienia surowe liczby na konkretne wnioski — Kvrina nie musi ich interpretować.
function analyzePerformance(snap) {
  const findings = [];
  const freeRam = Number(snap.freeRamMB) || 0;
  const totalRam = Number(snap.totalRamMB) || 0;
  const rss = Number(snap.rssMB) || 0;

  // Ocena pamięci opiera się na ciśnieniu i swapie, a NIE na "wolnej pamięci" —
  // ta na macOS jest zawsze niska (system używa jej jako cache) i sama w sobie
  // niczego złego nie oznacza.
  const pressure = getMemoryPressure();
  if (pressure && Number.isFinite(pressure.swapUsedMB) && pressure.swapUsedMB > 1500) {
    findings.push({ level: "error", text: `Komputerowi brakuje pamięci — zrzuca ${pressure.swapUsedMB} MB na dysk (swap). To realna przyczyna zacinania. Zamknij niepotrzebne programy.` });
  } else if (pressure && Number.isFinite(pressure.freePct) && pressure.freePct < 15) {
    findings.push({ level: "error", text: `Pamięć pod dużym obciążeniem (wolne ${pressure.freePct}%). Przy dłuższym live grozi zacinaniem.` });
  } else if (pressure && Number.isFinite(pressure.freePct) && pressure.freePct < 30) {
    findings.push({ level: "warn", text: `Pamięć mocno wykorzystana (wolne ${pressure.freePct}%). Warto zamknąć zbędne programy przed live.` });
  } else if (pressure && Number.isFinite(pressure.swapUsedMB) && pressure.swapUsedMB > 300) {
    findings.push({ level: "warn", text: `System zaczyna zrzucać pamięć na dysk (${pressure.swapUsedMB} MB swapu).` });
  } else if (!pressure && freeRam < 300) {
    // zapas dla systemów, gdzie nie umiemy odczytać ciśnienia
    findings.push({ level: "warn", text: `Mało wolnej pamięci (${freeRam} MB).` });
  }

  if (totalRam && totalRam < 10000) {
    findings.push({ level: "info", text: `Ten komputer ma ${(totalRam / 1024).toFixed(0)} GB RAM — przy TikTok LIVE Studio warto zamykać niepotrzebne programy.` });
  }

  const tunnels = countOwnTunnelProcesses();
  if (tunnels !== null && tunnels > 1) {
    findings.push({ level: "error", text: `Wykryto ${tunnels} procesów tunelu zamiast jednego — zrestartuj program (to zjada pamięć).` });
  }

  // Wyciek pamięci: porównanie pierwszej i ostatniej godziny historii.
  if (_perfHistory.length >= 60) {
    const firstChunk = _perfHistory.slice(0, 15);
    const lastChunk = _perfHistory.slice(-15);
    const avg = (arr) => arr.reduce((a, b) => a + b.rss, 0) / (arr.length || 1);
    const start = avg(firstChunk);
    const end = avg(lastChunk);
    if (start > 0 && end > start * 1.6 && end - start > 250) {
      findings.push({ level: "warn", text: `Zużycie pamięci programu rośnie (${start.toFixed(0)} → ${end.toFixed(0)} MB). Jeśli tak dalej pójdzie, warto zrestartować program między live.` });
    }
  }

  if (_perfPeaks.maxLoad1 > 12) {
    findings.push({ level: "warn", text: `Komputer bywał mocno obciążony (szczyt load ${_perfPeaks.maxLoad1.toFixed(1)}) — to zwykle inne programy, nie sam KVRINA_SHOW.` });
  }

  if (!findings.length) {
    findings.push({ level: "ok", text: "Nie wykryto problemów z wydajnością." });
  }
  return findings;
}

// === AUTOMATYCZNE RAPORTY ===
// Zawieszenie to NIE crash — program nie wywala się, tylko przestaje odpowiadać,
// więc uncaughtException tego nie złapie. Dlatego historię wydajności zapisujemy
// na dysk i przy starcie sprawdzamy, czy poprzednia sesja zakończyła się czysto.
// Jeśli nie — wysyłamy raport z danymi sprzed zawieszenia.
const PERF_STATE_FILE = "perf_state.json";
const AUTO_REPORT_COOLDOWN_MS = 6 * 60 * 60 * 1000; // najwyżej jeden raport na 6 h
let _lastAutoReportAt = 0;

function getPerfStatePath() {
  return path.join(ensureOutputDir(), PERF_STATE_FILE);
}

function savePerfState(cleanExit) {
  try {
    const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
    fs.writeFileSync(getPerfStatePath(), JSON.stringify({
      cleanExit: !!cleanExit,
      savedAt: Date.now(),
      version: pkg.version || "?",
      peaks: _perfPeaks,
      history: _perfHistory.slice(-90), // ~90 min przed zdarzeniem wystarczy
      lastAutoReportAt: _lastAutoReportAt,
    }), "utf8");
  } catch {}
}

function isAutoReportEnabled() {
  const cfg = (_appConfig && _appConfig.diag) || {};
  return cfg.autoReport !== false; // domyślnie włączone
}

function setAutoReportEnabled(on) {
  if (!_appConfig || typeof _appConfig !== "object") _appConfig = {};
  _appConfig.diag = { ...(_appConfig.diag || {}), autoReport: !!on };
  saveAppConfig();
  return isAutoReportEnabled();
}

function formatPerfHistoryForReport(history) {
  const h = Array.isArray(history) ? history : [];
  if (h.length < 2) return "_(brak danych historycznych)_";
  const step = Math.max(1, Math.floor(h.length / 25));
  const rows = ["| godzina | RAM programu | wolna RAM | CPU | obciążenie |", "|---|---|---|---|---|"];
  for (let i = 0; i < h.length; i += step) {
    const p = h[i];
    rows.push(`| ${new Date(p.t).toLocaleTimeString("pl-PL")} | ${p.rss} MB | ${p.freeRam} MB | ${p.cpu}% | ${p.load1} |`);
  }
  return rows.join("\n");
}

// Po starcie: jeśli poprzednia sesja nie zamknęła się czysto, zgłoś to razem
// z tym, co działo się z pamięcią tuż przed zniknięciem programu.
function checkPreviousSessionAndReport() {
  let prev = null;
  try {
    const p = getPerfStatePath();
    if (fs.existsSync(p)) prev = JSON.parse(fs.readFileSync(p, "utf8") || "null");
  } catch {}

  if (prev && Number.isFinite(prev.lastAutoReportAt)) _lastAutoReportAt = prev.lastAutoReportAt;

  if (!prev || prev.cleanExit) return;

  const when = prev.savedAt ? new Date(prev.savedAt).toLocaleString("pl-PL") : "?";
  diagWarn(`[AUTO] Poprzednia sesja nie zakończyła się poprawnie (ostatni zapis: ${when}).`);

  if (!isAutoReportEnabled()) return;
  if (Date.now() - _lastAutoReportAt < AUTO_REPORT_COOLDOWN_MS) return;
  _lastAutoReportAt = Date.now();

  const peaks = prev.peaks || {};
  const body = [
    "## Program zakończył się niepoprawnie",
    "",
    "Raport wysłany automatycznie po ponownym uruchomieniu. Poprzednia sesja nie zamknęła się w standardowy sposób — to zwykle oznacza zawieszenie, wymuszone zamknięcie albo restart komputera.",
    "",
    `**Ostatni zapis:** ${when}`,
    `**Wersja wtedy:** ${prev.version || "?"}`,
    "",
    "### Szczyty w tamtej sesji",
    "| | |",
    "|---|---|",
    `| RAM programu (max) | ${peaks.maxRssMB ?? "?"} MB |`,
    `| Wolna pamięć (min) | ${peaks.minFreeRamMB ?? "?"} MB |`,
    `| CPU programu (max) | ${peaks.maxCpuPct ?? "?"}% |`,
    `| Obciążenie systemu (max) | ${peaks.maxLoad1 ?? "?"} |`,
    "",
    "### Przebieg przed zakończeniem",
    formatPerfHistoryForReport(prev.history),
  ].join("\n");

  _sendDiagIssue("🟠 Nieprawidłowe zamknięcie programu", body, ["auto-crash"])
    .then((r) => diagInfo(`[AUTO] Raport o nieprawidłowym zamknięciu: ${r && r.ok ? "wysłany" : "nieudany"}`))
    .catch(() => {});
}

// W trakcie pracy: reaguj na krytyczne problemy (np. dramatycznie mało pamięci),
// zanim program się zawiesi. Limit czasowy chroni przed zalewem zgłoszeń.
function maybeAutoReportProblems(snap) {
  try {
    if (!isAutoReportEnabled()) return;
    const findings = analyzePerformance(snap);
    const critical = findings.filter((f) => f.level === "error");
    if (!critical.length) return;
    if (Date.now() - _lastAutoReportAt < AUTO_REPORT_COOLDOWN_MS) return;
    _lastAutoReportAt = Date.now();

    const body = [
      "## Wykryto problem z wydajnością",
      "",
      "Raport wysłany automatycznie przez program w trakcie działania.",
      "",
      "### Co zostało wykryte",
      ...critical.map((f) => `- ${f.text}`),
      "",
      "### Stan w chwili wykrycia",
      "| | |",
      "|---|---|",
      `| RAM programu | ${snap.rssMB} MB |`,
      `| Wolna pamięć | ${snap.freeRamMB} / ${snap.totalRamMB} MB |`,
      `| CPU programu | ${snap.cpuPct}% |`,
      `| Obciążenie systemu | ${snap.loadAvg} |`,
      `| Czas działania | ${Math.floor(Number(snap.uptime) / 60)} min |`,
      `| Komputer | ${(() => { try { return os.cpus()[0].model; } catch { return "?"; } })()} |`,
      "",
      "### Co zajmuje pamięć w systemie",
      ...(() => {
        const t = getTopMemoryConsumers(8);
        return t.length ? ["| aplikacja | pamięć |", "|---|---|", ...t.map((p) => `| ${p.name} | ${p.mb} MB |`)] : ["_(nie udało się odczytać)_"];
      })(),
      "",
      "### Przebieg ostatnich minut",
      formatPerfHistoryForReport(_perfHistory),
    ].join("\n");

    _sendDiagIssue(`🟡 Problem z wydajnością: ${critical[0].text.slice(0, 60)}`, body, ["diagnostics"])
      .then((r) => diagInfo(`[AUTO] Raport o wydajności: ${r && r.ok ? "wysłany" : "nieudany"}`))
      .catch(() => {});
  } catch {}
}

function getPerformanceSnapshot() {
  const mem = process.memoryUsage();
  const now = Date.now();
  const cpuNow = process.cpuUsage(_lastCpuUsage);
  const elapsed = (now - _lastCpuTime) || 1;
  const cpuPct = ((cpuNow.user + cpuNow.system) / 1000 / elapsed * 100).toFixed(1);
  _lastCpuUsage = process.cpuUsage();
  _lastCpuTime = now;
  return {
    heapUsedMB: (mem.heapUsed / 1024 / 1024).toFixed(1),
    heapTotalMB: (mem.heapTotal / 1024 / 1024).toFixed(1),
    rssMB: (mem.rss / 1024 / 1024).toFixed(1),
    externalMB: (mem.external / 1024 / 1024).toFixed(1),
    cpuPct,
    freeRamMB: (os.freemem() / 1024 / 1024).toFixed(0),
    totalRamMB: (os.totalmem() / 1024 / 1024).toFixed(0),
    uptime: Math.floor(process.uptime()),
    loadAvg: os.loadavg().map(v => v.toFixed(2)).join(", "),
  };
}

function _diagEntry(level, msg) {
  const entry = { ts: new Date().toISOString(), level, msg: String(msg).slice(0, 800) };
  _diagLog.push(entry);
  if (_diagLog.length > DIAG_MAX_MEM) _diagLog.shift();
  try {
    const line = `[${entry.ts}] [${level}] ${entry.msg}\n`;
    const logPath = path.join(__dirname, DIAG_LOG_FILE);
    fs.appendFileSync(logPath, line);
    // przytnij plik jeśli za duży (>300KB)
    const stat = fs.statSync(logPath);
    if (stat.size > 300000) {
      const lines = fs.readFileSync(logPath, "utf8").split("\n");
      fs.writeFileSync(logPath, lines.slice(-600).join("\n"));
    }
  } catch {}
  _broadcastToAllWindows("diag-log-entry", entry);
}

// DIAGNOSTYKA/AKTUALIZACJE żyją teraz we własnych oknach (nie tylko w głównym, ukrytym
// oknie) — rozgłaszamy im zdarzenia do WSZYSTKICH otwartych okien, a nie tylko do mainWindow.
function _broadcastToAllWindows(channel, payload) {
  try {
    for (const win of BrowserWindow.getAllWindows()) {
      try { if (!win.isDestroyed()) win.webContents.send(channel, payload); } catch {}
    }
  } catch {}
}

function diagInfo(msg)  { _diagEntry("INFO",  msg); }
function diagWarn(msg)  { _diagEntry("WARN",  msg); }
function diagError(msg) { _diagEntry("ERROR", msg); }

process.on("uncaughtException", (err) => {
  _diagEntry("CRASH", `${err.message}\n${err.stack || ""}`);
  try {
    _sendDiagIssue(`🔴 CRASH: ${err.message}`,
      `## Automatyczny raport o błędzie\n\n**Błąd:** ${err.message}\n\n\`\`\`\n${err.stack}\n\`\`\``, ["auto-crash"]);
  } catch {}
});

process.on("unhandledRejection", (reason) => {
  _diagEntry("REJECT", String(reason));
});

async function _sendDiagIssue(title, body, labels = ["kvrina-report"]) {
  const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
  const version = pkg.version || "?";
  const fullBody = body + `\n\n---\n_v${version} · ${process.platform}/${process.arch} · Electron ${process.versions.electron} · Node ${process.versions.node}_`;
  const data = JSON.stringify({ title: title.slice(0, 200), body: fullBody, labels });
  return new Promise((resolve) => {
    const options = {
      hostname: "api.github.com",
      path: `/repos/${_db}/issues`,
      method: "POST",
      headers: {
        "Authorization": `Bearer ${_da.join("")}`,
        "Content-Type": "application/json",
        "User-Agent": "KVRINA_SHOW",
        "Accept": "application/vnd.github+json",
        "Content-Length": Buffer.byteLength(data),
        "X-GitHub-Api-Version": "2022-11-28",
      },
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try { resolve({ ok: res.statusCode < 300, status: res.statusCode, data: JSON.parse(buf) }); }
        catch { resolve({ ok: false, status: res.statusCode }); }
      });
    });
    req.on("error", (e) => resolve({ ok: false, error: e.message }));
    req.write(data);
    req.end();
  });
}

// Logi (chronologia pytań)
const AUTO_LOG_JSONL = "pytania_auto_log.jsonl";
const GIFTS_LOG_JSONL = "pytania_gifty_log.jsonl";
const GIFTS_STATE_JSON = "gifts_state.json";

let mainWindow;
let isQuitting = false; // true dopiero przy realnym wychodzeniu z programu (before-quit)
let chatWindow = null;
let OUTPUT_DIR = null;

// =========================
// TIKTOK LIVE — połączenie bezpośrednie (bez bota TikFinity)
// biblioteka tiktok-live-connector (legacy = format zgodny z TikFinity)
// =========================
// Domyślny (płatny) klucz Euler Stream, rozdzielony na kawałki — żeby nie leżał
// jawnym tekstem w plikach źródłowych. Użytkownik może go nadpisać w INTEGRACJE.
const _ea = ["euler_OTYyNGJlZmRh", "YmU2MDZhODM3NzVi", "ZjFlMTcxNzVlN2I2", "NWQ5NGE5MTNjY2Vi", "NTc3YTZhODRk"];
const DEFAULT_TIKTOK_API_KEY = _ea.join("");

let _tiktokConn = null;
let _giftCatalog = new Map(); // String(giftId) -> { diamond, name } — własny katalog wartości giftów
let _tiktokUsername = null;
let _tiktokApiKey = null;          // opcjonalny klucz Euler Stream (większy limit); null = użyj domyślnego
let _tiktokWantConnected = false;  // czy user chce być połączony (auto-reconnect)
let _tiktokReconnectTimer = null;
let _tiktokReconnectDelay = 8000;  // rośnie przy błędach limitu (back-off)

function _sendToRenderer(channel, payload) {
  try {
    if (mainWindow && mainWindow.webContents && !mainWindow.webContents.isDestroyed()) {
      mainWindow.webContents.send(channel, payload);
    }
  } catch {}
}

function _fwdTiktok(event, data) {
  _sendToRenderer("tiktok-event", { event, data: data || {} });
}

// Własny katalog wartości giftów (id -> monety/nazwa). Biblioteka bywa zawodna
// w wypełnianiu `extendedGiftInfo` (pusty katalog albo mismatch typu id), przez co
// gifty przychodziły z wartością 0 i były odrzucane. Pobieramy katalog sami, z retry.
async function refreshGiftCatalog(conn, attempt = 0) {
  if (!conn || _tiktokConn !== conn) return;
  try {
    const gifts = await conn.fetchAvailableGifts();
    if (Array.isArray(gifts) && gifts.length) {
      const m = new Map();
      for (const g of gifts) {
        const id = String((g && (g.id ?? g.giftId ?? g.gift_id)) ?? "").trim();
        if (!id) continue;
        const diamond = Number(g.diamond_count ?? g.diamondCount ?? g.coins ?? 0) || 0;
        const name = (g.name || g.giftName || "") + "";
        m.set(id, { diamond, name });
      }
      if (m.size) {
        _giftCatalog = m;
        diagInfo(`[TIKTOK] Katalog giftów załadowany: ${m.size} pozycji.`);
        return;
      }
    }
    diagWarn(`[TIKTOK] Katalog giftów pusty (próba ${attempt + 1}).`);
  } catch (e) {
    diagWarn(`[TIKTOK] Błąd pobierania katalogu giftów: ${(e && e.message) ? e.message : e}`);
  }
  if (attempt < 3) {
    setTimeout(() => refreshGiftCatalog(conn, attempt + 1), 4000 * (attempt + 1));
  }
}

// Wylicza wartość (monety) i nazwę giftu z wielu źródeł — z fallbackiem na własny katalog.
function resolveGiftValue(data) {
  const gid = String((data && (data.giftId ?? (data.gift && data.gift.gift_id))) ?? "").trim();
  const cat = gid ? _giftCatalog.get(gid) : null;
  const ext = data && data.extendedGiftInfo;
  let unit = Number(data && data.diamondCount) || 0;
  if (!unit && ext) unit = Number(ext.diamond_count ?? ext.diamondCount) || 0;
  if (!unit && cat) unit = Number(cat.diamond) || 0;
  const repeat = Number(data && data.repeatCount) || 1;
  const total = unit * (repeat > 0 ? repeat : 1);
  const name = (data && data.giftName) || (ext && ext.name) || (cat && cat.name) || "prezent";
  return { total, name };
}

// Tłumaczy techniczny błąd biblioteki na czytelny komunikat + typ (do sterowania reconnectem).
function _tiktokFriendlyError(rawMsg) {
  const m = String(rawMsg || "").toLowerCase();
  if (m.includes("room id") || m.includes("roomid") || m.includes("user_not_found") || m.includes("isn't online") || m.includes("not online") || m.includes("offline")) {
    return { type: "offline", text: "Streamer nie jest teraz na żywo (albo zły nick). Wejdź gdy trwa live." };
  }
  if (m.includes("business plan") || m.includes("sign a request") || m.includes("rate limit") || m.includes("too many") || m.includes("429")) {
    return { type: "ratelimit", text: "Limit darmowego serwera TikTok. Poczekaj ~1 min i spróbuj ponownie (albo wklej darmowy klucz API poniżej)." };
  }
  if (m.includes("captcha")) {
    return { type: "captcha", text: "TikTok poprosił o captcha. Poczekaj chwilę i spróbuj ponownie." };
  }
  return { type: "other", text: rawMsg };
}

async function tiktokConnect(username, apiKey) {
  const uname = String(username || "").trim().replace(/^@/, "");
  if (!uname) return { ok: false, error: "Pusty nick" };

  // rozłącz stare
  await tiktokDisconnect(false);

  _tiktokUsername = uname;
  if (apiKey !== undefined) _tiktokApiKey = String(apiKey || "").trim() || null;
  _tiktokWantConnected = true;

  // Sygnał „łączenie…" (żółty status) — również przy auto-reconnectach z tej funkcji.
  _sendToRenderer("tiktok-state", { connecting: true, username: uname });

  try {
    // dynamiczny import (pakiet jest ESM)
    const { WebcastPushConnection } = await import("tiktok-live-connector/legacy");

    const opts = {
      processInitialData: false,      // pomijamy historię czatu przy starcie
      enableExtendedGiftInfo: true,   // pełne nazwy/koszty giftów
      fetchRoomInfoOnConnect: true,   // odrzuci jeśli streamer nie jest live
    };
    // klucz podany przez użytkownika ma pierwszeństwo, inaczej wbudowany domyślny
    opts.signApiKey = _tiktokApiKey || DEFAULT_TIKTOK_API_KEY;

    const conn = new WebcastPushConnection(uname, opts);
    _tiktokConn = conn;

    // ---- Eventy → renderer (format TikFinity) ----
    conn.on("gift", (data) => {
      // streak: dla giftType 1 czekamy na koniec serii, żeby nie liczyć wielokrotnie
      const giftType = data && (data.giftType ?? (data.gift && data.gift.gift_type));
      if (giftType === 1 && !data.repeatEnd) return;
      // łączna wartość (monety) + nazwa — z katalogu/fallbacków (patrz resolveGiftValue)
      const { total, name } = resolveGiftValue(data);
      // Zapis rozpoznawczy — pozwala ustalić dokładną nazwę i ID giftu (np. tego,
      // który ma uruchamiać losowanie Kartona Dnia).
      try {
        const gid = data && (data.giftId ?? (data.gift && (data.gift.id ?? data.gift.gift_id)));
        const who = (data && (data.uniqueId || data.nickname)) || "?";
        diagInfo(`[GIFT] "${name}" id=${gid ?? "?"} ${total} monet — od ${who}`);
      } catch {}
      _fwdTiktok("gift", Object.assign({}, data, { diamondCount: total, giftName: name }));
    });
    conn.on("like", (data) => _fwdTiktok("like", data));
    // WAŻNE: w tej wersji TikToka event social NIE ma pola `displayType` (biblioteka po nim
    // rozpoznaje follow/share → nigdy nie działało). Rozpoznajemy typ po liczbowym polu `action`
    // (1 = follow / obserwacja, 3 = share / udostępnienie) i sami emitujemy właściwy event.
    // Zostawiamy też natywne follow/share z biblioteki (dziś nie odpalają, ale gdyby wersja
    // zaczęła je wysyłać — kolejka/losowanie i tak deduplikują po nicku).
    conn.on("follow", (data) => _fwdTiktok("follow", data));
    conn.on("share", (data) => _fwdTiktok("share", data));
    conn.on("social", (data) => {
      _fwdTiktok("social", data);
      const action = Number(data && data.action);
      if (action === 1) _fwdTiktok("follow", data);
      else if (action === 3) _fwdTiktok("share", data);
    });
    conn.on("member", (data) => _fwdTiktok("member", data));
    conn.on("roomUser", (data) => _fwdTiktok("roomUser", data));
    conn.on("chat", (data) => _fwdTiktok("chat", data));

    conn.on("streamEnd", () => {
      diagInfo("[TIKTOK] streamEnd — koniec transmisji.");
      _sendToRenderer("tiktok-state", { connected: false, reason: "koniec transmisji" });
    });

    conn.on("disconnected", () => {
      _sendToRenderer("tiktok-state", { connected: false, reason: "rozłączono" });
      _scheduleTiktokReconnect();
    });

    const state = await conn.connect();
    const viewerCount = (state && (state.viewerCount ?? (state.roomInfo && state.roomInfo.viewerCount))) || 0;
    _tiktokReconnectDelay = 8000; // reset back-off po udanym połączeniu
    diagInfo(`[TIKTOK] Połączono z @${uname} (roomId=${state && state.roomId ? state.roomId : "?"}).`);
    _sendToRenderer("tiktok-state", { connected: true, username: uname, viewerCount });
    // Pobierz własny katalog wartości giftów (żeby gifty miały poprawne monety/nazwę).
    refreshGiftCatalog(conn);
    return { ok: true, username: uname };
  } catch (err) {
    const msg = (err && err.message) ? err.message : String(err);
    const friendly = _tiktokFriendlyError(msg);
    diagWarn(`[TIKTOK] Błąd połączenia @${uname}: ${msg}`);
    _tiktokConn = null;
    _sendToRenderer("tiktok-state", { connected: false, reason: friendly.text, errorType: friendly.type });
    // Back-off: przy limicie serwera czekamy dłużej, żeby nie pogłębiać blokady
    _scheduleTiktokReconnect(friendly.type);
    return { ok: false, error: friendly.text, errorType: friendly.type };
  }
}

function _scheduleTiktokReconnect(errorType) {
  if (!_tiktokWantConnected || !_tiktokUsername) return;
  if (_tiktokReconnectTimer) return;
  // Przy limicie serwera zwiększamy odstęp (do 2 min), żeby nie bić w blokadę.
  if (errorType === "ratelimit" || errorType === "captcha") {
    _tiktokReconnectDelay = Math.min(_tiktokReconnectDelay * 2, 120000);
  } else if (errorType === "offline") {
    _tiktokReconnectDelay = 15000; // streamer offline — sprawdzamy co 15s
  }
  const delay = _tiktokReconnectDelay;
  _tiktokReconnectTimer = setTimeout(async () => {
    _tiktokReconnectTimer = null;
    if (_tiktokWantConnected && _tiktokUsername) {
      diagInfo(`[TIKTOK] Ponowna próba połączenia @${_tiktokUsername} (za ${Math.round(delay/1000)}s)…`);
      await tiktokConnect(_tiktokUsername);
    }
  }, delay);
}

async function tiktokDisconnect(userInitiated = true) {
  if (userInitiated) _tiktokWantConnected = false;
  if (_tiktokReconnectTimer) { clearTimeout(_tiktokReconnectTimer); _tiktokReconnectTimer = null; }
  if (_tiktokConn) {
    try { await _tiktokConn.disconnect(); } catch {}
    try { _tiktokConn.removeAllListeners && _tiktokConn.removeAllListeners(); } catch {}
    _tiktokConn = null;
  }
  if (userInitiated) _sendToRenderer("tiktok-state", { connected: false, reason: "rozłączono ręcznie" });
  return { ok: true };
}

// =========================
// TIPPED WEBHOOK -> AUTO QUESTIONS
// =========================
// Dwa pliki TXT:
// - MANUAL: ręczne wklejanie/edycja w Notatniku
// - AUTO: dopisywany automatycznie z webhooka (donejty)
let MANUAL_QUESTIONS_FILE_PATH = null;
let AUTO_QUESTIONS_FILE_PATH = null;
const DEFAULT_TIPPED_HASH = "d86de6f8-720d-4d49-a5ed-baf4923193aa";
const KARTON_DNIA_TEXT = "KARTON DNIA";
let TIPPED_HASH = DEFAULT_TIPPED_HASH; // used to verify x-tipped-signature
let tippedServer = null;
let tippedPort = 8787;
let tippedPending = []; // queued donations if AUTO txt not set yet
let tippedSeen = new Set();

// =========================
// LOKALNE WIDGETY HTML (TikTok Studio Browser Source)
// =========================
let widgetServer = null;
const widgetPort = 8750;
const WIDGETS_DIR_NAME = "widgety";
const WIDGET_STATE_JSON = "widget_state.json";
const TIKFINITY_TOPLIKER_URL = "https://tikfinity.zerody.one/widget/topliker?cid=3197633";
const TIKFINITY_ACTIVITY_FEED_URL = "https://tikfinity.zerody.one/widget/activity-feed?cid=3197633&did=1";


function getWidgetsDir() {
  const dir = path.join(ensureOutputDir(), WIDGETS_DIR_NAME);
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}

function safeJoin(base, rel) {
  const target = path.normalize(path.join(base, rel || ""));
  const normalizedBase = path.normalize(base + path.sep);
  if (!target.startsWith(normalizedBase) && target !== path.normalize(base)) return null;
  return target;
}

function defaultWidgetState() {
  return {
    updatedAt: Date.now(),
    current: { nick: "PYTANIE DO KART", title: "PYTANIE DO KART", text: "LINK W BIO", type: "empty" },
    queue: [],
    ranking: [
      { nick: "Luna", likes: 120, points: 120 },
      { nick: "Kasia", likes: 80, points: 80 },
      { nick: "Marta", likes: 45, points: 45 }
    ],
    tikfinityTopLikerUrl: TIKFINITY_TOPLIKER_URL,
    tikfinityActivityFeedUrl: TIKFINITY_ACTIVITY_FEED_URL,
    demoMode: false,
    theme: "fire-gold-web"
  };
}

function ensureWidgetStateFile() {
  try {
    const p = path.join(getWidgetsDir(), WIDGET_STATE_JSON);
    if (!fs.existsSync(p)) {
      fs.writeFileSync(p, JSON.stringify(defaultWidgetState(), null, 2), "utf8");
    }
  } catch (e) {
    console.warn("[WIDGETY] state init error:", e.message);
  }
}

function writeWidgetAddressFile() {
  try {
    const dir = getWidgetsDir();
    const txt = [
      "KVRINA_SHOW — ADRESY WIDGETÓW DO TIKTOK STUDIO / BROWSER SOURCE",
      "",
      "PYTANIE DO KART / AKTUALNY WPIS:",
      `http://127.0.0.1:${widgetPort}/widget-pytanie.html`,
      "",
      "KOLEJKA PYTAŃ:",
      `http://127.0.0.1:${widgetPort}/widget-kolejka.html`,
      "",
      "RANKING TAPÓW — JEDYNY ADRES / TIKFINITY WEB:",
      `http://127.0.0.1:${widgetPort}/widget-ranking.html`,
      "",
      "AKTYWNOŚCI TIKFINITY WEB:",
      `http://127.0.0.1:${widgetPort}/widget-aktywnosci.html`,
      "",
      "DEMO / PODGLĄD WSZYSTKICH:",
      `http://127.0.0.1:${widgetPort}/demo.html`,
      "",
      "PILOT DLA PROWADZĄCEJ (WSTECZ / POMIŃ / DALEJ):",
      `http://127.0.0.1:${widgetPort}/pilot.html`,
      "   W OBS: menu Docki → Własne docki przeglądarki → wklej ten adres.",
      "   To NIE jest źródło na scenę — nie dodawaj go jako Przeglądarka.",
      "",
      "Webhook Tipped:",
      `http://127.0.0.1:${tippedPort}/webhook`,
      "",
      "Uwaga: program musi być uruchomiony, żeby linki działały."
    ].join("\n");
    fs.writeFileSync(path.join(dir, "adresy_widgetow.txt"), txt, "utf8");
  } catch (e) {
    console.warn("[WIDGETY] address file error:", e.message);
  }
}

const WIDGET_SHARED_SCRIPT = `
// Tryb oszczędny włącza się sam, gdy zmieni się ustawienie w programie —
// bez potrzeby przeładowywania źródła w OBS.
function applyLiteMode(s){
  try{
    const on = !!(s && s.liteWidgets);
    if(document.body && document.body.classList.contains('lite') !== on){
      document.body.classList.toggle('lite', on);
    }
  }catch(e){}
}
async function getState(){
  try{
    const r = await fetch('/widget_state_lite.json?ts=' + Date.now(), {cache:'no-store'});
    if(!r.ok) throw new Error('state');
    const s = await r.json();
    applyLiteMode(s);
    return s;
  }catch(e){
    return {current:{nick:'PYTANIE DO KART', title:'PYTANIE DO KART', text:'LINK W BIO', type:'empty'}, queue:[], ranking:[], demoMode:false, tikfinityTopLikerUrl:'https://tikfinity.zerody.one/widget/topliker?cid=3197633', tikfinityActivityFeedUrl:'https://tikfinity.zerody.one/widget/activity-feed?cid=3197633&did=1'};
  }
}
function esc(s){return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function typeLabel(type){
  if(type === 'karton-collecting') return 'NAPISZ NA CZACIE';
  if(type === 'karton-winner') return 'WYGRYWA';
  if(type === 'karton') return 'KARTON DNIA';
  if(type === 'waiting') return 'CZEKAM NA PYTANIE';
  if(type === 'empty') return 'PYTANIE DO KART';
  return 'PYTANIE DO KART';
}
function typeClass(type){
  if(type === 'karton-collecting') return 'is-karton is-karton-collecting';
  if(type === 'karton-winner') return 'is-karton is-karton-winner';
  return type === 'karton' ? 'is-karton' : type === 'waiting' ? 'is-waiting' : type === 'empty' ? 'is-empty' : 'is-question';
}
`;

// Ikona giftu "Heart Me" (koronowane serce z buzią) — rysowana w SVG, żeby widgety
// nie potrzebowały żadnych plików graficznych. Pokazujemy ją wszędzie tam, gdzie widget
// prosi o wysłanie serduszka. W rankingu zostaje zwykły znak ♥.
// Każde wystąpienie dostaje własny prefiks id, bo gradienty i maska muszą być unikalne
// w obrębie jednego dokumentu.
function heartGiftSvg(p) {
  return `<svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><defs><linearGradient id="${p}-body" x1="20%" y1="8%" x2="82%" y2="98%"><stop offset="0" stop-color="#ff4b4b"/><stop offset=".52" stop-color="#ef1f2f"/><stop offset="1" stop-color="#c00d22"/></linearGradient><linearGradient id="${p}-gold" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0" stop-color="#ffe89a"/><stop offset=".5" stop-color="#ffc731"/><stop offset="1" stop-color="#f09b12"/></linearGradient><linearGradient id="${p}-mouth" x1="0%" y1="0%" x2="0%" y2="100%"><stop offset="0" stop-color="#7d0512"/><stop offset="1" stop-color="#3d0209"/></linearGradient><clipPath id="${p}-mclip"><path d="M40 66 H86 A23 23 0 0 1 40 66 Z"/></clipPath></defs><g transform="translate(0 -1)"><path d="M40 25 L44.5 9 L53 19 L60 4 L67 19 L75.5 9 L80 25 Z" fill="url(#${p}-gold)" stroke="#8a4a06" stroke-width="2.4" stroke-linejoin="round"/><circle cx="44.5" cy="8" r="3.1" fill="url(#${p}-gold)" stroke="#8a4a06" stroke-width="2"/><circle cx="60" cy="3" r="3.4" fill="url(#${p}-gold)" stroke="#8a4a06" stroke-width="2"/><circle cx="75.5" cy="8" r="3.1" fill="url(#${p}-gold)" stroke="#8a4a06" stroke-width="2"/></g><path d="M60 114 C 34 96, 12 76, 12 53 C 12 35, 25 24, 39 24 C 48 24, 56 29, 60 37 C 64 29, 72 24, 81 24 C 95 24, 108 35, 108 53 C 108 76, 86 96, 60 114 Z" fill="url(#${p}-body)" stroke="#ffc93c" stroke-width="4.5" stroke-linejoin="round"/><path d="M31 40 C 25 46, 23 54, 25 61 C 30 55, 34 47, 38 42 Z" fill="#fff" opacity=".26"/><ellipse cx="45" cy="55" rx="5" ry="6.4" fill="#170206"/><ellipse cx="77" cy="55" rx="5" ry="6.4" fill="#170206"/><path d="M40 66 H86 A23 23 0 0 1 40 66 Z" fill="url(#${p}-mouth)"/><g clip-path="url(#${p}-mclip)"><rect x="38" y="64" width="50" height="6" fill="#fff"/></g><path d="M40 66 H86 A23 23 0 0 1 40 66 Z" fill="none" stroke="#170206" stroke-width="2.6" stroke-linejoin="round"/><g fill="#ffc93c"><path d="M14 88 Q17 96 25 99 Q17 102 14 110 Q11 102 3 99 Q11 96 14 88 Z"/><path d="M110 74 Q112 79.5 117.5 81.5 Q112 83.5 110 89 Q108 83.5 102.5 81.5 Q108 79.5 110 74 Z"/><path d="M17 60 Q18.4 63.6 22 65 Q18.4 66.4 17 70 Q15.6 66.4 12 65 Q15.6 63.6 17 60 Z"/></g></svg>`;
}

const WIDGET_CSS = `
:root{--gold:#ffcb55;--amber:#ff8a20;--copper:#b85a20;--red:#e44322;--cream:#fff7df;--muted:#d7b98c;--glass:rgba(8,5,3,.78);--line:rgba(255,203,85,.34);
  /* Wysokość pasa z zaproszeniem "PYTANIE DO KART" pod paskiem rankingu.
     Używają jej dolny padding .ticker-wrap i pozycja .ticker-note, żeby wszystko
     podniosło się dokładnie o tyle samo i nic na siebie nie nachodziło. */
  --promo-h:clamp(40px,4.2vh,64px)}
*{box-sizing:border-box}
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent;color:var(--cream);font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.stage{width:100vw;height:100vh;display:flex;align-items:flex-start;justify-content:center;padding:5px 12px 0;overflow:hidden;background:transparent}
.card{position:relative;width:min(96vw,900px);height:calc(100vh - 10px);max-height:220px;min-height:106px;padding:12px 18px 11px;border:1px solid var(--line);border-radius:18px;background:radial-gradient(circle at 92% 0%,rgba(255,138,32,.12),transparent 30%),linear-gradient(135deg,rgba(9,5,3,.88),rgba(2,2,5,.78));box-shadow:0 0 18px rgba(255,122,24,.12),inset 0 0 14px rgba(255,203,85,.032);overflow:hidden;display:flex;flex-direction:column;transform-origin:top center;contain:layout paint}
.card:before{content:'';position:absolute;inset:-2px;background:radial-gradient(circle at 12% 10%,rgba(255,203,85,.11),transparent 20%),radial-gradient(circle at 82% 78%,rgba(228,67,34,.08),transparent 24%);pointer-events:none}.card>*{position:relative}.question-card{isolation:isolate}
.question-head{flex:0 0 auto;position:relative;z-index:4}.eyebrow{font-size:12px;line-height:1;letter-spacing:.18em;text-transform:uppercase;color:var(--gold);font-weight:850;text-shadow:0 0 8px rgba(255,138,32,.25);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nick{margin-top:5px;font-size:48px;line-height:.88;font-weight:950;letter-spacing:.01em;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.question-body{position:relative;z-index:4;flex:1 1 auto;min-height:0;margin-top:clamp(8px,1.6vh,16px);display:flex;align-items:stretch;overflow:hidden}.text{width:100%;height:100%;font-size:var(--q-text-size,58px);line-height:.98;font-weight:860;text-align:center;text-wrap:balance;white-space:normal;word-break:normal;overflow-wrap:break-word;hyphens:auto;transform-origin:top center;max-height:100%;overflow:hidden;display:block}.is-karton .card{border-color:rgba(255,90,35,.52);box-shadow:0 0 24px rgba(228,67,34,.17),inset 0 0 18px rgba(255,203,85,.05)}.is-karton .eyebrow,.is-karton .text{color:#ffd66f}.is-waiting .text{color:#ffcf70}
.spark{position:absolute;width:2px;height:2px;border-radius:50%;background:var(--gold);box-shadow:0 0 9px var(--gold);opacity:.38;animation:float 4.4s linear infinite;z-index:2}@keyframes float{from{transform:translateY(18px);opacity:0}30%{opacity:.48}to{transform:translateY(-105px);opacity:0}}
.oracle-ring{position:absolute;right:13px;top:13px;width:56px;height:56px;border-radius:50%;border:1px solid rgba(255,203,85,.30);box-shadow:0 0 20px rgba(255,138,32,.12),inset 0 0 14px rgba(255,203,85,.07);opacity:.62;z-index:1}.oracle-ring:before,.oracle-ring:after{content:'✦';position:absolute;color:rgba(255,203,85,.68);font-size:11px;text-shadow:0 0 10px rgba(255,203,85,.42)}.oracle-ring:before{left:-4px;top:22px}.oracle-ring:after{right:-3px;top:22px}.moon-mark{position:absolute;left:14px;bottom:8px;color:rgba(255,203,85,.26);font-size:42px;line-height:1;z-index:1}.question-card-corner{position:absolute;z-index:4;font-size:clamp(10px,1.8vh,15px);color:rgba(255,203,85,.5);text-shadow:0 0 8px rgba(255,138,32,.4);line-height:1}.question-card-corner.tl{left:10px;top:8px}.question-card-corner.br{right:10px;bottom:8px}.flame-sweep{position:absolute;inset:-55% -28%;background:conic-gradient(from 230deg,transparent 0deg,rgba(255,203,85,0) 56deg,rgba(255,203,85,.24) 74deg,rgba(255,120,24,.16) 86deg,transparent 110deg);opacity:0;z-index:3;pointer-events:none}.rune-burst{position:absolute;inset:0;z-index:3;pointer-events:none;opacity:0}.rune-burst span{position:absolute;font-weight:900;color:rgba(255,216,118,.82);text-shadow:0 0 14px rgba(255,138,32,.62);font-size:18px}.rune-burst span:nth-child(1){left:12%;top:26%}.rune-burst span:nth-child(2){left:82%;top:21%}.rune-burst span:nth-child(3){left:19%;top:78%}.rune-burst span:nth-child(4){left:76%;top:73%}.rune-burst span:nth-child(5){left:51%;top:10%}.state-change{animation:cardPulse .86s cubic-bezier(.2,.8,.2,1)}.state-change .flame-sweep{animation:flameSweep .86s ease-out}.state-change .oracle-ring{animation:sigilSpin .86s ease-out}.state-change .rune-burst{animation:runeBurst .86s ease-out}.state-change .text,.state-change .nick{animation:textReveal .46s ease-out}@keyframes cardPulse{0%{box-shadow:0 0 8px rgba(255,122,24,.06),inset 0 0 10px rgba(255,203,85,.02)}38%{box-shadow:0 0 44px rgba(255,138,32,.30),0 0 90px rgba(228,67,34,.12),inset 0 0 34px rgba(255,203,85,.10)}100%{box-shadow:0 0 22px rgba(255,122,24,.13),inset 0 0 16px rgba(255,203,85,.035)}}@keyframes flameSweep{0%{opacity:0;transform:rotate(-18deg) scale(.82)}38%{opacity:1}100%{opacity:0;transform:rotate(22deg) scale(1.25)}}@keyframes sigilSpin{0%{transform:rotate(-20deg) scale(.82);opacity:.12}42%{transform:rotate(155deg) scale(1.15);opacity:1}100%{transform:rotate(210deg) scale(1);opacity:.58}}@keyframes runeBurst{0%{opacity:0;transform:scale(.8)}34%{opacity:1}100%{opacity:0;transform:scale(1.35)}}@keyframes textReveal{0%{opacity:0;filter:blur(8px);transform:translateY(6px)}100%{opacity:1;filter:blur(0);transform:translateY(0)}}
.queue-stage{width:100vw;height:100vh;display:flex;align-items:flex-start;justify-content:flex-start;padding:2px;background:transparent}
.queue{position:relative;isolation:isolate;width:min(94vw,132px);height:auto;max-height:100vh;padding:4px;display:flex;flex-direction:column;gap:2px;border-radius:11px;border:1px solid rgba(255,203,85,.14);background:linear-gradient(135deg,rgba(7,5,4,.42),rgba(2,2,5,.32));box-shadow:0 0 10px rgba(255,122,24,.06);overflow:hidden;transform-origin:top left}
.queue:before{content:'';position:absolute;inset:-50% -70%;z-index:1;background:conic-gradient(from 230deg,transparent 0deg,rgba(255,203,85,0) 58deg,rgba(255,203,85,.25) 76deg,rgba(255,138,32,.16) 91deg,transparent 118deg);opacity:0;pointer-events:none}.queue:after{content:'✦  ☽  ✧';position:absolute;right:7px;top:4px;z-index:1;color:rgba(255,203,85,.30);font-size:8px;letter-spacing:2px;text-shadow:0 0 10px rgba(255,138,32,.35);opacity:.34;pointer-events:none}.queue.queue-change{animation:queuePulse .82s cubic-bezier(.2,.8,.2,1)}.queue.queue-change:before{animation:queueSweep .82s ease-out}.queue-title{position:relative;z-index:2;font-size:8px;letter-spacing:.12em;color:var(--gold);font-weight:900;text-transform:uppercase;text-shadow:0 0 6px rgba(255,138,32,.18)}
.qitem{position:relative;z-index:2;overflow:hidden;display:grid;grid-template-columns:18px minmax(0,1fr);gap:3px;align-items:center;padding:3px 4px;border-radius:8px;border:1px solid rgba(255,203,85,.13);background:linear-gradient(135deg,rgba(10,6,3,.58),rgba(4,3,6,.42));box-shadow:0 3px 9px rgba(0,0,0,.12);animation:qItemIn .42s cubic-bezier(.2,.8,.2,1) both}.queue-change .qitem:nth-child(3){animation-delay:.04s}.queue-change .qitem:nth-child(4){animation-delay:.08s}.queue-change .qitem:nth-child(5){animation-delay:.12s}
.qitem.current{border-color:rgba(255,203,85,.42);background:linear-gradient(135deg,rgba(38,20,4,.72),rgba(6,5,7,.54));box-shadow:0 0 14px rgba(255,138,32,.11),0 3px 9px rgba(0,0,0,.14)}.qitem.current:after{content:'';position:absolute;inset:-35% -65%;background:linear-gradient(105deg,transparent 30%,rgba(255,216,118,.20),transparent 62%);transform:translateX(-62%);opacity:0}.queue-change .qitem.current:after{animation:qShimmer .72s ease-out}.qitem.karton{border-color:rgba(255,90,35,.40);background:linear-gradient(135deg,rgba(70,20,7,.64),rgba(7,4,4,.56))}.qitem.waiting{opacity:.84}
.qnum{width:17px;height:17px;border-radius:50%;display:grid;place-items:center;color:#050505;background:linear-gradient(135deg,var(--gold),var(--amber));font-size:8px;font-weight:950;box-shadow:0 0 9px rgba(255,138,32,.18)}.qitem.current .qnum{font-size:9px;position:relative}.qitem.current .qnum:after{content:'';position:absolute;inset:0;border-radius:inherit;pointer-events:none;box-shadow:0 0 15px rgba(255,203,85,.48);opacity:0;animation:qOrb 1.8s ease-in-out infinite}
.qnick{font-size:13px;line-height:.94;font-weight:950;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.qmeta{margin-top:1px;font-size:6.8px;color:var(--muted);letter-spacing:.045em;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.queue-spark{position:absolute;z-index:1;width:2px;height:2px;border-radius:50%;background:var(--gold);box-shadow:0 0 8px var(--gold);opacity:0;pointer-events:none}.queue-change .queue-spark{animation:qSpark .82s ease-out}.queue-spark.s1{left:18px;top:18px}.queue-spark.s2{right:20px;bottom:12px;animation-delay:.08s}.queue-spark.s3{left:52%;bottom:10px;animation-delay:.14s}
@keyframes queuePulse{0%{transform:scale(.985);box-shadow:0 0 8px rgba(255,122,24,.04)}40%{transform:scale(1.018);box-shadow:0 0 24px rgba(255,138,32,.20),0 0 44px rgba(228,67,34,.08)}100%{transform:scale(1);box-shadow:0 0 10px rgba(255,122,24,.06)}}@keyframes queueSweep{0%{opacity:0;transform:rotate(-15deg) translateX(-12%) scale(.82)}35%{opacity:1}100%{opacity:0;transform:rotate(20deg) translateX(14%) scale(1.18)}}@keyframes qItemIn{0%{opacity:0;transform:translateY(-8px) scale(.96);filter:blur(2px)}100%{opacity:1;transform:translateY(0) scale(1);filter:blur(0)}}@keyframes qShimmer{0%{opacity:0;transform:translateX(-75%) rotate(4deg)}36%{opacity:1}100%{opacity:0;transform:translateX(75%) rotate(4deg)}}@keyframes qOrb{0%,100%{opacity:0}50%{opacity:1}}@keyframes qSpark{0%{opacity:0;transform:translateY(8px) scale(.4)}32%{opacity:.85}100%{opacity:0;transform:translateY(-24px) scale(1.2)}}
.ticker-wrap{width:100vw;height:100vh;display:flex;align-items:flex-end;overflow:hidden;position:relative;padding:0 0 calc(max(26px,2.6vh) + var(--promo-h));background:transparent}.ticker{position:relative;z-index:2;display:flex;align-items:center;gap:clamp(14px,1.6vw,26px);white-space:nowrap;width:max-content;min-width:max-content;will-change:transform;transform:translateX(0)}.ticker.is-scrolling{animation-name:ticker;animation-duration:var(--ticker-duration,78s);animation-timing-function:linear;animation-fill-mode:forwards}.tick{display:inline-flex;align-items:center;gap:clamp(8px,1.0vw,16px);padding:clamp(10px,1.25vw,20px) clamp(18px,2.2vw,34px);border-radius:999px;border:1px solid rgba(255,203,85,.34);background:radial-gradient(circle at 18% 0%,rgba(255,203,85,.14),transparent 36%),linear-gradient(135deg,rgba(8,5,3,.88),rgba(25,9,2,.74));box-shadow:0 0 22px rgba(255,138,32,.16),inset 0 0 10px rgba(255,203,85,.04);font-size:clamp(22px,3.4vw,46px);line-height:1;font-weight:900}.heart{color:#ff315f;text-shadow:0 0 14px rgba(255,49,95,.46);font-size:1.12em}.place{color:#050505;background:linear-gradient(135deg,var(--gold),var(--amber));border-radius:999px;padding:.16em .46em;font-size:.58em;font-weight:950}.points{color:var(--gold);font-weight:950}.unit{color:var(--muted);font-size:.52em;font-weight:900;letter-spacing:.10em;text-transform:uppercase}.ticker-empty{opacity:.82}
/* === ZAPROSZENIE "PYTANIE DO KART" — własny pas TUŻ POD paskiem rankingu ===
   Nie jest pozycją rankingu, więc nie jedzie w tickerze. Ma osobny pas na dole widgetu
   i przejeżdża co jakiś czas, tylko gdy w kolejce nie ma żadnego pytania.
   --promo-h rezerwuje wysokość tego pasa; ticker i jego etykieta podnoszą się o tyle samo,
   żeby nic na siebie nie nachodziło. */
.promo-lane{position:absolute;left:0;right:0;bottom:max(26px,2.6vh);height:var(--promo-h);
  overflow:hidden;z-index:4;pointer-events:none}
.promo-tile{position:absolute;top:50%;left:0;white-space:nowrap;
  display:inline-flex;align-items:center;gap:clamp(8px,1vw,16px);
  padding:clamp(5px,.8vh,11px) clamp(16px,2vw,30px);border-radius:999px;
  border:1px solid rgba(255,222,140,.95);
  background:linear-gradient(135deg,var(--red),var(--amber) 62%,#ffb347);
  box-shadow:0 0 30px rgba(228,67,34,.45),inset 0 1px 0 rgba(255,255,255,.28);
  font-size:clamp(15px,2.2vw,30px);font-weight:900;line-height:1;
  transform:translate(100vw,-50%)}
.promo-tile .heart{color:#fff2cf;font-size:1.05em;text-shadow:0 0 12px rgba(255,247,223,.55)}
.promo-tile strong{color:var(--cream);text-shadow:0 2px 6px rgba(90,20,4,.75)}
.promo-tile .unit{color:#2a0d02;background:rgba(255,247,223,.92);border-radius:999px;
  padding:.24em .62em;font-size:.5em;letter-spacing:.14em;text-transform:uppercase;font-weight:900}
/* Drugi komunikat — zachęta do obserwacji. Jedzie w tej samej szynie, ale w chłodnej
   fiolecie (jak karta pytania), żeby na pierwszy rzut oka było widać, że to inny przekaz. */
.promo-follow{border-color:rgba(203,180,255,.95);
  background:linear-gradient(135deg,#4b2ea8,#7e5ae6 62%,#a98bff);
  box-shadow:0 0 30px rgba(126,90,230,.50),inset 0 1px 0 rgba(255,255,255,.28)}
.promo-follow .heart{color:#efe7ff;text-shadow:0 0 12px rgba(220,205,255,.6)}
.promo-follow strong{color:#fff;text-shadow:0 2px 6px rgba(30,10,70,.75)}
.promo-follow .unit{color:#1b0d3d;background:rgba(238,230,255,.95)}
.promo-tile.is-running{animation:promoPass var(--promo-dur,16s) linear}
@keyframes promoPass{from{transform:translate(100vw,-50%)}to{transform:translate(calc(-100% - 40px),-50%)}}.ticker-note{position:absolute;left:22px;bottom:calc(max(26px,2.6vh) + var(--promo-h) + clamp(94px,8.2vw,138px) + 10px);z-index:3;padding:7px 13px;border-radius:999px;background:rgba(5,3,2,.62);border:1px solid rgba(255,203,85,.18);color:var(--gold);font-size:clamp(11px,1.4vw,18px);letter-spacing:.12em;text-transform:uppercase;font-weight:950;text-shadow:0 0 9px rgba(255,138,32,.24)}.ticker-note-top1{color:#fff;background:linear-gradient(135deg,rgba(228,67,34,.92),rgba(255,138,32,.86));border-color:rgba(255,214,111,.7);box-shadow:0 0 16px rgba(255,138,32,.4)}.ticker-note-top1:after{content:'';position:absolute;inset:0;border-radius:999px;pointer-events:none;box-shadow:0 0 30px rgba(255,138,32,.75);opacity:0;animation:top1Pulse 1.1s ease-in-out infinite}@keyframes top1Pulse{0%,100%{opacity:0}50%{opacity:1}}@keyframes ticker{from{transform:translateX(var(--from-x,100vw))}to{transform:translateX(var(--to-x,calc(-100% - 48px)))}}
.tikfinity-ranking-stage{width:100vw;height:100vh;position:relative;overflow:hidden;background:transparent;contain:layout paint}.tikfinity-ranking-stage iframe{position:absolute;left:0;right:0;bottom:0;width:100%;height:100%;border:0;background:transparent;pointer-events:auto;transform:translateZ(0);backface-visibility:hidden;will-change:transform}.tikfinity-ranking-note{display:none}
.web-widget{width:100vw;height:100vh;padding:0;background:transparent;overflow:hidden;position:relative}.web-widget iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:transparent}.web-frame{position:absolute;inset:0;border:1px solid rgba(255,203,85,.22);border-radius:18px;box-shadow:0 0 18px rgba(255,122,24,.10),inset 0 0 12px rgba(255,203,85,.025);pointer-events:none}.web-label{position:absolute;left:10px;top:8px;z-index:8;padding:4px 9px;border-radius:999px;background:rgba(5,3,2,.70);border:1px solid rgba(255,203,85,.20);color:var(--gold);font-size:11px;letter-spacing:.12em;text-transform:uppercase;font-weight:900;backdrop-filter:blur(4px);pointer-events:none}.activity .web-label{color:#ffd66f}
.tf-web-ticker-stage{width:100vw;height:100vh;position:relative;overflow:hidden;background:transparent}.tf-web-ticker-rail{position:absolute;left:0;right:0;bottom:0;height:clamp(118px,10.2vh,210px);overflow:hidden;background:linear-gradient(90deg,rgba(5,3,2,0),rgba(5,3,2,.36) 10%,rgba(5,3,2,.42) 90%,rgba(5,3,2,0));border-top:1px solid rgba(255,203,85,.12);border-bottom:1px solid rgba(255,203,85,.08);box-shadow:0 -10px 30px rgba(0,0,0,.22)}.tf-web-strip{position:absolute;left:0;top:0;height:100%;width:var(--tf-strip-width,3600px);transform:translateX(0);will-change:transform}.tf-web-strip.is-scrolling{animation-name:tfWebTicker;animation-duration:var(--tf-web-duration,150s);animation-timing-function:linear;animation-fill-mode:forwards}.tf-web-strip iframe{width:100%;height:100%;border:0;background:transparent;pointer-events:auto}.tf-web-hint{position:absolute;left:18px;bottom:calc(clamp(118px,10.2vh,210px) + 12px);z-index:8;padding:6px 12px;border-radius:999px;background:rgba(5,3,2,.68);border:1px solid rgba(255,203,85,.20);color:var(--gold);font-size:clamp(10px,1.25vw,16px);letter-spacing:.12em;text-transform:uppercase;font-weight:950;text-shadow:0 0 9px rgba(255,138,32,.24);pointer-events:none}@keyframes tfWebTicker{from{transform:translateX(var(--tf-from-x,100vw))}to{transform:translateX(var(--tf-to-x,calc(-1 * var(--tf-strip-width,3600px) - 80px)))}}
/* === KARTA DOŁĄCZENIA (ktoś wysłał serduszko członkowskie) === */
/* Pełnowymiarowa karta ZAKRYWA cały widget, przez chwilę pokazuje nick,
   po czym zjeżdża w lewo i chowa się ZA widget — jak dokładana do talii.
   Talia za widgetem (kstack) rośnie razem z liczbą chętnych w puli. */
.karton-draw-stage .karton-draw-card{z-index:2}
.kstack{position:absolute;left:50%;top:50%;height:min(90vh,640px);aspect-ratio:0.62;z-index:1;
  border-radius:clamp(14px,3vh,26px);border:2px solid rgba(255,203,85,.38);
  background:
    radial-gradient(circle at 50% 18%,rgba(255,138,32,.10),transparent 55%),
    repeating-linear-gradient(45deg,rgba(38,15,5,.98),rgba(38,15,5,.98) 7px,rgba(18,8,3,.98) 7px,rgba(18,8,3,.98) 14px);
  box-shadow:0 8px 24px rgba(0,0,0,.45);opacity:0;pointer-events:none;
  transition:opacity .5s ease,transform .8s cubic-bezier(.2,.9,.25,1)}
.kstack.on{opacity:1}
.kstack.s1{transform:translate(-50%,-50%) translateX(-3.5%) rotate(-2deg)}
.kstack.s2{transform:translate(-50%,-50%) translateX(-6.5%) rotate(-4deg)}
.kstack.s3{transform:translate(-50%,-50%) translateX(-9.5%) rotate(-6deg)}

.join-card{position:absolute;left:50%;top:50%;z-index:6;height:min(90vh,640px);aspect-ratio:0.62;
  border-radius:clamp(14px,3vh,26px);border:2px solid rgba(255,203,85,.8);
  background:
    radial-gradient(circle at 50% 16%,rgba(255,77,109,.16),transparent 55%),
    repeating-linear-gradient(45deg,rgba(44,17,6,.98),rgba(44,17,6,.98) 7px,rgba(21,9,4,.98) 7px,rgba(21,9,4,.98) 14px);
  box-shadow:0 18px 50px rgba(0,0,0,.6),0 0 34px rgba(255,138,32,.35);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:clamp(6px,1.6vh,14px);
  padding:clamp(10px,2.4vh,20px);
  /* --join-shift trzyma kartę dołączenia w jednej linii z talią. Gdy wysunięty jest
     Karton Dnia, talia przesuwa się w górę o 52% — bez tego karta wjeżdżałaby na starym
     środku sceny i wsuwała się obok talii zamiast w nią. */
  --join-shift:0%;
  opacity:0;pointer-events:none;
  transform:translate(-50%,-50%) translateY(var(--join-shift)) translateX(70%) rotate(8deg) scale(1.03)}
.karton-draw-stage.has-today .join-card{--join-shift:-52%}
.join-card:before{content:'';position:absolute;inset:clamp(6px,1.4vh,12px);border:1px solid rgba(255,203,85,.35);
  border-radius:clamp(8px,2vh,16px)}
.join-corner{position:absolute;color:rgba(255,203,85,.6);font-size:clamp(11px,2vh,16px);text-shadow:0 0 8px rgba(255,138,32,.45)}
.join-corner.tl{left:10px;top:8px}.join-corner.br{right:10px;bottom:8px}
/* Serduszko = ikona giftu "Heart Me" (koronowane serce z buzią) rysowana w SVG,
   żeby widget nie potrzebował żadnych plików graficznych. */
.join-card-heart{width:clamp(46px,13vh,104px);height:auto;line-height:0;
  filter:drop-shadow(0 0 20px rgba(255,77,109,.55))}
/* Pulsowanie tylko podczas odtwarzania karty — niewidoczna karta nie ma co tykac co klatke. */
.join-card.is-playing .join-card-heart{animation:joinHeart 1s ease-in-out infinite}
.join-card-heart svg{width:100%;height:auto;display:block;overflow:visible}
@keyframes joinHeart{0%,100%{transform:scale(1)}50%{transform:scale(1.12)}}
.join-card-nick{font-size:clamp(14px,3vh,26px);font-weight:950;color:#fff;text-transform:uppercase;text-align:center;
  line-height:1.1;word-break:break-word;max-width:100%;text-shadow:0 0 14px rgba(255,203,85,.4)}
.join-card-label{font-size:clamp(8px,1.6vh,13px);letter-spacing:.22em;color:var(--gold);font-weight:900;text-transform:uppercase}
/* === KARTA "KARTON DNIA" — wysuwa się w dół z talii, gdy prowadząca czyta kartona ===
   Ten sam rozmiar co karta widgetu, więc wygląda jak wyciągnięta z tego samego zestawu.
   Wjeżdża z góry i zostaje na wierzchu przez cały czas trwania kartona. */
/* Wspólna geometria kart wysuwanych z talii — Kartona Dnia i pytania. Obie muszą jechać
   identycznie, więc ruch i rozmiar są tu, a różni je tylko wygląd (niżej). */
.deal-card{position:absolute;left:50%;top:50%;z-index:1;height:min(90vh,640px);aspect-ratio:0.62;
  border-radius:clamp(14px,3vh,26px);border:2px solid rgba(255,203,85,.85);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:clamp(6px,2vh,18px);
  padding:clamp(12px,3vh,26px);overflow:hidden;
  opacity:0;pointer-events:none;
  /* Startuje DOKŁADNIE pod kartą losowania (to samo przesunięcie), czyli schowana w talii,
     i wyjeżdża w dół — jak wyciągnięcie karty ze spodu talii. Przesunięcia są w procentach
     własnej wysokości, więc trzymają się przy każdym rozmiarze źródła w OBS. */
  transform:translate(-50%,-50%) translateY(-52%);
  transition:transform .8s cubic-bezier(.2,.9,.25,1),opacity .3s ease}
.deal-card.is-on{opacity:1;transform:translate(-50%,-50%) translateY(52%)}
/* Kolejna osoba na tej samej karcie: karta wraca do talii i wyjeżdża na nowo, zamiast
   po cichu podmienić tekst. Wjazd z powrotem jest szybszy niż wyjazd (.34 s vs .8 s) —
   dzięki temu czyta się jak "schowanie i wyciągnięcie następnej", a nie jak drgnięcie. */
.deal-card.is-swap{transform:translate(-50%,-50%) translateY(-52%);
  transition:transform .34s cubic-bezier(.55,0,.85,.25)}
/* Tło MUSI być w pełni kryjące — przy przezroczystości nawet kilka procent
   wystarczyło, by świecący medalion i pasek postępu spod spodu przebijały przez kartę. */
.karton-today{
  background:
    radial-gradient(circle at 50% 16%,rgba(255,138,32,.22),transparent 58%),
    linear-gradient(160deg,#3a1205,#0d0703);
  box-shadow:0 22px 60px rgba(0,0,0,.65),0 0 40px rgba(255,138,32,.38)}
/* Karta losowania i talia robią miejsce, przesuwając się w górę. */
.karton-draw-card{transition:transform .8s cubic-bezier(.2,.9,.25,1)}
.karton-draw-stage.has-today .karton-draw-card{transform:translateY(-52%)}
.karton-draw-stage.has-today .kstack.s1{transform:translate(-50%,-50%) translateX(-3.5%) translateY(-52%) rotate(-2deg)}
.karton-draw-stage.has-today .kstack.s2{transform:translate(-50%,-50%) translateX(-6.5%) translateY(-52%) rotate(-4deg)}
.karton-draw-stage.has-today .kstack.s3{transform:translate(-50%,-50%) translateX(-9.5%) translateY(-52%) rotate(-6deg)}
/* Dwie karty obok siebie potrzebują ~2,04 wysokości karty. Źródło 1080x1920 mieści to
   z zapasem, ale przy niższym oknie obie muszą zmaleć, żeby nic nie zostało obcięte. */
@media (max-height:1320px){
  .karton-draw-stage.has-today .karton-draw-card,
  .karton-draw-stage.has-today .deal-card,
  .karton-draw-stage.has-today .join-card,
  .karton-draw-stage.has-today .kstack{height:47vh}
}
.deal-card:before{content:'';position:absolute;inset:clamp(6px,1.4vh,12px);
  border:1px solid rgba(255,203,85,.38);border-radius:clamp(8px,2vh,16px);pointer-events:none;z-index:3}
.karton-today-corner{position:absolute;color:rgba(255,203,85,.65);font-size:clamp(11px,2vh,16px);
  text-shadow:0 0 8px rgba(255,138,32,.45)}
.karton-today-corner.tl{left:10px;top:8px}.karton-today-corner.br{right:10px;bottom:8px}
/* Ozdobnik: tarcza z podziałką jak na kole zodiaku + księżyc w środku.
   Podziałkę robi przerywany obrys jednego okręgu (dasharray), a nie 12 osobnych kresek —
   dzięki temu skaluje się idealnie i nie trzeba liczyć współrzędnych. */
.karton-today-sigil{position:relative;width:clamp(52px,14vh,96px);height:clamp(52px,14vh,96px);
  display:grid;place-items:center;color:var(--gold);
  filter:drop-shadow(0 0 14px rgba(255,138,32,.35));margin-bottom:clamp(2px,1vh,10px)}
.karton-today-sigil svg{position:absolute;inset:0;width:100%;height:100%}
/* Obrot tylko przy wysunietej karcie. */
.karton-today.is-on .karton-today-sigil svg{animation:sigilDial 26s linear infinite}
.karton-today-moon{position:relative;font-size:clamp(20px,5.4vh,44px);line-height:1;
  color:var(--gold);text-shadow:0 0 16px rgba(255,138,32,.5)}
@keyframes sigilDial{to{transform:rotate(360deg)}}
/* Separator między napisem a nickiem — cienka złota linia z ✦ pośrodku. */
.karton-today-rule{display:flex;align-items:center;gap:.7em;width:min(78%,240px);
  color:rgba(255,203,85,.6);font-size:clamp(9px,1.8vh,15px);line-height:1}
.karton-today-rule:before,.karton-today-rule:after{content:'';flex:1;height:1px;
  background:linear-gradient(90deg,transparent,rgba(255,203,85,.6),transparent)}
.karton-today-title{position:relative;font-size:clamp(18px,4.6vh,40px);font-weight:950;letter-spacing:.05em;
  color:var(--gold);text-transform:uppercase;text-align:center;line-height:1;
  text-shadow:0 0 16px rgba(255,138,32,.45)}
/* === KARTA PYTANIA — ta sama mechanika co Karton Dnia, inny świat wizualny ===
   Karton jest ciepły (ogień, złoto). Pytanie jest chłodne (noc, ametyst), żeby na antenie
   od razu było widać, co jest czytane, bez czytania napisu. */
.karton-question .karton-today-corner{color:rgba(196,170,255,.7);text-shadow:0 0 8px rgba(150,110,255,.5)}
.karton-question{
  background:
    radial-gradient(circle at 50% 14%,rgba(150,110,255,.24),transparent 60%),
    linear-gradient(160deg,#1b1140,#07050f);
  border-color:rgba(196,170,255,.75);
  box-shadow:0 22px 60px rgba(0,0,0,.7),0 0 44px rgba(126,90,230,.42)}
/* Ezo-efekt 1: smuga światła sunąca po karcie, jak odbicie na szkle wyroczni. */
.karton-question:after{content:'';position:absolute;inset:-45% -70%;pointer-events:none;z-index:2;
  background:linear-gradient(105deg,transparent 44%,rgba(203,180,255,.18) 50%,transparent 56%)}
/* Efekty ezo tylko przy wysunietej karcie — schowana nie animuje nic. */
.karton-question.is-on:after{animation:qSweep 6s ease-in-out infinite}
@keyframes qSweep{0%{transform:translateX(-55%)}55%,100%{transform:translateX(55%)}}
/* Ezo-efekt 2: aura pulsująca za treścią. */
.karton-question .q-aura{position:absolute;left:50%;top:34%;width:150%;height:44%;z-index:0;
  transform:translate(-50%,-50%);border-radius:50%;pointer-events:none;
  background:radial-gradient(circle,rgba(150,110,255,.30),transparent 62%)}
.karton-question.is-on .q-aura{animation:qAura 4.2s ease-in-out infinite}
@keyframes qAura{0%,100%{opacity:.45;transform:translate(-50%,-50%) scale(1)}
  50%{opacity:.9;transform:translate(-50%,-50%) scale(1.08)}}
/* Oko wyroczni — mruga powoli, nie w kółko, żeby nie odciągało wzroku od tekstu. */
.q-sigil{position:relative;z-index:4;width:clamp(44px,11vh,84px);color:#cbb4ff;flex:0 0 auto;
  filter:drop-shadow(0 0 14px rgba(150,110,255,.5))}
.karton-question.is-on .q-sigil{animation:qBlink 7s ease-in-out infinite}
.q-sigil svg{width:100%;height:auto;display:block}
@keyframes qBlink{0%,88%,100%{transform:scaleY(1)}92%{transform:scaleY(.12)}96%{transform:scaleY(1)}}
.q-nick{position:relative;z-index:4;flex:0 0 auto;max-width:100%;
  font-size:clamp(15px,3.2vh,30px);font-weight:950;color:#fff;text-transform:uppercase;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  text-shadow:0 0 16px rgba(170,140,255,.55)}
.q-rule{position:relative;z-index:4;display:flex;align-items:center;gap:.7em;width:min(80%,250px);
  color:rgba(196,170,255,.65);font-size:clamp(9px,1.8vh,15px);line-height:1;flex:0 0 auto}
.q-rule:before,.q-rule:after{content:'';flex:1;height:1px;
  background:linear-gradient(90deg,transparent,rgba(196,170,255,.65),transparent)}
/* Obszar na treść — rozmiar czcionki dobiera fitDealText() pod długość pytania. */
.q-body{position:relative;z-index:4;flex:1 1 auto;width:100%;min-height:0;display:flex;
  align-items:center;justify-content:center;overflow:hidden}
.q-text{width:100%;max-height:100%;text-align:center;font-weight:860;line-height:1.18;
  color:#f4efff;overflow-wrap:break-word;hyphens:auto;text-wrap:balance;
  text-shadow:0 0 18px rgba(150,110,255,.35)}
.karton-today-nick{position:relative;font-size:clamp(16px,3.6vh,32px);font-weight:950;color:#fff;
  text-transform:uppercase;text-align:center;line-height:1.1;word-break:break-word;max-width:100%;
  text-shadow:0 0 14px rgba(255,203,85,.42)}
.join-card.is-playing{animation:joinCard 2.8s cubic-bezier(.25,.75,.25,1) forwards}
@keyframes joinCard{
  0%{opacity:0;transform:translate(-50%,-50%) translateY(var(--join-shift)) translateX(70%) rotate(8deg) scale(1.03);z-index:6}
  13%{opacity:1;transform:translate(-50%,-50%) translateY(var(--join-shift)) rotate(0deg) scale(1);z-index:6}
  55%{opacity:1;transform:translate(-50%,-50%) translateY(var(--join-shift)) rotate(0deg) scale(1);z-index:6}
  78%{opacity:1;transform:translate(-50%,-50%) translateY(var(--join-shift)) translateX(-58%) rotate(-8deg) scale(.98);z-index:6}
  79%{z-index:1}
  100%{opacity:1;transform:translate(-50%,-50%) translateY(calc(var(--join-shift) + .5%)) translateX(-4%) rotate(-2deg) scale(.97);z-index:1}
}

/* === SCENA LOSOWANIA (w widgecie pytania) === */
/* Na czas losowania karta pytania ZNIKA całkowicie — na ekranie zostaje
   tylko tasowanie, a po nim karta z wylosowaną osobą (odsłaniana flipem). */
.stage.is-drawing .question-card{display:none}
/* Pusta kolejka = na widgecie PYTANIE nie ma nic. Zaproszenie "PYTANIE DO KART / LINK W BIO"
   przejechało do rankingu (patrz .promo-lane), więc karta nie ma tu czego pokazywać. */
.is-empty .question-card{display:none}
/* Karton Dnia ORAZ zwykłe pytanie pokazuje teraz WYŁĄCZNIE widget losowania — wyjeżdżają
   tam jako karty z talii (.karton-today i .karton-question). Tutaj chowamy jedno i drugie.
   Wykluczamy warianty -collecting i -winner: one też noszą klasę is-karton, a scenę zbierania
   i ogłoszenie zwycięzcy nadal rysuje widget PYTANIE i muszą zostać widoczne. */
.is-karton:not(.is-karton-collecting):not(.is-karton-winner) .question-card{display:none}
.is-question .question-card,
.is-waiting .question-card{display:none}
.draw-overlay{position:absolute;inset:0;z-index:20;display:none;align-items:flex-start;justify-content:center;pointer-events:none}
.draw-overlay.is-on{display:flex}
/* Górny odstęp musi pomieścić NAROŻNIKI obracających się kart — przy obrocie o 14° karta
   130x228 wystaje ponad swój prostokąt o ~17 px. Bez tego scena (.stage ma overflow:hidden)
   ucinała talii czubek przy każdym machnięciu. */
.draw-inner{display:flex;flex-direction:column;align-items:center;gap:clamp(6px,1.4vh,12px);
  padding-top:clamp(16px,2.4vh,30px)}

/* talia tasujących się kart — o 20% większa niż wcześniej */
.draw-deck{position:relative;width:clamp(108px,19.2vh,156px);height:clamp(156px,27.6vh,228px);
  perspective:1100px}
/* Poświata pod talią — daje głębię i "dzianie się", zamiast płaskich kart na czarnym tle. */
.draw-deck:before{content:'';position:absolute;left:50%;top:50%;width:190%;height:150%;
  transform:translate(-50%,-50%);border-radius:50%;pointer-events:none;
  background:radial-gradient(circle,rgba(255,138,32,.20),transparent 62%);opacity:0}
.draw-deck.is-shuffling:before{animation:deckGlow 1.5s ease-in-out infinite}
@keyframes deckGlow{0%,100%{opacity:.45}50%{opacity:.95}}
/* Rewers karty: gęsty splot w tle, podwójna złota ramka, tarcza z księżycem i podpis.
   Wszystko w jednostkach względnych, więc wzór trzyma proporcje przy każdym rozmiarze źródła. */
.draw-deck .dcard{position:absolute;inset:0;border-radius:clamp(8px,1.6vh,14px);
  border:2px solid rgba(255,203,85,.62);overflow:hidden;color:var(--gold);
  display:flex;flex-direction:column;align-items:center;justify-content:center;gap:clamp(3px,.8vh,7px);
  background:
    radial-gradient(circle at 50% 40%,rgba(255,138,32,.22),transparent 64%),
    repeating-linear-gradient(45deg,rgba(58,20,6,.98),rgba(58,20,6,.98) 3px,rgba(22,9,3,.98) 3px,rgba(22,9,3,.98) 6px);
  box-shadow:0 8px 22px rgba(0,0,0,.45),inset 0 0 20px rgba(0,0,0,.55);will-change:transform}
.dcard-frame{position:absolute;inset:clamp(4px,.9vh,7px);pointer-events:none;
  border:1px solid rgba(255,203,85,.45);border-radius:clamp(5px,1vh,9px)}
.dcard-corner{position:absolute;line-height:1;font-size:clamp(5px,.95vh,8px);color:rgba(255,203,85,.62)}
.dcard-corner.tl{left:clamp(6px,1.3vh,10px);top:clamp(5px,1vh,8px)}
.dcard-corner.br{right:clamp(6px,1.3vh,10px);bottom:clamp(5px,1vh,8px)}
.dcard-ring{position:relative;width:52%;aspect-ratio:1;display:grid;place-items:center;
  filter:drop-shadow(0 0 6px rgba(255,138,32,.35))}
.dcard-ring svg{position:absolute;inset:0;width:100%;height:100%}
.dcard-moon{position:relative;line-height:1;font-size:clamp(11px,2.4vh,20px);
  color:var(--gold);text-shadow:0 0 8px rgba(255,138,32,.55)}
.dcard-name{position:relative;font-size:clamp(6px,1.15vh,10px);letter-spacing:.13em;
  text-transform:uppercase;font-weight:900;color:rgba(255,214,111,.94);
  text-shadow:0 0 6px rgba(255,138,32,.45);white-space:nowrap}
/* Riffle: karty rozchodzą się na boki i wracają. Każda startuje później, więc talia
   faluje zamiast machać wszystkim naraz. */
.draw-deck.is-shuffling .dcard:nth-child(1){animation:shuf 1.5s cubic-bezier(.36,.06,.28,1) infinite}
.draw-deck.is-shuffling .dcard:nth-child(2){animation:shuf 1.5s cubic-bezier(.36,.06,.28,1) infinite .1s}
.draw-deck.is-shuffling .dcard:nth-child(3){animation:shuf 1.5s cubic-bezier(.36,.06,.28,1) infinite .2s}
.draw-deck.is-shuffling .dcard:nth-child(4){animation:shuf 1.5s cubic-bezier(.36,.06,.28,1) infinite .3s}
.draw-deck.is-shuffling .dcard:nth-child(5){animation:shuf 1.5s cubic-bezier(.36,.06,.28,1) infinite .4s}
/* translateY nigdy nie schodzi poniżej 0 — karty rozchodzą się w bok i W DÓŁ, nigdy w górę,
   więc nie mają jak wyjechać poza kadr. Skala i rotacja Y dają wrażenie grubości talii. */
@keyframes shuf{
  0%  {transform:translate(0,0) rotate(0deg) rotateY(0deg) scale(1)}
  16% {transform:translate(-56%,7%) rotate(-13deg) rotateY(16deg) scale(.965)}
  34% {transform:translate(50%,11%) rotate(11deg) rotateY(-14deg) scale(.975)}
  52% {transform:translate(-32%,6%) rotate(-7deg) rotateY(9deg) scale(.99)}
  70% {transform:translate(20%,3%) rotate(4deg) rotateY(-5deg) scale(1)}
  85% {transform:translate(-7%,1%) rotate(-1.5deg) rotateY(2deg) scale(1)}
  100%{transform:translate(0,0) rotate(0deg) rotateY(0deg) scale(1)}
}

/* karta z wylosowaną osobą — wchodzi flipem jak odwracana karta tarota.
   display:none, a nie samo opacity:0 — inaczej niewidoczna karta nadal zajmowała miejsce
   w kolumnie i rozpychała scenę, zostawiając pustą dziurę pod talią. */
.draw-result{display:none;opacity:0;transform:scale(.86);pointer-events:none}
.draw-result.is-on{display:block}
.draw-result.is-on{opacity:1;transform:scale(1);animation:flipIn .65s cubic-bezier(.2,.8,.2,1)}
@keyframes flipIn{
  0%{opacity:0;transform:perspective(900px) rotateY(88deg) scale(.9)}
  60%{opacity:1;transform:perspective(900px) rotateY(-8deg) scale(1.03)}
  100%{opacity:1;transform:perspective(900px) rotateY(0deg) scale(1)}
}
/* Szersza niż wcześniej (330px), bo dłuższe nicki łamały się w środku słowa — "NATALIA_VIB / ES". */
.draw-card{position:relative;width:clamp(250px,58vh,440px);padding:clamp(12px,3vh,22px) clamp(14px,3.4vw,26px);
  border-radius:clamp(10px,2vh,18px);border:2px solid rgba(255,203,85,.65);
  background:radial-gradient(circle at 50% 0%,rgba(255,138,32,.16),transparent 55%),linear-gradient(160deg,rgba(28,11,4,.97),rgba(6,4,3,.95));
  box-shadow:0 14px 40px rgba(0,0,0,.55),0 0 30px rgba(255,138,32,.25);
  text-align:center;display:flex;flex-direction:column;gap:clamp(4px,1.2vh,10px)}
.draw-card:after{content:'';position:absolute;inset:0;border-radius:inherit;pointer-events:none;
  box-shadow:0 0 46px rgba(255,138,32,.45);opacity:0;animation:drawPulse 1.6s ease-in-out infinite}
@keyframes drawPulse{0%,100%{opacity:0}50%{opacity:1}}
.draw-corner{position:absolute;color:rgba(255,203,85,.6);font-size:clamp(10px,1.8vh,15px);text-shadow:0 0 8px rgba(255,138,32,.4)}
.draw-corner.tl{left:8px;top:6px}
.draw-corner.br{right:8px;bottom:6px}
.draw-eyebrow{font-size:clamp(9px,1.7vh,13px);letter-spacing:.2em;color:var(--gold);font-weight:900;text-transform:uppercase}
/* Zawsze JEDNA linia — rozmiar dobiera fitOneLine() przy każdym losowaniu, tak samo jak
   nick na widgecie pytania. Bez tego długie nicki łamały się w środku słowa. */
.draw-nick{font-size:clamp(20px,4.6vh,40px);font-weight:950;color:#fff;text-transform:uppercase;line-height:1.05;
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;
  text-shadow:0 0 18px rgba(255,203,85,.35)}
.draw-call{font-size:clamp(11px,2.1vh,17px);color:var(--cream);opacity:.95}
.draw-call b{color:#2ecc71;font-weight:950;letter-spacing:.06em}
.draw-timer{font-size:clamp(22px,5vh,44px);font-weight:950;color:#ffd66f;line-height:1;text-shadow:0 0 16px rgba(255,138,32,.5)}
.draw-caption{font-size:clamp(10px,1.9vh,15px);letter-spacing:.18em;color:var(--gold);font-weight:900;text-transform:uppercase;
  text-shadow:0 0 10px rgba(255,138,32,.3)}

/* === WIDGET ZBIORCZY (wszystko na jednym płótnie) === */
.combo-stage{position:absolute;left:0;top:0;width:1080px;height:1920px;transform-origin:0 0;overflow:hidden;background:transparent}
.combo-part{position:absolute;border:0;background:transparent;pointer-events:none;width:1080px;height:1920px;transform-origin:0 0}

/* === TRYB OSZCZĘDNY WIDGETÓW ===
   Każdy widget w OBS/TikTok Studio to osobna przeglądarka. Animacje działające
   bez przerwy zmuszają ją do rysowania non-stop, nawet gdy nic się nie dzieje.
   Najdroższe są animacje cieni (wymuszają przerysowanie), dlatego w tym trybie
   gasną w pierwszej kolejności. Zostają zmiany stanu — krótkie i rzadkie,
   więc nic nie kosztują, a bez nich widget wyglądałby martwo. */
body.lite .spark,
body.lite .flame-sweep,
body.lite .rune-burst,
body.lite .queue-spark { display: none !important; }
body.lite .oracle-ring,
body.lite .tap-rank-total,
body.lite .karton-draw-gift,
body.lite .karton-today-sigil svg,
body.lite .ticker-note-top1,
body.lite .qitem.current .qnum { animation: none !important; }
body.lite .karton-draw-card.is-collecting { animation: none !important; }
body.lite .web-label { backdrop-filter: none !important; }
body.lite .karton-draw-gift { filter: none !important; }
body.lite .tap-rank-total { filter: none !important; }
body.lite .queue:before { display: none !important; }

.demo-grid{height:100vh;padding:14px;display:grid;grid-template-columns:1fr 350px;grid-template-rows:1fr 120px 190px;gap:12px;background:radial-gradient(circle at 70% 0%,rgba(255,122,24,.14),transparent 32%),#050303}.demo-box{border:1px solid rgba(255,203,85,.20);border-radius:20px;background:rgba(0,0,0,.30);overflow:hidden}.demo-box iframe{width:100%;height:100%;border:0;background:transparent}.demo-activity{grid-column:1/3}

/* === KVRINA_SHOW 1.0.36 — nowy jedyny widget RANKING TAPÓW === */
.tap-rank-widget{position:relative;width:100vw;height:100vh;overflow:hidden;background:transparent;pointer-events:none;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.tap-rank-shell{position:absolute;left:clamp(16px,5vw,54px);right:clamp(16px,5vw,54px);bottom:clamp(28px,4.2vh,72px);height:clamp(74px,7.3vh,132px);display:grid;grid-template-columns:clamp(150px,16vw,220px) minmax(0,1fr) clamp(58px,7vw,98px);align-items:center;border-radius:999px;overflow:hidden;background:radial-gradient(circle at 10% 20%,rgba(255,203,85,.20),transparent 34%),radial-gradient(circle at 92% 50%,rgba(228,67,34,.13),transparent 35%),linear-gradient(135deg,rgba(8,5,3,.86),rgba(22,9,5,.70),rgba(3,2,5,.84));border:1px solid rgba(255,203,85,.30);box-shadow:0 18px 48px rgba(0,0,0,.38),0 0 30px rgba(255,122,24,.12),inset 0 1px 0 rgba(255,255,255,.10);isolation:isolate}
.tap-rank-shell:before{content:'';position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(255,203,85,.30),transparent 15%,transparent 86%,rgba(228,67,34,.18)),linear-gradient(180deg,rgba(255,255,255,.09),transparent 52%,rgba(0,0,0,.18));pointer-events:none;opacity:.65}.tap-rank-shell:after{content:'';position:absolute;left:0;top:0;bottom:0;width:7px;z-index:5;background:linear-gradient(180deg,#fff7df,var(--gold),var(--amber),var(--red));box-shadow:0 0 16px rgba(255,203,85,.58),0 0 28px rgba(255,122,24,.28)}
.tap-rank-label{position:relative;z-index:6;height:100%;display:flex;flex-direction:column;justify-content:center;padding:0 14px 0 22px;border-right:1px solid rgba(255,203,85,.18);text-shadow:0 0 10px rgba(255,138,32,.25)}.tap-rank-label span{font-size:clamp(10px,1.1vw,15px);line-height:1;color:rgba(255,203,85,.72);letter-spacing:.18em;font-weight:900}.tap-rank-label strong{margin-top:5px;font-size:clamp(21px,2.5vw,38px);line-height:.9;color:var(--cream);letter-spacing:.035em;font-weight:950;white-space:nowrap}.tap-rank-total{position:relative;z-index:6;height:100%;display:grid;place-items:center;border-left:1px solid rgba(255,203,85,.18);color:#ffdf7d;font-size:clamp(24px,3vw,44px);text-shadow:0 0 18px rgba(255,203,85,.42);animation:tapHeartPulse 1.35s ease-in-out infinite}.tap-rank-window{position:relative;z-index:6;height:100%;min-width:0;overflow:hidden;mask-image:linear-gradient(90deg,transparent 0,#000 5%,#000 95%,transparent 100%)}.tap-rank-track{position:absolute;left:0;top:0;height:100%;will-change:transform;transform:translateX(0)}.tap-rank-track.tap-scroll{animation:tapRankScroll var(--tap-duration,118s) linear forwards}.tap-rank-track.live-track{transform:none!important;will-change:auto;animation:none!important}.tap-rank-live-slot{position:absolute;inset:0;overflow:hidden;z-index:2;background:transparent}.tap-rank-live-slot iframe{position:absolute;left:50%;bottom:0;width:min(1320px,240vw);height:min(640px,280vh);max-width:none;transform:translateX(-50%);border:0;background:transparent;pointer-events:none}.tap-rank-track.demo-track{display:none;align-items:center;gap:18px;white-space:nowrap;padding:0 10px}.tap-chip{height:clamp(42px,4.8vh,74px);min-width:clamp(230px,24vw,360px);display:inline-flex;align-items:center;gap:10px;padding:0 18px 0 10px;border-radius:999px;background:radial-gradient(circle at 14% 22%,rgba(255,203,85,.16),transparent 48%),linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.026));border:1px solid rgba(255,203,85,.22);box-shadow:inset 0 1px 0 rgba(255,255,255,.10),0 6px 18px rgba(0,0,0,.22)}.tap-chip.top{border-color:rgba(255,203,85,.48);box-shadow:0 0 18px rgba(255,203,85,.16),inset 0 1px 0 rgba(255,255,255,.14)}.tap-place{width:clamp(25px,2.8vw,38px);height:clamp(25px,2.8vw,38px);border-radius:50%;display:grid;place-items:center;background:linear-gradient(180deg,#fff7df,var(--gold));color:#160b05;font-weight:950;font-size:clamp(12px,1.25vw,18px)}.tap-heart{color:#ffdf7d;font-size:clamp(18px,2vw,30px);text-shadow:0 0 12px rgba(255,203,85,.38)}.tap-chip strong{max-width:clamp(118px,14vw,220px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:clamp(15px,1.7vw,26px);font-weight:950;color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.82)}.tap-likes{margin-left:auto;color:#ffdf7d;font-size:clamp(16px,1.8vw,28px);font-weight:950;text-shadow:0 0 12px rgba(255,203,85,.25)}
@keyframes tapRankScroll{from{transform:translateX(var(--tap-from-x,100vw))}to{transform:translateX(var(--tap-to-x,-3680px))}}@keyframes tapHeartPulse{0%,100%{transform:scale(1)}50%{transform:scale(1.14)}}

/* === KVRINA_SHOW — KARTON DNIA (losowanie, karta w kształcie karty tarota) === */
.karton-draw-stage{width:100vw;height:100vh;display:flex;align-items:center;justify-content:center;padding:10px;overflow:hidden;background:transparent}
.karton-draw-card{
  width:auto;height:min(90vh,640px);aspect-ratio:0.62;max-height:none;min-height:0;
  padding:clamp(8px,1.6vh,16px);border-radius:clamp(14px,3vh,26px);border-width:2px;
  display:flex;flex-direction:column;align-items:stretch;justify-content:stretch;text-align:center;gap:0;
}
.karton-draw-frame{
  position:relative;flex:1;width:100%;min-height:0;
  border:1px solid rgba(255,203,85,.40);border-radius:clamp(8px,2vh,16px);
  padding:clamp(10px,3vh,22px) clamp(8px,3vw,16px);
  display:flex;flex-direction:column;align-items:center;justify-content:space-between;
  box-shadow:inset 0 0 0 1px rgba(255,203,85,.12),inset 0 0 30px rgba(255,138,32,.06);
  overflow:hidden;
}
.karton-draw-corner{position:absolute;z-index:4;font-size:clamp(11px,2.2vh,17px);color:rgba(255,203,85,.55);text-shadow:0 0 8px rgba(255,138,32,.42);line-height:1}
.karton-draw-corner.tl{left:7px;top:6px}
.karton-draw-corner.tr{right:7px;top:6px}
.karton-draw-corner.bl{left:7px;bottom:6px}
.karton-draw-corner.br{right:7px;bottom:6px}
.karton-draw-eyebrow{position:relative;z-index:4;font-size:clamp(11px,2.1vh,17px);letter-spacing:.22em;text-transform:uppercase;color:var(--gold);font-weight:900;text-shadow:0 0 10px rgba(255,138,32,.30)}
.karton-draw-medallion{
  position:relative;z-index:4;width:clamp(64px,20vh,132px);height:clamp(64px,20vh,132px);border-radius:50%;
  margin:clamp(4px,1.4vh,10px) 0;display:flex;align-items:center;justify-content:center;
  border:2px solid rgba(255,203,85,.42);box-shadow:0 0 20px rgba(255,138,32,.18),inset 0 0 16px rgba(255,203,85,.07);
}
.karton-draw-medallion:before,.karton-draw-medallion:after{content:'✦';position:absolute;color:rgba(255,203,85,.55);font-size:clamp(9px,1.6vh,13px);text-shadow:0 0 8px rgba(255,203,85,.4)}
.karton-draw-medallion:before{left:clamp(-16px,-4vh,-11px)}
.karton-draw-medallion:after{right:clamp(-16px,-4vh,-11px)}
.karton-draw-gift{position:relative;z-index:4;width:clamp(46px,13vh,86px);height:auto;line-height:0;filter:drop-shadow(0 0 16px rgba(255,77,109,.45));animation:giftBreathe 3.6s ease-in-out infinite}
.karton-draw-gift svg{width:100%;height:auto;display:block;overflow:visible}
@keyframes giftBreathe{0%,100%{transform:scale(1)}50%{transform:scale(1.06)}}
/* Mała ikonka serduszka przed tekstem "wyślij serduszko" pod paskiem postępu. */
.kd-mini-heart{display:inline-block;width:1.7em;height:1.7em;vertical-align:-.52em;margin-right:.42em;line-height:0}
.kd-mini-heart svg{width:100%;height:100%;display:block;overflow:visible}
.karton-draw-title{position:relative;z-index:4;font-size:clamp(16px,3.2vh,28px);font-weight:950;letter-spacing:.05em;color:#ffd66f;text-shadow:0 0 12px rgba(255,138,32,.30)}
.karton-draw-nick{position:relative;z-index:4;font-size:clamp(18px,4vh,34px);font-weight:950;text-transform:uppercase;line-height:1.08;word-break:break-word;max-width:100%;margin-top:clamp(2px,1vh,8px);white-space:normal;overflow:visible;text-overflow:clip}
.karton-progress{position:relative;z-index:4;width:100%;margin-top:clamp(4px,1.4vh,12px);display:flex;flex-direction:column;gap:clamp(4px,1.2vh,8px)}
.karton-progress-track{width:100%;height:clamp(7px,1.6vh,12px);border-radius:999px;background:rgba(255,203,85,.10);border:1px solid rgba(255,203,85,.24);overflow:hidden;box-shadow:inset 0 0 8px rgba(0,0,0,.35)}
.karton-progress-fill{display:block;height:100%;width:0%;border-radius:999px;background:linear-gradient(90deg,var(--gold),var(--amber),var(--red));box-shadow:0 0 12px rgba(255,138,32,.5);transition:width .5s ease}
.karton-progress-label{font-size:clamp(10px,2vh,14px);letter-spacing:.06em;color:var(--muted);font-weight:800;text-transform:uppercase}
@keyframes kartonCollectPulse{0%,100%{box-shadow:0 0 22px rgba(255,60,60,.22),inset 0 0 16px rgba(255,203,85,.05)}50%{box-shadow:0 0 42px rgba(255,60,60,.42),inset 0 0 24px rgba(255,203,85,.09)}}
.is-karton-collecting .card{border-color:rgba(255,60,60,.62);box-shadow:0 0 34px rgba(255,60,60,.28),inset 0 0 18px rgba(255,203,85,.05);animation:kartonCollectPulse 1s ease-in-out infinite}
.is-karton-collecting .eyebrow{color:#ff6a4d}
.is-karton-collecting .nick,.is-karton-collecting .text{color:#fff}
.is-karton-winner .card{border-color:rgba(255,255,255,.4);box-shadow:0 0 30px rgba(255,255,255,.22),inset 0 0 18px rgba(255,203,85,.05)}
.is-karton-winner .eyebrow{color:#ffd66f}
.is-karton-winner .nick,.is-karton-winner .text{color:#fff}

`;


function widgetHtml(kind) {
  let body = "";
  let script = WIDGET_SHARED_SCRIPT;
  if (kind === "question") {
    body = `<div id="root" class="stage"></div>`;
    script += `
let lastSignature='';
function questionShell(){
 const root=document.getElementById('root');
 if(root.dataset.ready==='1') return;
 root.dataset.ready='1';
 root.innerHTML='<div class="card question-card" id="qcard"><i class="spark" style="left:12%;bottom:18%;animation-delay:.1s"></i><i class="spark" style="left:86%;bottom:28%;animation-delay:1.1s"></i><i class="spark" style="left:72%;bottom:12%;animation-delay:2s"></i><span class="question-card-corner tl">✦</span><span class="question-card-corner br">✦</span><div class="oracle-ring"></div><div class="moon-mark">☽</div><div class="flame-sweep"></div><div class="rune-burst"><span>✦</span><span>✧</span><span>✺</span><span>✦</span><span>☽</span></div><div class="question-head"><div class="eyebrow" id="qeyebrow"></div><div class="nick" id="qnick"></div></div><div class="question-body" id="qbody"><div class="text" id="qtext"></div></div></div>';
}
function fitOneLine(el, max, min){
 if(!el) return;
 let size=max;
 el.style.fontSize=size+'px';
 while(size>min && el.scrollWidth>el.clientWidth){
   size-=1;
   el.style.fontSize=size+'px';
 }
}
function fitQuestionText(){
 const text=document.getElementById('qtext');
 const body=document.getElementById('qbody');
 const nick=document.getElementById('qnick');
 if(!text||!body) return;
 fitOneLine(nick,48,24);
 const raw=(text.textContent||'').trim();
 const len=raw.length;
 // Ważne: nie mierzymy scrollWidth, bo przy długim ciągu bez spacji
 // przeglądarka potrafi raportować szerokość naturalną i bez sensu zaniżać font.
 // Priorytet: łamanie tekstu + maksymalne wypełnienie dostępnej wysokości.
 const maxH=Math.max(30, body.clientHeight-1);
 const area=Math.max(1, body.clientWidth*maxH);
 let maxSize=42;
 if(len>35) maxSize=37;
 if(len>70) maxSize=33;
 if(len>120) maxSize=29;
 if(len>190) maxSize=25;
 if(len>300) maxSize=21;
 // Przy bardzo niskim źródle OBS nie pompujemy fontu bez limitu,
 // ale nadal trzymamy go dużo większego niż wcześniej.
 maxSize=Math.min(maxSize, Math.max(20, Math.sqrt(area/12)));
 const minSize=16;
 let lo=minSize, hi=maxSize, best=minSize;
 text.style.lineHeight='1.06';
 text.style.whiteSpace='normal';
 // break-word łamie tylko gdy pojedyncze słowo nie mieści się w linii —
 // "anywhere" potrafiło rozcinać słowa w dowolnym miejscu i wyglądało krzywo.
 text.style.wordBreak='normal';
 text.style.overflowWrap='break-word';
 for(let i=0;i<18;i++){
   const mid=(lo+hi)/2;
   text.style.fontSize=mid+'px';
   if(text.scrollHeight<=maxH+1){
     best=mid;
     lo=mid+0.5;
   }else{
     hi=mid-0.5;
   }
 }
 if(best<24) text.style.lineHeight='1.00';
 else if(best<38) text.style.lineHeight='.98';
 else text.style.lineHeight='.94';
 text.style.fontSize=Math.floor(best)+'px';
}
function triggerMysticChange(){
 const card=document.getElementById('qcard');
 if(!card) return;
 card.classList.remove('state-change');
 void card.offsetWidth;
 card.classList.add('state-change');
 clearTimeout(card._changeTimer);
 card._changeTimer=setTimeout(()=>card.classList.remove('state-change'),920);
}
// Na czas losowania Kartona Dnia ten widget zamienia się w scenę losowania:
// tasowanie kart, a potem karta z wylosowaną osobą czekającą na "tak".
// Rewers karty — jeden wzór powielany na całą talię. Świadomie BEZ atrybutów id w SVG:
// kart jest pięć, a powtórzone id psułyby gradienty i maski.
const REWERS_KARTY='<i class="dcard"><span class="dcard-frame"></span><span class="dcard-corner tl">✦</span><span class="dcard-corner br">✦</span><span class="dcard-ring"><svg viewBox="0 0 64 64" xmlns="http://www.w3.org/2000/svg"><circle cx="32" cy="32" r="29" fill="none" stroke="currentColor" stroke-width="4" stroke-dasharray="1.6 13.6" opacity=".85"/><circle cx="32" cy="32" r="23" fill="none" stroke="currentColor" stroke-width="1.4" opacity=".6"/></svg><span class="dcard-moon">☽</span></span><b class="dcard-name">Karina.Zone</b></i>';
function ensureDrawShell(){
 const root=document.getElementById('root');
 if(root.dataset.draw==='1') return;
 root.dataset.draw='1';
 const d=document.createElement('div');
 d.className='draw-overlay';
 d.id='drawOverlay';
 d.innerHTML='<div class="draw-inner">'
  +'<div class="draw-deck" id="drawDeck">'+Array(5).fill(REWERS_KARTY).join('')+'</div>'
  +'<div class="draw-result" id="drawResult">'
  +'<div class="draw-card"><span class="draw-corner tl">✦</span><span class="draw-corner br">✦</span>'
  +'<div class="draw-eyebrow" id="drawEyebrow">KARTON DNIA DLA</div>'
  +'<div class="draw-nick" id="drawNick">—</div>'
  +'<div class="draw-call" id="drawCall">KARTON DNIA JEST TWÓJ</div>'
  +'<div class="draw-timer" id="drawTimer">20</div></div></div>'
  +'<div class="draw-caption" id="drawCaption">MANIFESTUJ NA CZACIE</div>'
  +'</div>';
 root.appendChild(d);
}
function renderKartonDraw(k){
 ensureDrawShell();
 const ov=document.getElementById('drawOverlay');
 const deck=document.getElementById('drawDeck');
 const res=document.getElementById('drawResult');
 const cap=document.getElementById('drawCaption');
 const phase=k.phase;
 ov.classList.add('is-on');
 if(phase==='shuffling'){
   deck.classList.add('is-shuffling');
   deck.style.display='';
   res.classList.remove('is-on');
   cap.style.display='';
   // Odliczanie w napisie — widz ma wiedzieć, ile zostało na odezwanie się.
   const left=Math.max(0, Math.ceil(Number(k.secondsLeft)||0));
   cap.textContent='MANIFESTUJ NA CZACIE'+(left?'  '+left+' s':'');
 } else {
   deck.classList.remove('is-shuffling');
   deck.style.display='none';
   res.classList.add('is-on');
   const nickEl=document.getElementById('drawNick');
   nickEl.textContent=k.pendingNick||'—';
   // Dopasowanie po wstawieniu tekstu — karta jest już widoczna, więc da się zmierzyć szerokość.
   requestAnimationFrame(()=>fitOneLine(nickEl,40,18));
   // Nie ma już potwierdzania — karta ogłasza zwycięzcę, nie prosi go o nic.
   document.getElementById('drawCall').textContent='KARTON DNIA JEST TWÓJ';
   document.getElementById('drawTimer').style.display='none';
   cap.style.display='none';
 }
}
function hideKartonDraw(){
 const ov=document.getElementById('drawOverlay');
 if(ov) ov.classList.remove('is-on');
}
function render(s){
 questionShell();
 const k=(s && s.kartonCharge) || {};
 const drawing = k.phase==='shuffling' || k.phase==='winner';
 if(drawing){ renderKartonDraw(k); } else { hideKartonDraw(); }

 const c=s.current||{};
 const type=c.type||'empty';
 const text=c.text||'LINK W BIO';
 const nick=c.nick||'PYTANIE DO KART';
 const root=document.getElementById('root');
 root.className='stage '+typeClass(type)+(drawing?' is-drawing':'');
 document.getElementById('qeyebrow').textContent=typeLabel(type);
 document.getElementById('qnick').textContent=nick;
 document.getElementById('qtext').textContent=text;
 const sig=[type,nick,text].join('|');
 if(sig!==lastSignature){ lastSignature=sig; if(!drawing) triggerMysticChange(); }
 // Gdy karta pytania jest schowana, pomiar tekstu nie ma czego mierzyć.
 if(!drawing) requestAnimationFrame(()=>{ fitQuestionText(); requestAnimationFrame(fitQuestionText); });
}
async function loop(){
 const s=await getState(); render(s);
 const k=(s&&s.kartonCharge)||{};
 const fast = k.phase==='shuffling'||k.phase==='winner';
 setTimeout(loop, fast?400:1000);
}
loop(); window.addEventListener('resize',()=>requestAnimationFrame(fitQuestionText));
`;
  } else if (kind === "queue") {
    body = `<div class="queue-stage"><div id="root" class="queue"></div></div>`;
    script += `
let lastQueueSignature='';
function itemHtml(it, label, cls){
 const t=it.type||'question';
 const classes=['qitem']; if(cls) classes.push(cls); if(t==='karton') classes.push('karton'); if(t==='waiting') classes.push('waiting');
 const meta=(cls==='current'?'TERAZ • ':'')+typeLabel(t);
 return '<div class="'+classes.join(' ')+'"><div class="qnum">'+esc(label)+'</div><div><div class="qnick">'+esc(it.nick||'-')+'</div><div class="qmeta">'+esc(meta)+'</div></div></div>';
}
function triggerQueueChange(){
 const root=document.getElementById('root'); if(!root) return;
 root.classList.remove('queue-change'); void root.offsetWidth; root.classList.add('queue-change');
 clearTimeout(root._qTimer); root._qTimer=setTimeout(()=>root.classList.remove('queue-change'),900);
}
function render(s){
 const current=s.current&&s.current.type!=='empty'?s.current:null;
 const q=(s.queue||[]);
 const sig=JSON.stringify({current:current?{nick:current.nick,text:current.text,type:current.type}:null,queue:q.map(it=>({nick:it.nick,text:it.text,type:it.type}))});
 if(sig===lastQueueSignature) return;
 lastQueueSignature=sig;
 // Pusto = na ekranie nie ma NIC. Wcześniej wisiał tu kafelek "Dołącz / Pytanie do kart •
 // link w bio" — to zaproszenie przejechało do rankingu (.promo-lane), więc chowamy
 // całą ramkę razem z nagłówkiem, a nie tylko sam kafelek.
 // Samo wyczyszczenie zawartości NIE wystarczy: .queue ma własne tło, obrys i padding,
 // więc puste pudełko zostawało na ekranie jako cienki pasek. Chowamy cały element.
 const root=document.getElementById('root');
 if(!current && !q.length){ root.innerHTML=''; root.style.display='none'; return; }
 root.style.display='';
 let html='<i class="queue-spark s1"></i><i class="queue-spark s2"></i><i class="queue-spark s3"></i><div class="queue-title">Kolejka</div>';
 if(current){ html+=itemHtml(current,'★','current'); }
 q.forEach((it,i)=>{html+=itemHtml(it,String(i+1),'');});
 root.innerHTML=html;
 triggerQueueChange();
}
async function loop(){render(await getState())} loop(); setInterval(loop, 1200);
`;
  } else if (kind === "ranking" || kind === "ranking-local") {
    body = `<div class="ticker-wrap"><div class="ticker-note">Ranking widzów ♥</div><div id="root"></div><div class="promo-lane" id="promoLane"><div class="promo-tile" id="promoTile"><span class="heart">♥</span><strong>PYTANIE DO KART</strong><span class="unit">link w bio</span></div><div class="promo-tile promo-follow" id="promoTile2"><span class="heart">✦</span><strong>ZAOBSERWUJ I NAPISZ „KARTON DNIA" NA CZACIE</strong><span class="unit">darmowa karta</span></div></div></div>`;
    script += `
// Płynny, nieprzerywany ticker. KLUCZOWA POPRAWKA: nowe dane rankingu (a zmieniają
// się co komentarz/tap podczas live'a) NIE resetują już przewijania — podmieniamy je
// dopiero przy zawinięciu cyklu. Wcześniej każda zmiana punktów restartowała animację,
// więc pasek wiecznie "skakał" do prawej krawędzi i nigdy nie przejeżdżał.
let lastRankingSignature='';
let pendingRankingHtml=null;   // HTML czekający na podmianę przy najbliższym zawinięciu
let pendingRankingEmpty=false;
let tickerRunning=false;
let currentTickerEmpty=true;   // czy AKTUALNIE wyświetlany jest placeholder "czekam"
const TICKER_SPEED_PX_PER_SEC=28;
const TICKER_MIN_DURATION_MS=58000;
const TICKER_MAX_DURATION_MS=210000;
let tickerScrollTimer=null;
function itemsToHtml(items){
 return '<div id="ticker" class="ticker">'+items.map((it,i)=>{ const likes=Number(it.likes ?? it.points ?? 0)||0; const empty=it.empty?' ticker-empty':''; return '<div class="tick'+empty+'"><span class="place">#'+(i+1)+'</span><span class="heart">♥</span><strong>'+esc(it.nick||'-')+'</strong><span class="points">'+esc(likes)+'</span><span class="unit">pkt</span></div>'; }).join('')+'</div>';
}
function buildRankingTicker(s){
 const r=(s.ranking||[]).filter(Boolean);
 const isEmpty=!r.length;
 const items=r.length?r:[{nick:'Czekam na widzów',likes:0,points:0,empty:true}];
 const sig=JSON.stringify(items.map(it=>({nick:it.nick||'',likes:Number(it.likes ?? it.points ?? 0)||0,empty:!!it.empty})));
 if(sig===lastRankingSignature){
   if(!tickerRunning) startTicker();
   return;
 }
 lastRankingSignature=sig;
 const html=itemsToHtml(items);
 // Podmieniamy natychmiast gdy: nic nie jedzie, wisi placeholder, ALBO ranking właśnie
 // stał się pusty (ZERUJ SESJĘ — widget ma się wyczyścić od razu, nie po ~58s cyklu).
 // W innym wypadku (realne→realne) pauzujemy podmianę do zawinięcia — płynny przejazd.
 if(!tickerRunning || currentTickerEmpty || isEmpty){
   document.getElementById('root').innerHTML=html;
   currentTickerEmpty=isEmpty;
   pendingRankingHtml=null;
   startTicker();
 } else {
   pendingRankingHtml=html;
   pendingRankingEmpty=isEmpty;
 }
}
function startTicker(){
 const ticker=document.getElementById('ticker');
 if(!ticker){ tickerRunning=false; return; }
 if(tickerScrollTimer) clearTimeout(tickerScrollTimer);
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const trackW=Math.max(1, ticker.scrollWidth || ticker.getBoundingClientRect().width || 1);
 const fromX=winW + 48;
 const toX=-(trackW + 48);
 const distance=fromX - toX;
 const durationMs=Math.max(TICKER_MIN_DURATION_MS, Math.min(TICKER_MAX_DURATION_MS, Math.round((distance / TICKER_SPEED_PX_PER_SEC) * 1000)));
 tickerRunning=true;
 ticker.classList.remove('is-scrolling');
 ticker.style.setProperty('--from-x', fromX + 'px');
 ticker.style.setProperty('--to-x', toX + 'px');
 ticker.style.setProperty('--ticker-duration', durationMs + 'ms');
 ticker.style.transform='translateX('+fromX+'px)';
 void ticker.offsetWidth;
 ticker.classList.add('is-scrolling');
 tickerScrollTimer=setTimeout(()=>{
   // Zawinięcie: tu — i tylko tu — wpuszczamy świeże dane, potem restart.
   tickerRunning=false;
   if(pendingRankingHtml!==null){
     document.getElementById('root').innerHTML=pendingRankingHtml;
     currentTickerEmpty=pendingRankingEmpty;
     pendingRankingHtml=null;
   }
   startTicker();
 }, durationMs + 120);
}
function restartTickerScroll(){
 if(tickerScrollTimer) clearTimeout(tickerScrollTimer);
 tickerRunning=false;
 startTicker();
}
function updateRankingNote(s){
 const note=document.querySelector('.ticker-note');
 if(!note) return;
 const c=s&&s.countdown;
 // 15 min przed końcem licznika: ogłoszenie TOP1, który trafił do kolejki jako pytanie do kart.
 if(c && c.top1Fired && c.top1Nick){
   note.textContent='⭐ TOP 1: '+c.top1Nick+' → PYTANIE DO KART';
   note.classList.add('ticker-note-top1');
 } else {
   note.textContent='Ranking widzów ♥';
   note.classList.remove('ticker-note-top1');
 }
}
// Pas pod paskiem rankingu. Dwa komunikaty jadą NA ZMIANĘ: zaproszenie do zadania pytania,
// a w miejsce dawnej pauzy — zachęta do obserwacji. Kolejny przejazd startuje zaraz po
// poprzednim, więc szyna nigdy nie stoi pusta.
const PROMO_PASS_MS=16000;
const PROMO_EVERY_MS=PROMO_PASS_MS;
const PROMO_TILES=['promoTile','promoTile2'];
let lastPromoAt=0;
let promoIdx=0;
function maybeRunPromo(){
 const lane=document.getElementById('promoLane');
 if(!lane) return;
 // Pas jedzie przez CAŁY live, niezależnie od tego, czy ktoś czeka w kolejce.
 const now=Date.now();
 if(now-lastPromoAt < PROMO_EVERY_MS) return;
 lastPromoAt=now;
 const tile=document.getElementById(PROMO_TILES[promoIdx%PROMO_TILES.length]);
 promoIdx++;
 if(!tile) return;
 tile.style.setProperty('--promo-dur', PROMO_PASS_MS+'ms');
 tile.classList.remove('is-running'); void tile.offsetWidth; tile.classList.add('is-running');
 // Zdejmujemy klasę po przejeździe — inaczej zostawałaby na kafelku i stan mówiłby,
 // że jadą oba naraz. Wizualnie było poprawnie, ale kod kłamał.
 tile.addEventListener('animationend',()=>tile.classList.remove('is-running'),{once:true});
}
function render(s){ buildRankingTicker(s); updateRankingNote(s); maybeRunPromo(); }
async function loop(){render(await getState())} loop(); setInterval(loop, 1600); window.addEventListener('resize',restartTickerScroll);
`;
  } else if (kind === "ranking-tikfinity") {
    body = `<section id="tapRank" class="tap-rank-widget" aria-label="Ranking tapów TikFinity">
  <div class="tap-rank-shell">
    <div class="tap-rank-label"><span>TOP LIKE</span><strong>RANKING TAPÓW</strong></div>
    <div class="tap-rank-window">
      <div id="liveTrack" class="tap-rank-track live-track">
        <div class="tap-rank-live-slot">
          <iframe id="tfTopLiker" src="${TIKFINITY_TOPLIKER_URL}" allow="autoplay; clipboard-read; clipboard-write"></iframe>
        </div>
      </div>
      <div id="demoTrack" class="tap-rank-track demo-track" style="display:none"></div>
    </div>
    <div class="tap-rank-total">♥</div>
  </div>
</section>`;
    script += `
let activeTapMode='';
let demoSig='';
let demoResetTimer=null;
const DEMO_SCROLL_MIN_SECONDS=46;
const DEMO_SCROLL_MAX_SECONDS=160;
function stopTrack(track){
 if(!track) return;
 track.classList.remove('tap-scroll');
 track.style.transform='translateX(0)';
}
function animateTrack(track, seconds){
 if(!track) return;
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const trackW=Math.max(1, track.scrollWidth || track.getBoundingClientRect().width || 900);
 const fromX=winW + 60;
 const toX=-(trackW + 80);
 track.classList.remove('tap-scroll');
 track.style.setProperty('--tap-from-x', fromX+'px');
 track.style.setProperty('--tap-to-x', toX+'px');
 track.style.setProperty('--tap-duration', Math.max(30, seconds)+'s');
 track.style.transform='translateX('+fromX+'px)';
 void track.offsetWidth;
 track.classList.add('tap-scroll');
}
function startDemoScroll(){
 const demo=document.getElementById('demoTrack');
 if(demoResetTimer) clearTimeout(demoResetTimer);
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const trackW=Math.max(1, demo.scrollWidth || demo.getBoundingClientRect().width || 900);
 const seconds=Math.max(DEMO_SCROLL_MIN_SECONDS, Math.min(DEMO_SCROLL_MAX_SECONDS, Math.round((winW+trackW+160)/32)));
 animateTrack(demo, seconds);
 demoResetTimer=setTimeout(startDemoScroll, (seconds*1000)+900);
}
function syncTopLikerUrl(url){
 const f=document.getElementById('tfTopLiker');
 if(!f || !url) return;
 const cur=(f.getAttribute('src')||'').trim();
 if(cur!==url) f.setAttribute('src', url);
}
function setMode(mode){
 if(activeTapMode===mode) return;
 activeTapMode=mode;
 const live=document.getElementById('liveTrack');
 const demo=document.getElementById('demoTrack');
 if(demoResetTimer) clearTimeout(demoResetTimer);
 demoResetTimer=null;
 if(mode==='demo'){
   if(live){ live.style.display='none'; stopTrack(live); }
   if(demo){ demo.style.display='inline-flex'; }
   requestAnimationFrame(startDemoScroll);
 } else {
   if(demo){ demo.style.display='none'; stopTrack(demo); }
   if(live){ live.style.display='block'; stopTrack(live); }
 }
}
function demoChip(it,i){
 const likes=Number(it.likes ?? it.points ?? 0)||0;
 const nick=it.nick||'Demo user';
 return '<div class="tap-chip '+(i===0?'top':'')+'"><span class="tap-place">#'+(i+1)+'</span><span class="tap-heart">♥</span><strong>'+esc(nick)+'</strong><span class="tap-likes">'+esc(likes)+'</span></div>';
}
function renderDemo(s){
 const r=(s.ranking||[]).filter(Boolean).slice(0,18);
 const items=r.length?r:[{nick:'Demo lajki lecą',likes:0}];
 const sig=JSON.stringify(items.map(x=>[x.nick,Number(x.likes??x.points??0)||0]));
 if(sig!==demoSig){
   demoSig=sig;
   const demo=document.getElementById('demoTrack');
   if(demo){ demo.innerHTML=items.map(demoChip).join(''); }
   if(activeTapMode==='demo') requestAnimationFrame(startDemoScroll);
 }
}
async function boot(){
 const s=await getState();
 const url=(s && s.tikfinityTopLikerUrl) || '${TIKFINITY_TOPLIKER_URL}';
 syncTopLikerUrl(url);
 if(s && s.demoMode){ renderDemo(s); setMode('demo'); }
 else { setMode('live'); }
}
boot();
setInterval(boot, 1500);
window.addEventListener('resize',()=>{ if(activeTapMode==='demo') startDemoScroll(); });
`;
  } else if (kind === "ranking-web") {
    body = `<div class="tf-web-ticker-stage"><div class="tf-web-hint">Ranking tapów TikFinity Web</div><div class="tf-web-ticker-rail"><div id="strip" class="tf-web-strip"><iframe id="tf" allow="autoplay; clipboard-read; clipboard-write"></iframe></div></div></div>`;
    script += `
let webTickerTimer=null;
let webTickerBusy=false;
let lastWebWidth=0;
const WEB_TICKER_SPEED_PX_PER_SEC=24;
const WEB_TICKER_MIN_DURATION_MS=120000;
const WEB_TICKER_MAX_DURATION_MS=300000;
function tuneWebTicker(){
 const strip = document.getElementById('strip');
 if(!strip) return;
 // Nie zmieniamy wyglądu TikFinity Web — przewijamy tylko zewnętrzny wrapper/iframe.
 const w = Math.max(3200, Math.round((window.innerWidth || 1080) * 3.6));
 strip.style.setProperty('--tf-strip-width', w + 'px');
 if(Math.abs(w - lastWebWidth) > 24){ lastWebWidth = w; restartWebTickerScroll(); }
}
function stopWebTickerScroll(){
 if(webTickerTimer) clearTimeout(webTickerTimer);
 webTickerTimer=null;
 webTickerBusy=false;
 const strip=document.getElementById('strip');
 if(strip){ strip.classList.remove('is-scrolling'); strip.style.transform='translateX(0)'; }
}
function runWebTickerScroll(){
 const strip=document.getElementById('strip');
 if(!strip) return;
 if(webTickerTimer) clearTimeout(webTickerTimer);
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const stripW=Math.max(1, parseFloat(getComputedStyle(strip).width) || strip.scrollWidth || lastWebWidth || 3200);
 const fromX=winW + 80;
 const toX=-(stripW + 80);
 const distance=fromX - toX;
 const durationMs=Math.max(WEB_TICKER_MIN_DURATION_MS, Math.min(WEB_TICKER_MAX_DURATION_MS, Math.round((distance / WEB_TICKER_SPEED_PX_PER_SEC) * 1000)));
 webTickerBusy=true;
 strip.classList.remove('is-scrolling');
 strip.style.setProperty('--tf-from-x', fromX + 'px');
 strip.style.setProperty('--tf-to-x', toX + 'px');
 strip.style.setProperty('--tf-web-duration', durationMs + 'ms');
 strip.style.transform='translateX('+fromX+'px)';
 void strip.offsetWidth;
 strip.classList.add('is-scrolling');
 webTickerTimer=setTimeout(()=>{
   strip.classList.remove('is-scrolling');
   strip.style.transform='translateX('+fromX+'px)';
   webTickerBusy=false;
   webTickerTimer=setTimeout(runWebTickerScroll, 900);
 }, durationMs + 120);
}
function restartWebTickerScroll(){ stopWebTickerScroll(); requestAnimationFrame(()=>{ tuneWebTicker(); runWebTickerScroll(); }); }
async function boot(){
 const s = await getState();
 const url = (s && s.tikfinityTopLikerUrl) || '${TIKFINITY_TOPLIKER_URL}';
 const f = document.getElementById('tf');
 if(f && f.src !== url) f.src = url;
 tuneWebTicker();
 if(!webTickerBusy) requestAnimationFrame(runWebTickerScroll);
}
boot(); setInterval(boot, 5000); window.addEventListener('resize', restartWebTickerScroll);
`;
  } else if (kind === "ranking-web-raw") {
    body = `<div id="root" class="web-widget"><div class="web-label">Ranking tapów TikFinity Web — surowy</div><iframe id="tf" allow="autoplay; clipboard-read; clipboard-write"></iframe><div class="web-frame"></div></div>`;
    script += `
async function boot(){
 const s = await getState();
 const url = (s && s.tikfinityTopLikerUrl) || '${TIKFINITY_TOPLIKER_URL}';
 const f = document.getElementById('tf');
 if(f && f.src !== url) f.src = url;
}
boot(); setInterval(boot, 5000);
`;
  } else if (kind === "karton-draw") {
    // Widget Kartona Dnia. Podczas ładowania pokazuje pasek i liczbę chętnych,
    // a gdy ktoś wyśle serduszko — karta wjeżdża i wsuwa się do talii.
    // Fazy losowania (tasowanie / oczekiwanie na "tak") pokazuje widget PYTANIA,
    // bo losowanie odbywa się na środku, w miejscu pytania.
    body = `<div class="stage karton-draw-stage" id="kstage"><div class="card karton-draw-card" id="kcard"><i class="spark" style="left:10%;bottom:12%;animation-delay:.2s"></i><i class="spark" style="left:88%;bottom:20%;animation-delay:1.3s"></i><i class="spark" style="left:72%;bottom:6%;animation-delay:2.1s"></i><div class="karton-draw-frame"><span class="karton-draw-corner tl">✦</span><span class="karton-draw-corner tr">✦</span><span class="karton-draw-corner bl">✦</span><span class="karton-draw-corner br">✦</span><div class="moon-mark">☽</div><div class="flame-sweep"></div><div class="rune-burst"><span>✦</span><span>✧</span><span>✺</span><span>✦</span><span>☽</span></div><div class="karton-draw-eyebrow" id="kd-eyebrow">DO LOSOWANIA</div><div class="karton-draw-medallion"><div class="karton-draw-gift" id="kd-gift">${heartGiftSvg("kdm")}</div></div><div class="karton-draw-title" id="kd-title">KARTON DNIA</div><div class="karton-draw-nick nick" id="kd-nick">Ładowanie Karton Dnia</div><div class="karton-progress" id="kd-progress-wrap"><div class="karton-progress-track"><span id="kd-bar" class="karton-progress-fill"></span></div><div class="karton-progress-label" id="kd-status"><span class="kd-mini-heart">${heartGiftSvg("kds")}</span><span id="kd-status-text">0%</span></div></div></div></div><i class="kstack s3"></i><i class="kstack s2"></i><i class="kstack s1"></i><div class="deal-card karton-question" id="kd-question"><span class="karton-today-corner tl">✧</span><span class="karton-today-corner br">✧</span><i class="q-aura"></i><div class="q-sigil"><svg viewBox="0 0 100 60" xmlns="http://www.w3.org/2000/svg"><path d="M2 30 C 20 2, 80 2, 98 30 C 80 58, 20 58, 2 30 Z" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="50" cy="30" r="15" fill="none" stroke="currentColor" stroke-width="4"/><circle cx="50" cy="30" r="5.5" fill="currentColor"/></svg></div><div class="q-nick" id="kd-q-nick"></div><div class="q-rule">✧</div><div class="q-body" id="kd-q-body"><div class="q-text" id="kd-q-text"></div></div></div><div class="deal-card karton-today" id="kd-today"><span class="karton-today-corner tl">✦</span><span class="karton-today-corner br">✦</span><div class="moon-mark">☽</div><div class="karton-today-sigil"><svg viewBox="0 0 120 120" xmlns="http://www.w3.org/2000/svg"><g fill="none" stroke="currentColor"><circle cx="60" cy="60" r="49.5" stroke-width="6" stroke-dasharray="2.5 23.4" opacity=".85"/><circle cx="60" cy="60" r="41" stroke-width="1.6" opacity=".7"/><circle cx="60" cy="60" r="33" stroke-width="1.2" stroke-dasharray="3 7" opacity=".55"/></g></svg><span class="karton-today-moon">☽</span></div><div class="karton-today-title">KARTON DNIA</div><div class="karton-today-rule">✦</div><div class="karton-today-nick" id="kd-today-nick"></div></div><div class="join-card" id="kd-join"><span class="join-corner tl">✦</span><span class="join-corner br">✦</span><span class="join-card-heart">${heartGiftSvg("kdj")}</span><span class="join-card-nick" id="kd-join-nick"></span><span class="join-card-label">DOŁĄCZA DO LOSOWANIA</span></div></div>`;
    script += `
let lastJoinTs=0;
let lastPhase='';
function triggerKartonChange(){
 const card=document.getElementById('kcard'); if(!card) return;
 card.classList.remove('state-change'); void card.offsetWidth; card.classList.add('state-change');
 clearTimeout(card._changeTimer); card._changeTimer=setTimeout(()=>card.classList.remove('state-change'),920);
}
// Ktoś dołączył: karta z jego nickiem wjeżdża i wsuwa się do talii.
function showJoinCard(nick){
 const el=document.getElementById('kd-join');
 const nk=document.getElementById('kd-join-nick');
 if(!el||!nk) return;
 nk.textContent=nick||'';
 el.classList.remove('is-playing'); void el.offsetWidth; el.classList.add('is-playing');
 clearTimeout(el._t); el._t=setTimeout(()=>el.classList.remove('is-playing'), 2850);
}
// Treść pytania bywa jednym słowem albo pięcioma zdaniami, więc rozmiar dobieramy pod nią:
// startujemy od górnego limitu i schodzimy w dół, aż tekst zmieści się w polu karty.
// Liczymy tylko przy zmianie treści — inaczej pętla widgetu robiłaby to co 0,9 s.
let lastQuestionSig='';
function fitDealText(){
 const box=document.getElementById('kd-q-body');
 const el=document.getElementById('kd-q-text');
 if(!box||!el) return;
 const h=box.clientHeight, w=box.clientWidth;
 if(h<12||w<12) return; // karta jeszcze schowana — nie ma czego mierzyć
 const mieściSie=(px)=>{ el.style.fontSize=px+'px'; return el.scrollHeight<=h+1 && el.scrollWidth<=w+1; };
 // Górny limit celowo umiarkowany. Wcześniej krótkie pytania wchodziły po 96 px i wyglądały
 // jak krzyk — przy nicku o rozmiarze 30 px hierarchia się rozjeżdżała. 52 px zostawia
 // wyraźną różnicę względem nicku i nadal dobrze czyta się na telefonie.
 const lo0=13, hi0=Math.max(18,Math.min(52,Math.round(h*0.2)));
 // Krótkie pytanie bierze maksimum; dłuższe schodzi niżej.
 if(mieściSie(hi0)) return;
 // Szukanie binarne zamiast schodzenia po 1 px — 7 przeliczeń układu zamiast ~80.
 let lo=lo0, hi=hi0;
 while(lo<hi){
   const mid=Math.ceil((lo+hi)/2);
   if(mieściSie(mid)) lo=mid; else hi=mid-1;
 }
 el.style.fontSize=lo+'px';
}
function ustawPytanie(cur){
 const sig=(cur.nick||'')+'|'+(cur.text||'');
 if(sig===lastQuestionSig) return;
 lastQuestionSig=sig;
 const nick=document.getElementById('kd-q-nick');
 const text=document.getElementById('kd-q-text');
 if(!nick||!text) return;
 nick.textContent=cur.nick||'';
 text.textContent=cur.text||'';
 // Dwa przebiegi: pierwszy po wstawieniu tekstu, drugi gdy karta skończy wjeżdżać
 // i pole ma już docelową wysokość.
 requestAnimationFrame(fitDealText);
 setTimeout(fitDealText,850);
}
window.addEventListener('resize',fitDealText);
// Podpis osoby aktualnie pokazanej na karcie — po nim poznajemy, że rozdano następną.
let lastDealSig='';
// Chowamy kartę w talii, w połowie podmieniamy treść, po czym pozwalamy jej wyjechać
// z powrotem (usunięcie klasy przywraca wolniejsze przejście z .deal-card.is-on).
function przeladujKarte(el, wstawTresc){
 if(!el){ wstawTresc(); return; }
 el.classList.add('is-swap');
 clearTimeout(el._swapT);
 el._swapT=setTimeout(()=>{ wstawTresc(); el.classList.remove('is-swap'); },340);
}
function render(s){
 const stage=document.getElementById('kstage');
 const k=s.kartonCharge||{phase:'charging',progress:0,entrants:0};
 const phase=k.phase||'charging';

 // Prowadząca czyta Kartona Dnia — wysuwamy kartę z jego nickiem. Ustawiamy to PRZED
 // wyjściem na czas losowania, żeby po powrocie widgetu karta była już w dobrym stanie.
 const cur=(s&&s.current)||{};
 const today=document.getElementById('kd-today');
 if(today){
   const typ=cur.type||'empty';
   const jestKarton=typ==='karton';
   // "waiting" to osoba, której wpis czeka na treść — też jej kolej, więc karta wyjeżdża.
   const jestPytanie=(typ==='question'||typ==='waiting');
   const ques=document.getElementById('kd-question');

   // Podpis rozdanej karty. Pierwszy znak mówi, KTÓRA karta jest na wierzchu — dzięki temu
   // odróżniamy "kolejna osoba na tej samej karcie" (przeładowanie z animacją) od
   // "zmiana karton<->pytanie" (jedna karta i tak chowa się, druga wyjeżdża).
   const podpis = jestKarton ? ('k|'+(cur.nick||''))
     : jestPytanie ? ('q|'+(cur.nick||'')+'|'+(cur.text||'')) : '';
   const wstawTresc=()=>{
     if(jestKarton) document.getElementById('kd-today-nick').textContent=cur.nick||'';
     if(jestPytanie) ustawPytanie(cur);
   };
   if(podpis!==lastDealSig){
     const taSamaKarta = podpis && lastDealSig && podpis[0]===lastDealSig[0];
     if(taSamaKarta) przeladujKarte(jestKarton?today:ques, wstawTresc);
     else wstawTresc();
     lastDealSig=podpis;
   }

   today.classList.toggle('is-on',jestKarton);
   if(ques) ques.classList.toggle('is-on',jestPytanie);
   // Klasa na scenie odsuwa kartę losowania i talię w górę, robiąc miejsce pod spodem.
   stage.classList.toggle('has-today',jestKarton||jestPytanie);
 }

 // W trakcie losowania ten widget znika — pokazuje je widget PYTANIA.
 if(phase!=='charging'){ stage.style.display='none'; lastPhase=phase; return; }
 stage.style.display='flex';
 if(phase!==lastPhase){ lastPhase=phase; triggerKartonChange(); }

 const join=k.lastJoin;
 if(join && join.ts && join.ts!==lastJoinTs){ lastJoinTs=join.ts; showJoinCard(join.nick); }

 const n=Number(k.entrants)||0;
 // Talia za widgetem — im więcej chętnych, tym więcej kart wystaje zza krawędzi.
 document.querySelectorAll('.kstack').forEach(el=>{
   const need = el.classList.contains('s1') ? 1 : el.classList.contains('s2') ? 4 : 8;
   el.classList.toggle('on', n>=need);
 });
 document.getElementById('kd-eyebrow').textContent='DO LOSOWANIA';
 document.getElementById('kd-title').textContent='KARTON DNIA';
 document.getElementById('kd-nick').textContent = n ? (n+(n===1?' OSOBA':' OSÓB')) : 'WYŚLIJ SERDUSZKO';
 const pct=Math.max(0, Math.min(100, Math.round((Number(k.progress)||0)*100)));
 document.getElementById('kd-bar').style.width=pct+'%';
 // Serduszko przed tekstem jest osobną ikoną SVG (span.kd-mini-heart), więc
 // podmieniamy tu wyłącznie sam tekst.
 // Licznik pokazuje osoby realnie w grze: z serduszkiem i jeszcze nie wylosowane w tej sesji.
 document.getElementById('kd-status-text').textContent = n
   ? ('w losowaniu: '+n+' — dołącz wysyłając serduszko')
   : 'wyślij serduszko, aby wziąć udział';
}
async function loop(){ render(await getState()); setTimeout(loop, 900); }
loop();
`;
  } else if (kind === "combo") {
    // WIDGET ZBIORCZY — wszystkie widgety na jednym płótnie 1080x1920.
    // Zamiast trzech źródeł w OBS (= trzy osobne procesy przeglądarki) wystarczy jedno.
    // Ramki wskazują na te same adresy co osobne widgety, więc kod nie jest duplikowany,
    // a że są z tego samego serwera — przeglądarka trzyma je w JEDNYM procesie.
    // Pozycje odpowiadają układowi ustawionemu wcześniej ręcznie w OBS.
    body = `<div class="combo-stage">
      <iframe class="combo-part" data-part="ranking" src="/widget-ranking.html"></iframe>
      <iframe class="combo-part" data-part="karton" src="/widget-karton-dnia.html"></iframe>
      <iframe class="combo-part" data-part="kolejka" src="/widget-kolejka.html"></iframe>
      <iframe class="combo-part" data-part="pytanie" src="/widget-pytanie.html"></iframe>
    </div>`;
    script += `
// Płótno skaluje się do rozmiaru źródła w OBS — układ pozostaje ten sam
// niezależnie od tego, czy źródło ma dokładnie 1080x1920, czy inny rozmiar.
function fitCombo(){
  const st=document.querySelector('.combo-stage');
  if(!st) return;
  const s=Math.min(window.innerWidth/1080, window.innerHeight/1920);
  st.style.transform='scale('+s+')';
  st.style.left=((window.innerWidth-1080*s)/2)+'px';
}
fitCombo();
window.addEventListener('resize', fitCombo);

// Układ pochodzi z programu (panel UKŁAD) — zmiany widać od razu,
// bez przeładowywania źródła w OBS.
//
// Na czas losowania Karton Dnia PRZEJMUJE miejsce pytania: pytanie znika,
// a karton przenosi się na jego pozycję i wielkość. Po wyłonieniu zwycięzcy
// (i krótkim pokazaniu go) wszystko wraca na swoje miejsce.
const KARTON_WINNER_SHOW_MS=5000;
let lastComboSig='';
function applyComboLayout(s){
  const L=(s && s.comboLayout) || null;
  if(!L) return;

  // W trakcie losowania (tasowanie / czekanie na "tak") karton znika, a scenę
  // losowania rysuje widget PYTANIA — dlatego on musi zostać widoczny.
  const charge=(s && s.kartonCharge) || {};
  const drawing = charge.phase==='shuffling' || charge.phase==='winner';

  const sig=JSON.stringify(L)+'|'+drawing;
  if(sig===lastComboSig) return;
  lastComboSig=sig;

  const q=L.pytanie||null;
  document.querySelectorAll('.combo-part').forEach(f=>{
    const part=f.dataset.part;
    const c=L[part];
    if(!c) return;

    // Karton znika na czas losowania — jego rolę przejmuje scena w widgecie pytania.
    if(part==='karton' && drawing){
      f.style.display='none';
    } else {
      f.style.visibility='visible';
      f.style.display = c.enabled===false ? 'none' : 'block';
    }
    f.style.left=(Number(c.x)||0)+'px';
    f.style.top=(Number(c.y)||0)+'px';
    f.style.transform='scale('+(Number(c.scale)||1)+')';
  });


}

async function comboLoop(){
  const s=await getState();
  applyComboLayout(s);
  const busy=!!(s.kartonCharge&&s.kartonCharge.collecting);
  clearTimeout(window._cTimer);
  window._cTimer=setTimeout(comboLoop, busy?400:1000);
}
comboLoop();
`;
  } else if (kind === "activity") {
    body = `<div id="root" class="web-widget activity"><div class="web-label">Aktywności TikFinity</div><iframe id="tf" allow="autoplay; clipboard-read; clipboard-write"></iframe><div class="web-frame"></div></div>`;
    script += `
async function boot(){
 const s = await getState();
 const url = (s && s.tikfinityActivityFeedUrl) || '${TIKFINITY_ACTIVITY_FEED_URL}';
 const f = document.getElementById('tf');
 if(f && f.src !== url) f.src = url;
}
boot(); setInterval(boot, 5000);
`;
  } else {
    body = `<div class="demo-grid"><div class="demo-box"><iframe src="/widget-pytanie.html"></iframe></div><div class="demo-box"><iframe src="/widget-kolejka.html"></iframe></div><div class="demo-box" style="grid-column:1/3"><iframe src="/widget-ranking.html"></iframe></div><div class="demo-box demo-activity"><iframe src="/widget-aktywnosci.html"></iframe></div></div>`;
  }
  return `<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KVRINA widget</title><style>${WIDGET_CSS}</style></head><body>${body}<script>${script}</script></body></html>`;
}

// =========================
// PILOT — panel sterowania kolejką jako dock w OBS.
// Świadomie NIE jest to skompilowana wtyczka OBS: taka wymaga budowania osobno pod każdą
// wersję OBS i pod procesor, a przy aktualizacji OBS przestaje działać. Dock przeglądarkowy
// jest wbudowaną funkcją OBS, nic się nie instaluje i przeżywa aktualizacje.
// Strona jest samowystarczalna (własny CSS), bo WIDGET_CSS zakłada przezroczyste tło sceny.
// =========================
function pilotHtml() {
  return `<!doctype html><html lang="pl"><head><meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>KVRINA — pilot</title><style>
:root{--gold:#ffcb55;--amber:#ff8a20;--red:#e44322;--cream:#fff7df;--muted:#d7b98c}
*{box-sizing:border-box;-webkit-user-select:none;user-select:none}
html,body{margin:0;height:100%;background:#0b0603;color:var(--cream);
  font-family:Inter,system-ui,-apple-system,'Segoe UI',sans-serif}
body{display:flex;flex-direction:column;gap:8px;padding:10px;min-width:220px}
.teraz{flex:0 0 auto;border:1px solid rgba(255,203,85,.3);border-radius:12px;padding:8px 10px;
  background:linear-gradient(135deg,rgba(38,20,4,.75),rgba(6,5,7,.6));min-height:64px}
.etykieta{font-size:10px;letter-spacing:.16em;color:var(--gold);font-weight:900;text-transform:uppercase}
.nick{margin-top:3px;font-size:17px;font-weight:950;line-height:1.1;word-break:break-word}
.tresc{margin-top:2px;font-size:12px;color:var(--muted);line-height:1.25;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.pasek{display:flex;gap:8px;font-size:11px;color:var(--muted);align-items:center;flex:0 0 auto}
.kropka{width:8px;height:8px;border-radius:50%;background:#7a2a1a;flex:0 0 auto}
.kropka.zywa{background:#3ddc7f;box-shadow:0 0 8px rgba(61,220,127,.7)}
.przyciski{flex:1 1 auto;display:grid;gap:8px;grid-template-columns:1fr 1fr;grid-template-rows:1fr auto}
button{font-family:inherit;font-weight:950;color:#150a03;border:0;border-radius:12px;cursor:pointer;
  font-size:15px;letter-spacing:.04em;text-transform:uppercase;transition:transform .08s ease,filter .15s ease}
button:active{transform:scale(.96)}
button:disabled{opacity:.45;cursor:default}
.wstecz{background:linear-gradient(160deg,#e46a4a,#b3341c);color:#fff}
.dalej{background:linear-gradient(160deg,#7fe0a3,#25a45f);color:#04240f}
.pomin{grid-column:1/-1;padding:12px;background:linear-gradient(160deg,#ffd06a,#e8951a)}
.blad{flex:0 0 auto;font-size:11px;color:#ff9c85;min-height:14px;text-align:center}
</style></head><body>
<div class="teraz">
  <div class="etykieta" id="p-etykieta">TERAZ CZYTASZ</div>
  <div class="nick" id="p-nick">—</div>
  <div class="tresc" id="p-tresc"></div>
</div>
<div class="pasek"><span class="kropka" id="p-kropka"></span><span id="p-kolejka">—</span></div>
<div class="przyciski">
  <button class="wstecz" id="p-wstecz">← Wstecz</button>
  <button class="dalej" id="p-dalej">Dalej →</button>
  <button class="pomin" id="p-pomin">Pomiń</button>
</div>
<div class="blad" id="p-blad"></div>
<script>
const $=(id)=>document.getElementById(id);
let blokada=0;
async function slij(akcja){
  // Krótka blokada po kliknięciu — przy podwójnym kliknięciu prowadząca przeskoczyłaby
  // dwa pytania naraz i nie zauważyła tego na antenie.
  const teraz=Date.now();
  if(teraz-blokada<350) return;
  blokada=teraz;
  try{
    const r=await fetch('/pilot/'+akcja,{method:'POST',cache:'no-store'});
    if(!r.ok) throw new Error('HTTP '+r.status);
    $('p-blad').textContent='';
    odswiez();
  }catch(e){ $('p-blad').textContent='Brak łączności z programem'; }
}
$('p-wstecz').addEventListener('click',()=>slij('prev'));
$('p-dalej').addEventListener('click',()=>slij('next'));
$('p-pomin').addEventListener('click',()=>slij('skip'));
// Skróty klawiszowe działają, gdy dock ma zaznaczenie — wygodne przy klawiaturze pod ręką.
window.addEventListener('keydown',(e)=>{
  if(e.key==='ArrowRight') slij('next');
  else if(e.key==='ArrowLeft') slij('prev');
  else if(e.key===' '){ e.preventDefault(); slij('skip'); }
});
async function odswiez(){
  try{
    const r=await fetch('/widget_state.json?t='+Date.now(),{cache:'no-store'});
    const s=await r.json();
    const c=s.current||{};
    const pusto=(c.type||'empty')==='empty';
    const q=Array.isArray(s.queue)?s.queue:[];
    $('p-kropka').classList.add('zywa');
    $('p-etykieta').textContent = pusto ? 'KOLEJKA PUSTA'
      : (c.type==='karton' ? 'TERAZ — KARTON DNIA' : 'TERAZ CZYTASZ');
    $('p-nick').textContent = pusto ? '—' : (c.nick||'—');
    $('p-tresc').textContent = pusto ? 'Czekam na pytania i kartony…' : (c.text||'');
    $('p-kolejka').textContent = q.length
      ? ('w kolejce: '+q.length+'  •  następny: '+(q[0].nick||'—'))
      : 'w kolejce: 0';
    $('p-dalej').disabled = !q.length;
    $('p-pomin').disabled = q.length<1 || pusto;
  }catch(e){
    $('p-kropka').classList.remove('zywa');
    $('p-kolejka').textContent='program nie odpowiada';
  }
}
odswiez(); setInterval(odswiez,1000);
</script></body></html>`;
}

function writeWidgetAssetFiles() {
  try {
    const dir = getWidgetsDir();
    fs.writeFileSync(path.join(dir, "widget-pytanie.html"), widgetHtml("question"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-aktualny.html"), widgetHtml("question"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-kolejka.html"), widgetHtml("queue"), "utf8");
    // 1.0.66: RANKING WIDZÓW liczony lokalnie (komentarz/tap/follow/share + boost od giftów) —
    // już NIE embeduje zewnętrznego widgetu TikFinity (obcy cid, brak własnych danych).
    // Stare nazwy plików zostają jako aliasy tej samej zawartości, żeby stare źródła w OBS/TikTok Studio nie padły.
    fs.writeFileSync(path.join(dir, "widget-ranking.html"), widgetHtml("ranking"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-ranking-lokalny.html"), widgetHtml("ranking"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-ranking-web.html"), widgetHtml("ranking"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-ranking-web-raw.html"), widgetHtml("ranking"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-aktywnosci.html"), widgetHtml("activity"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-karton-dnia.html"), widgetHtml("karton-draw"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-wszystko.html"), widgetHtml("combo"), "utf8");
    fs.writeFileSync(path.join(dir, "demo.html"), widgetHtml("demo"), "utf8");
    // PILOT — dock do OBS. Nie jest widgetem na scenę, więc ma własny, "jasny" wygląd
    // i nie korzysta ze wspólnego WIDGET_CSS (tamten zakłada przezroczyste tło).
    fs.writeFileSync(path.join(dir, "pilot.html"), pilotHtml(), "utf8");
    ensureWidgetStateFile();
    writeWidgetAddressFile();
  } catch (e) {
    console.warn("[WIDGETY] asset write error:", e.message);
  }
}

function sendStaticFile(res, filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
      res.end("Not found");
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".txt": "text/plain; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp", ".mp3": "audio/mpeg", ".wav": "audio/wav", ".m4a": "audio/mp4", ".aac": "audio/aac", ".ogg": "audio/ogg", ".oga": "audio/ogg", ".opus": "audio/ogg", ".flac": "audio/flac" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*" });
    fs.createReadStream(filePath).pipe(res);
  } catch (e) {
    res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
    res.end("Server error");
  }
}

// widget_state.json jest odpytywany przez KAŻDY widget w OBS i każde okno panelu
// kilka razy na sekundę. Czytanie pliku z dysku przy każdym takim zapytaniu
// niepotrzebnie obciążało słabsze maszyny — trzymamy treść w pamięci i odświeżamy
// tylko gdy zmieni się mtime (stat jest dużo tańszy niż odczyt całego pliku).
let _wsCache = { mtimeMs: 0, size: -1, body: null, lite: null };

// Widgety w OBS nie korzystają z listy obserwujących (to najcięższa część stanu —
// potrafi być kilkanaście kB), więc dostają wersję "lite" bez niej. Pełny stan
// zostaje pod /widget_state.json dla paneli w aplikacji, które faktycznie go potrzebują.
// === UKŁAD WIDGETU ZBIORCZEGO ===
// Pozycja i wielkość każdego elementu na makiecie 1080x1920.
// Wartości domyślne odpowiadają układowi ustawionemu wcześniej ręcznie w OBS.
const COMBO_PARTS = ["pytanie", "ranking", "kolejka", "karton"];
const COMBO_PART_LABELS = {
  pytanie: "PYTANIE",
  ranking: "RANKING WIDZÓW",
  kolejka: "KOLEJKA",
  karton: "KARTON DNIA",
};
const COMBO_DEFAULT_LAYOUT = {
  pytanie: { x: 70, y: 960, scale: 0.9, enabled: true },
  ranking: { x: 0, y: -1550, scale: 1.0, enabled: true },
  kolejka: { x: 863, y: 366, scale: 1.173, enabled: true },
  karton: { x: -177, y: 5, scale: 0.56, enabled: true },
};

function getComboLayout() {
  const saved = (_appConfig && _appConfig.comboLayout) || {};
  const out = {};
  for (const k of COMBO_PARTS) {
    const d = COMBO_DEFAULT_LAYOUT[k];
    const s = saved[k] || {};
    out[k] = {
      x: Number.isFinite(Number(s.x)) ? Number(s.x) : d.x,
      y: Number.isFinite(Number(s.y)) ? Number(s.y) : d.y,
      scale: Number.isFinite(Number(s.scale)) && Number(s.scale) > 0 ? Number(s.scale) : d.scale,
      enabled: s.enabled === undefined ? d.enabled : !!s.enabled,
    };
  }
  return out;
}

function setComboLayout(patch) {
  if (!_appConfig || typeof _appConfig !== "object") _appConfig = {};
  const cur = getComboLayout();
  for (const k of Object.keys(patch || {})) {
    if (!COMBO_PARTS.includes(k)) continue;
    cur[k] = { ...cur[k], ...patch[k] };
  }
  _appConfig.comboLayout = cur;
  saveAppConfig();
  _wsCache = {}; // widget podchwyci nowy układ przy najbliższym odpytaniu
  return cur;
}

function resetComboLayout() {
  if (!_appConfig || typeof _appConfig !== "object") _appConfig = {};
  delete _appConfig.comboLayout;
  saveAppConfig();
  _wsCache = {};
  return getComboLayout();
}

// Tryb oszczędny widgetów — ustawienie programu, nie stan sesji.
function isLiteWidgets() {
  const cfg = (_appConfig && _appConfig.widgets) || {};
  return cfg.lite === true; // domyślnie wyłączony (pełne animacje)
}

function setLiteWidgets(on) {
  if (!_appConfig || typeof _appConfig !== "object") _appConfig = {};
  _appConfig.widgets = { ...(_appConfig.widgets || {}), lite: !!on };
  saveAppConfig();
  _wsCache = {}; // wymuś przebudowę, żeby widgety dostały nową flagę od razu
  return isLiteWidgets();
}

function refreshWidgetStateCache() {
  ensureWidgetStateFile();
  const p = path.join(getWidgetsDir(), WIDGET_STATE_JSON);
  const st = fs.statSync(p);
  const lite = isLiteWidgets();
  if (_wsCache.body && st.mtimeMs === _wsCache.mtimeMs && st.size === _wsCache.size && _wsCache.liteFlag === lite) return;
  const raw = fs.readFileSync(p);
  let bodyBuf = raw;
  let liteBuf = raw;
  try {
    const obj = JSON.parse(raw.toString("utf8"));
    obj.liteWidgets = lite;
    obj.comboLayout = getComboLayout();
    bodyBuf = Buffer.from(JSON.stringify(obj), "utf8");
    if (Array.isArray(obj.followQueue) && obj.followQueue.length) delete obj.followQueue;
    liteBuf = Buffer.from(JSON.stringify(obj), "utf8");
  } catch {}
  _wsCache = { mtimeMs: st.mtimeMs, size: st.size, body: bodyBuf, lite: liteBuf, liteFlag: lite };
}

function sendWidgetState(req, res, wantLite) {
  try {
    refreshWidgetStateCache();
    const payload = wantLite ? _wsCache.lite : _wsCache.body;
    res.writeHead(200, {
      "Content-Type": "application/json; charset=utf-8",
      "Content-Length": payload.length,
      "Cache-Control": "no-store",
      "Access-Control-Allow-Origin": "*",
    });
    res.end(payload);
  } catch (e) {
    res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
    res.end("Server error");
  }
}

function startWidgetServer() {
  if (widgetServer) return;
  writeWidgetAssetFiles();
  widgetServer = http.createServer((req, res) => {
    try {
      const parsed = new URL(req.url || "/", `http://127.0.0.1:${widgetPort}`);
      let pathname = decodeURIComponent(parsed.pathname || "/");
      if (pathname === "/" || pathname === "/index.html") pathname = "/demo.html";
      // Pliki dźwiękowe podajemy przez ten sam lokalny serwer — dzięki temu
      // odtwarzacz nie musi sięgać do dysku po ścieżkach file://.
      if (pathname.startsWith("/dzwieki/")) {
        const rel = pathname.replace(/^\/dzwieki\//, "");
        return sendStaticFile(res, safeJoin(getSoundsDir(), rel));
      }
      // PILOT — sterowanie kolejką z docka w OBS. Serwer słucha wyłącznie na 127.0.0.1,
      // więc te polecenia są nieosiągalne spoza tego Maca. Wykonują dokładnie to samo,
      // co przyciski WSTECZ/POMIŃ/DALEJ w czytniku — jedna ścieżka logiki, nie druga kopia.
      if (pathname.startsWith("/pilot/")) {
        const akcja = pathname.slice(7);
        const kanal = { next: "wb-questions-next", prev: "wb-questions-prev", skip: "wb-questions-skip" }[akcja];
        res.writeHead(kanal ? 200 : 404, {
          "Content-Type": "application/json; charset=utf-8",
          "Cache-Control": "no-store",
          "Access-Control-Allow-Origin": "*",
        });
        if (kanal) _wbSendToRenderer(kanal);
        return res.end(JSON.stringify({ ok: !!kanal, akcja }));
      }
      if (pathname === "/widget_state.json") {
        return sendWidgetState(req, res, false);
      }
      if (pathname === "/widget_state_lite.json") {
        return sendWidgetState(req, res, true);
      }
      // Zapamiętujemy, które widgety są realnie wczytywane — dzięki temu raport
      // pokazuje, czy w OBS działa jeden widget zbiorczy, czy kilka osobnych źródeł.
      // WAŻNE: widget zbiorczy wczytuje pozostałe widgety w swoich ramkach. Takie
      // żądania mają nagłówek Referer wskazujący na niego i NIE są osobnymi źródłami
      // w OBS — bez tego rozróżnienia raport pokazywał 5 źródeł zamiast jednego.
      if (/^\/widget-[a-z0-9-]+\.html$/i.test(pathname)) {
        const ref = String(req.headers.referer || "");
        const fromCombo = ref.includes("widget-wszystko");
        if (!fromCombo) _widgetUsage.set(pathname.replace(/^\/|\.html$/gi, ""), Date.now());
      }
      const safe = safeJoin(getWidgetsDir(), pathname.replace(/^\/+/, ""));
      return sendStaticFile(res, safe);
    } catch (e) {
      res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
      res.end("Server error");
    }
  });
  widgetServer.listen(widgetPort, "127.0.0.1", () => {
    console.log(`[WIDGETY] listening on http://127.0.0.1:${widgetPort}/demo.html`);
  });
}

// =========================
// Cloudflare Named Tunnel (HTTPS, stały adres) for Tipped
// =========================
// Stały tunel niezależny od tuneli innych projektów (np. Wiedźma Basia) —
// osobne ID, osobne credentials, osobna subdomena. Adres NIE zmienia się między
// uruchomieniami programu (w przeciwieństwie do starego "quick tunnel" *.trycloudflare.com).
const KVRINA_TUNNEL_ID = "31cc4be7-1d74-44fe-bfe6-439e2e053624";
const KVRINA_TUNNEL_HOSTNAME = "kvrina.wiedzmabasia.com";
const KVRINA_TUNNEL_CREDS_FILE = "cloudflared-kvrina-show.json"; // obok main.js, dostarczany tylko przez INSTALKĘ (nigdy przez publiczny ZIP aktualizacji)

let tunnelProc = null;
let tunnelUrl = null;

function getCloudflaredInstallHint() {
  if (process.platform === "darwin") {
    return "Nie mogę uruchomić cloudflared. Na Macu zainstaluj Homebrew, potem w Terminalu: brew install cloudflared. Jeśli już jest zainstalowany, uruchom program przez START_KVRINA_SHOW_MAC.command.";
  }
  if (process.platform === "win32") {
    return "Nie mogę uruchomić cloudflared. Zainstaluj cloudflared: winget install --id Cloudflare.cloudflared i uruchom program ponownie.";
  }
  return "Nie mogę uruchomić cloudflared. Zainstaluj cloudflared i uruchom program ponownie.";
}

function getCloudflaredCommand() {
  const candidates = process.platform === "darwin"
    ? ["/opt/homebrew/bin/cloudflared", "/usr/local/bin/cloudflared", "cloudflared"]
    : ["cloudflared"];
  for (const candidate of candidates) {
    if (candidate === "cloudflared") return candidate;
    try {
      if (fs.existsSync(candidate)) return candidate;
    } catch {}
  }
  return "cloudflared";
}

function stopTunnel() {
  try {
    if (tunnelProc) {
      const proc = tunnelProc;
      proc.kill();
      // cloudflared potrafi ignorować SIGTERM i wisieć — po 2s dobijamy na twardo,
      // inaczej każdy restart programu zostawiał osierocony proces (~40MB + połączenia).
      setTimeout(() => { try { if (!proc.killed) proc.kill("SIGKILL"); } catch {} }, 2000);
    }
  } catch {}
  tunnelProc = null;
  tunnelUrl = null;
}

// Sprząta tunele zostawione przez poprzednie uruchomienia (np. po crashu albo
// wymuszonym zamknięciu, gdy "before-quit" nie zdążyło się wykonać).
// Dopasowanie po ścieżce NASZEGO pliku config — cudze tunele cloudflared zostają nietknięte.
function killOrphanedTunnels() {
  try {
    const configPath = path.join(app.getPath("userData"), "kvrina-tunnel-config.yml");
    if (process.platform === "win32") return;
    const out = execSync(`pgrep -f ${JSON.stringify(configPath)} || true`, { encoding: "utf8" });
    const pids = out.split(/\s+/).map((s) => parseInt(s, 10)).filter((n) => Number.isFinite(n) && n !== process.pid);
    if (!pids.length) return;
    for (const pid of pids) {
      try { process.kill(pid, "SIGKILL"); } catch {}
    }
    diagInfo(`[TUNEL] Posprzątano ${pids.length} osieroconych procesów cloudflared z poprzednich uruchomień.`);
  } catch (e) {
    console.warn("[TUNEL] killOrphanedTunnels:", e.message);
  }
}

// Generuje (za każdym startem, żeby ścieżka do credentials zawsze była aktualna)
// plik konfiguracyjny cloudflared w zapisywalnym katalogu userData.
function writeTunnelConfigYml() {
  const credsPath = path.join(__dirname, KVRINA_TUNNEL_CREDS_FILE);
  if (!fs.existsSync(credsPath)) {
    throw new Error(`Brak pliku ${KVRINA_TUNNEL_CREDS_FILE} — tunel nie może wystartować. Zainstaluj świeżą paczkę programu.`);
  }
  const configPath = path.join(app.getPath("userData"), "kvrina-tunnel-config.yml");
  const yml = [
    `tunnel: ${KVRINA_TUNNEL_ID}`,
    `credentials-file: ${credsPath}`,
    ``,
    `ingress:`,
    `  - hostname: ${KVRINA_TUNNEL_HOSTNAME}`,
    `    service: http://127.0.0.1:${tippedPort}`,
    `  - service: http_status:404`,
    ``,
  ].join("\n");
  fs.writeFileSync(configPath, yml, "utf8");
  return configPath;
}

function startQuickTunnel() {
  if (tunnelProc) {
    return { ok: true, alreadyRunning: true, url: tunnelUrl };
  }

  let configPath;
  try {
    configPath = writeTunnelConfigYml();
  } catch (e) {
    return { ok: false, error: e.message };
  }

  // Zanim wystartujemy własny tunel — usuń ewentualne osierocone z poprzednich uruchomień.
  killOrphanedTunnels();

  // Adres jest stały i znany z góry — nie trzeba parsować stdout jak przy quick tunnelu.
  tunnelUrl = `https://${KVRINA_TUNNEL_HOSTNAME}`;
  const args = ["tunnel", "--config", configPath, "run"];
  try {
    tunnelProc = spawn(getCloudflaredCommand(), args, { windowsHide: true });
  } catch (e) {
    tunnelProc = null;
    tunnelUrl = null;
    return { ok: false, error: getCloudflaredInstallHint() };
  }

  try {
    clipboard.writeText(`${tunnelUrl}/webhook`);
  } catch {}
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send("wb-tunnel-url", { url: tunnelUrl, webhookUrl: `${tunnelUrl}/webhook` });
    }
  } catch {}

  const onLine = (line) => {
    const s = String(line || "").trim();
    if (!s) return;
    if (/error|failed|WRN|ERR/i.test(s)) diagWarn(`[TUNEL] ${s}`);
  };

  tunnelProc.stdout.on("data", (d) => {
    const text = d.toString("utf8");
    text.split(/\r?\n/).forEach(onLine);
  });

  tunnelProc.stderr.on("data", (d) => {
    const text = d.toString("utf8");
    text.split(/\r?\n/).forEach(onLine);
  });

  tunnelProc.on("exit", () => {
    stopTunnel();
    try {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("wb-tunnel-stopped", {});
      }
    } catch {}
  });

  return { ok: true, started: true };
}

function _seenStorePath() {
  return path.join(ensureOutputDir(), "tipped_seen_orders.json");
}

function loadSeenOrders() {
  try {
    const p = _seenStorePath();
    if (!fs.existsSync(p)) return;
    const raw = fs.readFileSync(p, "utf8");
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) {
      tippedSeen = new Set(arr.map(String));
    }
  } catch (e) {
    console.warn("[WB] loadSeenOrders failed:", e.message);
  }
}

function saveSeenOrders() {
  try {
    const p = _seenStorePath();
    const arr = Array.from(tippedSeen).slice(-5000); // cap
    fs.writeFileSync(p, JSON.stringify(arr, null, 2), "utf8");
  } catch (e) {
    console.warn("[WB] saveSeenOrders failed:", e.message);
  }
}


// =========================
// UKŁAD OKIEN / MONITORY
// =========================
const WINDOW_STATE_JSON = "window_state.json";
const MIN_WINDOW_WIDTH = 900;
const MIN_WINDOW_HEIGHT = 600;

function _windowStatePath() {
  return path.join(ensureOutputDir(), WINDOW_STATE_JSON);
}

function loadWindowState() {
  try {
    const p = _windowStatePath();
    if (!fs.existsSync(p)) return {};
    const raw = fs.readFileSync(p, "utf8");
    const obj = JSON.parse(raw || "{}");
    return obj && typeof obj === "object" ? obj : {};
  } catch (e) {
    console.warn("[WB] loadWindowState failed:", e.message);
    return {};
  }
}

function saveWindowState(state) {
  try {
    const p = _windowStatePath();
    fs.writeFileSync(p, JSON.stringify(state || {}, null, 2), "utf8");
    return true;
  } catch (e) {
    console.warn("[WB] saveWindowState failed:", e.message);
    return false;
  }
}

function _rectIntersects(a, b) {
  if (!a || !b) return false;
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}

function _clamp(n, min, max) {
  if (!Number.isFinite(n)) return min;
  if (max < min) return min;
  return Math.max(min, Math.min(max, n));
}

function getDisplayById(displayId) {
  try {
    const displays = screen.getAllDisplays();
    return displays.find((d) => String(d.id) === String(displayId)) || null;
  } catch {
    return null;
  }
}

function sanitizeWindowBounds(savedBounds, displayId, fallbackWidth, fallbackHeight) {
  const displays = screen.getAllDisplays();
  const primary = screen.getPrimaryDisplay();
  const saved = savedBounds && typeof savedBounds === "object" ? savedBounds : {};

  let width = Math.round(Number(saved.width) || fallbackWidth || 1400);
  let height = Math.round(Number(saved.height) || fallbackHeight || 900);
  width = _clamp(width, MIN_WINDOW_WIDTH, 10000);
  height = _clamp(height, MIN_WINDOW_HEIGHT, 10000);

  const requested = {
    x: Math.round(Number(saved.x)),
    y: Math.round(Number(saved.y)),
    width,
    height,
  };

  const requestedLooksValid = Number.isFinite(requested.x) && Number.isFinite(requested.y);
  const savedDisplay = getDisplayById(displayId);
  const matchingDisplay = requestedLooksValid ? screen.getDisplayMatching(requested) : null;
  const targetDisplay = savedDisplay || matchingDisplay || primary;
  const wa = targetDisplay.workArea || targetDisplay.bounds;

  // Jeśli zapisany prostokąt dalej dotyka któregoś aktualnego monitora, zachowujemy jego pozycję.
  if (requestedLooksValid && displays.some((d) => _rectIntersects(requested, d.workArea || d.bounds))) {
    return {
      x: _clamp(requested.x, wa.x - Math.round(width * 0.85), wa.x + wa.width - Math.round(width * 0.15)),
      y: _clamp(requested.y, wa.y, wa.y + wa.height - 80),
      width,
      height,
    };
  }

  // Jeśli monitor zniknął albo rozdzielczość się zmieniła — ustawiamy okno na środku wybranego/primary monitora.
  return {
    x: Math.round(wa.x + Math.max(0, (wa.width - width) / 2)),
    y: Math.round(wa.y + Math.max(0, (wa.height - height) / 2)),
    width: Math.min(width, wa.width),
    height: Math.min(height, wa.height),
  };
}

function getSavedWindowOptions(windowName, defaults) {
  const state = loadWindowState();
  const item = state && state[windowName] ? state[windowName] : null;
  const bounds = sanitizeWindowBounds(item && item.bounds, item && item.displayId, defaults.width, defaults.height);
  return {
    ...bounds,
    isMaximized: !!(item && item.isMaximized),
    isFullScreen: !!(item && item.isFullScreen),
  };
}

function persistWindowPlacement(windowName, win) {
  try {
    if (!win || win.isDestroyed()) return;
    const state = loadWindowState();
    const bounds = (win.isMaximized() || win.isFullScreen()) ? win.getNormalBounds() : win.getBounds();
    const display = screen.getDisplayMatching(bounds);
    state[windowName] = {
      bounds,
      displayId: display ? display.id : null,
      displayBounds: display ? display.bounds : null,
      isMaximized: win.isMaximized(),
      isFullScreen: win.isFullScreen(),
      savedAt: new Date().toISOString(),
    };
    saveWindowState(state);
  } catch (e) {
    console.warn(`[WB] persistWindowPlacement failed (${windowName}):`, e.message);
  }
}

function attachWindowPlacementMemory(windowName, win) {
  let t = null;
  const schedule = () => {
    try { if (t) clearTimeout(t); } catch {}
    t = setTimeout(() => persistWindowPlacement(windowName, win), 350);
  };
  try {
    win.on("move", schedule);
    win.on("resize", schedule);
    win.on("maximize", schedule);
    win.on("unmaximize", schedule);
    win.on("enter-full-screen", schedule);
    win.on("leave-full-screen", schedule);
    win.on("close", () => persistWindowPlacement(windowName, win));
  } catch (e) {
    console.warn(`[WB] attachWindowPlacementMemory failed (${windowName}):`, e.message);
  }
}

// =========================
// PREFERENCJE (ostatnio użyte pliki TXT)
// =========================
function _prefsPath() {
  return path.join(ensureOutputDir(), "wb_prefs.json");
}

function loadPrefs() {
  try {
    const p = _prefsPath();
    if (!fs.existsSync(p)) return;
    const raw = fs.readFileSync(p, "utf8");
    const obj = JSON.parse(raw || "{}");
    if (obj && typeof obj === "object") {
      if (typeof obj.manualTxtPath === "string" && obj.manualTxtPath.trim()) {
        MANUAL_QUESTIONS_FILE_PATH = obj.manualTxtPath;
      }
      if (typeof obj.autoTxtPath === "string" && obj.autoTxtPath.trim()) {
        AUTO_QUESTIONS_FILE_PATH = obj.autoTxtPath;
      }
    }
  } catch (e) {
    console.warn("[WB] loadPrefs failed:", e.message);
  }
}

function savePrefs() {
  try {
    const p = _prefsPath();
    const obj = {
      manualTxtPath: MANUAL_QUESTIONS_FILE_PATH || null,
      autoTxtPath: AUTO_QUESTIONS_FILE_PATH || null,
      savedAt: new Date().toISOString(),
    };
    fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
  } catch (e) {
    console.warn("[WB] savePrefs failed:", e.message);
  }
}

function resetTxtFilesOnExit() {
  // 1.0.37: nie czyścimy już stanu przy zamykaniu.
  // Program ma po ponownym uruchomieniu wrócić do stanu sprzed wyłączenia.
  // Czysty start robi teraz tylko przycisk ZERUJ SESJĘ.
}

function normalizeQuestionLine(nick, msg) {
  const n = String(nick || "Anon").trim().replace(/[\r\n]+/g, " ").slice(0, 80) || "Anon";
  const q = String(msg || "").trim().replace(/[\r\n]+/g, " ").slice(0, 400);
  return { nick: n, question: q };
}

function appendQuestionBlockToFile(fullPath, nick, question) {
  try {
    if (!fullPath) return false;
    const block = `${nick}\n${question}\n\n`;
    fs.appendFileSync(fullPath, block, "utf8");
    return true;
  } catch (e) {
    console.error("[WB] appendQuestionBlockToFile failed:", e);
    return false;
  }
}

function safeTimingEqualString(a, b) {
  try {
    const aa = Buffer.from(String(a || ""));
    const bb = Buffer.from(String(b || ""));
    if (aa.length !== bb.length) return false;
    return crypto.timingSafeEqual(aa, bb);
  } catch {
    return false;
  }
}

function normalizeSignatureValue(v) {
  return String(v || "")
    .trim()
    .replace(/^sha256=/i, "")
    .replace(/^Bearer\s+/i, "")
    .trim();
}

function maybeVerifyTippedSignature(req, rawBody) {
  // Hash Tipped ustawiony domyślnie dla KVRINA_SHOW.
  // W praktyce Tipped potrafi przekazać hash/podpis różnymi drogami (nagłówek, query),
  // dlatego akceptujemy kilka wariantów. Jeśli podpisu w ogóle nie ma — nie blokujemy webhooka,
  // bo część konfiguracji Tipped nie wysyła nagłówka x-tipped-signature.
  if (!TIPPED_HASH) return true;
  try {
    const expected = String(TIPPED_HASH || "").trim();
    if (!expected) return true;

    let queryHash = "";
    try {
      const u = new URL(req.url || "/webhook", `http://127.0.0.1:${tippedPort}`);
      queryHash = u.searchParams.get("hash") || u.searchParams.get("webhook_hash") || u.searchParams.get("secret") || "";
    } catch {}

    let payloadHash = "";
    try {
      const parsed = JSON.parse(rawBody || "{}");
      payloadHash = parsed.hash || parsed.webhook_hash || parsed.webhookHash || parsed.secret || parsed.signature || "";
    } catch {}

    const directCandidates = [
      queryHash,
      payloadHash,
      req.headers["x-tipped-hash"],
      req.headers["x-webhook-hash"],
      req.headers["x-hook-secret"],
      req.headers["x-tipped-secret"],
      req.headers["authorization"],
    ].map(normalizeSignatureValue).filter(Boolean);

    if (directCandidates.some((v) => safeTimingEqualString(v, expected))) return true;

    const sig = normalizeSignatureValue(req.headers["x-tipped-signature"] || req.headers["x-signature"] || "");
    if (sig) {
      if (safeTimingEqualString(sig, expected)) return true;
      const h = crypto.createHmac("sha256", expected).update(rawBody).digest("hex");
      if (safeTimingEqualString(sig, h)) return true;
      return false;
    }

    console.warn("[WB] Tipped webhook bez podpisu/hash — przyjmuję payload, żeby nie blokować wpłat.");
    return true;
  } catch (e) {
    console.warn("[WB] Signature verify error:", e.message);
    return true;
  }
}

function startTippedServer() {
  if (tippedServer) return;
  loadSeenOrders();

  tippedServer = http.createServer((req, res) => {
    try {
      if (req.method === "GET" && req.url && req.url.startsWith("/webhook")) {
        res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("WB OK");
        return;
      }

      if (req.method !== "POST" || !req.url || !req.url.startsWith("/webhook")) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Not Found");
        return;
      }

      let body = "";
      req.on("data", (chunk) => {
        body += chunk;
        if (body.length > 2_000_000) {
          req.destroy();
        }
      });
      req.on("end", () => {
        const rawBody = body;

        // Optional signature verification
        if (!maybeVerifyTippedSignature(req, rawBody)) {
          res.writeHead(401, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("Invalid signature");
          return;
        }

        let payload;
        try {
          payload = JSON.parse(rawBody || "{}");
        } catch {
          res.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("Bad JSON");
          return;
        }

                const orderId = String(payload.order_id || payload.orderId || "").trim();
        const payerName = String(payload.payer_name || payload.payerName || payload.name || "Anon").trim();
        const message = String(payload.message || "").trim();

        if (orderId && tippedSeen.has(orderId)) {
          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("OK (duplicate)");
          return;
        }

        const ts = Date.now();
        const amount = getTippedAmount(payload);
        const isKartonDnia = isKartonDniaAmount(amount);
        const goalLabel = extractGoalLabel(payload);

        // Jeśli webhook ma ustawiony "Zbiórka / Cel" (cokolwiek niepustego) – traktujemy jako zbiórkę,
        // NIE dodajemy do czytnika pytań. Wyjątek: 5 zł odpala specjalny wpis KARTON DNIA.
        if (goalLabel && !isKartonDnia) {
          try {
            if (mainWindow && !mainWindow.isDestroyed()) {
              mainWindow.webContents.send("wb-tipped-fund", {
                ts,
                amount: amount ?? null,
                goal: goalLabel,
                payer: payerName,
                message: message || "",
                orderId: orderId || null,
              });
            }
          } catch {}

          if (orderId) {
            tippedSeen.add(orderId);
            saveSeenOrders();
          }

          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("OK (fund)");
          return;
        }

        const meta = computeQuestionsMeta(amount);

        // Opłacone pytania wpadają do kolejki nawet bez wiadomości — wtedy pokazujemy "CZEKAM NA PYTANIE".
        // Poniżej 30 zł nie dodajemy normalnego pytania (wyjątek: KARTON DNIA za ok. 10 zł).
        if (!isKartonDnia && meta.count <= 0) {
          // Kwota nie trafiła w żaden próg (Karton Dnia ~10 zł / Pytanie od 30 zł) —
          // zamiast po cichu ignorować, informujemy prowadzącą na dole kolejki ile brakuje.
          if (amount !== null && amount !== undefined && Number.isFinite(amount) && amount > 0) {
            const shortfallToQuestion = Math.max(0, Math.round((30 - amount) * 100) / 100);
            try {
              if (mainWindow && !mainWindow.isDestroyed()) {
                mainWindow.webContents.send("wb-tipped-shortfall", {
                  ts,
                  nick: payerName,
                  amount,
                  shortfallToQuestion,
                });
              }
            } catch {}
          }

          if (orderId) {
            tippedSeen.add(orderId);
            saveSeenOrders();
          }
          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("OK (amount below question threshold)");
          return;
        }

        const base = normalizeQuestionLine(payerName, isKartonDnia ? KARTON_DNIA_TEXT : (message || "x"));
        const nick = base.nick;
        const question = isKartonDnia ? KARTON_DNIA_TEXT : base.question;
        const kind = isKartonDnia ? "karton" : null;
        const questionCount = isKartonDnia ? 1 : Math.max(1, meta.count || 1);

        // Log chronologii (dla sortowania w rendererze)
        appendJsonlOutputFile(AUTO_LOG_JSONL, { ts, nick, question, kind, orderId: orderId || null, amount: amount ?? null, priority: !!meta.priority, questionCount });
        // Nie dopisujemy już pytań do zewnętrznych TXT — program trzyma kolejkę w pamięci.

        if (orderId) {
          tippedSeen.add(orderId);
          saveSeenOrders();
        }

        // Notify renderer for a subtle toast/log (optional)
        try {
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send("wb-tipped-question", {
              nick,
              question,
              ts,
              amount: amount ?? null,
              priority: !!meta.priority,
              kind,
              questionCount,
            });
          }
        } catch {}

        res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("OK");
      });
    } catch (e) {
      res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Server error");
    }
  });

  tippedServer.listen(tippedPort, "127.0.0.1", () => {
    console.log(`[WB] Tipped webhook server listening on http://127.0.0.1:${tippedPort}/webhook`);
  });
}

function stopTippedServer() {
  try { if (tippedServer) tippedServer.close(); } catch {}
  tippedServer = null;
}

function ensureOutputDir() {
  if (OUTPUT_DIR) return OUTPUT_DIR;
  const desktop = app.getPath("desktop");
  OUTPUT_DIR = path.join(desktop, "KVRINA_SHOW TXT");
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }
  return OUTPUT_DIR;
}


// =========================
// DŹWIĘKI: powiadomienia o nowym pytaniu + muzyka w tle
// Pliki wrzuca się do dwóch folderów obok reszty danych programu.
// Odtwarzaniem zajmuje się główne (ukryte) okno — jest zawsze żywe, więc muzyka
// nie urywa się przy zamykaniu paneli czy czytnika.
// =========================
const SOUNDS_DIR_NAME = "dzwieki";
const NOTIFY_SUBDIR = "powiadomienia";
const MUSIC_SUBDIR = "muzyka";
const SHUFFLE_SUBDIR = "tasowanie";
const AUDIO_EXTS = [".mp3", ".wav", ".m4a", ".ogg", ".oga", ".aac", ".flac", ".opus"];

function getSoundsDir() {
  const dir = path.join(ensureOutputDir(), SOUNDS_DIR_NAME);
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}
function getNotifyDir() {
  const d = path.join(getSoundsDir(), NOTIFY_SUBDIR);
  try { fs.mkdirSync(d, { recursive: true }); } catch {}
  return d;
}
function getMusicDir() {
  const d = path.join(getSoundsDir(), MUSIC_SUBDIR);
  try { fs.mkdirSync(d, { recursive: true }); } catch {}
  return d;
}
function getShuffleDir() {
  const d = path.join(getSoundsDir(), SHUFFLE_SUBDIR);
  try { fs.mkdirSync(d, { recursive: true }); } catch {}
  return d;
}

function listAudioFiles(dir) {
  try {
    return fs.readdirSync(dir)
      .filter((f) => !f.startsWith(".") && AUDIO_EXTS.includes(path.extname(f).toLowerCase()))
      .sort((a, b) => a.localeCompare(b, "pl"));
  } catch {
    return [];
  }
}

// Krótkie readme, żeby po otwarciu folderu było jasne co tu wrzucić.
function ensureSoundFolders() {
  try {
    const notify = getNotifyDir();
    const music = getMusicDir();
    const shuffle = getShuffleDir();
    const readme = path.join(getSoundsDir(), "JAK-UZYWAC.txt");
    if (!fs.existsSync(readme)) {
      fs.writeFileSync(readme, [
        "DŹWIĘKI W KVRINA_SHOW",
        "",
        `1) ${NOTIFY_SUBDIR}/  — krótki dźwięk odtwarzany, gdy do kolejki wpadnie nowe pytanie.`,
        "   Wrzuć tu jeden lub kilka plików. W panelu DŹWIĘK wybierasz który ma grać.",
        "",
        `2) ${MUSIC_SUBDIR}/  — muzyka lecąca w tle podczas live (odtwarzana w kółko).`,
        "   Wrzuć tu dowolną liczbę utworów.",
        "",
        `3) ${SHUFFLE_SUBDIR}/  — dźwięk tasowania kart przy losowaniu Kartona Dnia.`,
        "   Gra przez cały czas tasowania i urywa się, gdy wypadnie zwycięzca.",
        "   Krótki plik zapętla się sam, więc nie musi mieć dokładnej długości.",
        "",
        "Obsługiwane formaty: mp3, wav, m4a, ogg, aac, flac, opus.",
        "Głośność każdego z nich ustawiasz osobno w programie: menu → DŹWIĘK.",
        "",
      ].join("\n"), "utf8");
    }
    return { notify, music, shuffle };
  } catch (e) {
    console.warn("[DŹWIĘK] nie mogę utworzyć folderów:", e.message);
    return null;
  }
}

const SOUND_DEFAULTS = {
  notifyEnabled: true,
  notifyVolume: 0.7,
  notifyFile: null,     // null = pierwszy dostępny
  musicEnabled: true,   // muzyka startuje sama razem z programem
  musicVolume: 0.18,    // cicho, bo to tło pod mówienie
  musicShuffle: true,
  shuffleEnabled: true, // dźwięk tasowania kart przy losowaniu Kartona Dnia
  shuffleVolume: 0.6,
  shuffleFile: null,    // null = pierwszy dostępny
};

function getSoundSettings() {
  const s = (_appConfig && _appConfig.sound) || {};
  return { ...SOUND_DEFAULTS, ...s };
}

function setSoundSettings(patch) {
  if (!_appConfig || typeof _appConfig !== "object") _appConfig = {};
  _appConfig.sound = { ...getSoundSettings(), ...(patch || {}) };
  saveAppConfig();
  // Silnik (główne okno) natychmiast reaguje na zmianę głośności / włącznika.
  _wbSendToRenderer("wb-sound-settings", _appConfig.sound);
  _broadcastToAllWindows("wb-sound-settings-changed", _appConfig.sound);
  return _appConfig.sound;
}

// Stan odtwarzania raportowany przez główne okno — panel go tylko czyta.
let _soundNowPlaying = { track: null, playing: false };

// =========================
// GITHUB AUTO-AKTUALIZACJE
// =========================
const GITHUB_LATEST_JSON = "https://raw.githubusercontent.com/pioniton-cmyk/kvrina-show-releases/main/latest.json";

function compareVersions(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const na = pa[i] || 0, nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

function checkGitHubRelease() {
  return new Promise((resolve) => {
    const req = https.get(GITHUB_LATEST_JSON, {
      headers: { "User-Agent": "KVRINA_SHOW" }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        resolve({ available: false, error: "redirect" });
        return;
      }
      let data = "";
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        try {
          const remote = JSON.parse(data);
          const pkgPath = path.join(__dirname, "package.json");
          const current = JSON.parse(fs.readFileSync(pkgPath, "utf8")).version || "0.0.0";
          const latestVersion = remote.version || "0.0.0";
          const available = compareVersions(latestVersion, current) > 0;
          resolve({
            available,
            latestVersion,
            currentVersion: current,
            downloadUrl: remote.zipUrl || null,
            assetName: remote.zipName || "update.zip",
            releaseNotes: remote.notes || "",
            publishedAt: remote.publishedAt || ""
          });
        } catch (e) {
          resolve({ available: false, error: e.message });
        }
      });
    });
    req.on("error", (e) => resolve({ available: false, error: e.message }));
    req.setTimeout(9000, () => { req.destroy(); resolve({ available: false, error: "timeout" }); });
  });
}

function downloadFileToPath(url, destPath) {
  return new Promise((resolve, reject) => {
    const follow = (u, hops) => {
      if (hops > 6) return reject(new Error("Za dużo przekierowań"));
      const mod = u.startsWith("https") ? https : http;
      mod.get(u, { headers: { "User-Agent": "KVRINA_SHOW" } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          return follow(res.headers.location, hops + 1);
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error(`HTTP ${res.statusCode}`));
        }
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on("finish", () => file.close(resolve));
        file.on("error", (e) => { try { fs.unlinkSync(destPath); } catch {} reject(e); });
      }).on("error", reject);
    };
    follow(url, 0);
  });
}

// =========================
// AKTUALIZACJE Z ZIPA
// =========================
const UPDATE_DIR_NAME = "aktualizacje";
const UPDATE_BACKUP_DIR_NAME = "backupy_aktualizacji";

function getAppBaseDir() {
  // Bez --asar: __dirname to realny folder z plikami zarówno w dev jak i w .app.
  return __dirname;
}

function ensureUpdatesDir() {
  const dir = path.join(getAppBaseDir(), UPDATE_DIR_NAME);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function ensureUpdateBackupsDir() {
  const dir = path.join(getAppBaseDir(), UPDATE_BACKUP_DIR_NAME);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function updateTimestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

function listUpdateZips() {
  const dir = ensureUpdatesDir();
  const files = fs.readdirSync(dir)
    .filter((name) => /\.zip$/i.test(name) && !name.startsWith("._"))
    .map((name) => {
      const fullPath = path.join(dir, name);
      const st = fs.statSync(fullPath);
      return { name, fullPath, mtimeMs: st.mtimeMs, size: st.size };
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);
  return files;
}

function copyDirSync(src, dest, skipNames = new Set()) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    const base = path.basename(src);
    if (skipNames.has(base)) return;
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      if (skipNames.has(entry)) continue;
      copyDirSync(path.join(src, entry), path.join(dest, entry), skipNames);
    }
    return;
  }
  if (st.isFile()) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
    try { fs.chmodSync(dest, st.mode); } catch {}
  }
}

function extractZipTo(zipPath, destDir) {
  fs.rmSync(destDir, { recursive: true, force: true });
  fs.mkdirSync(destDir, { recursive: true });

  let r;
  if (process.platform === "win32") {
    const cmd = `Expand-Archive -LiteralPath ${JSON.stringify(zipPath)} -DestinationPath ${JSON.stringify(destDir)} -Force`;
    r = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd], { encoding: "utf8" });
  } else {
    r = spawnSync("ditto", ["-x", "-k", zipPath, destDir], { encoding: "utf8" });
    if (r.error || r.status !== 0) {
      r = spawnSync("unzip", ["-q", "-o", zipPath, "-d", destDir], { encoding: "utf8" });
    }
  }

  if (r.error) throw r.error;
  if (r.status !== 0) {
    throw new Error((r.stderr || r.stdout || "Nie udało się rozpakować ZIPa.").trim());
  }
}

function resolveUpdateRoot(tmpDir) {
  const entries = fs.readdirSync(tmpDir).filter((x) => !x.startsWith("__MACOSX") && x !== ".DS_Store");
  const hasMainHere = ["main.js", "package.json", "index.html"].some((name) => fs.existsSync(path.join(tmpDir, name)));
  if (hasMainHere) return tmpDir;
  if (entries.length === 1) {
    const only = path.join(tmpDir, entries[0]);
    if (fs.existsSync(only) && fs.statSync(only).isDirectory()) return only;
  }
  return tmpDir;
}

function readPackageVersionSafe(dir) {
  try {
    const p = path.join(dir, "package.json");
    if (!fs.existsSync(p)) return null;
    const obj = JSON.parse(fs.readFileSync(p, "utf8") || "{}");
    return obj.version || null;
  } catch { return null; }
}

function sanitizeZipFileName(name) {
  return String(name || "update.zip").replace(/[/\\?%*:|"<>]/g, "_");
}

function copyZipToUpdatesDir(sourcePath) {
  const dir = ensureUpdatesDir();
  const base = sanitizeZipFileName(path.basename(sourcePath));
  let dest = path.join(dir, base);
  if (path.resolve(sourcePath) === path.resolve(dest)) {
    return { ok: true, fullPath: dest, name: base, copied: false };
  }
  if (fs.existsSync(dest)) {
    const ext = path.extname(base) || ".zip";
    const stem = path.basename(base, ext);
    dest = path.join(dir, `${stem}_${updateTimestamp()}${ext}`);
  }
  fs.copyFileSync(sourcePath, dest);
  return { ok: true, fullPath: dest, name: path.basename(dest), copied: true };
}

function getUpdateSkipNames() {
  return new Set([
    "node_modules", "aktualizacje", "backupy_aktualizacji",
    "dist", ".git", ".cache", "tmp_update", "__MACOSX"
  ]);
}

function installUpdateZipFromPath(zipFullPath, zipLabel) {
  const zipName = zipLabel || path.basename(zipFullPath);
  const appDir = getAppBaseDir();
  const stamp = updateTimestamp();
  const tmpDir = path.join(ensureUpdatesDir(), `_tmp_instalacja_${stamp}`);
  const backupDir = path.join(ensureUpdateBackupsDir(), `backup_${stamp}`);
  const skip = getUpdateSkipNames();

  try {
    if (!zipFullPath || !fs.existsSync(zipFullPath)) {
      throw new Error("Nie znaleziono pliku ZIP aktualizacji.");
    }
    copyDirSync(appDir, backupDir, skip);
    extractZipTo(zipFullPath, tmpDir);
    const updateRoot = resolveUpdateRoot(tmpDir);
    const detectedVersion = readPackageVersionSafe(updateRoot);

    const looksLikeProgram = ["main.js", "package.json", "index.html"].some((name) => fs.existsSync(path.join(updateRoot, name)));
    if (!looksLikeProgram) {
      throw new Error("ZIP nie wygląda jak paczka KVRINA_SHOW — brakuje main.js / package.json / index.html.");
    }

    copyDirSync(updateRoot, appDir, skip);
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}

    return {
      ok: true,
      zip: zipName,
      zipPath: zipFullPath,
      backupDir,
      appDir,
      version: detectedVersion || readPackageVersionSafe(appDir),
      message: "Aktualizacja zainstalowana.",
    };
  } catch (e) {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
    return { ok: false, error: e.message, zip: zipName, backupDir };
  }
}

function installNewestUpdateZip() {
  const zips = listUpdateZips();
  if (!zips.length) {
    return { ok: false, error: "Brak pliku .zip w folderze aktualizacje." };
  }
  return installUpdateZipFromPath(zips[0].fullPath, zips[0].name);
}

async function pickUpdateZipPath() {
  const win = BrowserWindow.getFocusedWindow() || mainWindow;
  const pick = await dialog.showOpenDialog(win, {
    title: "Wybierz paczkę aktualizacji KVRINA_SHOW (.zip)",
    filters: [{ name: "ZIP", extensions: ["zip"] }],
    properties: ["openFile"],
  });
  if (pick.canceled || !pick.filePaths || !pick.filePaths.length) {
    return { ok: false, cancelled: true, error: "Anulowano wybór pliku." };
  }
  return { ok: true, filePath: pick.filePaths[0] };
}

async function finalizeUpdateInstallResult(result) {
  if (!result.ok) return result;
  try {
    const choice = await dialog.showMessageBox(mainWindow, {
      type: "info",
      title: "KVRINA_SHOW — aktualizacja zainstalowana",
      message: `Zainstalowano aktualizację${result.version ? " do wersji " + result.version : ""}.`,
      detail: `ZIP: ${result.zip}\nBackup programu: ${result.backupDir}\n\nZrestartować program teraz?`,
      buttons: ["Restart teraz", "Później"],
      defaultId: 0,
      cancelId: 1,
    });
    if (choice.response === 0) {
      app.relaunch({ execPath: process.execPath });
      app.exit(0);
    }
  } catch {}
  return result;
}

function listUpdateBackups() {
  const dir = ensureUpdateBackupsDir();
  return fs.readdirSync(dir)
    .filter((name) => name.startsWith("backup_"))
    .map((name) => {
      const fullPath = path.join(dir, name);
      const st = fs.statSync(fullPath);
      return { name, fullPath, mtimeMs: st.mtimeMs };
    })
    .filter((x) => {
      try { return fs.statSync(x.fullPath).isDirectory(); } catch { return false; }
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);
}

function restorePreviousUpdateBackup() {
  const backups = listUpdateBackups();
  if (!backups.length) {
    return { ok: false, error: "Brak backupu poprzedniej wersji w folderze backupy_aktualizacji." };
  }

  const backup = backups[0];
  const appDir = getAppBaseDir();
  const stamp = updateTimestamp();
  const beforeRestoreDir = path.join(ensureUpdateBackupsDir(), `backup_przed_cofnieciem_${stamp}`);
  const skip = getUpdateSkipNames();

  try {
    copyDirSync(appDir, beforeRestoreDir, skip);
    copyDirSync(backup.fullPath, appDir, skip);
    return {
      ok: true,
      restoredFrom: backup.name,
      restoredFromPath: backup.fullPath,
      beforeRestoreDir,
      appDir,
      version: readPackageVersionSafe(appDir),
      message: "Poprzednia wersja została przywrócona."
    };
  } catch (e) {
    return { ok: false, error: e.message, restoredFrom: backup.name, beforeRestoreDir };
  }
}


let _appConfigLoaded = false;
let _appConfig = {};

function getConfigPath() {
  const dir = ensureOutputDir();
  return path.join(dir, "config.json");
}

function loadAppConfig() {
  try {
    const p = getConfigPath();
    if (fs.existsSync(p)) {
      const raw = fs.readFileSync(p, "utf8");
      const obj = JSON.parse(raw || "{}");
      _appConfig = obj && typeof obj === "object" ? obj : {};
      if (typeof _appConfig.tippedHash === "string" && _appConfig.tippedHash.trim()) {
        TIPPED_HASH = _appConfig.tippedHash.trim();
      }
    }
  } catch (e) {
    console.warn("[WB] config.json load error:", e.message);
  } finally {
    _appConfigLoaded = true;
  }
}

function saveAppConfig() {
  try {
    const p = getConfigPath();
    fs.writeFileSync(p, JSON.stringify(_appConfig || {}, null, 2), "utf8");
    return true;
  } catch (e) {
    console.warn("[WB] config.json save error:", e.message);
    return false;
  }
}


// Domyślne wartości liczników (pliki do OBS)
const DEFAULT_COUNTER_1 = "00:00:00";
const DEFAULT_COUNTER_2 = "00:00";

function safeWriteOutputFileSync(filename, data) {
  try {
    const dir = ensureOutputDir();
    const fullPath = path.join(dir, filename);
    fs.writeFileSync(fullPath, data ?? "", "utf-8");
  } catch (err) {
    console.error("safeWriteOutputFileSync error:", filename, err);
  }
}

function appendJsonlOutputFile(name, obj) {
  try {
    const dir = ensureOutputDir();
    const fullPath = path.join(dir, name);
    fs.appendFileSync(fullPath, JSON.stringify(obj) + "\n", "utf8");
    return true;
  } catch (e) {
    console.error("appendJsonlOutputFile error:", name, e.message);
    return false;
  }
}

function _num(v) {
  const n = typeof v === "number" ? v : parseFloat(String(v || "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function getTippedAmount(payload) {
  try {
    const keys = [
      "amount",
      "amount_value",
      "amountValue",
      "value",
      "price",
      "gross_amount",
      "grossAmount",
      "amount_gross",
      "amountGross",
      "amount_brutto",
      "amountBrutto",
      "amount_pln",
      "amountPLN",
    ];

    const normalizePln = (n, rawVal) => {
      if (n === null || n === undefined || !Number.isFinite(n)) return null;

      // Heurystyka TIPPED: część webhooków wysyła kwotę w groszach (np. 3000 zamiast 30.00).
      // Jeśli oryginał wygląda na "złotówki z przecinkiem" → zostaw.
      const rawStr = typeof rawVal === "string" ? rawVal.trim() : "";
      const rawLooksDecimal = rawStr && /[.,]\d{1,2}\s*$/.test(rawStr);

      if (!rawLooksDecimal && Number.isInteger(n) && n >= 1000) {
        // najczęściej: 3000 -> 30.00
        const pln = n / 100;
        return Math.round(pln * 100) / 100;
      }

      return Math.round(n * 100) / 100;
    };

    for (const k of keys) {
      if (payload && Object.prototype.hasOwnProperty.call(payload, k)) {
        const rawVal = payload[k];
        const n = _num(rawVal);
        if (n !== null) {
          const pln = normalizePln(n, rawVal);
          if (pln !== null) return pln;
        }
      }
    }
  } catch {}
  return null;
}


function _inAmountRange(amount, low, high) {
  const a = typeof amount === "number" ? amount : parseFloat(String(amount || "").replace(",", "."));
  if (!Number.isFinite(a)) return false;
  const eps = 0.005; // tolerancja na zaokrąglenia (0.5 grosza)
  return a + eps >= low && a - eps <= high;
}

function isKartonDniaAmount(amount) {
  // KARTON DNIA odpala się tylko dla wpłaty około 10,00 zł.
  // Tolerancja 1 grosza chroni przed formatami 9.99 / 10 / 10.00 z webhooka.
  return _inAmountRange(amount, 9.99, 10.01);
}

// Zasady liczenia pytań po kwocie (Tipped)
// UWAGA: amount jest już w PLN (po normalizacji z groszy, jeśli webhook tak wysyła).
//
// Cennik live:
//   30 zł  = 1 pytanie
//   60 zł  = 2 pytania
//   80 zł  = 3 pytania          <- ostatni „pakietowy" próg
//   100 zł = 1 pytanie POZA KOLEJKĄ (osobna, droższa opcja — nie pakiet)
//   powyżej 80 zł każde kolejne pełne 30 zł to +1 pytanie: 110 = 4, 140 = 5, 170 = 6…
const QUESTIONS_MAX_PER_PAYMENT = 12; // bezpiecznik przy literówce w kwocie

function computeQuestionsMeta(amount) {
  if (amount === null || amount === undefined || !Number.isFinite(amount)) {
    // Awaryjnie: jeśli Tipped zmieni format i kwoty nie uda się odczytać,
    // nie blokujemy pytania z wiadomością.
    return { count: 1, priority: false };
  }

  // POZA KOLEJKĄ: dokładnie 100 zł. Celowo NIE „od 100 w górę" — inaczej zjadałoby
  // to próg 110 zł (4 pytania) i wyżej.
  if (_inAmountRange(amount, 99.99, 100.01)) {
    return { count: 1, priority: true };
  }

  if (amount >= 80) {
    // 80 zł = 3 pytania, potem co pełne 30 zł jedno więcej.
    const extra = Math.floor((amount - 80 + 0.005) / 30);
    return { count: Math.min(QUESTIONS_MAX_PER_PAYMENT, 3 + extra), priority: false };
  }
  if (amount >= 60) return { count: 2, priority: false };
  if (amount >= 30) return { count: 1, priority: false };

  // Poniżej 30 zł nie robimy normalnego pytania (wyjątek: KARTON DNIA obsługiwany osobno).
  return { count: 0, priority: false };
}


// Rozpoznawanie "Zbiórka / Cel" w webhooku Tipped.
// Jeśli w payloadzie istnieje jakiekolwiek sensowne (niepuste) pole celu/zbiórki/kampanii,
// traktujemy wpłatę jako ZBIÓRKĘ (oddzielny licznik) i NIE wysyłamy jej do czytnika pytań.
function extractGoalLabel(payload) {
  try {
    const KEY_HINT = /(goal|cel|zbi[oó]rka|zbiorka|campaign|collection|target|fund|fundraiser|purpose|event)/i;

    const isEmpty = (s) => {
      const t = String(s || "").trim();
      if (!t) return true;
      if (t === "-" || t === "—" || t === "–") return true;
      if (/^[-–—]+$/.test(t)) return true;
      return false;
    };

    const fromValue = (v, depth) => {
      if (depth > 6 || v === null || v === undefined) return null;

      if (typeof v === "string") {
        const t = v.trim();
        return isEmpty(t) ? null : t;
      }

      if (typeof v !== "object") return null;

      if (Array.isArray(v)) {
        for (const it of v) {
          const r = fromValue(it, depth + 1);
          if (r) return r;
        }
        return null;
      }

      // typowe miejsca, gdzie siedzi nazwa zbiórki
      for (const k of ["name", "title", "label", "goalName", "campaignName", "campaignTitle"]) {
        if (typeof v[k] === "string") {
          const t = String(v[k] || "").trim();
          if (!isEmpty(t)) return t;
        }
      }

      // w obiekcie celu często jest np. { id, name }, więc jeśli nie znaleźliśmy,
      // przejdź po polach i spróbuj wyciągnąć pierwszą niepustą nazwę.
      for (const [k, val] of Object.entries(v)) {
        if (typeof val === "string") {
          const t = String(val || "").trim();
          if (!isEmpty(t) && /name|title|label/i.test(String(k || ""))) return t;
        }
      }

      return null;
    };

    const seen = new Set();

    const scan = (obj, depth) => {
      if (depth > 6 || obj === null || obj === undefined) return null;
      if (typeof obj !== "object") return null;

      if (seen.has(obj)) return null;
      seen.add(obj);

      if (Array.isArray(obj)) {
        for (const it of obj) {
          const r = scan(it, depth + 1);
          if (r) return r;
        }
        return null;
      }

      for (const [k, v] of Object.entries(obj)) {
        const key = String(k || "");
        if (!key) continue;

        // Jeśli klucz wskazuje na cel/zbiórkę/kampanię -> spróbuj wyciągnąć label
        if (KEY_HINT.test(key)) {
          const label = fromValue(v, depth + 1);
          if (label) return label;
        }

        // Idź głębiej, bo czasem cel jest zagnieżdżony w data/meta/extra...
        if (v && typeof v === "object") {
          const r = scan(v, depth + 1);
          if (r) return r;
        }
      }

      return null;
    };

    if (!payload || typeof payload !== "object") return null;
    return scan(payload, 0);
  } catch {
    return null;
  }
}


function applyQuestionsSuffix(nick, amount) {
  const n = String(nick || "").trim();
  const meta = computeQuestionsMeta(amount);
  if (meta.count >= 2) return `${n} -${meta.count}pyt`;
  return n;
}



function resetCounterFilesSync() {
  safeWriteOutputFileSync("odliczanie1.txt", DEFAULT_COUNTER_1);
  safeWriteOutputFileSync("odliczanie2.txt", DEFAULT_COUNTER_2);
}



function ensureCounterFilesExist() {
  const dir = ensureOutputDir();
  const p1 = path.join(dir, "odliczanie1.txt");
  const p2 = path.join(dir, "odliczanie2.txt");
  try {
    if (!fs.existsSync(p1)) fs.writeFileSync(p1, DEFAULT_COUNTER_1, "utf8");
    if (!fs.existsSync(p2)) fs.writeFileSync(p2, DEFAULT_COUNTER_2, "utf8");
  } catch (err) {
    console.error("ensureCounterFilesExist error:", err);
  }
}


// =========================
// GLOBAL SHORTCUTS (działają nawet gdy okno nie jest aktywne)
// Wariant 1 (Windows): Ctrl + Alt + Shift + → / ←
// W Electronie rejestrujemy to jako: CommandOrControl + Alt + Shift + Right/Left
// (na Windowsie to będzie Ctrl, na macOS Command)
// =========================
function _wbSendToRenderer(channel, payload) {
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send(channel, payload);
    }
  } catch (e) {
    console.error("wbSendToRenderer error:", e);
  }
}

function registerGlobalShortcuts() {
  const nextOk = globalShortcut.register(
    "CommandOrControl+Alt+Shift+Right",
    () => _wbSendToRenderer("wb-questions-next")
  );

  const prevOk = globalShortcut.register(
    "CommandOrControl+Alt+Shift+Left",
    () => _wbSendToRenderer("wb-questions-prev")
  );

  if (!nextOk) {
    console.warn("[WB] Nie udało się zarejestrować globalnego skrótu: Ctrl+Alt+Shift+Right");
  }
  if (!prevOk) {
    console.warn("[WB] Nie udało się zarejestrować globalnego skrótu: Ctrl+Alt+Shift+Left");
  }
}


function createWindow() {
  const savedWindow = getSavedWindowOptions("mainWindow", { width: 1400, height: 900 });

  const iconPath = path.join(__dirname, "icon.icns");
  const appIcon = fs.existsSync(iconPath) ? nativeImage.createFromPath(iconPath) : null;

  mainWindow = new BrowserWindow({
    width: savedWindow.width,
    height: savedWindow.height,
    x: savedWindow.x,
    y: savedWindow.y,
    icon: appIcon || undefined,
    // Główne okno nie pokazuje się przy starcie — pełni rolę „silnika” w tle
    // (właściciel całego stanu: kolejka, gifty, ranking, kasa, połączenie z TikTokiem,
    // zapis widget_state.json). Widoczny jest tylko czytnik i panele otwierane z menu.
    // Pokazywane jest tylko na wyraźne żądanie (WIDGETY / AKTUALIZACJE / DIAGNOSTYKA).
    show: false,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
      // Ukryte okno musi działać pełną prędkością (bez usypiania timerów w tle),
      // bo to ono przetwarza eventy live i odświeża stan dla czytnika/widgetów.
      backgroundThrottling: false,
    },
  });

  if (appIcon && app.dock) {
    app.dock.setIcon(appIcon);
  }

  attachWindowPlacementMemory("mainWindow", mainWindow);

  // Główne okno jest praktycznie zawsze ukryte (silnik w tle), a mimo to przebudowywało
  // pełne listy (kolejka, obserwujący, gifty) przy każdym evencie z live — dla nikogo.
  // Informujemy renderer o widoczności, żeby mógł pomijać rysowanie gdy okna nie widać.
  const sendVisibility = (visible) => {
    try {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("wb-main-visibility", { visible: !!visible });
      }
    } catch {}
  };
  mainWindow.on("show", () => sendVisibility(true));
  mainWindow.on("hide", () => sendVisibility(false));

  if (savedWindow.isMaximized) {
    try { mainWindow.maximize(); } catch {}
  }
  if (savedWindow.isFullScreen) {
    try { mainWindow.setFullScreen(true); } catch {}
  }

  mainWindow.loadFile("index.html");
  mainWindow.webContents.on("did-finish-load", async () => {
    try {
      // Wyślij do renderer ostatnio użyte ścieżki (żeby ustawiło się automatycznie przy starcie)
      mainWindow.webContents.send("wb-last-question-paths", {
        manual: MANUAL_QUESTIONS_FILE_PATH,
        auto: AUTO_QUESTIONS_FILE_PATH,
      });
    } catch {}

    // AUTOSTART: odpal tunel cloudflared i pokaż URL w UI (tylko w zapakowanej wersji — patrz wyżej przy webhooku)
    try {
      if (app.isPackaged) startQuickTunnel();
    } catch {}
  });


  // Główne okno to silnik całej aplikacji — nie wolno go zniszczyć klikając „X”,
  // bo zatrzymałoby to czytnik, obsługę live i zapis widgetów. Zamiast zamykać,
  // chowamy je (widoczne tylko na żądanie). Realne zamknięcie następuje wyłącznie
  // przy wychodzeniu z programu (before-quit ustawia isQuitting).
  mainWindow.on("close", (e) => {
    if (!isQuitting) {
      e.preventDefault();
      try { mainWindow.hide(); } catch {}
    }
  });

  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}
app.whenReady().then(() => {
  const _startPkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
  const _snap0 = getPerformanceSnapshot();
  diagInfo(`=== KVRINA_SHOW v${_startPkg.version || "?"} start === platform=${process.platform}/${process.arch} electron=${process.versions.electron} RAM=${_snap0.rssMB}MB free=${_snap0.freeRamMB}/${_snap0.totalRamMB}MB`);
  recordPerfSample(_snap0);
  // Próbka do historii co minutę (tanie: memoryUsage + os.freemem), wpis do logu co 5 minut.
  setInterval(() => { recordPerfSample(getPerformanceSnapshot()); }, 60 * 1000);
  setInterval(() => {
    const s = getPerformanceSnapshot();
    recordPerfSample(s);
    diagInfo(`[PERF] heap=${s.heapUsedMB}/${s.heapTotalMB}MB rss=${s.rssMB}MB cpu=${s.cpuPct}% freeRAM=${s.freeRamMB}MB uptime=${s.uptime}s load=${s.loadAvg}`);
    // Zapis na dysk co 5 min — dzięki temu dane przetrwają zawieszenie i wymuszone zamknięcie.
    savePerfState(false);
    maybeAutoReportProblems(s);
  }, 5 * 60 * 1000);
  ensureOutputDir();
  ensureUpdatesDir();
  ensureUpdateBackupsDir();
  ensureCounterFilesExist();
  ensureSoundFolders();
  writeWidgetAssetFiles();

  // wczytaj ostatnie ustawienia (pliki TXT)
  loadPrefs();
  loadAppConfig();

  // Czy poprzednia sesja zakończyła się poprawnie? Jeśli nie — zgłoś to automatycznie.
  // Musi być PO loadAppConfig (potrzebne ustawienie autoReport), ale zaraz na starcie.
  checkPreviousSessionAndReport();
  savePerfState(false); // od teraz sesja jest "otwarta"

  // W wersji dev (uruchomionej z folderu źródłowego, nie z zapakowanej paczki)
  // webhook Tipped + tunel startują TYLKO ręcznie (przełącznik w oknie czytnika) —
  // żeby nie kolidować portami z równolegle działającą prawdziwą paczką na żywo.
  // Wszystkie zapakowane wersje (w tym aktualizacje z GitHub) zachowują się jak dotychczas.
  if (app.isPackaged) {
    startTippedServer();
  } else {
    diagInfo("[DEV] Webhook Tipped domyślnie wyłączony w wersji dev — włącz przełącznikiem w oknie czytnika, jeśli potrzebny.");
  }
  startWidgetServer();
  createWindow();
  createReaderWindow(); // domyślnie otwiera się razem z programem
  registerGlobalShortcuts();

  app.on("activate", () => {
    // Główne okno jest ukryte (silnik w tle) — po kliknięciu ikony w Docku
    // przywracamy WIDOCZNY czytnik, a nie niewidoczne główne okno.
    if (!mainWindow || mainWindow.isDestroyed()) {
      createWindow();
    }
    createReaderWindow();
  });
});

app.on("before-quit", () => {
  isQuitting = true;
  // Znacznik czystego wyjścia — brak tego zapisu przy następnym starcie
  // oznacza, że program został zawieszony lub ubity.
  try { savePerfState(true); } catch {}
  try { resetTxtFilesOnExit(); } catch {}
  try { stopTunnel(); } catch {}
  try { if (widgetServer) widgetServer.close(); } catch {}
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

// IPC: OUTPUT DIR
ipcMain.handle("wb-get-output-dir", async () => {
  try {
    const dir = ensureOutputDir();
    return dir;
  } catch (err) {
    console.error("wb-get-output-dir error:", err);
    throw err;
  }
});

// IPC: OPEN OUTPUT DIR (Explorer)
ipcMain.handle("wb-open-output-dir", async () => {
  try {
    const dir = ensureOutputDir();
    await shell.openPath(dir);
    return { ok: true };
  } catch (err) {
    console.error("wb-open-output-dir error:", err);
    return { ok: false, error: err.message };
  }
});




// IPC: OPEN WIDGETS DIR
ipcMain.handle("wb-open-widgets-dir", async () => {
  try {
    writeWidgetAssetFiles();
    const dir = getWidgetsDir();
    await shell.openPath(dir);
    return { ok: true, dir };
  } catch (err) {
    console.error("wb-open-widgets-dir error:", err);
    return { ok: false, error: err.message };
  }
});


// =========================
// IPC: AKTUALIZACJE Z ZIPA
// =========================
ipcMain.handle("wb-open-updates-dir", async () => {
  try {
    const dir = ensureUpdatesDir();
    await shell.openPath(dir);
    return { ok: true, dir };
  } catch (err) {
    console.error("wb-open-updates-dir error:", err);
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("wb-update-check", async () => {
  try {
    const dir = ensureUpdatesDir();
    const zips = listUpdateZips();
    return { ok: true, dir, zips, backups: listUpdateBackups() };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("wb-update-install", async () => {
  return finalizeUpdateInstallResult(installNewestUpdateZip());
});

ipcMain.handle("wb-update-pick-install", async () => {
  const picked = await pickUpdateZipPath();
  if (!picked.ok) return picked;
  const copied = copyZipToUpdatesDir(picked.filePath);
  const result = installUpdateZipFromPath(copied.fullPath, copied.name);
  if (result.ok && copied.copied) {
    result.savedTo = copied.fullPath;
  }
  return finalizeUpdateInstallResult(result);
});

// Potwierdzenie ZERUJ SESJĘ — natywny dialog BEZ okna-rodzica (celowo), żeby działał
// niezależnie od tego, czy główne okno jest w danej chwili ukryte (jest "silnikiem" w tle
// i ZERUJ SESJĘ jest wywoływane też z menu czytnika). `window.confirm()` w hidden BrowserWindow
// nie pokazuje się i po cichu zwraca false — stąd wcześniejszy bug "reset nic nie robi".
ipcMain.handle("wb-confirm-reset-session", async () => {
  try {
    const r = await dialog.showMessageBox({
      type: "warning",
      title: "KVRINA_SHOW — zerowanie sesji",
      message: "Wyzerować całą sesję?",
      detail: "Wyczyści pytania, kolejki, ranking, gifty, zbiórki i backup sesji. Układ paneli zostaje bez zmian.",
      buttons: ["Anuluj", "Tak, wyzeruj"],
      defaultId: 1,
      cancelId: 0,
    });
    return { ok: true, confirmed: r.response === 1 };
  } catch (err) {
    return { ok: false, confirmed: false, error: err.message };
  }
});

ipcMain.handle("wb-update-restore-previous", async () => {
  try {
    const backups = listUpdateBackups();
    if (!backups.length) return { ok: false, error: "Brak backupu poprzedniej wersji." };

    const ask = await dialog.showMessageBox(mainWindow, {
      type: "warning",
      title: "KVRINA_SHOW — cofnąć wersję?",
      message: "Przywrócić poprzednią wersję programu?",
      detail: `Zostanie użyty najnowszy backup: ${backups[0].name}\n\nObecna wersja też zostanie zabezpieczona, więc można wrócić później.`,
      buttons: ["Cofnij wersję", "Anuluj"],
      defaultId: 0,
      cancelId: 1,
    });
    if (ask.response !== 0) return { ok: false, cancelled: true, error: "Anulowano." };

    const result = restorePreviousUpdateBackup();
    if (!result.ok) return result;

    const choice = await dialog.showMessageBox(mainWindow, {
      type: "info",
      title: "KVRINA_SHOW — wersja przywrócona",
      message: `Przywrócono poprzednią wersję${result.version ? " (" + result.version + ")" : ""}.`,
      detail: `Backup: ${result.restoredFrom}\nZabezpieczenie obecnej wersji: ${result.beforeRestoreDir}\n\nZrestartować program teraz?`,
      buttons: ["Restart teraz", "Później"],
      defaultId: 0,
      cancelId: 1,
    });
    if (choice.response === 0) {
      app.relaunch({ execPath: process.execPath });
      app.exit(0);
    }
    return result;
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// =========================
// IPC: GITHUB AUTO-AKTUALIZACJE
// =========================
ipcMain.handle("wb-github-check", async () => {
  try {
    return await checkGitHubRelease();
  } catch (e) {
    return { available: false, error: e.message };
  }
});

ipcMain.handle("wb-github-download-install", async (event, { downloadUrl, assetName }) => {
  const send = (status, detail) => {
    _broadcastToAllWindows("wb-github-progress", { status, detail });
    console.log(`[AKTUALIZACJA] ${status}${detail ? ": " + detail : ""}`);
  };
  try {
    if (!downloadUrl) return { ok: false, error: "Brak URL do pobrania." };

    // KROK 1 — pobieranie
    send("downloading", downloadUrl);
    const tmpDir = path.join(os.tmpdir(), `kvrina_github_${Date.now()}`);
    fs.mkdirSync(tmpDir, { recursive: true });
    const tmpZip = path.join(tmpDir, assetName || "github_update.zip");
    await downloadFileToPath(downloadUrl, tmpZip);

    const zipSize = fs.statSync(tmpZip).size;
    if (zipSize < 1000) return { ok: false, error: `ZIP za mały (${zipSize} bajtów) — pobieranie nie powiodło się.` };
    send("downloaded", `${(zipSize/1024).toFixed(0)} KB`);

    // KROK 2 — instalacja
    send("installing", `cel: ${getAppBaseDir()}`);
    const result = installUpdateZipFromPath(tmpZip, assetName || "github_update.zip");
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}

    if (!result.ok) {
      send("error", result.error);
      return result;
    }
    send("installed", `wersja: ${result.version || "?"}`);

    // KROK 3 — dialog restartu
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.focus();
    return await finalizeUpdateInstallResult(result);
  } catch (e) {
    send("error", e.message);
    return { ok: false, error: e.message };
  }
});

// =========================
// IPC: CLOUDLFARED QUICK TUNNEL (HTTPS)
// =========================
ipcMain.handle("wb-tunnel-start", async () => {
  const r = startQuickTunnel();
  return { ...r, url: tunnelUrl, webhookUrl: tunnelUrl ? `${tunnelUrl}/webhook` : null };
});

ipcMain.handle("wb-tunnel-stop", async () => {
  stopTunnel();
  return { ok: true };
});

ipcMain.handle("wb-tunnel-get", async () => {
  return { ok: true, url: tunnelUrl, webhookUrl: tunnelUrl ? `${tunnelUrl}/webhook` : null, running: !!tunnelProc };
});

ipcMain.handle("wb-is-dev", async () => ({ isDev: !app.isPackaged }));

ipcMain.handle("wb-webhook-set-enabled", async (event, enabled) => {
  if (enabled) {
    startTippedServer();
    try { startQuickTunnel(); } catch {}
  } else {
    stopTippedServer();
    stopTunnel();
  }
  return { ok: true, running: !!tippedServer };
});

ipcMain.handle("wb-webhook-get-status", async () => {
  return {
    ok: true,
    running: !!tippedServer,
    port: tippedPort,
    pending: tippedPending.length,
    autoFile: AUTO_QUESTIONS_FILE_PATH || null,
    tunnelRunning: !!tunnelProc,
    tunnelUrl: tunnelUrl || null,
    widgetPort,
    widgetUrl: `http://127.0.0.1:${widgetPort}/demo.html`,
    tippedHash: TIPPED_HASH,
    expectedTippedHash: DEFAULT_TIPPED_HASH,
    hashOk: TIPPED_HASH === DEFAULT_TIPPED_HASH,
  };
});


ipcMain.handle("wb-clipboard-copy", async (event, { text }) => {
  try {
    clipboard.writeText(String(text || ""));
    savePrefs();
    savePrefs();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// IPC: WRITE FILE (do katalogu OUTPUT_DIR)
ipcMain.handle("wb-write-file", async (event, { name, data }) => {
  const dir = ensureOutputDir();
  const fullPath = safeJoin(dir, name);
  try {
    if (!fullPath) return { ok: false, error: "Invalid path" };
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, data ?? "", "utf8");
    return { ok: true, fullPath };
  } catch (err) {
    console.error("wb-write-file error:", err);
    return { ok: false, error: err.message };
  }
});


// IPC: APPEND FILE (do katalogu OUTPUT_DIR) — dopisuje na koniec, nie nadpisuje
ipcMain.handle("wb-append-file", async (event, { name, data }) => {
  try {
    const dir = ensureOutputDir();
    const fullPath = safeJoin(dir, name);
    if (!fullPath) return { ok: false, error: "Invalid path" };
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.appendFileSync(fullPath, data ?? "", "utf-8");
    return { ok: true };
  } catch (err) {
    console.error("wb-append-file error:", err);
    return { ok: false, error: err.message };
  }
});


// IPC: READ FILE (z OUTPUT_DIR)
ipcMain.handle("wb-read-file", async (event, { name }) => {
  const dir = ensureOutputDir();
  const fullPath = safeJoin(dir, name);
  try {
    if (!fullPath) return { ok: false, error: "Invalid path" };
    if (!fs.existsSync(fullPath)) {
      return { ok: true, data: "", fullPath };
    }
    const data = fs.readFileSync(fullPath, "utf8");
    return { ok: true, data, fullPath };
  } catch (err) {
    console.error("wb-read-file error:", err);
    return { ok: false, error: err.message };
  }
});

// IPC: READ ABSOLUTE FILE (do pliku z pytaniami)
ipcMain.handle("wb-read-absolute-file", async (event, { fullPath }) => {
  try {
    if (!fs.existsSync(fullPath)) {
      return { ok: false, error: "File not found" };
    }
    const stat = fs.statSync(fullPath);
    const data = fs.readFileSync(fullPath, "utf8");
    return { ok: true, data, mtimeMs: stat.mtimeMs };
  } catch (err) {
    console.error("wb-read-absolute-file error:", err);
    return { ok: false, error: err.message };
  }
});

// IPC: OPEN QUESTION FILE DIALOG
// IPC: OPEN QUESTION FILE DIALOG (manual/auto)
ipcMain.handle("wb-open-question-file", async (event, { mode } = {}) => {
  try {
    const m = String(mode || "").toLowerCase();
    const title = m === "auto" ? "Wybierz plik TXT (AUTO – donejty)" : m === "manual" ? "Wybierz plik TXT (RĘCZNE pytania)" : "Wybierz plik z pytaniami";
    const result = await dialog.showOpenDialog({
      title,
      properties: ["openFile"],
      filters: [{ name: "Pliki tekstowe", extensions: ["txt"] }],
    });
    if (result.canceled || !result.filePaths || !result.filePaths[0]) {
      return { ok: true, canceled: true };
    }
    const fullPath = result.filePaths[0];
    const stat = fs.statSync(fullPath);
    const data = fs.readFileSync(fullPath, "utf8");
    return {
      ok: true,
      canceled: false,
      fullPath,
      data,
      mtimeMs: stat.mtimeMs,
    };
  } catch (err) {
    console.error("wb-open-question-file error:", err);
    return { ok: false, error: err.message };
  }
});

// IPC: SET CURRENT QUESTIONS FILE PATH
// mode: "manual" | "auto" (default: "auto" for backward compatibility)
ipcMain.handle("wb-set-questions-file-path", async (event, { fullPath, mode } = {}) => {
  try {
    if (!fullPath || typeof fullPath !== "string") return { ok: false, error: "Invalid path" };
    const m = String(mode || "auto").toLowerCase();
    if (m === "manual") {
      MANUAL_QUESTIONS_FILE_PATH = fullPath;
      savePrefs();
      return { ok: true };
    }

    AUTO_QUESTIONS_FILE_PATH = fullPath;

    // Flush pending questions captured before file was selected.
    if (tippedPending.length) {
      const pending = tippedPending;
      tippedPending = [];
      for (const it of pending) {
        if (it && it.nick && it.question) {
          appendQuestionBlockToFile(AUTO_QUESTIONS_FILE_PATH, it.nick, it.question);
        }
      }
    }
    savePrefs();
    return { ok: true };

  } catch (e) {
    return { ok: false, error: e.message };
  }
});


// IPC: GET LAST QUESTIONS FILE PATHS (manual + auto)
ipcMain.handle("wb-get-last-questions-file-paths", async () => {
  return {
    ok: true,
    manual: MANUAL_QUESTIONS_FILE_PATH,
    auto: AUTO_QUESTIONS_FILE_PATH,
  };
});

// =========================
// CHAT POP-OUT WINDOW
// =========================
function createChatWindow() {
  if (chatWindow && !chatWindow.isDestroyed()) {
    try { chatWindow.focus(); } catch {}
    return chatWindow;
  }

  const savedChatWindow = getSavedWindowOptions("chatWindow", { width: 460, height: 820 });

  chatWindow = new BrowserWindow({
    width: savedChatWindow.width,
    height: savedChatWindow.height,
    x: savedChatWindow.x,
    y: savedChatWindow.y,
    title: "KVRINA_SHOW — Gifty",
    backgroundColor: "#020308",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  attachWindowPlacementMemory("chatWindow", chatWindow);
  if (savedChatWindow.isMaximized) {
    try { chatWindow.maximize(); } catch {}
  }
  if (savedChatWindow.isFullScreen) {
    try { chatWindow.setFullScreen(true); } catch {}
  }

  chatWindow.setMenuBarVisibility(false);

  try {
    chatWindow.loadFile(path.join(__dirname, "chat.html"));
  } catch (err) {
    console.error("Failed to load chat.html:", err);
  }

  // Jawne przejęcie fokusu — patrz komentarz w createGenericPanelWindow (czytnik bywa
  // przypięty always-on-top, co utrudnia nowemu oknu naturalne przejęcie "key window").
  chatWindow.once("ready-to-show", () => { try { chatWindow.focus(); } catch {} });
  try { chatWindow.focus(); } catch {}

  chatWindow.on("closed", () => {
    chatWindow = null;
  });

  return chatWindow;
}


// ===== Chat pop-out IPC =====
ipcMain.handle("wb-open-chat-window", async () => {
  try {
    createChatWindow();
    return { ok: true };
  } catch (err) {
    console.error("wb-open-chat-window error:", err);
    return { ok: false, error: err.message };
  }
});

ipcMain.on("wb-chat-line", (evt, payload) => {
  try {
    if (chatWindow && !chatWindow.isDestroyed()) {
      chatWindow.webContents.send("wb-chat-line", payload || {});
    }
  } catch (err) {
    // ignore
  }
});

// ===== Tryb okienka — czytnik pytań + kolejka (osobne, skalowalne okno) =====
// Lekki pop-out: WYŁĄCZNIE wyświetla dane (odczyt z lokalnego serwera widgetów,
// dokładnie tak jak widgety OBS) i przekazuje DALEJ/WSTECZ do głównego okna przez
// ten sam kanał co globalne skróty klawiszowe — zero duplikacji logiki/stanu.
let readerWindow = null;

function createReaderWindow() {
  if (readerWindow && !readerWindow.isDestroyed()) {
    try { readerWindow.focus(); } catch {}
    return readerWindow;
  }

  const saved = getSavedWindowOptions("readerWindow", { width: 615, height: 591 });

  readerWindow = new BrowserWindow({
    width: saved.width,
    height: saved.height,
    x: saved.x,
    y: saved.y,
    minWidth: 520,
    minHeight: 320,
    title: "KVRINA_SHOW — Czytnik",
    backgroundColor: "#020308",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  attachWindowPlacementMemory("readerWindow", readerWindow);
  if (saved.isMaximized) {
    try { readerWindow.maximize(); } catch {}
  }
  if (saved.isFullScreen) {
    try { readerWindow.setFullScreen(true); } catch {}
  }

  readerWindow.setMenuBarVisibility(false);

  try {
    readerWindow.loadFile(path.join(__dirname, "reader.html"));
  } catch (err) {
    console.error("Failed to load reader.html:", err);
  }

  readerWindow.on("closed", () => {
    readerWindow = null;
  });

  return readerWindow;
}

ipcMain.handle("wb-open-reader-window", async () => {
  try {
    createReaderWindow();
    return { ok: true };
  } catch (err) {
    console.error("wb-open-reader-window error:", err);
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("reader-set-always-on-top", async (event, val) => {
  try {
    if (readerWindow && !readerWindow.isDestroyed()) {
      readerWindow.setAlwaysOnTop(!!val, "floating");
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// Te same kanały co globalne skróty klawiszowe DALEJ/WSTECZ — okienko "zdalnie steruje"
// głównym oknem, żadna logika kolejki/pytań nie jest duplikowana.
ipcMain.handle("reader-next", async () => {
  _wbSendToRenderer("wb-questions-next");
  return { ok: true };
});
ipcMain.handle("reader-prev", async () => {
  _wbSendToRenderer("wb-questions-prev");
  return { ok: true };
});
ipcMain.handle("reader-skip", async () => {
  _wbSendToRenderer("wb-questions-skip");
  return { ok: true };
});

// Przesuwanie / edycja z okienka — identyfikacja wpisu po "ts" (stabilne, odporne
// na przesunięcia indeksów), główne okno wykonuje dokładnie te same funkcje co jego
// własne przyciski ↑↓✎.
ipcMain.handle("reader-queue-move", async (event, payload) => {
  _wbSendToRenderer("reader-cmd-move", payload);
  return { ok: true };
});
ipcMain.handle("reader-queue-remove", async (event, payload) => {
  _wbSendToRenderer("reader-cmd-remove", payload);
  return { ok: true };
});
ipcMain.handle("reader-queue-edit", async (event, payload) => {
  _wbSendToRenderer("reader-cmd-edit", payload);
  return { ok: true };
});
ipcMain.handle("reader-queue-jump", async (event, payload) => {
  _wbSendToRenderer("reader-cmd-jump", payload);
  return { ok: true };
});
ipcMain.handle("reader-queue-add", async (event, payload) => {
  _wbSendToRenderer("reader-cmd-add", payload);
  return { ok: true };
});
ipcMain.handle("reader-set-countdown", async (event, payload) => {
  _wbSendToRenderer("reader-cmd-countdown", payload);
  return { ok: true };
});

// Chowanie/pokazywanie głównego okna z poziomu okienka czytnika.
ipcMain.handle("reader-toggle-main-window", async () => {
  try {
    if (!mainWindow || mainWindow.isDestroyed()) return { ok: false, visible: false };
    if (mainWindow.isVisible()) {
      mainWindow.hide();
      return { ok: true, visible: false };
    } else {
      mainWindow.show();
      mainWindow.focus();
      return { ok: true, visible: true };
    }
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("reader-get-main-visible", async () => {
  try {
    return { ok: true, visible: !!(mainWindow && !mainWindow.isDestroyed() && mainWindow.isVisible()) };
  } catch {
    return { ok: true, visible: true };
  }
});

// Akcje z menu okienka czytnika (przeniesione z ☰ głównego okna). WIDGETY/AKTUALIZACJE/
// DIAGNOSTYKA mają teraz własne okienka (patrz wb-open-panel-window) — nie pokazujemy już
// przez to głównego, ukrytego okna. Tu zostają tylko akcje "w tle" na stanie silnika
// (kopiuj URL / demo / zeruj), które nie potrzebują żadnego widocznego okna.
ipcMain.handle("reader-menu-action", async (event, action) => {
  try {
    _wbSendToRenderer("reader-menu-cmd", action);
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

// =========================
// PANELE PROGRAMU — osobne, kompaktowe okienka (GIFTY / OBSERWUJĄCY / RANKING / KASA)
// wywoływane z menu ⧉ okienka czytnika. Każde to lekki pop-out czytający
// widget_state.json (jak widgety OBS) — bez duplikowania stanu.
// =========================
const panelWindows = { obserwujacy: null, ranking: null, kasa: null, widgets: null, aktualizacje: null, diagnostyka: null, dzwiek: null, uklad: null };

const PANEL_WINDOW_CONFIG = {
  obserwujacy: { file: "panel_obserwujacy.html", title: "KVRINA_SHOW — Obserwujący", width: 380, height: 560 },
  ranking: { file: "panel_ranking.html", title: "KVRINA_SHOW — Ranking widzów", width: 380, height: 560 },
  kasa: { file: "panel_kasa.html", title: "KVRINA_SHOW — Kasa", width: 340, height: 260 },
  widgets: { file: "panel_widgets.html", title: "KVRINA_SHOW — Widgety", width: 1180, height: 800 },
  aktualizacje: { file: "panel_aktualizacje.html", title: "KVRINA_SHOW — Aktualizacje", width: 480, height: 440 },
  diagnostyka: { file: "panel_diagnostyka.html", title: "KVRINA_SHOW — Diagnostyka", width: 820, height: 700 },
  dzwiek: { file: "panel_dzwiek.html", title: "KVRINA_SHOW — Dźwięk", width: 420, height: 560 },
  uklad: { file: "panel_uklad.html", title: "KVRINA_SHOW — Układ widgetu zbiorczego", width: 560, height: 520 },
};

// Panele z menu czytnika są wzajemnie wykluczające się — otwarcie jednego zamyka
// pozostałe (łącznie z GIFTY, które ma osobną zmienną chatWindow, nie panelWindows).
function closeOtherReaderPanels(except) {
  try {
    if (except !== "gifty" && chatWindow && !chatWindow.isDestroyed()) chatWindow.close();
  } catch {}
  for (const key of Object.keys(panelWindows)) {
    if (key === except) continue;
    try {
      const w = panelWindows[key];
      if (w && !w.isDestroyed()) w.close();
    } catch {}
  }
}

function createGenericPanelWindow(panel) {
  const cfg = PANEL_WINDOW_CONFIG[panel];
  if (!cfg) return null;

  if (panelWindows[panel] && !panelWindows[panel].isDestroyed()) {
    try { panelWindows[panel].focus(); } catch {}
    return panelWindows[panel];
  }

  const winKey = `panel_${panel}`;
  const saved = getSavedWindowOptions(winKey, { width: cfg.width, height: cfg.height });

  const win = new BrowserWindow({
    width: saved.width,
    height: saved.height,
    x: saved.x,
    y: saved.y,
    minWidth: 260,
    minHeight: 200,
    title: cfg.title,
    backgroundColor: "#020308",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  attachWindowPlacementMemory(winKey, win);
  win.setMenuBarVisibility(false);

  try {
    win.loadFile(path.join(__dirname, cfg.file));
  } catch (err) {
    console.error(`Failed to load ${cfg.file}:`, err);
  }

  // Jawne przejęcie fokusu klawiatury — czytnik bywa przypięty (always-on-top/floating),
  // co na macOS potrafi utrudnić świeżo utworzonemu oknu normalnie stać się "key window"
  // (np. Esc w nowym panelu nie działałby, dopóki użytkownik nie kliknie w nie ręcznie).
  win.once("ready-to-show", () => { try { win.focus(); } catch {} });
  try { win.focus(); } catch {}

  win.on("closed", () => {
    panelWindows[panel] = null;
  });

  panelWindows[panel] = win;
  return win;
}

ipcMain.handle("wb-open-panel-window", async (event, panel) => {
  try {
    closeOtherReaderPanels(panel);
    if (panel === "gifty") {
      // GIFTY już ma gotowe okienko (chat.html — mirror giftów przez sendChatLine).
      createChatWindow();
      return { ok: true };
    }
    if (!PANEL_WINDOW_CONFIG[panel]) return { ok: false, error: `Nieznany panel: ${panel}` };
    createGenericPanelWindow(panel);
    return { ok: true };
  } catch (err) {
    console.error("wb-open-panel-window error:", err);
    return { ok: false, error: err.message };
  }
});

// Relay: OBSERWUJĄCY (dodaj do kolejki / usuń / zmień nick) — identyfikacja przez "ts".
ipcMain.handle("panel-follow-add", async (event, payload) => {
  _wbSendToRenderer("panel-cmd-follow-add", payload);
  return { ok: true };
});
ipcMain.handle("panel-follow-remove", async (event, payload) => {
  _wbSendToRenderer("panel-cmd-follow-remove", payload);
  return { ok: true };
});
ipcMain.handle("panel-follow-edit", async (event, payload) => {
  _wbSendToRenderer("panel-cmd-follow-edit", payload);
  return { ok: true };
});

// Relay: RANKING WIDZÓW (dodaj do kolejki) — identyfikacja przez nick.
ipcMain.handle("panel-ranking-add", async (event, payload) => {
  _wbSendToRenderer("panel-cmd-ranking-add", payload);
  return { ok: true };
});


// ===== DIAGNOSTYKA IPC =====
ipcMain.handle("diag-get-log", async () => {
  let fileLines = [];
  try {
    const raw = fs.readFileSync(path.join(__dirname, DIAG_LOG_FILE), "utf8");
    fileLines = raw.split("\n").filter(Boolean).slice(-300);
  } catch {}
  const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
  return {
    log: _diagLog.slice(-150),
    fileLines,
    version: pkg.version || "?",
    platform: `${process.platform} ${process.arch}`,
    electron: process.versions.electron,
    node: process.versions.node,
    perf: getPerformanceSnapshot(),
  };
});

ipcMain.handle("diag-send-report", async (event, { message, type = "raport" } = {}) => {
  try {
    const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
    const version = pkg.version || "?";
    const logSnippet = _diagLog.slice(-60).map(e => `[${e.ts}] [${e.level}] ${e.msg}`).join("\n");
    const emoji = type === "crash" ? "🔴" : type === "bug" ? "🐛" : type === "suggestion" ? "💡" : "💬";
    const label = type === "crash" ? "auto-crash" : type === "bug" ? "diagnostics" : "kvrina-report";
    const title = `${emoji} [v${version}] ${(message || "(brak treści)").slice(0, 80)}`;
    const body = [
      `## Wiadomość od Kvriny`,
      "",
      message || "(brak wiadomości)",
      "",
      `## Informacje systemowe`,
      `| | |`,
      `|---|---|`,
      `| Wersja | ${version} |`,
      `| System | ${process.platform} ${process.arch} |`,
      `| Electron | ${process.versions.electron} |`,
      `| Node | ${process.versions.node} |`,
      `| Data | ${new Date().toISOString()} |`,
      ``,
      `## Wydajność (snapshot)`,
      (() => { const p = getPerformanceSnapshot(); return `| | |\n|---|---|\n| Heap | ${p.heapUsedMB} / ${p.heapTotalMB} MB |\n| RSS | ${p.rssMB} MB |\n| CPU (proc) | ${p.cpuPct}% |\n| RAM wolna | ${p.freeRamMB} / ${p.totalRamMB} MB |\n| Load avg | ${p.loadAvg} |\n| Uptime apki | ${p.uptime}s |`; })(),
      "",
      `## Ostatnie logi`,
      "```",
      logSnippet || "(brak)",
      "```",
    ].join("\n");

    const result = await _sendDiagIssue(title, body, [label]);
    if (result.ok) {
      diagInfo(`Raport wysłany: #${result.data.number} ${result.data.html_url}`);
      return { ok: true, url: result.data.html_url, number: result.data.number };
    } else {
      diagError(`Błąd raportu: HTTP ${result.status}`);
      return { ok: false, error: `HTTP ${result.status}` };
    }
  } catch (e) {
    diagError(`diag-send-report error: ${e.message}`);
    return { ok: false, error: e.message };
  }
});

// === IPC: DŹWIĘKI ===
ipcMain.handle("sound-get-state", async () => {
  try {
    ensureSoundFolders();
    return {
      ok: true,
      settings: getSoundSettings(),
      notifyFiles: listAudioFiles(getNotifyDir()),
      musicFiles: listAudioFiles(getMusicDir()),
      shuffleFiles: listAudioFiles(getShuffleDir()),
      nowPlaying: _soundNowPlaying,
      baseUrl: `http://127.0.0.1:${widgetPort}/dzwieki`,
    };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("sound-set-settings", async (event, patch) => {
  try {
    return { ok: true, settings: setSoundSettings(patch) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("sound-open-folder", async (event, which) => {
  try {
    ensureSoundFolders();
    const dir = which === "muzyka" ? getMusicDir()
      : which === "powiadomienia" ? getNotifyDir()
      : which === "tasowanie" ? getShuffleDir()
      : getSoundsDir();
    shell.openPath(dir);
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// Polecenia sterujące odtwarzaczem w głównym oknie (play/pause/next/test).
ipcMain.handle("sound-control", async (event, payload) => {
  try {
    _wbSendToRenderer("wb-sound-control", payload || {});
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// Główne okno melduje co aktualnie gra — panel odpytuje o to przez sound-get-state.
ipcMain.handle("sound-report-playing", async (event, payload) => {
  _soundNowPlaying = payload || { track: null, playing: false };
  return { ok: true };
});

ipcMain.handle("combo-get-layout", async () => ({
  ok: true,
  layout: getComboLayout(),
  parts: COMBO_PARTS,
  labels: COMBO_PART_LABELS,
  url: `http://127.0.0.1:${widgetPort}/widget-wszystko.html`,
}));
ipcMain.handle("combo-set-layout", async (event, patch) => {
  try {
    return { ok: true, layout: setComboLayout(patch) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});
ipcMain.handle("combo-reset-layout", async () => {
  try {
    return { ok: true, layout: resetComboLayout() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("widgets-get-lite", async () => ({ ok: true, lite: isLiteWidgets() }));
ipcMain.handle("widgets-set-lite", async (event, on) => {
  try {
    return { ok: true, lite: setLiteWidgets(on) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("diag-set-auto-report", async (event, on) => {
  try {
    return { ok: true, autoReport: setAutoReportEnabled(on) };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("diag-get-perf", async () => {
  try {
    const snap = getPerformanceSnapshot();
    return {
      ok: true,
      snapshot: snap,
      peaks: _perfPeaks,
      history: _perfHistory,
      findings: analyzePerformance(snap),
      autoReport: isAutoReportEnabled(),
      topMemory: getTopMemoryConsumers(6),
      pressure: getMemoryPressure(),
      windows: listOpenWindows(),
      perfSettings: getPerfRelevantSettings(),
      tunnels: countOwnTunnelProcesses(),
      cpuModel: (() => { try { return os.cpus()[0].model; } catch { return "?"; } })(),
      cpuCount: (() => { try { return os.cpus().length; } catch { return 0; } })(),
    };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// Tekstowy raport gotowy do wysłania — trafia w treść zgłoszenia na GitHub.
function buildPerfReportText() {
  const s = getPerformanceSnapshot();
  const f = analyzePerformance(s);
  const h = _perfHistory;
  const lines = [];
  lines.push(`Model CPU: ${(() => { try { return os.cpus()[0].model; } catch { return "?"; } })()} (${(() => { try { return os.cpus().length; } catch { return 0; } })()} rdzeni)`);
  const _p = getMemoryPressure();
  lines.push(`RAM total: ${(Number(s.totalRamMB) / 1024).toFixed(1)} GB`);
  if (_p && (_p.freePct !== null || _p.swapUsedMB !== null)) {
    lines.push(`Pamięć: wolne ${_p.freePct ?? "?"}% | swap (zrzut na dysk): ${_p.swapUsedMB ?? "?"} MB  ← to są miarodajne wskaźniki`);
    lines.push(`("wolna pamięć": ${s.freeRamMB} MB — na macOS zawsze niska, bo reszta służy jako cache; sama w sobie nic nie oznacza)`);
  } else {
    lines.push(`Wolna pamięć: ${s.freeRamMB} MB`);
  }
  lines.push(`Program RSS: ${s.rssMB} MB | heap: ${s.heapUsedMB}/${s.heapTotalMB} MB | CPU: ${s.cpuPct}%`);
  lines.push(`Uptime: ${Math.floor(Number(s.uptime) / 60)} min | load: ${s.loadAvg}`);
  lines.push(`Szczyty: RSS max ${_perfPeaks.maxRssMB} MB | wolna RAM min ${_perfPeaks.minFreeRamMB ?? "?"} MB | CPU max ${_perfPeaks.maxCpuPct}% | load max ${_perfPeaks.maxLoad1}`);
  lines.push(`Procesy tunelu: ${countOwnTunnelProcesses() ?? "?"} (powinien być 1 gdy webhook włączony)`);
  lines.push("");
  const cfg = getPerfRelevantSettings();
  lines.push("Ustawienia odciążające:");
  lines.push(`  - tryb oszczędny widgetów: ${cfg.liteWidgets ? "WŁĄCZONY" : "wyłączony"}`);
  if (cfg.usesCombo && cfg.separateCount === 0) {
    lines.push("  - widget zbiorczy: TAK (jedno źródło w OBS)");
  } else if (cfg.usesCombo && cfg.separateCount > 0) {
    lines.push(`  - widget zbiorczy: częściowo — obok niego działa jeszcze ${cfg.separateCount} osobnych źródeł`);
  } else if (cfg.separateCount > 0) {
    lines.push(`  - widget zbiorczy: NIE — używane ${cfg.separateCount} osobnych źródeł (każde to osobny proces przeglądarki)`);
  } else {
    lines.push("  - widgety: żaden nie był jeszcze wczytany (OBS/TikTok Studio nie działa?)");
  }
  if (cfg.widgetsLoaded.length) lines.push(`  - wczytane widgety: ${cfg.widgetsLoaded.join(", ")}`);
  lines.push("");
  const wins = listOpenWindows();
  if (wins.length) {
    lines.push(`Otwarte okna programu: ${wins.length} (każde to osobny proces, ~100-130 MB)`);
    wins.forEach((w) => lines.push(`  - ${w.name}${w.visible ? "" : "  [niewidoczne, ale otwarte]"}`));
    const hidden = wins.filter((w) => !w.visible && !/GŁÓWNE/.test(w.name)).length;
    if (hidden) lines.push(`  → ${hidden} okno/okna zajmują pamięć, choć nie są widoczne — można je zamknąć.`);
    lines.push("");
  }
  const top = getTopMemoryConsumers(8);
  if (top.length) {
    lines.push("Co zajmuje pamięć w całym systemie (suma wszystkich procesów aplikacji):");
    top.forEach((p, i) => lines.push(`  ${i + 1}. ${p.name} — ${p.mb} MB`));
    lines.push("");
  }
  lines.push("Wnioski:");
  f.forEach((x) => lines.push(`- [${x.level}] ${x.text}`));
  if (h.length > 1) {
    lines.push("");
    lines.push(`Historia (${h.length} próbek, co ~1 min, od najstarszej):`);
    const step = Math.max(1, Math.floor(h.length / 30));
    for (let i = 0; i < h.length; i += step) {
      const p = h[i];
      lines.push(`  ${new Date(p.t).toLocaleTimeString("pl-PL")}  rss=${p.rss}MB  heap=${p.heap}MB  cpu=${p.cpu}%  wolnaRAM=${p.freeRam}MB  load=${p.load1}`);
    }
  }
  return lines.join("\n");
}

ipcMain.handle("diag-get-perf-report-text", async () => {
  try {
    return { ok: true, text: buildPerfReportText() };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("diag-get-reports", async (event, { state = "open" } = {}) => {
  return new Promise((resolve) => {
    const options = {
      hostname: "api.github.com",
      path: `/repos/${_db}/issues?state=${state}&per_page=50&sort=created&direction=desc`,
      method: "GET",
      headers: {
        "Authorization": `Bearer ${_da.join("")}`,
        "User-Agent": "KVRINA_SHOW",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
      },
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try { resolve({ ok: res.statusCode < 300, issues: JSON.parse(buf) }); }
        catch { resolve({ ok: false, issues: [], error: buf }); }
      });
    });
    req.on("error", (e) => resolve({ ok: false, issues: [], error: e.message }));
    req.end();
  });
});

ipcMain.handle("diag-close-issue", async (event, { number } = {}) => {
  return new Promise((resolve) => {
    const data = JSON.stringify({ state: "closed" });
    const options = {
      hostname: "api.github.com",
      path: `/repos/${_db}/issues/${number}`,
      method: "PATCH",
      headers: {
        "Authorization": `Bearer ${_da.join("")}`,
        "Content-Type": "application/json",
        "User-Agent": "KVRINA_SHOW",
        "Accept": "application/vnd.github+json",
        "Content-Length": Buffer.byteLength(data),
        "X-GitHub-Api-Version": "2022-11-28",
      },
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try { resolve({ ok: res.statusCode < 300, issue: JSON.parse(buf) }); }
        catch { resolve({ ok: false }); }
      });
    });
    req.on("error", (e) => resolve({ ok: false, error: e.message }));
    req.write(data);
    req.end();
  });
});

ipcMain.handle("diag-clear-log", async () => {
  _diagLog = [];
  try { fs.writeFileSync(path.join(__dirname, DIAG_LOG_FILE), ""); } catch {}
  return { ok: true };
});

// RAM monitoring – lekki handler dla paska statusu w rendererze
// Wersja programu, czytana z package.json po stronie main (niezależnie od tego, które
// okno pyta — bez tego panel AKTUALIZACJE pokazywał zawsze starą, zaszytą etykietę,
// bo liczył ścieżkę względną do package.json od siebie zamiast od realnego folderu appki).
ipcMain.handle("wb-get-app-version", async () => {
  try {
    const pkg = JSON.parse(fs.readFileSync(path.join(getAppBaseDir(), "package.json"), "utf8"));
    return { ok: true, version: pkg.version || "?" };
  } catch (e) {
    return { ok: false, version: "?", error: e.message };
  }
});

ipcMain.handle("wb-get-ram", async () => {
  const freeMB = Math.round(os.freemem() / 1024 / 1024);
  const totalMB = Math.round(os.totalmem() / 1024 / 1024);
  const heapMB = Math.round(process.memoryUsage().heapUsed / 1024 / 1024);
  return { freeMB, totalMB, heapMB };
});

// ---- TikTok Live bezpośrednio (bez bota TikFinity) ----
ipcMain.handle("tiktok-connect", async (event, arg) => {
  // arg może być stringiem (nick) albo obiektem { username, apiKey }
  if (arg && typeof arg === "object") {
    return await tiktokConnect(arg.username, arg.apiKey);
  }
  return await tiktokConnect(arg);
});
ipcMain.handle("tiktok-disconnect", async () => {
  return await tiktokDisconnect(true);
});

app.on("will-quit", () => {
  try { globalShortcut.unregisterAll(); } catch (e) {}
  try { tiktokDisconnect(true); } catch (e) {}
  try { stopTunnel(); } catch (e) {}
  try { if (tippedServer) tippedServer.close(); } catch (e) {}
  diagInfo("App zamknięty.");
});
