// =========================
// KVRINA_SHOW - preload.js
// =========================

const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("wbApi", {
  getOutputDir: () => ipcRenderer.invoke("wb-get-output-dir"),
  openOutputDir: () => ipcRenderer.invoke("wb-open-output-dir"),
  openWidgetsDir: () => ipcRenderer.invoke("wb-open-widgets-dir"),
  openUpdatesDir: () => ipcRenderer.invoke("wb-open-updates-dir"),
  updateCheck: () => ipcRenderer.invoke("wb-update-check"),
  updateInstall: () => ipcRenderer.invoke("wb-update-install"),
  updatePickInstall: () => ipcRenderer.invoke("wb-update-pick-install"),
  updateRestorePrevious: () => ipcRenderer.invoke("wb-update-restore-previous"),

  writeFile: (name, data) =>
    ipcRenderer.invoke("wb-write-file", { name, data }),

  appendFile: (name, data) =>
    ipcRenderer.invoke("wb-append-file", { name, data }),

  readFile: (name) =>
    ipcRenderer.invoke("wb-read-file", { name }),

  readAbsoluteFile: (fullPath) =>
    ipcRenderer.invoke("wb-read-absolute-file", { fullPath }),

  openQuestionFileDialog: (mode) =>
    ipcRenderer.invoke("wb-open-question-file", { mode }),

  // Inform main process which TXT file is currently used for questions.
  // Enables auto-append from Tipped webhook.
  setQuestionsFilePath: (fullPath, mode) =>
    ipcRenderer.invoke("wb-set-questions-file-path", { fullPath, mode }),

  getLastQuestionsFilePaths: () => ipcRenderer.invoke("wb-get-last-questions-file-paths"),

  // Global shortcuts -> renderer
  onQuestionsNext: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-questions-next");
    ipcRenderer.on("wb-questions-next", () => cb());
  },

  onQuestionsPrev: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-questions-prev");
    ipcRenderer.on("wb-questions-prev", () => cb());
  },

  onTippedQuestion: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tipped-question");
    ipcRenderer.on("wb-tipped-question", (evt, payload) => cb(payload));
  },

  onTippedFund: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tipped-fund");
    ipcRenderer.on("wb-tipped-fund", (evt, payload) => cb(payload));
  },


  // Cloudflared quick tunnel controls
  tunnelStart: () => ipcRenderer.invoke("wb-tunnel-start"),
  tunnelStop: () => ipcRenderer.invoke("wb-tunnel-stop"),
  tunnelGet: () => ipcRenderer.invoke("wb-tunnel-get"),
  clipboardCopy: (text) => ipcRenderer.invoke("wb-clipboard-copy", { text }),
  webhookGetStatus: () => ipcRenderer.invoke("wb-webhook-get-status"),

  onTunnelUrl: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tunnel-url");
    ipcRenderer.on("wb-tunnel-url", (evt, payload) => cb(payload));
  },

  onTunnelStopped: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-tunnel-stopped");
    ipcRenderer.on("wb-tunnel-stopped", () => cb());
  },


  onLastQuestionPaths: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-last-question-paths");
    ipcRenderer.on("wb-last-question-paths", (evt, payload) => cb(payload));
  },

  // GitHub auto-aktualizacje
  githubCheck: () => ipcRenderer.invoke("wb-github-check"),
  githubDownloadInstall: (opts) => ipcRenderer.invoke("wb-github-download-install", opts),
  onGithubProgress: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-github-progress");
    ipcRenderer.on("wb-github-progress", (evt, data) => cb(data));
  },

  // Diagnostyka
  diagGetLog: () => ipcRenderer.invoke("diag-get-log"),
  diagSendReport: (opts) => ipcRenderer.invoke("diag-send-report", opts),
  diagClearLog: () => ipcRenderer.invoke("diag-clear-log"),
  diagGetReports: (opts) => ipcRenderer.invoke("diag-get-reports", opts),
  diagCloseIssue: (opts) => ipcRenderer.invoke("diag-close-issue", opts),
  onDiagEntry: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("diag-log-entry");
    ipcRenderer.on("diag-log-entry", (evt, entry) => cb(entry));
  },

  // Chat pop-out
  openChatWindow: () => ipcRenderer.invoke("wb-open-chat-window"),
  sendChatLine: (payload) => ipcRenderer.send("wb-chat-line", payload || {}),
  onChatLine: (cb) => {
    if (typeof cb !== "function") return;
    ipcRenderer.removeAllListeners("wb-chat-line");
    ipcRenderer.on("wb-chat-line", (evt, payload) => cb(payload));
  },

});
