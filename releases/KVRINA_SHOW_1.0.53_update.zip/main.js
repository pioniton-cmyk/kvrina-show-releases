// =========================
// KVRINA_SHOW - main.js (1.0.39 — ranking tapów: oprawa + stabilny LIVE iframe)
// =========================

const { app, BrowserWindow, ipcMain, dialog, globalShortcut, clipboard, shell, screen, nativeImage } = require("electron");
const path = require("path");
const fs = require("fs");
const http = require("http");
const crypto = require("crypto");
const { spawn, spawnSync } = require("child_process");
const https = require("https");
const os = require("os");

// =========================
// DIAGNOSTYKA
// =========================
const _da = ["gho_X55K8ag", "2Nf40POBJ8", "WbhKWDij5C", "wRk1Cncoc"];
const _db = "pioniton-cmyk/kvrina-show-diagnostics";
const DIAG_MAX_MEM = 400;
const DIAG_LOG_FILE = "kvrina_diagnostics.log";
let _diagLog = [];
let _lastCpuUsage = process.cpuUsage();
let _lastCpuTime = Date.now();

function getPerformanceSnapshot() {
  const mem = process.memoryUsage();
  const now = Date.now();
  const cpuNow = process.cpuUsage(_lastCpuUsage);
  const elapsed = (now - _lastCpuTime) || 1;
  const cpuPct = ((cpuNow.user + cpuNow.system) / 1000 / elapsed * 100).toFixed(1);
  _lastCpuUsage = process.cpuUsage();
  _lastCpuTime = now;
  return {
    heapUsedMB: (mem.heapUsed / 1024 / 1024).toFixed(1),
    heapTotalMB: (mem.heapTotal / 1024 / 1024).toFixed(1),
    rssMB: (mem.rss / 1024 / 1024).toFixed(1),
    externalMB: (mem.external / 1024 / 1024).toFixed(1),
    cpuPct,
    freeRamMB: (os.freemem() / 1024 / 1024).toFixed(0),
    totalRamMB: (os.totalmem() / 1024 / 1024).toFixed(0),
    uptime: Math.floor(process.uptime()),
    loadAvg: os.loadavg().map(v => v.toFixed(2)).join(", "),
  };
}

function _diagEntry(level, msg) {
  const entry = { ts: new Date().toISOString(), level, msg: String(msg).slice(0, 800) };
  _diagLog.push(entry);
  if (_diagLog.length > DIAG_MAX_MEM) _diagLog.shift();
  try {
    const line = `[${entry.ts}] [${level}] ${entry.msg}\n`;
    const logPath = path.join(__dirname, DIAG_LOG_FILE);
    fs.appendFileSync(logPath, line);
    // przytnij plik jeśli za duży (>300KB)
    const stat = fs.statSync(logPath);
    if (stat.size > 300000) {
      const lines = fs.readFileSync(logPath, "utf8").split("\n");
      fs.writeFileSync(logPath, lines.slice(-600).join("\n"));
    }
  } catch {}
  if (mainWindow && !mainWindow.isDestroyed()) {
    try { mainWindow.webContents.send("diag-log-entry", entry); } catch {}
  }
}

function diagInfo(msg)  { _diagEntry("INFO",  msg); }
function diagWarn(msg)  { _diagEntry("WARN",  msg); }
function diagError(msg) { _diagEntry("ERROR", msg); }

process.on("uncaughtException", (err) => {
  _diagEntry("CRASH", `${err.message}\n${err.stack || ""}`);
  try {
    _sendDiagIssue(`🔴 CRASH: ${err.message}`,
      `## Automatyczny raport o błędzie\n\n**Błąd:** ${err.message}\n\n\`\`\`\n${err.stack}\n\`\`\``, ["auto-crash"]);
  } catch {}
});

process.on("unhandledRejection", (reason) => {
  _diagEntry("REJECT", String(reason));
});

async function _sendDiagIssue(title, body, labels = ["kvrina-report"]) {
  const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
  const version = pkg.version || "?";
  const fullBody = body + `\n\n---\n_v${version} · ${process.platform}/${process.arch} · Electron ${process.versions.electron} · Node ${process.versions.node}_`;
  const data = JSON.stringify({ title: title.slice(0, 200), body: fullBody, labels });
  return new Promise((resolve) => {
    const options = {
      hostname: "api.github.com",
      path: `/repos/${_db}/issues`,
      method: "POST",
      headers: {
        "Authorization": `Bearer ${_da.join("")}`,
        "Content-Type": "application/json",
        "User-Agent": "KVRINA_SHOW",
        "Accept": "application/vnd.github+json",
        "Content-Length": Buffer.byteLength(data),
        "X-GitHub-Api-Version": "2022-11-28",
      },
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try { resolve({ ok: res.statusCode < 300, status: res.statusCode, data: JSON.parse(buf) }); }
        catch { resolve({ ok: false, status: res.statusCode }); }
      });
    });
    req.on("error", (e) => resolve({ ok: false, error: e.message }));
    req.write(data);
    req.end();
  });
}

// Logi (chronologia pytań)
const AUTO_LOG_JSONL = "pytania_auto_log.jsonl";
const GIFTS_LOG_JSONL = "pytania_gifty_log.jsonl";
const GIFTS_STATE_JSON = "gifts_state.json";

let mainWindow;
let chatWindow = null;
let OUTPUT_DIR = null;

// =========================
// TIPPED WEBHOOK -> AUTO QUESTIONS
// =========================
// Dwa pliki TXT:
// - MANUAL: ręczne wklejanie/edycja w Notatniku
// - AUTO: dopisywany automatycznie z webhooka (donejty)
let MANUAL_QUESTIONS_FILE_PATH = null;
let AUTO_QUESTIONS_FILE_PATH = null;
const DEFAULT_TIPPED_HASH = "d86de6f8-720d-4d49-a5ed-baf4923193aa";
const KARTON_DNIA_TEXT = "KARTON DNIA";
let TIPPED_HASH = DEFAULT_TIPPED_HASH; // used to verify x-tipped-signature
let tippedServer = null;
let tippedPort = 8787;
let tippedPending = []; // queued donations if AUTO txt not set yet
let tippedSeen = new Set();

// =========================
// LOKALNE WIDGETY HTML (TikTok Studio Browser Source)
// =========================
let widgetServer = null;
const widgetPort = 8750;
const WIDGETS_DIR_NAME = "widgety";
const WIDGET_STATE_JSON = "widget_state.json";
const TIKFINITY_TOPLIKER_URL = "https://tikfinity.zerody.one/widget/topliker?cid=3197633";
const TIKFINITY_ACTIVITY_FEED_URL = "https://tikfinity.zerody.one/widget/activity-feed?cid=3197633&did=1";


function getWidgetsDir() {
  const dir = path.join(ensureOutputDir(), WIDGETS_DIR_NAME);
  try { fs.mkdirSync(dir, { recursive: true }); } catch {}
  return dir;
}

function safeJoin(base, rel) {
  const target = path.normalize(path.join(base, rel || ""));
  const normalizedBase = path.normalize(base + path.sep);
  if (!target.startsWith(normalizedBase) && target !== path.normalize(base)) return null;
  return target;
}

function defaultWidgetState() {
  return {
    updatedAt: Date.now(),
    current: { nick: "TERAZ TY", title: "PYTANIE DO KART", text: "LINK W BIO", type: "empty" },
    queue: [],
    ranking: [
      { nick: "Luna", likes: 120, points: 120 },
      { nick: "Kasia", likes: 80, points: 80 },
      { nick: "Marta", likes: 45, points: 45 }
    ],
    tikfinityTopLikerUrl: TIKFINITY_TOPLIKER_URL,
    tikfinityActivityFeedUrl: TIKFINITY_ACTIVITY_FEED_URL,
    demoMode: false,
    theme: "fire-gold-web"
  };
}

function ensureWidgetStateFile() {
  try {
    const p = path.join(getWidgetsDir(), WIDGET_STATE_JSON);
    if (!fs.existsSync(p)) {
      fs.writeFileSync(p, JSON.stringify(defaultWidgetState(), null, 2), "utf8");
    }
  } catch (e) {
    console.warn("[WIDGETY] state init error:", e.message);
  }
}

function writeWidgetAddressFile() {
  try {
    const dir = getWidgetsDir();
    const txt = [
      "KVRINA_SHOW — ADRESY WIDGETÓW DO TIKTOK STUDIO / BROWSER SOURCE",
      "",
      "PYTANIE DO KART / AKTUALNY WPIS:",
      `http://127.0.0.1:${widgetPort}/widget-pytanie.html`,
      "",
      "KOLEJKA PYTAŃ:",
      `http://127.0.0.1:${widgetPort}/widget-kolejka.html`,
      "",
      "RANKING TAPÓW — JEDYNY ADRES / TIKFINITY WEB:",
      `http://127.0.0.1:${widgetPort}/widget-ranking.html`,
      "",
      "AKTYWNOŚCI TIKFINITY WEB:",
      `http://127.0.0.1:${widgetPort}/widget-aktywnosci.html`,
      "",
      "DEMO / PODGLĄD WSZYSTKICH:",
      `http://127.0.0.1:${widgetPort}/demo.html`,
      "",
      "Webhook Tipped:",
      `http://127.0.0.1:${tippedPort}/webhook`,
      "",
      "Uwaga: program musi być uruchomiony, żeby linki działały."
    ].join("\n");
    fs.writeFileSync(path.join(dir, "adresy_widgetow.txt"), txt, "utf8");
  } catch (e) {
    console.warn("[WIDGETY] address file error:", e.message);
  }
}

const WIDGET_SHARED_SCRIPT = `
async function getState(){
  try{
    const r = await fetch('/widget_state.json?ts=' + Date.now(), {cache:'no-store'});
    if(!r.ok) throw new Error('state');
    return await r.json();
  }catch(e){
    return {current:{nick:'TERAZ TY', title:'PYTANIE DO KART', text:'LINK W BIO', type:'empty'}, queue:[], ranking:[], demoMode:false, tikfinityTopLikerUrl:'https://tikfinity.zerody.one/widget/topliker?cid=3197633', tikfinityActivityFeedUrl:'https://tikfinity.zerody.one/widget/activity-feed?cid=3197633&did=1'};
  }
}
function esc(s){return String(s ?? '').replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));}
function typeLabel(type){
  if(type === 'karton') return 'KARTON DNIA';
  if(type === 'waiting') return 'CZEKAM NA PYTANIE';
  if(type === 'empty') return 'PYTANIE DO KART';
  return 'PYTANIE DO KART';
}
function typeClass(type){return type === 'karton' ? 'is-karton' : type === 'waiting' ? 'is-waiting' : type === 'empty' ? 'is-empty' : 'is-question';}
`;

const WIDGET_CSS = `
:root{--gold:#ffcb55;--amber:#ff8a20;--copper:#b85a20;--red:#e44322;--cream:#fff7df;--muted:#d7b98c;--glass:rgba(8,5,3,.78);--line:rgba(255,203,85,.34)}
*{box-sizing:border-box}
html,body{margin:0;width:100%;height:100%;overflow:hidden;background:transparent;color:var(--cream);font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.stage{width:100vw;height:100vh;display:flex;align-items:flex-start;justify-content:center;padding:5px 12px 0;overflow:hidden;background:transparent}
.card{position:relative;width:min(96vw,900px);height:calc(100vh - 10px);max-height:220px;min-height:106px;padding:12px 18px 11px;border:1px solid var(--line);border-radius:18px;background:radial-gradient(circle at 92% 0%,rgba(255,138,32,.12),transparent 30%),linear-gradient(135deg,rgba(9,5,3,.88),rgba(2,2,5,.78));box-shadow:0 0 18px rgba(255,122,24,.12),inset 0 0 14px rgba(255,203,85,.032);overflow:hidden;display:flex;flex-direction:column;transform-origin:top center;contain:layout paint}
.card:before{content:'';position:absolute;inset:-2px;background:radial-gradient(circle at 12% 10%,rgba(255,203,85,.11),transparent 20%),radial-gradient(circle at 82% 78%,rgba(228,67,34,.08),transparent 24%);pointer-events:none}.card>*{position:relative}.question-card{isolation:isolate}
.question-head{flex:0 0 auto;position:relative;z-index:4}.eyebrow{font-size:12px;line-height:1;letter-spacing:.18em;text-transform:uppercase;color:var(--gold);font-weight:850;text-shadow:0 0 8px rgba(255,138,32,.25);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.nick{margin-top:5px;font-size:48px;line-height:.88;font-weight:950;letter-spacing:.01em;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:100%}.question-body{position:relative;z-index:4;flex:1 1 auto;min-height:0;margin-top:5px;display:flex;align-items:stretch;overflow:hidden}.text{width:100%;height:100%;font-size:var(--q-text-size,58px);line-height:.98;font-weight:860;text-align:center;text-wrap:balance;white-space:normal;word-break:break-word;overflow-wrap:anywhere;hyphens:auto;transform-origin:top center;max-height:100%;overflow:hidden;display:block}.is-karton .card{border-color:rgba(255,90,35,.52);box-shadow:0 0 24px rgba(228,67,34,.17),inset 0 0 18px rgba(255,203,85,.05)}.is-karton .eyebrow,.is-karton .text{color:#ffd66f}.is-waiting .text{color:#ffcf70}
.spark{position:absolute;width:2px;height:2px;border-radius:50%;background:var(--gold);box-shadow:0 0 9px var(--gold);opacity:.38;animation:float 4.4s linear infinite;z-index:2}@keyframes float{from{transform:translateY(18px);opacity:0}30%{opacity:.48}to{transform:translateY(-105px);opacity:0}}
.oracle-ring{position:absolute;right:13px;top:13px;width:48px;height:48px;border-radius:50%;border:1px solid rgba(255,203,85,.18);box-shadow:0 0 16px rgba(255,138,32,.07),inset 0 0 12px rgba(255,203,85,.04);opacity:.42;z-index:1}.oracle-ring:before,.oracle-ring:after{content:'✦';position:absolute;color:rgba(255,203,85,.60);font-size:10px;text-shadow:0 0 10px rgba(255,203,85,.38)}.oracle-ring:before{left:-4px;top:18px}.oracle-ring:after{right:-3px;top:18px}.moon-mark{position:absolute;left:14px;bottom:8px;color:rgba(255,203,85,.16);font-size:36px;line-height:1;z-index:1}.flame-sweep{position:absolute;inset:-55% -28%;background:conic-gradient(from 230deg,transparent 0deg,rgba(255,203,85,0) 56deg,rgba(255,203,85,.24) 74deg,rgba(255,120,24,.16) 86deg,transparent 110deg);opacity:0;z-index:3;pointer-events:none}.rune-burst{position:absolute;inset:0;z-index:3;pointer-events:none;opacity:0}.rune-burst span{position:absolute;font-weight:900;color:rgba(255,216,118,.82);text-shadow:0 0 14px rgba(255,138,32,.62);font-size:18px}.rune-burst span:nth-child(1){left:12%;top:26%}.rune-burst span:nth-child(2){left:82%;top:21%}.rune-burst span:nth-child(3){left:19%;top:78%}.rune-burst span:nth-child(4){left:76%;top:73%}.rune-burst span:nth-child(5){left:51%;top:10%}.state-change{animation:cardPulse .86s cubic-bezier(.2,.8,.2,1)}.state-change .flame-sweep{animation:flameSweep .86s ease-out}.state-change .oracle-ring{animation:sigilSpin .86s ease-out}.state-change .rune-burst{animation:runeBurst .86s ease-out}.state-change .text,.state-change .nick{animation:textReveal .46s ease-out}@keyframes cardPulse{0%{box-shadow:0 0 8px rgba(255,122,24,.06),inset 0 0 10px rgba(255,203,85,.02)}38%{box-shadow:0 0 44px rgba(255,138,32,.30),0 0 90px rgba(228,67,34,.12),inset 0 0 34px rgba(255,203,85,.10)}100%{box-shadow:0 0 22px rgba(255,122,24,.13),inset 0 0 16px rgba(255,203,85,.035)}}@keyframes flameSweep{0%{opacity:0;transform:rotate(-18deg) scale(.82)}38%{opacity:1}100%{opacity:0;transform:rotate(22deg) scale(1.25)}}@keyframes sigilSpin{0%{transform:rotate(-20deg) scale(.82);opacity:.12}42%{transform:rotate(155deg) scale(1.15);opacity:1}100%{transform:rotate(210deg) scale(1);opacity:.58}}@keyframes runeBurst{0%{opacity:0;transform:scale(.8)}34%{opacity:1}100%{opacity:0;transform:scale(1.35)}}@keyframes textReveal{0%{opacity:0;filter:blur(8px);transform:translateY(6px)}100%{opacity:1;filter:blur(0);transform:translateY(0)}}
.queue-stage{width:100vw;height:100vh;display:flex;align-items:flex-start;justify-content:flex-start;padding:2px;background:transparent}
.queue{position:relative;isolation:isolate;width:min(94vw,132px);height:auto;max-height:100vh;padding:4px;display:flex;flex-direction:column;gap:2px;border-radius:11px;border:1px solid rgba(255,203,85,.14);background:linear-gradient(135deg,rgba(7,5,4,.42),rgba(2,2,5,.32));box-shadow:0 0 10px rgba(255,122,24,.06);overflow:hidden;transform-origin:top left}
.queue:before{content:'';position:absolute;inset:-50% -70%;z-index:1;background:conic-gradient(from 230deg,transparent 0deg,rgba(255,203,85,0) 58deg,rgba(255,203,85,.25) 76deg,rgba(255,138,32,.16) 91deg,transparent 118deg);opacity:0;pointer-events:none}.queue:after{content:'✦  ☽  ✧';position:absolute;right:7px;top:4px;z-index:1;color:rgba(255,203,85,.30);font-size:8px;letter-spacing:2px;text-shadow:0 0 10px rgba(255,138,32,.35);opacity:.34;pointer-events:none}.queue.queue-change{animation:queuePulse .82s cubic-bezier(.2,.8,.2,1)}.queue.queue-change:before{animation:queueSweep .82s ease-out}.queue-title{position:relative;z-index:2;font-size:8px;letter-spacing:.12em;color:var(--gold);font-weight:900;text-transform:uppercase;text-shadow:0 0 6px rgba(255,138,32,.18)}
.qitem{position:relative;z-index:2;overflow:hidden;display:grid;grid-template-columns:18px minmax(0,1fr);gap:3px;align-items:center;padding:3px 4px;border-radius:8px;border:1px solid rgba(255,203,85,.13);background:linear-gradient(135deg,rgba(10,6,3,.58),rgba(4,3,6,.42));box-shadow:0 3px 9px rgba(0,0,0,.12);animation:qItemIn .42s cubic-bezier(.2,.8,.2,1) both}.queue-change .qitem:nth-child(3){animation-delay:.04s}.queue-change .qitem:nth-child(4){animation-delay:.08s}.queue-change .qitem:nth-child(5){animation-delay:.12s}
.qitem.current{border-color:rgba(255,203,85,.42);background:linear-gradient(135deg,rgba(38,20,4,.72),rgba(6,5,7,.54));box-shadow:0 0 14px rgba(255,138,32,.11),0 3px 9px rgba(0,0,0,.14)}.qitem.current:after{content:'';position:absolute;inset:-35% -65%;background:linear-gradient(105deg,transparent 30%,rgba(255,216,118,.20),transparent 62%);transform:translateX(-62%);opacity:0}.queue-change .qitem.current:after{animation:qShimmer .72s ease-out}.qitem.karton{border-color:rgba(255,90,35,.40);background:linear-gradient(135deg,rgba(70,20,7,.64),rgba(7,4,4,.56))}.qitem.waiting{opacity:.84}
.qnum{width:17px;height:17px;border-radius:50%;display:grid;place-items:center;color:#050505;background:linear-gradient(135deg,var(--gold),var(--amber));font-size:8px;font-weight:950;box-shadow:0 0 9px rgba(255,138,32,.18)}.qitem.current .qnum{font-size:9px;animation:qOrb 1.8s ease-in-out infinite}
.qnick{font-size:13px;line-height:.94;font-weight:950;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.qmeta{margin-top:1px;font-size:6.8px;color:var(--muted);letter-spacing:.045em;text-transform:uppercase;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.queue-spark{position:absolute;z-index:1;width:2px;height:2px;border-radius:50%;background:var(--gold);box-shadow:0 0 8px var(--gold);opacity:0;pointer-events:none}.queue-change .queue-spark{animation:qSpark .82s ease-out}.queue-spark.s1{left:18px;top:18px}.queue-spark.s2{right:20px;bottom:12px;animation-delay:.08s}.queue-spark.s3{left:52%;bottom:10px;animation-delay:.14s}
@keyframes queuePulse{0%{transform:scale(.985);box-shadow:0 0 8px rgba(255,122,24,.04)}40%{transform:scale(1.018);box-shadow:0 0 24px rgba(255,138,32,.20),0 0 44px rgba(228,67,34,.08)}100%{transform:scale(1);box-shadow:0 0 10px rgba(255,122,24,.06)}}@keyframes queueSweep{0%{opacity:0;transform:rotate(-15deg) translateX(-12%) scale(.82)}35%{opacity:1}100%{opacity:0;transform:rotate(20deg) translateX(14%) scale(1.18)}}@keyframes qItemIn{0%{opacity:0;transform:translateY(-8px) scale(.96);filter:blur(2px)}100%{opacity:1;transform:translateY(0) scale(1);filter:blur(0)}}@keyframes qShimmer{0%{opacity:0;transform:translateX(-75%) rotate(4deg)}36%{opacity:1}100%{opacity:0;transform:translateX(75%) rotate(4deg)}}@keyframes qOrb{0%,100%{box-shadow:0 0 7px rgba(255,138,32,.18)}50%{box-shadow:0 0 15px rgba(255,203,85,.48)}}@keyframes qSpark{0%{opacity:0;transform:translateY(8px) scale(.4)}32%{opacity:.85}100%{opacity:0;transform:translateY(-24px) scale(1.2)}}
.ticker-wrap{width:100vw;height:100vh;display:flex;align-items:flex-end;overflow:hidden;position:relative;padding:0 0 max(26px,2.6vh);background:transparent}.ticker-wrap:before{content:'';position:absolute;left:0;right:0;bottom:0;height:clamp(94px,8.2vw,138px);background:linear-gradient(90deg,rgba(5,3,2,0),rgba(5,3,2,.64) 12%,rgba(5,3,2,.72) 88%,rgba(5,3,2,0));border-top:1px solid rgba(255,203,85,.13);border-bottom:1px solid rgba(255,203,85,.10);box-shadow:0 -10px 34px rgba(0,0,0,.30),0 0 24px rgba(255,122,24,.08);pointer-events:none}.ticker{position:relative;z-index:2;display:flex;align-items:center;gap:clamp(14px,1.6vw,26px);white-space:nowrap;width:max-content;min-width:max-content;will-change:transform;transform:translateX(0)}.ticker.is-scrolling{animation-name:ticker;animation-duration:var(--ticker-duration,78s);animation-timing-function:linear;animation-fill-mode:forwards}.tick{display:inline-flex;align-items:center;gap:clamp(8px,1.0vw,16px);padding:clamp(10px,1.25vw,20px) clamp(18px,2.2vw,34px);border-radius:999px;border:1px solid rgba(255,203,85,.34);background:radial-gradient(circle at 18% 0%,rgba(255,203,85,.14),transparent 36%),linear-gradient(135deg,rgba(8,5,3,.88),rgba(25,9,2,.74));box-shadow:0 0 22px rgba(255,138,32,.16),inset 0 0 10px rgba(255,203,85,.04);font-size:clamp(22px,3.4vw,46px);line-height:1;font-weight:900}.heart{color:#ff315f;text-shadow:0 0 14px rgba(255,49,95,.46);font-size:1.12em}.place{color:#050505;background:linear-gradient(135deg,var(--gold),var(--amber));border-radius:999px;padding:.16em .46em;font-size:.58em;font-weight:950}.points{color:var(--gold);font-weight:950}.unit{color:var(--muted);font-size:.52em;font-weight:900;letter-spacing:.10em;text-transform:uppercase}.ticker-empty{opacity:.82}.ticker-note{position:absolute;left:22px;bottom:calc(max(26px,2.6vh) + clamp(94px,8.2vw,138px) + 10px);z-index:3;padding:7px 13px;border-radius:999px;background:rgba(5,3,2,.62);border:1px solid rgba(255,203,85,.18);color:var(--gold);font-size:clamp(11px,1.4vw,18px);letter-spacing:.12em;text-transform:uppercase;font-weight:950;text-shadow:0 0 9px rgba(255,138,32,.24)}@keyframes ticker{from{transform:translateX(var(--from-x,100vw))}to{transform:translateX(var(--to-x,calc(-100% - 48px)))}}
.tikfinity-ranking-stage{width:100vw;height:100vh;position:relative;overflow:hidden;background:transparent;contain:layout paint}.tikfinity-ranking-stage iframe{position:absolute;left:0;right:0;bottom:0;width:100%;height:100%;border:0;background:transparent;pointer-events:auto;transform:translateZ(0);backface-visibility:hidden;will-change:transform}.tikfinity-ranking-note{display:none}
.web-widget{width:100vw;height:100vh;padding:0;background:transparent;overflow:hidden;position:relative}.web-widget iframe{position:absolute;inset:0;width:100%;height:100%;border:0;background:transparent}.web-frame{position:absolute;inset:0;border:1px solid rgba(255,203,85,.22);border-radius:18px;box-shadow:0 0 18px rgba(255,122,24,.10),inset 0 0 12px rgba(255,203,85,.025);pointer-events:none}.web-label{position:absolute;left:10px;top:8px;z-index:8;padding:4px 9px;border-radius:999px;background:rgba(5,3,2,.70);border:1px solid rgba(255,203,85,.20);color:var(--gold);font-size:11px;letter-spacing:.12em;text-transform:uppercase;font-weight:900;backdrop-filter:blur(4px);pointer-events:none}.activity .web-label{color:#ffd66f}
.tf-web-ticker-stage{width:100vw;height:100vh;position:relative;overflow:hidden;background:transparent}.tf-web-ticker-rail{position:absolute;left:0;right:0;bottom:0;height:clamp(118px,10.2vh,210px);overflow:hidden;background:linear-gradient(90deg,rgba(5,3,2,0),rgba(5,3,2,.36) 10%,rgba(5,3,2,.42) 90%,rgba(5,3,2,0));border-top:1px solid rgba(255,203,85,.12);border-bottom:1px solid rgba(255,203,85,.08);box-shadow:0 -10px 30px rgba(0,0,0,.22)}.tf-web-strip{position:absolute;left:0;top:0;height:100%;width:var(--tf-strip-width,3600px);transform:translateX(0);will-change:transform}.tf-web-strip.is-scrolling{animation-name:tfWebTicker;animation-duration:var(--tf-web-duration,150s);animation-timing-function:linear;animation-fill-mode:forwards}.tf-web-strip iframe{width:100%;height:100%;border:0;background:transparent;pointer-events:auto}.tf-web-hint{position:absolute;left:18px;bottom:calc(clamp(118px,10.2vh,210px) + 12px);z-index:8;padding:6px 12px;border-radius:999px;background:rgba(5,3,2,.68);border:1px solid rgba(255,203,85,.20);color:var(--gold);font-size:clamp(10px,1.25vw,16px);letter-spacing:.12em;text-transform:uppercase;font-weight:950;text-shadow:0 0 9px rgba(255,138,32,.24);pointer-events:none}@keyframes tfWebTicker{from{transform:translateX(var(--tf-from-x,100vw))}to{transform:translateX(var(--tf-to-x,calc(-1 * var(--tf-strip-width,3600px) - 80px)))}}
.demo-grid{height:100vh;padding:14px;display:grid;grid-template-columns:1fr 350px;grid-template-rows:1fr 120px 190px;gap:12px;background:radial-gradient(circle at 70% 0%,rgba(255,122,24,.14),transparent 32%),#050303}.demo-box{border:1px solid rgba(255,203,85,.20);border-radius:20px;background:rgba(0,0,0,.30);overflow:hidden}.demo-box iframe{width:100%;height:100%;border:0;background:transparent}.demo-activity{grid-column:1/3}

/* === KVRINA_SHOW 1.0.36 — nowy jedyny widget RANKING TAPÓW === */
.tap-rank-widget{position:relative;width:100vw;height:100vh;overflow:hidden;background:transparent;pointer-events:none;font-family:Inter,system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif}
.tap-rank-shell{position:absolute;left:clamp(16px,5vw,54px);right:clamp(16px,5vw,54px);bottom:clamp(28px,4.2vh,72px);height:clamp(74px,7.3vh,132px);display:grid;grid-template-columns:clamp(150px,16vw,220px) minmax(0,1fr) clamp(58px,7vw,98px);align-items:center;border-radius:999px;overflow:hidden;background:radial-gradient(circle at 10% 20%,rgba(255,203,85,.20),transparent 34%),radial-gradient(circle at 92% 50%,rgba(228,67,34,.13),transparent 35%),linear-gradient(135deg,rgba(8,5,3,.86),rgba(22,9,5,.70),rgba(3,2,5,.84));border:1px solid rgba(255,203,85,.30);box-shadow:0 18px 48px rgba(0,0,0,.38),0 0 30px rgba(255,122,24,.12),inset 0 1px 0 rgba(255,255,255,.10);isolation:isolate}
.tap-rank-shell:before{content:'';position:absolute;inset:0;z-index:1;background:linear-gradient(90deg,rgba(255,203,85,.30),transparent 15%,transparent 86%,rgba(228,67,34,.18)),linear-gradient(180deg,rgba(255,255,255,.09),transparent 52%,rgba(0,0,0,.18));pointer-events:none;opacity:.65}.tap-rank-shell:after{content:'';position:absolute;left:0;top:0;bottom:0;width:7px;z-index:5;background:linear-gradient(180deg,#fff7df,var(--gold),var(--amber),var(--red));box-shadow:0 0 16px rgba(255,203,85,.58),0 0 28px rgba(255,122,24,.28)}
.tap-rank-label{position:relative;z-index:6;height:100%;display:flex;flex-direction:column;justify-content:center;padding:0 14px 0 22px;border-right:1px solid rgba(255,203,85,.18);text-shadow:0 0 10px rgba(255,138,32,.25)}.tap-rank-label span{font-size:clamp(10px,1.1vw,15px);line-height:1;color:rgba(255,203,85,.72);letter-spacing:.18em;font-weight:900}.tap-rank-label strong{margin-top:5px;font-size:clamp(21px,2.5vw,38px);line-height:.9;color:var(--cream);letter-spacing:.035em;font-weight:950;white-space:nowrap}.tap-rank-total{position:relative;z-index:6;height:100%;display:grid;place-items:center;border-left:1px solid rgba(255,203,85,.18);color:#ffdf7d;font-size:clamp(24px,3vw,44px);text-shadow:0 0 18px rgba(255,203,85,.42);animation:tapHeartPulse 1.35s ease-in-out infinite}.tap-rank-window{position:relative;z-index:6;height:100%;min-width:0;overflow:hidden;mask-image:linear-gradient(90deg,transparent 0,#000 5%,#000 95%,transparent 100%)}.tap-rank-track{position:absolute;left:0;top:0;height:100%;will-change:transform;transform:translateX(0)}.tap-rank-track.tap-scroll{animation:tapRankScroll var(--tap-duration,118s) linear forwards}.tap-rank-track.live-track{transform:none!important;will-change:auto;animation:none!important}.tap-rank-live-slot{position:absolute;inset:0;overflow:hidden;z-index:2;background:transparent}.tap-rank-live-slot iframe{position:absolute;left:50%;bottom:0;width:min(1320px,240vw);height:min(640px,280vh);max-width:none;transform:translateX(-50%);border:0;background:transparent;pointer-events:none}.tap-rank-track.demo-track{display:none;align-items:center;gap:18px;white-space:nowrap;padding:0 10px}.tap-chip{height:clamp(42px,4.8vh,74px);min-width:clamp(230px,24vw,360px);display:inline-flex;align-items:center;gap:10px;padding:0 18px 0 10px;border-radius:999px;background:radial-gradient(circle at 14% 22%,rgba(255,203,85,.16),transparent 48%),linear-gradient(145deg,rgba(255,255,255,.10),rgba(255,255,255,.026));border:1px solid rgba(255,203,85,.22);box-shadow:inset 0 1px 0 rgba(255,255,255,.10),0 6px 18px rgba(0,0,0,.22)}.tap-chip.top{border-color:rgba(255,203,85,.48);box-shadow:0 0 18px rgba(255,203,85,.16),inset 0 1px 0 rgba(255,255,255,.14)}.tap-place{width:clamp(25px,2.8vw,38px);height:clamp(25px,2.8vw,38px);border-radius:50%;display:grid;place-items:center;background:linear-gradient(180deg,#fff7df,var(--gold));color:#160b05;font-weight:950;font-size:clamp(12px,1.25vw,18px)}.tap-heart{color:#ffdf7d;font-size:clamp(18px,2vw,30px);text-shadow:0 0 12px rgba(255,203,85,.38)}.tap-chip strong{max-width:clamp(118px,14vw,220px);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:clamp(15px,1.7vw,26px);font-weight:950;color:#fff;text-shadow:0 2px 8px rgba(0,0,0,.82)}.tap-likes{margin-left:auto;color:#ffdf7d;font-size:clamp(16px,1.8vw,28px);font-weight:950;text-shadow:0 0 12px rgba(255,203,85,.25)}
@keyframes tapRankScroll{from{transform:translateX(var(--tap-from-x,100vw))}to{transform:translateX(var(--tap-to-x,-3680px))}}@keyframes tapHeartPulse{0%,100%{transform:scale(1);filter:drop-shadow(0 0 4px rgba(255,203,85,.22))}50%{transform:scale(1.14);filter:drop-shadow(0 0 12px rgba(255,203,85,.42))}}

`;


function widgetHtml(kind) {
  let body = "";
  let script = WIDGET_SHARED_SCRIPT;
  if (kind === "question") {
    body = `<div id="root" class="stage"></div>`;
    script += `
let lastSignature='';
function questionShell(){
 const root=document.getElementById('root');
 if(root.dataset.ready==='1') return;
 root.dataset.ready='1';
 root.innerHTML='<div class="card question-card" id="qcard"><i class="spark" style="left:12%;bottom:18%;animation-delay:.1s"></i><i class="spark" style="left:86%;bottom:28%;animation-delay:1.1s"></i><i class="spark" style="left:72%;bottom:12%;animation-delay:2s"></i><div class="oracle-ring"></div><div class="moon-mark">☽</div><div class="flame-sweep"></div><div class="rune-burst"><span>✦</span><span>✧</span><span>✺</span><span>✦</span><span>☽</span></div><div class="question-head"><div class="eyebrow" id="qeyebrow"></div><div class="nick" id="qnick"></div></div><div class="question-body" id="qbody"><div class="text" id="qtext"></div></div></div>';
}
function fitOneLine(el, max, min){
 if(!el) return;
 let size=max;
 el.style.fontSize=size+'px';
 while(size>min && el.scrollWidth>el.clientWidth){
   size-=1;
   el.style.fontSize=size+'px';
 }
}
function fitQuestionText(){
 const text=document.getElementById('qtext');
 const body=document.getElementById('qbody');
 const nick=document.getElementById('qnick');
 if(!text||!body) return;
 fitOneLine(nick,48,24);
 const raw=(text.textContent||'').trim();
 const len=raw.length;
 // Ważne: nie mierzymy scrollWidth, bo przy długim ciągu bez spacji
 // przeglądarka potrafi raportować szerokość naturalną i bez sensu zaniżać font.
 // Priorytet: łamanie tekstu + maksymalne wypełnienie dostępnej wysokości.
 const maxH=Math.max(30, body.clientHeight-1);
 const area=Math.max(1, body.clientWidth*maxH);
 let maxSize=82;
 if(len>35) maxSize=74;
 if(len>70) maxSize=66;
 if(len>120) maxSize=58;
 if(len>190) maxSize=48;
 if(len>300) maxSize=38;
 // Przy bardzo niskim źródle OBS nie pompujemy fontu bez limitu,
 // ale nadal trzymamy go dużo większego niż wcześniej.
 maxSize=Math.min(maxSize, Math.max(34, Math.sqrt(area/6.2)));
 const minSize=20;
 let lo=minSize, hi=maxSize, best=minSize;
 text.style.lineHeight='1.06';
 text.style.whiteSpace='normal';
 text.style.wordBreak='break-word';
 text.style.overflowWrap='anywhere';
 for(let i=0;i<18;i++){
   const mid=(lo+hi)/2;
   text.style.fontSize=mid+'px';
   if(text.scrollHeight<=maxH+1){
     best=mid;
     lo=mid+0.5;
   }else{
     hi=mid-0.5;
   }
 }
 if(best<24) text.style.lineHeight='1.00';
 else if(best<38) text.style.lineHeight='.98';
 else text.style.lineHeight='.94';
 text.style.fontSize=Math.floor(best)+'px';
}
function triggerMysticChange(){
 const card=document.getElementById('qcard');
 if(!card) return;
 card.classList.remove('state-change');
 void card.offsetWidth;
 card.classList.add('state-change');
 clearTimeout(card._changeTimer);
 card._changeTimer=setTimeout(()=>card.classList.remove('state-change'),920);
}
function render(s){
 questionShell();
 const c=s.current||{}; const type=c.type||'empty'; const text=c.text||'LINK W BIO'; const nick=c.nick||'TERAZ TY';
 const root=document.getElementById('root');
 root.className='stage '+typeClass(type);
 document.getElementById('qeyebrow').textContent=typeLabel(type);
 document.getElementById('qnick').textContent=nick;
 document.getElementById('qtext').textContent=text;
 const sig=[type,nick,text].join('|');
 if(sig!==lastSignature){ lastSignature=sig; triggerMysticChange(); }
 requestAnimationFrame(()=>{ fitQuestionText(); requestAnimationFrame(fitQuestionText); });
}
async function loop(){render(await getState())} loop(); setInterval(loop, 700); window.addEventListener('resize',()=>requestAnimationFrame(fitQuestionText));
`;
  } else if (kind === "queue") {
    body = `<div class="queue-stage"><div id="root" class="queue"></div></div>`;
    script += `
let lastQueueSignature='';
function itemHtml(it, label, cls){
 const t=it.type||'question';
 const classes=['qitem']; if(cls) classes.push(cls); if(t==='karton') classes.push('karton'); if(t==='waiting') classes.push('waiting');
 const meta=(cls==='current'?'TERAZ • ':'')+typeLabel(t);
 return '<div class="'+classes.join(' ')+'"><div class="qnum">'+esc(label)+'</div><div><div class="qnick">'+esc(it.nick||'-')+'</div><div class="qmeta">'+esc(meta)+'</div></div></div>';
}
function triggerQueueChange(){
 const root=document.getElementById('root'); if(!root) return;
 root.classList.remove('queue-change'); void root.offsetWidth; root.classList.add('queue-change');
 clearTimeout(root._qTimer); root._qTimer=setTimeout(()=>root.classList.remove('queue-change'),900);
}
function render(s){
 const current=s.current&&s.current.type!=='empty'?s.current:null;
 const q=(s.queue||[]).slice(0,2);
 const sig=JSON.stringify({current:current?{nick:current.nick,text:current.text,type:current.type}:null,queue:q.map(it=>({nick:it.nick,text:it.text,type:it.type}))});
 if(sig===lastQueueSignature) return;
 lastQueueSignature=sig;
 let html='<i class="queue-spark s1"></i><i class="queue-spark s2"></i><i class="queue-spark s3"></i><div class="queue-title">Kolejka</div>';
 if(current){ html+=itemHtml(current,'★','current'); }
 if(!current && !q.length){html+='<div class="qitem"><div class="qnum">•</div><div><div class="qnick">Dołącz</div><div class="qmeta">Pytanie do kart • link w bio</div></div></div>'}
 q.forEach((it,i)=>{html+=itemHtml(it,String(i+1),'');});
 document.getElementById('root').innerHTML=html;
 triggerQueueChange();
}
async function loop(){render(await getState())} loop(); setInterval(loop, 900);
`;
  } else if (kind === "ranking" || kind === "ranking-local") {
    body = `<div class="ticker-wrap"><div class="ticker-note">Ranking tapów ♥</div><div id="root"></div></div>`;
    script += `
let lastRankingSignature='';
let tickerScrollTimer=null;
let tickerScrollBusy=false;
const TICKER_SPEED_PX_PER_SEC=28;
const TICKER_MIN_DURATION_MS=58000;
const TICKER_MAX_DURATION_MS=210000;
function stopTickerScroll(){
 if(tickerScrollTimer) clearTimeout(tickerScrollTimer);
 tickerScrollTimer=null;
 tickerScrollBusy=false;
 const ticker=document.getElementById('ticker');
 if(ticker){ ticker.classList.remove('is-scrolling'); ticker.style.transform='translateX(0)'; }
}
function buildRankingTicker(s){
 const r=(s.ranking||[]).filter(Boolean);
 const items=r.length?r:[{nick:'Czekam na tapy',likes:0,points:0,empty:true}];
 const sig=JSON.stringify(items.map(it=>({nick:it.nick||'',likes:Number(it.likes ?? it.points ?? 0)||0,empty:!!it.empty})));
 if(sig===lastRankingSignature){
   if(!tickerScrollBusy) requestAnimationFrame(runTickerScroll);
   return;
 }
 lastRankingSignature=sig;
 const html='<div id="ticker" class="ticker">'+items.map((it,i)=>{ const likes=Number(it.likes ?? it.points ?? 0)||0; const empty=it.empty?' ticker-empty':''; return '<div class="tick'+empty+'"><span class="place">#'+(i+1)+'</span><span class="heart">♥</span><strong>'+esc(it.nick||'-')+'</strong><span class="points">'+esc(likes)+'</span><span class="unit">like</span></div>'; }).join('')+'</div>';
 document.getElementById('root').innerHTML=html;
 stopTickerScroll();
 requestAnimationFrame(()=>{ requestAnimationFrame(runTickerScroll); });
}
function runTickerScroll(){
 const ticker=document.getElementById('ticker');
 if(!ticker) return;
 if(tickerScrollTimer) clearTimeout(tickerScrollTimer);
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const trackW=Math.max(1, ticker.scrollWidth || ticker.getBoundingClientRect().width || 1);
 const fromX=winW + 48;
 const toX=-(trackW + 48);
 const distance=fromX - toX;
 const durationMs=Math.max(TICKER_MIN_DURATION_MS, Math.min(TICKER_MAX_DURATION_MS, Math.round((distance / TICKER_SPEED_PX_PER_SEC) * 1000)));
 tickerScrollBusy=true;
 ticker.classList.remove('is-scrolling');
 ticker.style.setProperty('--from-x', fromX + 'px');
 ticker.style.setProperty('--to-x', toX + 'px');
 ticker.style.setProperty('--ticker-duration', durationMs + 'ms');
 ticker.style.transform='translateX('+fromX+'px)';
 void ticker.offsetWidth;
 ticker.classList.add('is-scrolling');
 tickerScrollTimer=setTimeout(()=>{
   ticker.classList.remove('is-scrolling');
   ticker.style.transform='translateX('+fromX+'px)';
   tickerScrollBusy=false;
   tickerScrollTimer=setTimeout(runTickerScroll, 900);
 }, durationMs + 120);
}
function restartTickerScroll(){ stopTickerScroll(); requestAnimationFrame(runTickerScroll); }
function render(s){ buildRankingTicker(s); }
async function loop(){render(await getState())} loop(); setInterval(loop, 1600); window.addEventListener('resize',restartTickerScroll);
`;
  } else if (kind === "ranking-tikfinity") {
    body = `<section id="tapRank" class="tap-rank-widget" aria-label="Ranking tapów TikFinity">
  <div class="tap-rank-shell">
    <div class="tap-rank-label"><span>TOP LIKE</span><strong>RANKING TAPÓW</strong></div>
    <div class="tap-rank-window">
      <div id="liveTrack" class="tap-rank-track live-track">
        <div class="tap-rank-live-slot">
          <iframe id="tfTopLiker" src="${TIKFINITY_TOPLIKER_URL}" allow="autoplay; clipboard-read; clipboard-write"></iframe>
        </div>
      </div>
      <div id="demoTrack" class="tap-rank-track demo-track" style="display:none"></div>
    </div>
    <div class="tap-rank-total">♥</div>
  </div>
</section>`;
    script += `
let activeTapMode='';
let demoSig='';
let demoResetTimer=null;
const DEMO_SCROLL_MIN_SECONDS=46;
const DEMO_SCROLL_MAX_SECONDS=160;
function stopTrack(track){
 if(!track) return;
 track.classList.remove('tap-scroll');
 track.style.transform='translateX(0)';
}
function animateTrack(track, seconds){
 if(!track) return;
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const trackW=Math.max(1, track.scrollWidth || track.getBoundingClientRect().width || 900);
 const fromX=winW + 60;
 const toX=-(trackW + 80);
 track.classList.remove('tap-scroll');
 track.style.setProperty('--tap-from-x', fromX+'px');
 track.style.setProperty('--tap-to-x', toX+'px');
 track.style.setProperty('--tap-duration', Math.max(30, seconds)+'s');
 track.style.transform='translateX('+fromX+'px)';
 void track.offsetWidth;
 track.classList.add('tap-scroll');
}
function startDemoScroll(){
 const demo=document.getElementById('demoTrack');
 if(demoResetTimer) clearTimeout(demoResetTimer);
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const trackW=Math.max(1, demo.scrollWidth || demo.getBoundingClientRect().width || 900);
 const seconds=Math.max(DEMO_SCROLL_MIN_SECONDS, Math.min(DEMO_SCROLL_MAX_SECONDS, Math.round((winW+trackW+160)/32)));
 animateTrack(demo, seconds);
 demoResetTimer=setTimeout(startDemoScroll, (seconds*1000)+900);
}
function syncTopLikerUrl(url){
 const f=document.getElementById('tfTopLiker');
 if(!f || !url) return;
 const cur=(f.getAttribute('src')||'').trim();
 if(cur!==url) f.setAttribute('src', url);
}
function setMode(mode){
 if(activeTapMode===mode) return;
 activeTapMode=mode;
 const live=document.getElementById('liveTrack');
 const demo=document.getElementById('demoTrack');
 if(demoResetTimer) clearTimeout(demoResetTimer);
 demoResetTimer=null;
 if(mode==='demo'){
   if(live){ live.style.display='none'; stopTrack(live); }
   if(demo){ demo.style.display='inline-flex'; }
   requestAnimationFrame(startDemoScroll);
 } else {
   if(demo){ demo.style.display='none'; stopTrack(demo); }
   if(live){ live.style.display='block'; stopTrack(live); }
 }
}
function demoChip(it,i){
 const likes=Number(it.likes ?? it.points ?? 0)||0;
 const nick=it.nick||'Demo user';
 return '<div class="tap-chip '+(i===0?'top':'')+'"><span class="tap-place">#'+(i+1)+'</span><span class="tap-heart">♥</span><strong>'+esc(nick)+'</strong><span class="tap-likes">'+esc(likes)+'</span></div>';
}
function renderDemo(s){
 const r=(s.ranking||[]).filter(Boolean).slice(0,18);
 const items=r.length?r:[{nick:'Demo lajki lecą',likes:0}];
 const sig=JSON.stringify(items.map(x=>[x.nick,Number(x.likes??x.points??0)||0]));
 if(sig!==demoSig){
   demoSig=sig;
   const demo=document.getElementById('demoTrack');
   if(demo){ demo.innerHTML=items.map(demoChip).join(''); }
   if(activeTapMode==='demo') requestAnimationFrame(startDemoScroll);
 }
}
async function boot(){
 const s=await getState();
 const url=(s && s.tikfinityTopLikerUrl) || '${TIKFINITY_TOPLIKER_URL}';
 syncTopLikerUrl(url);
 if(s && s.demoMode){ renderDemo(s); setMode('demo'); }
 else { setMode('live'); }
}
boot();
setInterval(boot, 1500);
window.addEventListener('resize',()=>{ if(activeTapMode==='demo') startDemoScroll(); });
`;
  } else if (kind === "ranking-web") {
    body = `<div class="tf-web-ticker-stage"><div class="tf-web-hint">Ranking tapów TikFinity Web</div><div class="tf-web-ticker-rail"><div id="strip" class="tf-web-strip"><iframe id="tf" allow="autoplay; clipboard-read; clipboard-write"></iframe></div></div></div>`;
    script += `
let webTickerTimer=null;
let webTickerBusy=false;
let lastWebWidth=0;
const WEB_TICKER_SPEED_PX_PER_SEC=24;
const WEB_TICKER_MIN_DURATION_MS=120000;
const WEB_TICKER_MAX_DURATION_MS=300000;
function tuneWebTicker(){
 const strip = document.getElementById('strip');
 if(!strip) return;
 // Nie zmieniamy wyglądu TikFinity Web — przewijamy tylko zewnętrzny wrapper/iframe.
 const w = Math.max(3200, Math.round((window.innerWidth || 1080) * 3.6));
 strip.style.setProperty('--tf-strip-width', w + 'px');
 if(Math.abs(w - lastWebWidth) > 24){ lastWebWidth = w; restartWebTickerScroll(); }
}
function stopWebTickerScroll(){
 if(webTickerTimer) clearTimeout(webTickerTimer);
 webTickerTimer=null;
 webTickerBusy=false;
 const strip=document.getElementById('strip');
 if(strip){ strip.classList.remove('is-scrolling'); strip.style.transform='translateX(0)'; }
}
function runWebTickerScroll(){
 const strip=document.getElementById('strip');
 if(!strip) return;
 if(webTickerTimer) clearTimeout(webTickerTimer);
 const winW=Math.max(1, window.innerWidth || document.documentElement.clientWidth || 1080);
 const stripW=Math.max(1, parseFloat(getComputedStyle(strip).width) || strip.scrollWidth || lastWebWidth || 3200);
 const fromX=winW + 80;
 const toX=-(stripW + 80);
 const distance=fromX - toX;
 const durationMs=Math.max(WEB_TICKER_MIN_DURATION_MS, Math.min(WEB_TICKER_MAX_DURATION_MS, Math.round((distance / WEB_TICKER_SPEED_PX_PER_SEC) * 1000)));
 webTickerBusy=true;
 strip.classList.remove('is-scrolling');
 strip.style.setProperty('--tf-from-x', fromX + 'px');
 strip.style.setProperty('--tf-to-x', toX + 'px');
 strip.style.setProperty('--tf-web-duration', durationMs + 'ms');
 strip.style.transform='translateX('+fromX+'px)';
 void strip.offsetWidth;
 strip.classList.add('is-scrolling');
 webTickerTimer=setTimeout(()=>{
   strip.classList.remove('is-scrolling');
   strip.style.transform='translateX('+fromX+'px)';
   webTickerBusy=false;
   webTickerTimer=setTimeout(runWebTickerScroll, 900);
 }, durationMs + 120);
}
function restartWebTickerScroll(){ stopWebTickerScroll(); requestAnimationFrame(()=>{ tuneWebTicker(); runWebTickerScroll(); }); }
async function boot(){
 const s = await getState();
 const url = (s && s.tikfinityTopLikerUrl) || '${TIKFINITY_TOPLIKER_URL}';
 const f = document.getElementById('tf');
 if(f && f.src !== url) f.src = url;
 tuneWebTicker();
 if(!webTickerBusy) requestAnimationFrame(runWebTickerScroll);
}
boot(); setInterval(boot, 5000); window.addEventListener('resize', restartWebTickerScroll);
`;
  } else if (kind === "ranking-web-raw") {
    body = `<div id="root" class="web-widget"><div class="web-label">Ranking tapów TikFinity Web — surowy</div><iframe id="tf" allow="autoplay; clipboard-read; clipboard-write"></iframe><div class="web-frame"></div></div>`;
    script += `
async function boot(){
 const s = await getState();
 const url = (s && s.tikfinityTopLikerUrl) || '${TIKFINITY_TOPLIKER_URL}';
 const f = document.getElementById('tf');
 if(f && f.src !== url) f.src = url;
}
boot(); setInterval(boot, 5000);
`;
  } else if (kind === "activity") {
    body = `<div id="root" class="web-widget activity"><div class="web-label">Aktywności TikFinity</div><iframe id="tf" allow="autoplay; clipboard-read; clipboard-write"></iframe><div class="web-frame"></div></div>`;
    script += `
async function boot(){
 const s = await getState();
 const url = (s && s.tikfinityActivityFeedUrl) || '${TIKFINITY_ACTIVITY_FEED_URL}';
 const f = document.getElementById('tf');
 if(f && f.src !== url) f.src = url;
}
boot(); setInterval(boot, 5000);
`;
  } else {
    body = `<div class="demo-grid"><div class="demo-box"><iframe src="/widget-pytanie.html"></iframe></div><div class="demo-box"><iframe src="/widget-kolejka.html"></iframe></div><div class="demo-box" style="grid-column:1/3"><iframe src="/widget-ranking.html"></iframe></div><div class="demo-box demo-activity"><iframe src="/widget-aktywnosci.html"></iframe></div></div>`;
  }
  return `<!DOCTYPE html><html lang="pl"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>KVRINA widget</title><style>${WIDGET_CSS}</style></head><body>${body}<script>${script}</script></body></html>`;
}

function writeWidgetAssetFiles() {
  try {
    const dir = getWidgetsDir();
    fs.writeFileSync(path.join(dir, "widget-pytanie.html"), widgetHtml("question"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-aktualny.html"), widgetHtml("question"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-kolejka.html"), widgetHtml("queue"), "utf8");
    // 1.0.35: zostaje jeden oficjalny adres rankingu tapów: widget-ranking.html.
    // Stare nazwy plików zostają tylko jako techniczne aliasy tej samej zawartości, żeby stare źródła w OBS/TikTok Studio nie padły.
    fs.writeFileSync(path.join(dir, "widget-ranking.html"), widgetHtml("ranking-tikfinity"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-ranking-lokalny.html"), widgetHtml("ranking-tikfinity"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-ranking-web.html"), widgetHtml("ranking-tikfinity"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-ranking-web-raw.html"), widgetHtml("ranking-tikfinity"), "utf8");
    fs.writeFileSync(path.join(dir, "widget-aktywnosci.html"), widgetHtml("activity"), "utf8");
    fs.writeFileSync(path.join(dir, "demo.html"), widgetHtml("demo"), "utf8");
    ensureWidgetStateFile();
    writeWidgetAddressFile();
  } catch (e) {
    console.warn("[WIDGETY] asset write error:", e.message);
  }
}

function sendStaticFile(res, filePath) {
  try {
    if (!filePath || !fs.existsSync(filePath) || !fs.statSync(filePath).isFile()) {
      res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
      res.end("Not found");
      return;
    }
    const ext = path.extname(filePath).toLowerCase();
    const types = { ".html": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8", ".js": "application/javascript; charset=utf-8", ".json": "application/json; charset=utf-8", ".txt": "text/plain; charset=utf-8", ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".webp": "image/webp" };
    res.writeHead(200, { "Content-Type": types[ext] || "application/octet-stream", "Cache-Control": "no-store", "Access-Control-Allow-Origin": "*" });
    fs.createReadStream(filePath).pipe(res);
  } catch (e) {
    res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
    res.end("Server error");
  }
}

function startWidgetServer() {
  if (widgetServer) return;
  writeWidgetAssetFiles();
  widgetServer = http.createServer((req, res) => {
    try {
      const parsed = new URL(req.url || "/", `http://127.0.0.1:${widgetPort}`);
      let pathname = decodeURIComponent(parsed.pathname || "/");
      if (pathname === "/" || pathname === "/index.html") pathname = "/demo.html";
      if (pathname === "/widget_state.json") {
        ensureWidgetStateFile();
        return sendStaticFile(res, path.join(getWidgetsDir(), WIDGET_STATE_JSON));
      }
      const safe = safeJoin(getWidgetsDir(), pathname.replace(/^\/+/, ""));
      return sendStaticFile(res, safe);
    } catch (e) {
      res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8", "Access-Control-Allow-Origin": "*" });
      res.end("Server error");
    }
  });
  widgetServer.listen(widgetPort, "127.0.0.1", () => {
    console.log(`[WIDGETY] listening on http://127.0.0.1:${widgetPort}/demo.html`);
  });
}

// =========================
// Cloudflare Quick Tunnel (HTTPS) for Tipped
// =========================
let tunnelProc = null;
let tunnelUrl = null;

function getCloudflaredInstallHint() {
  if (process.platform === "darwin") {
    return "Nie mogę uruchomić cloudflared. Na Macu zainstaluj Homebrew, potem w Terminalu: brew install cloudflared. Jeśli już jest zainstalowany, uruchom program przez START_KVRINA_SHOW_MAC.command.";
  }
  if (process.platform === "win32") {
    return "Nie mogę uruchomić cloudflared. Zainstaluj cloudflared: winget install --id Cloudflare.cloudflared i uruchom program ponownie.";
  }
  return "Nie mogę uruchomić cloudflared. Zainstaluj cloudflared i uruchom program ponownie.";
}

function getCloudflaredCommand() {
  const candidates = process.platform === "darwin"
    ? ["/opt/homebrew/bin/cloudflared", "/usr/local/bin/cloudflared", "cloudflared"]
    : ["cloudflared"];
  for (const candidate of candidates) {
    if (candidate === "cloudflared") return candidate;
    try {
      if (fs.existsSync(candidate)) return candidate;
    } catch {}
  }
  return "cloudflared";
}

function stopTunnel() {
  try {
    if (tunnelProc) {
      tunnelProc.kill();
    }
  } catch {}
  tunnelProc = null;
  tunnelUrl = null;
}

function startQuickTunnel() {
  if (tunnelProc) {
    return { ok: true, alreadyRunning: true, url: tunnelUrl };
  }

  tunnelUrl = null;
  const args = ["tunnel", "--url", `http://127.0.0.1:${tippedPort}`];
  try {
    tunnelProc = spawn(getCloudflaredCommand(), args, { windowsHide: true });
  } catch (e) {
    tunnelProc = null;
    return { ok: false, error: getCloudflaredInstallHint() };
  }

  const onLine = (line) => {
    const s = String(line || "");
    const m = s.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/ig);
    if (m && m[0] && !tunnelUrl) {
      tunnelUrl = m[0];
      try {
        clipboard.writeText(`${tunnelUrl}/webhook`);
      } catch {}
      try {
        if (mainWindow && !mainWindow.isDestroyed()) {
          mainWindow.webContents.send("wb-tunnel-url", { url: tunnelUrl, webhookUrl: `${tunnelUrl}/webhook` });
        }
      } catch {}
    }
  };

  tunnelProc.stdout.on("data", (d) => {
    const text = d.toString("utf8");
    text.split(/\r?\n/).forEach(onLine);
  });

  tunnelProc.stderr.on("data", (d) => {
    const text = d.toString("utf8");
    text.split(/\r?\n/).forEach(onLine);
  });

  tunnelProc.on("exit", () => {
    stopTunnel();
    try {
      if (mainWindow && !mainWindow.isDestroyed()) {
        mainWindow.webContents.send("wb-tunnel-stopped", {});
      }
    } catch {}
  });

  return { ok: true, started: true };
}

function _seenStorePath() {
  return path.join(ensureOutputDir(), "tipped_seen_orders.json");
}

function loadSeenOrders() {
  try {
    const p = _seenStorePath();
    if (!fs.existsSync(p)) return;
    const raw = fs.readFileSync(p, "utf8");
    const arr = JSON.parse(raw);
    if (Array.isArray(arr)) {
      tippedSeen = new Set(arr.map(String));
    }
  } catch (e) {
    console.warn("[WB] loadSeenOrders failed:", e.message);
  }
}

function saveSeenOrders() {
  try {
    const p = _seenStorePath();
    const arr = Array.from(tippedSeen).slice(-5000); // cap
    fs.writeFileSync(p, JSON.stringify(arr, null, 2), "utf8");
  } catch (e) {
    console.warn("[WB] saveSeenOrders failed:", e.message);
  }
}


// =========================
// UKŁAD OKIEN / MONITORY
// =========================
const WINDOW_STATE_JSON = "window_state.json";
const MIN_WINDOW_WIDTH = 900;
const MIN_WINDOW_HEIGHT = 600;

function _windowStatePath() {
  return path.join(ensureOutputDir(), WINDOW_STATE_JSON);
}

function loadWindowState() {
  try {
    const p = _windowStatePath();
    if (!fs.existsSync(p)) return {};
    const raw = fs.readFileSync(p, "utf8");
    const obj = JSON.parse(raw || "{}");
    return obj && typeof obj === "object" ? obj : {};
  } catch (e) {
    console.warn("[WB] loadWindowState failed:", e.message);
    return {};
  }
}

function saveWindowState(state) {
  try {
    const p = _windowStatePath();
    fs.writeFileSync(p, JSON.stringify(state || {}, null, 2), "utf8");
    return true;
  } catch (e) {
    console.warn("[WB] saveWindowState failed:", e.message);
    return false;
  }
}

function _rectIntersects(a, b) {
  if (!a || !b) return false;
  return a.x < b.x + b.width && a.x + a.width > b.x && a.y < b.y + b.height && a.y + a.height > b.y;
}

function _clamp(n, min, max) {
  if (!Number.isFinite(n)) return min;
  if (max < min) return min;
  return Math.max(min, Math.min(max, n));
}

function getDisplayById(displayId) {
  try {
    const displays = screen.getAllDisplays();
    return displays.find((d) => String(d.id) === String(displayId)) || null;
  } catch {
    return null;
  }
}

function sanitizeWindowBounds(savedBounds, displayId, fallbackWidth, fallbackHeight) {
  const displays = screen.getAllDisplays();
  const primary = screen.getPrimaryDisplay();
  const saved = savedBounds && typeof savedBounds === "object" ? savedBounds : {};

  let width = Math.round(Number(saved.width) || fallbackWidth || 1400);
  let height = Math.round(Number(saved.height) || fallbackHeight || 900);
  width = _clamp(width, MIN_WINDOW_WIDTH, 10000);
  height = _clamp(height, MIN_WINDOW_HEIGHT, 10000);

  const requested = {
    x: Math.round(Number(saved.x)),
    y: Math.round(Number(saved.y)),
    width,
    height,
  };

  const requestedLooksValid = Number.isFinite(requested.x) && Number.isFinite(requested.y);
  const savedDisplay = getDisplayById(displayId);
  const matchingDisplay = requestedLooksValid ? screen.getDisplayMatching(requested) : null;
  const targetDisplay = savedDisplay || matchingDisplay || primary;
  const wa = targetDisplay.workArea || targetDisplay.bounds;

  // Jeśli zapisany prostokąt dalej dotyka któregoś aktualnego monitora, zachowujemy jego pozycję.
  if (requestedLooksValid && displays.some((d) => _rectIntersects(requested, d.workArea || d.bounds))) {
    return {
      x: _clamp(requested.x, wa.x - Math.round(width * 0.85), wa.x + wa.width - Math.round(width * 0.15)),
      y: _clamp(requested.y, wa.y, wa.y + wa.height - 80),
      width,
      height,
    };
  }

  // Jeśli monitor zniknął albo rozdzielczość się zmieniła — ustawiamy okno na środku wybranego/primary monitora.
  return {
    x: Math.round(wa.x + Math.max(0, (wa.width - width) / 2)),
    y: Math.round(wa.y + Math.max(0, (wa.height - height) / 2)),
    width: Math.min(width, wa.width),
    height: Math.min(height, wa.height),
  };
}

function getSavedWindowOptions(windowName, defaults) {
  const state = loadWindowState();
  const item = state && state[windowName] ? state[windowName] : null;
  const bounds = sanitizeWindowBounds(item && item.bounds, item && item.displayId, defaults.width, defaults.height);
  return {
    ...bounds,
    isMaximized: !!(item && item.isMaximized),
    isFullScreen: !!(item && item.isFullScreen),
  };
}

function persistWindowPlacement(windowName, win) {
  try {
    if (!win || win.isDestroyed()) return;
    const state = loadWindowState();
    const bounds = (win.isMaximized() || win.isFullScreen()) ? win.getNormalBounds() : win.getBounds();
    const display = screen.getDisplayMatching(bounds);
    state[windowName] = {
      bounds,
      displayId: display ? display.id : null,
      displayBounds: display ? display.bounds : null,
      isMaximized: win.isMaximized(),
      isFullScreen: win.isFullScreen(),
      savedAt: new Date().toISOString(),
    };
    saveWindowState(state);
  } catch (e) {
    console.warn(`[WB] persistWindowPlacement failed (${windowName}):`, e.message);
  }
}

function attachWindowPlacementMemory(windowName, win) {
  let t = null;
  const schedule = () => {
    try { if (t) clearTimeout(t); } catch {}
    t = setTimeout(() => persistWindowPlacement(windowName, win), 350);
  };
  try {
    win.on("move", schedule);
    win.on("resize", schedule);
    win.on("maximize", schedule);
    win.on("unmaximize", schedule);
    win.on("enter-full-screen", schedule);
    win.on("leave-full-screen", schedule);
    win.on("close", () => persistWindowPlacement(windowName, win));
  } catch (e) {
    console.warn(`[WB] attachWindowPlacementMemory failed (${windowName}):`, e.message);
  }
}

// =========================
// PREFERENCJE (ostatnio użyte pliki TXT)
// =========================
function _prefsPath() {
  return path.join(ensureOutputDir(), "wb_prefs.json");
}

function loadPrefs() {
  try {
    const p = _prefsPath();
    if (!fs.existsSync(p)) return;
    const raw = fs.readFileSync(p, "utf8");
    const obj = JSON.parse(raw || "{}");
    if (obj && typeof obj === "object") {
      if (typeof obj.manualTxtPath === "string" && obj.manualTxtPath.trim()) {
        MANUAL_QUESTIONS_FILE_PATH = obj.manualTxtPath;
      }
      if (typeof obj.autoTxtPath === "string" && obj.autoTxtPath.trim()) {
        AUTO_QUESTIONS_FILE_PATH = obj.autoTxtPath;
      }
    }
  } catch (e) {
    console.warn("[WB] loadPrefs failed:", e.message);
  }
}

function savePrefs() {
  try {
    const p = _prefsPath();
    const obj = {
      manualTxtPath: MANUAL_QUESTIONS_FILE_PATH || null,
      autoTxtPath: AUTO_QUESTIONS_FILE_PATH || null,
      savedAt: new Date().toISOString(),
    };
    fs.writeFileSync(p, JSON.stringify(obj, null, 2), "utf8");
  } catch (e) {
    console.warn("[WB] savePrefs failed:", e.message);
  }
}

function resetTxtFilesOnExit() {
  // 1.0.37: nie czyścimy już stanu przy zamykaniu.
  // Program ma po ponownym uruchomieniu wrócić do stanu sprzed wyłączenia.
  // Czysty start robi teraz tylko przycisk ZERUJ SESJĘ.
}

function normalizeQuestionLine(nick, msg) {
  const n = String(nick || "Anon").trim().replace(/[\r\n]+/g, " ").slice(0, 80) || "Anon";
  const q = String(msg || "").trim().replace(/[\r\n]+/g, " ").slice(0, 400);
  return { nick: n, question: q };
}

function appendQuestionBlockToFile(fullPath, nick, question) {
  try {
    if (!fullPath) return false;
    const block = `${nick}\n${question}\n\n`;
    fs.appendFileSync(fullPath, block, "utf8");
    return true;
  } catch (e) {
    console.error("[WB] appendQuestionBlockToFile failed:", e);
    return false;
  }
}

function safeTimingEqualString(a, b) {
  try {
    const aa = Buffer.from(String(a || ""));
    const bb = Buffer.from(String(b || ""));
    if (aa.length !== bb.length) return false;
    return crypto.timingSafeEqual(aa, bb);
  } catch {
    return false;
  }
}

function normalizeSignatureValue(v) {
  return String(v || "")
    .trim()
    .replace(/^sha256=/i, "")
    .replace(/^Bearer\s+/i, "")
    .trim();
}

function maybeVerifyTippedSignature(req, rawBody) {
  // Hash Tipped ustawiony domyślnie dla KVRINA_SHOW.
  // W praktyce Tipped potrafi przekazać hash/podpis różnymi drogami (nagłówek, query),
  // dlatego akceptujemy kilka wariantów. Jeśli podpisu w ogóle nie ma — nie blokujemy webhooka,
  // bo część konfiguracji Tipped nie wysyła nagłówka x-tipped-signature.
  if (!TIPPED_HASH) return true;
  try {
    const expected = String(TIPPED_HASH || "").trim();
    if (!expected) return true;

    let queryHash = "";
    try {
      const u = new URL(req.url || "/webhook", `http://127.0.0.1:${tippedPort}`);
      queryHash = u.searchParams.get("hash") || u.searchParams.get("webhook_hash") || u.searchParams.get("secret") || "";
    } catch {}

    let payloadHash = "";
    try {
      const parsed = JSON.parse(rawBody || "{}");
      payloadHash = parsed.hash || parsed.webhook_hash || parsed.webhookHash || parsed.secret || parsed.signature || "";
    } catch {}

    const directCandidates = [
      queryHash,
      payloadHash,
      req.headers["x-tipped-hash"],
      req.headers["x-webhook-hash"],
      req.headers["x-hook-secret"],
      req.headers["x-tipped-secret"],
      req.headers["authorization"],
    ].map(normalizeSignatureValue).filter(Boolean);

    if (directCandidates.some((v) => safeTimingEqualString(v, expected))) return true;

    const sig = normalizeSignatureValue(req.headers["x-tipped-signature"] || req.headers["x-signature"] || "");
    if (sig) {
      if (safeTimingEqualString(sig, expected)) return true;
      const h = crypto.createHmac("sha256", expected).update(rawBody).digest("hex");
      if (safeTimingEqualString(sig, h)) return true;
      return false;
    }

    console.warn("[WB] Tipped webhook bez podpisu/hash — przyjmuję payload, żeby nie blokować wpłat.");
    return true;
  } catch (e) {
    console.warn("[WB] Signature verify error:", e.message);
    return true;
  }
}

function startTippedServer() {
  if (tippedServer) return;
  loadSeenOrders();

  tippedServer = http.createServer((req, res) => {
    try {
      if (req.method === "GET" && req.url && req.url.startsWith("/webhook")) {
        res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("WB OK");
        return;
      }

      if (req.method !== "POST" || !req.url || !req.url.startsWith("/webhook")) {
        res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("Not Found");
        return;
      }

      let body = "";
      req.on("data", (chunk) => {
        body += chunk;
        if (body.length > 2_000_000) {
          req.destroy();
        }
      });
      req.on("end", () => {
        const rawBody = body;

        // Optional signature verification
        if (!maybeVerifyTippedSignature(req, rawBody)) {
          res.writeHead(401, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("Invalid signature");
          return;
        }

        let payload;
        try {
          payload = JSON.parse(rawBody || "{}");
        } catch {
          res.writeHead(400, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("Bad JSON");
          return;
        }

                const orderId = String(payload.order_id || payload.orderId || "").trim();
        const payerName = String(payload.payer_name || payload.payerName || payload.name || "Anon").trim();
        const message = String(payload.message || "").trim();

        if (orderId && tippedSeen.has(orderId)) {
          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("OK (duplicate)");
          return;
        }

        const ts = Date.now();
        const amount = getTippedAmount(payload);
        const isKartonDnia = isKartonDniaAmount(amount);
        const goalLabel = extractGoalLabel(payload);

        // Jeśli webhook ma ustawiony "Zbiórka / Cel" (cokolwiek niepustego) – traktujemy jako zbiórkę,
        // NIE dodajemy do czytnika pytań. Wyjątek: 5 zł odpala specjalny wpis KARTON DNIA.
        if (goalLabel && !isKartonDnia) {
          try {
            if (mainWindow && !mainWindow.isDestroyed()) {
              mainWindow.webContents.send("wb-tipped-fund", {
                ts,
                amount: amount ?? null,
                goal: goalLabel,
                payer: payerName,
                message: message || "",
                orderId: orderId || null,
              });
            }
          } catch {}

          if (orderId) {
            tippedSeen.add(orderId);
            saveSeenOrders();
          }

          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("OK (fund)");
          return;
        }

        const meta = computeQuestionsMeta(amount);

        // 30/60/80 zł wpadają do kolejki nawet bez wiadomości — wtedy pokazujemy "CZEKAM NA PYTANIE".
        // Poniżej 30 zł nie dodajemy normalnego pytania (wyjątek: KARTON DNIA za ok. 5 zł).
        if (!isKartonDnia && meta.count <= 0) {
          if (orderId) {
            tippedSeen.add(orderId);
            saveSeenOrders();
          }
          res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
          res.end("OK (amount below question threshold)");
          return;
        }

        const base = normalizeQuestionLine(payerName, isKartonDnia ? KARTON_DNIA_TEXT : (message || "x"));
        const nick = base.nick;
        const question = isKartonDnia ? KARTON_DNIA_TEXT : base.question;
        const kind = isKartonDnia ? "karton" : null;
        const questionCount = isKartonDnia ? 1 : Math.max(1, meta.count || 1);

        // Log chronologii (dla sortowania w rendererze)
        appendJsonlOutputFile(AUTO_LOG_JSONL, { ts, nick, question, kind, orderId: orderId || null, amount: amount ?? null, priority: !!meta.priority, questionCount });
        // Nie dopisujemy już pytań do zewnętrznych TXT — program trzyma kolejkę w pamięci.

        if (orderId) {
          tippedSeen.add(orderId);
          saveSeenOrders();
        }

        // Notify renderer for a subtle toast/log (optional)
        try {
          if (mainWindow && !mainWindow.isDestroyed()) {
            mainWindow.webContents.send("wb-tipped-question", {
              nick,
              question,
              ts,
              amount: amount ?? null,
              priority: !!meta.priority,
              kind,
              questionCount,
            });
          }
        } catch {}

        res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8" });
        res.end("OK");
      });
    } catch (e) {
      res.writeHead(500, { "Content-Type": "text/plain; charset=utf-8" });
      res.end("Server error");
    }
  });

  tippedServer.listen(tippedPort, "127.0.0.1", () => {
    console.log(`[WB] Tipped webhook server listening on http://127.0.0.1:${tippedPort}/webhook`);
  });
}

function ensureOutputDir() {
  if (OUTPUT_DIR) return OUTPUT_DIR;
  const desktop = app.getPath("desktop");
  OUTPUT_DIR = path.join(desktop, "KVRINA_SHOW TXT");
  if (!fs.existsSync(OUTPUT_DIR)) {
    fs.mkdirSync(OUTPUT_DIR, { recursive: true });
  }
  return OUTPUT_DIR;
}


// =========================
// GITHUB AUTO-AKTUALIZACJE
// =========================
const GITHUB_LATEST_JSON = "https://raw.githubusercontent.com/pioniton-cmyk/kvrina-show-releases/main/latest.json";

function compareVersions(a, b) {
  const pa = String(a).split(".").map(Number);
  const pb = String(b).split(".").map(Number);
  const len = Math.max(pa.length, pb.length);
  for (let i = 0; i < len; i++) {
    const na = pa[i] || 0, nb = pb[i] || 0;
    if (na > nb) return 1;
    if (na < nb) return -1;
  }
  return 0;
}

function checkGitHubRelease() {
  return new Promise((resolve) => {
    const req = https.get(GITHUB_LATEST_JSON, {
      headers: { "User-Agent": "KVRINA_SHOW" }
    }, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        res.resume();
        resolve({ available: false, error: "redirect" });
        return;
      }
      let data = "";
      res.on("data", (chunk) => { data += chunk; });
      res.on("end", () => {
        try {
          const remote = JSON.parse(data);
          const pkgPath = path.join(__dirname, "package.json");
          const current = JSON.parse(fs.readFileSync(pkgPath, "utf8")).version || "0.0.0";
          const latestVersion = remote.version || "0.0.0";
          const available = compareVersions(latestVersion, current) > 0;
          resolve({
            available,
            latestVersion,
            currentVersion: current,
            downloadUrl: remote.zipUrl || null,
            assetName: remote.zipName || "update.zip",
            releaseNotes: remote.notes || "",
            publishedAt: remote.publishedAt || ""
          });
        } catch (e) {
          resolve({ available: false, error: e.message });
        }
      });
    });
    req.on("error", (e) => resolve({ available: false, error: e.message }));
    req.setTimeout(9000, () => { req.destroy(); resolve({ available: false, error: "timeout" }); });
  });
}

function downloadFileToPath(url, destPath) {
  return new Promise((resolve, reject) => {
    const follow = (u, hops) => {
      if (hops > 6) return reject(new Error("Za dużo przekierowań"));
      const mod = u.startsWith("https") ? https : http;
      mod.get(u, { headers: { "User-Agent": "KVRINA_SHOW" } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          return follow(res.headers.location, hops + 1);
        }
        if (res.statusCode !== 200) {
          res.resume();
          return reject(new Error(`HTTP ${res.statusCode}`));
        }
        const file = fs.createWriteStream(destPath);
        res.pipe(file);
        file.on("finish", () => file.close(resolve));
        file.on("error", (e) => { try { fs.unlinkSync(destPath); } catch {} reject(e); });
      }).on("error", reject);
    };
    follow(url, 0);
  });
}

// =========================
// AKTUALIZACJE Z ZIPA
// =========================
const UPDATE_DIR_NAME = "aktualizacje";
const UPDATE_BACKUP_DIR_NAME = "backupy_aktualizacji";

function getAppBaseDir() {
  // Bez --asar: __dirname to realny folder z plikami zarówno w dev jak i w .app.
  return __dirname;
}

function ensureUpdatesDir() {
  const dir = path.join(getAppBaseDir(), UPDATE_DIR_NAME);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function ensureUpdateBackupsDir() {
  const dir = path.join(getAppBaseDir(), UPDATE_BACKUP_DIR_NAME);
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function updateTimestamp() {
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth()+1)}-${pad(d.getDate())}_${pad(d.getHours())}-${pad(d.getMinutes())}-${pad(d.getSeconds())}`;
}

function listUpdateZips() {
  const dir = ensureUpdatesDir();
  const files = fs.readdirSync(dir)
    .filter((name) => /\.zip$/i.test(name) && !name.startsWith("._"))
    .map((name) => {
      const fullPath = path.join(dir, name);
      const st = fs.statSync(fullPath);
      return { name, fullPath, mtimeMs: st.mtimeMs, size: st.size };
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);
  return files;
}

function copyDirSync(src, dest, skipNames = new Set()) {
  const st = fs.statSync(src);
  if (st.isDirectory()) {
    const base = path.basename(src);
    if (skipNames.has(base)) return;
    fs.mkdirSync(dest, { recursive: true });
    for (const entry of fs.readdirSync(src)) {
      if (skipNames.has(entry)) continue;
      copyDirSync(path.join(src, entry), path.join(dest, entry), skipNames);
    }
    return;
  }
  if (st.isFile()) {
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.copyFileSync(src, dest);
    try { fs.chmodSync(dest, st.mode); } catch {}
  }
}

function extractZipTo(zipPath, destDir) {
  fs.rmSync(destDir, { recursive: true, force: true });
  fs.mkdirSync(destDir, { recursive: true });

  let r;
  if (process.platform === "win32") {
    const cmd = `Expand-Archive -LiteralPath ${JSON.stringify(zipPath)} -DestinationPath ${JSON.stringify(destDir)} -Force`;
    r = spawnSync("powershell.exe", ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", cmd], { encoding: "utf8" });
  } else {
    r = spawnSync("ditto", ["-x", "-k", zipPath, destDir], { encoding: "utf8" });
    if (r.error || r.status !== 0) {
      r = spawnSync("unzip", ["-q", "-o", zipPath, "-d", destDir], { encoding: "utf8" });
    }
  }

  if (r.error) throw r.error;
  if (r.status !== 0) {
    throw new Error((r.stderr || r.stdout || "Nie udało się rozpakować ZIPa.").trim());
  }
}

function resolveUpdateRoot(tmpDir) {
  const entries = fs.readdirSync(tmpDir).filter((x) => !x.startsWith("__MACOSX") && x !== ".DS_Store");
  const hasMainHere = ["main.js", "package.json", "index.html"].some((name) => fs.existsSync(path.join(tmpDir, name)));
  if (hasMainHere) return tmpDir;
  if (entries.length === 1) {
    const only = path.join(tmpDir, entries[0]);
    if (fs.existsSync(only) && fs.statSync(only).isDirectory()) return only;
  }
  return tmpDir;
}

function readPackageVersionSafe(dir) {
  try {
    const p = path.join(dir, "package.json");
    if (!fs.existsSync(p)) return null;
    const obj = JSON.parse(fs.readFileSync(p, "utf8") || "{}");
    return obj.version || null;
  } catch { return null; }
}

function sanitizeZipFileName(name) {
  return String(name || "update.zip").replace(/[/\\?%*:|"<>]/g, "_");
}

function copyZipToUpdatesDir(sourcePath) {
  const dir = ensureUpdatesDir();
  const base = sanitizeZipFileName(path.basename(sourcePath));
  let dest = path.join(dir, base);
  if (path.resolve(sourcePath) === path.resolve(dest)) {
    return { ok: true, fullPath: dest, name: base, copied: false };
  }
  if (fs.existsSync(dest)) {
    const ext = path.extname(base) || ".zip";
    const stem = path.basename(base, ext);
    dest = path.join(dir, `${stem}_${updateTimestamp()}${ext}`);
  }
  fs.copyFileSync(sourcePath, dest);
  return { ok: true, fullPath: dest, name: path.basename(dest), copied: true };
}

function getUpdateSkipNames() {
  return new Set([
    "node_modules", "aktualizacje", "backupy_aktualizacji",
    "dist", ".git", ".cache", "tmp_update", "__MACOSX"
  ]);
}

function installUpdateZipFromPath(zipFullPath, zipLabel) {
  const zipName = zipLabel || path.basename(zipFullPath);
  const appDir = getAppBaseDir();
  const stamp = updateTimestamp();
  const tmpDir = path.join(ensureUpdatesDir(), `_tmp_instalacja_${stamp}`);
  const backupDir = path.join(ensureUpdateBackupsDir(), `backup_${stamp}`);
  const skip = getUpdateSkipNames();

  try {
    if (!zipFullPath || !fs.existsSync(zipFullPath)) {
      throw new Error("Nie znaleziono pliku ZIP aktualizacji.");
    }
    copyDirSync(appDir, backupDir, skip);
    extractZipTo(zipFullPath, tmpDir);
    const updateRoot = resolveUpdateRoot(tmpDir);
    const detectedVersion = readPackageVersionSafe(updateRoot);

    const looksLikeProgram = ["main.js", "package.json", "index.html"].some((name) => fs.existsSync(path.join(updateRoot, name)));
    if (!looksLikeProgram) {
      throw new Error("ZIP nie wygląda jak paczka KVRINA_SHOW — brakuje main.js / package.json / index.html.");
    }

    copyDirSync(updateRoot, appDir, skip);
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}

    return {
      ok: true,
      zip: zipName,
      zipPath: zipFullPath,
      backupDir,
      appDir,
      version: detectedVersion || readPackageVersionSafe(appDir),
      message: "Aktualizacja zainstalowana.",
    };
  } catch (e) {
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}
    return { ok: false, error: e.message, zip: zipName, backupDir };
  }
}

function installNewestUpdateZip() {
  const zips = listUpdateZips();
  if (!zips.length) {
    return { ok: false, error: "Brak pliku .zip w folderze aktualizacje." };
  }
  return installUpdateZipFromPath(zips[0].fullPath, zips[0].name);
}

async function pickUpdateZipPath() {
  const win = BrowserWindow.getFocusedWindow() || mainWindow;
  const pick = await dialog.showOpenDialog(win, {
    title: "Wybierz paczkę aktualizacji KVRINA_SHOW (.zip)",
    filters: [{ name: "ZIP", extensions: ["zip"] }],
    properties: ["openFile"],
  });
  if (pick.canceled || !pick.filePaths || !pick.filePaths.length) {
    return { ok: false, cancelled: true, error: "Anulowano wybór pliku." };
  }
  return { ok: true, filePath: pick.filePaths[0] };
}

async function finalizeUpdateInstallResult(result) {
  if (!result.ok) return result;
  try {
    const choice = await dialog.showMessageBox(mainWindow, {
      type: "info",
      title: "KVRINA_SHOW — aktualizacja zainstalowana",
      message: `Zainstalowano aktualizację${result.version ? " do wersji " + result.version : ""}.`,
      detail: `ZIP: ${result.zip}\nBackup programu: ${result.backupDir}\n\nZrestartować program teraz?`,
      buttons: ["Restart teraz", "Później"],
      defaultId: 0,
      cancelId: 1,
    });
    if (choice.response === 0) {
      app.relaunch({ execPath: process.execPath });
      app.exit(0);
    }
  } catch {}
  return result;
}

function listUpdateBackups() {
  const dir = ensureUpdateBackupsDir();
  return fs.readdirSync(dir)
    .filter((name) => name.startsWith("backup_"))
    .map((name) => {
      const fullPath = path.join(dir, name);
      const st = fs.statSync(fullPath);
      return { name, fullPath, mtimeMs: st.mtimeMs };
    })
    .filter((x) => {
      try { return fs.statSync(x.fullPath).isDirectory(); } catch { return false; }
    })
    .sort((a, b) => b.mtimeMs - a.mtimeMs);
}

function restorePreviousUpdateBackup() {
  const backups = listUpdateBackups();
  if (!backups.length) {
    return { ok: false, error: "Brak backupu poprzedniej wersji w folderze backupy_aktualizacji." };
  }

  const backup = backups[0];
  const appDir = getAppBaseDir();
  const stamp = updateTimestamp();
  const beforeRestoreDir = path.join(ensureUpdateBackupsDir(), `backup_przed_cofnieciem_${stamp}`);
  const skip = getUpdateSkipNames();

  try {
    copyDirSync(appDir, beforeRestoreDir, skip);
    copyDirSync(backup.fullPath, appDir, skip);
    return {
      ok: true,
      restoredFrom: backup.name,
      restoredFromPath: backup.fullPath,
      beforeRestoreDir,
      appDir,
      version: readPackageVersionSafe(appDir),
      message: "Poprzednia wersja została przywrócona."
    };
  } catch (e) {
    return { ok: false, error: e.message, restoredFrom: backup.name, beforeRestoreDir };
  }
}


let _appConfigLoaded = false;
let _appConfig = {};

function getConfigPath() {
  const dir = ensureOutputDir();
  return path.join(dir, "config.json");
}

function loadAppConfig() {
  try {
    const p = getConfigPath();
    if (fs.existsSync(p)) {
      const raw = fs.readFileSync(p, "utf8");
      const obj = JSON.parse(raw || "{}");
      _appConfig = obj && typeof obj === "object" ? obj : {};
      if (typeof _appConfig.tippedHash === "string" && _appConfig.tippedHash.trim()) {
        TIPPED_HASH = _appConfig.tippedHash.trim();
      }
    }
  } catch (e) {
    console.warn("[WB] config.json load error:", e.message);
  } finally {
    _appConfigLoaded = true;
  }
}

function saveAppConfig() {
  try {
    const p = getConfigPath();
    fs.writeFileSync(p, JSON.stringify(_appConfig || {}, null, 2), "utf8");
    return true;
  } catch (e) {
    console.warn("[WB] config.json save error:", e.message);
    return false;
  }
}


// Domyślne wartości liczników (pliki do OBS)
const DEFAULT_COUNTER_1 = "00:00:00";
const DEFAULT_COUNTER_2 = "00:00";

function safeWriteOutputFileSync(filename, data) {
  try {
    const dir = ensureOutputDir();
    const fullPath = path.join(dir, filename);
    fs.writeFileSync(fullPath, data ?? "", "utf-8");
  } catch (err) {
    console.error("safeWriteOutputFileSync error:", filename, err);
  }
}

function appendJsonlOutputFile(name, obj) {
  try {
    const dir = ensureOutputDir();
    const fullPath = path.join(dir, name);
    fs.appendFileSync(fullPath, JSON.stringify(obj) + "\n", "utf8");
    return true;
  } catch (e) {
    console.error("appendJsonlOutputFile error:", name, e.message);
    return false;
  }
}

function _num(v) {
  const n = typeof v === "number" ? v : parseFloat(String(v || "").replace(",", "."));
  return Number.isFinite(n) ? n : null;
}

function getTippedAmount(payload) {
  try {
    const keys = [
      "amount",
      "amount_value",
      "amountValue",
      "value",
      "price",
      "gross_amount",
      "grossAmount",
      "amount_gross",
      "amountGross",
      "amount_brutto",
      "amountBrutto",
      "amount_pln",
      "amountPLN",
    ];

    const normalizePln = (n, rawVal) => {
      if (n === null || n === undefined || !Number.isFinite(n)) return null;

      // Heurystyka TIPPED: część webhooków wysyła kwotę w groszach (np. 3000 zamiast 30.00).
      // Jeśli oryginał wygląda na "złotówki z przecinkiem" → zostaw.
      const rawStr = typeof rawVal === "string" ? rawVal.trim() : "";
      const rawLooksDecimal = rawStr && /[.,]\d{1,2}\s*$/.test(rawStr);

      if (!rawLooksDecimal && Number.isInteger(n) && n >= 1000) {
        // najczęściej: 3000 -> 30.00
        const pln = n / 100;
        return Math.round(pln * 100) / 100;
      }

      return Math.round(n * 100) / 100;
    };

    for (const k of keys) {
      if (payload && Object.prototype.hasOwnProperty.call(payload, k)) {
        const rawVal = payload[k];
        const n = _num(rawVal);
        if (n !== null) {
          const pln = normalizePln(n, rawVal);
          if (pln !== null) return pln;
        }
      }
    }
  } catch {}
  return null;
}


function _inAmountRange(amount, low, high) {
  const a = typeof amount === "number" ? amount : parseFloat(String(amount || "").replace(",", "."));
  if (!Number.isFinite(a)) return false;
  const eps = 0.005; // tolerancja na zaokrąglenia (0.5 grosza)
  return a + eps >= low && a - eps <= high;
}

function isKartonDniaAmount(amount) {
  // KARTON DNIA odpala się tylko dla wpłaty około 5,00 zł.
  // Tolerancja 1 grosza chroni przed formatami 4.99 / 5 / 5.00 z webhooka.
  return _inAmountRange(amount, 4.99, 5.01);
}

// Zasady liczenia pytań po kwocie (Tipped) – v1.0.10
// UWAGA: amount jest już w PLN (po normalizacji z groszy, jeśli webhook tak wysyła).
// Maks: 5 pytań na jedną wpłatę.
function computeQuestionsMeta(amount) {
  if (amount === null || amount === undefined || !Number.isFinite(amount)) {
    // Awaryjnie: jeśli Tipped zmieni format i kwoty nie uda się odczytać,
    // nie blokujemy pytania z wiadomością.
    return { count: 1, priority: false };
  }

  // POZAKOLEJKA: zostawiamy dawną logikę dla wysokich wpłat, ale bez mnożenia pytań.
  if (amount >= 100) {
    return { count: 1, priority: true };
  }

  // Nowe progi live:
  // 30 zł = 1 pytanie, 60 zł = 2 pytania, 80 zł = 3 pytania.
  if (amount >= 80) return { count: 3, priority: false };
  if (amount >= 60) return { count: 2, priority: false };
  if (amount >= 30) return { count: 1, priority: false };

  // Poniżej 30 zł nie robimy normalnego pytania (wyjątek: KARTON DNIA obsługiwany osobno).
  return { count: 0, priority: false };
}


// Rozpoznawanie "Zbiórka / Cel" w webhooku Tipped.
// Jeśli w payloadzie istnieje jakiekolwiek sensowne (niepuste) pole celu/zbiórki/kampanii,
// traktujemy wpłatę jako ZBIÓRKĘ (oddzielny licznik) i NIE wysyłamy jej do czytnika pytań.
function extractGoalLabel(payload) {
  try {
    const KEY_HINT = /(goal|cel|zbi[oó]rka|zbiorka|campaign|collection|target|fund|fundraiser|purpose|event)/i;

    const isEmpty = (s) => {
      const t = String(s || "").trim();
      if (!t) return true;
      if (t === "-" || t === "—" || t === "–") return true;
      if (/^[-–—]+$/.test(t)) return true;
      return false;
    };

    const fromValue = (v, depth) => {
      if (depth > 6 || v === null || v === undefined) return null;

      if (typeof v === "string") {
        const t = v.trim();
        return isEmpty(t) ? null : t;
      }

      if (typeof v !== "object") return null;

      if (Array.isArray(v)) {
        for (const it of v) {
          const r = fromValue(it, depth + 1);
          if (r) return r;
        }
        return null;
      }

      // typowe miejsca, gdzie siedzi nazwa zbiórki
      for (const k of ["name", "title", "label", "goalName", "campaignName", "campaignTitle"]) {
        if (typeof v[k] === "string") {
          const t = String(v[k] || "").trim();
          if (!isEmpty(t)) return t;
        }
      }

      // w obiekcie celu często jest np. { id, name }, więc jeśli nie znaleźliśmy,
      // przejdź po polach i spróbuj wyciągnąć pierwszą niepustą nazwę.
      for (const [k, val] of Object.entries(v)) {
        if (typeof val === "string") {
          const t = String(val || "").trim();
          if (!isEmpty(t) && /name|title|label/i.test(String(k || ""))) return t;
        }
      }

      return null;
    };

    const seen = new Set();

    const scan = (obj, depth) => {
      if (depth > 6 || obj === null || obj === undefined) return null;
      if (typeof obj !== "object") return null;

      if (seen.has(obj)) return null;
      seen.add(obj);

      if (Array.isArray(obj)) {
        for (const it of obj) {
          const r = scan(it, depth + 1);
          if (r) return r;
        }
        return null;
      }

      for (const [k, v] of Object.entries(obj)) {
        const key = String(k || "");
        if (!key) continue;

        // Jeśli klucz wskazuje na cel/zbiórkę/kampanię -> spróbuj wyciągnąć label
        if (KEY_HINT.test(key)) {
          const label = fromValue(v, depth + 1);
          if (label) return label;
        }

        // Idź głębiej, bo czasem cel jest zagnieżdżony w data/meta/extra...
        if (v && typeof v === "object") {
          const r = scan(v, depth + 1);
          if (r) return r;
        }
      }

      return null;
    };

    if (!payload || typeof payload !== "object") return null;
    return scan(payload, 0);
  } catch {
    return null;
  }
}


function applyQuestionsSuffix(nick, amount) {
  const n = String(nick || "").trim();
  const meta = computeQuestionsMeta(amount);
  if (meta.count >= 2) return `${n} -${meta.count}pyt`;
  return n;
}



function resetCounterFilesSync() {
  safeWriteOutputFileSync("odliczanie1.txt", DEFAULT_COUNTER_1);
  safeWriteOutputFileSync("odliczanie2.txt", DEFAULT_COUNTER_2);
}



function ensureCounterFilesExist() {
  const dir = ensureOutputDir();
  const p1 = path.join(dir, "odliczanie1.txt");
  const p2 = path.join(dir, "odliczanie2.txt");
  try {
    if (!fs.existsSync(p1)) fs.writeFileSync(p1, DEFAULT_COUNTER_1, "utf8");
    if (!fs.existsSync(p2)) fs.writeFileSync(p2, DEFAULT_COUNTER_2, "utf8");
  } catch (err) {
    console.error("ensureCounterFilesExist error:", err);
  }
}


// =========================
// GLOBAL SHORTCUTS (działają nawet gdy okno nie jest aktywne)
// Wariant 1 (Windows): Ctrl + Alt + Shift + → / ←
// W Electronie rejestrujemy to jako: CommandOrControl + Alt + Shift + Right/Left
// (na Windowsie to będzie Ctrl, na macOS Command)
// =========================
function _wbSendToRenderer(channel) {
  try {
    if (mainWindow && !mainWindow.isDestroyed()) {
      mainWindow.webContents.send(channel);
    }
  } catch (e) {
    console.error("wbSendToRenderer error:", e);
  }
}

function registerGlobalShortcuts() {
  const nextOk = globalShortcut.register(
    "CommandOrControl+Alt+Shift+Right",
    () => _wbSendToRenderer("wb-questions-next")
  );

  const prevOk = globalShortcut.register(
    "CommandOrControl+Alt+Shift+Left",
    () => _wbSendToRenderer("wb-questions-prev")
  );

  if (!nextOk) {
    console.warn("[WB] Nie udało się zarejestrować globalnego skrótu: Ctrl+Alt+Shift+Right");
  }
  if (!prevOk) {
    console.warn("[WB] Nie udało się zarejestrować globalnego skrótu: Ctrl+Alt+Shift+Left");
  }
}


function createWindow() {
  const savedWindow = getSavedWindowOptions("mainWindow", { width: 1400, height: 900 });

  const iconPath = path.join(__dirname, "icon.icns");
  const appIcon = fs.existsSync(iconPath) ? nativeImage.createFromPath(iconPath) : null;

  mainWindow = new BrowserWindow({
    width: savedWindow.width,
    height: savedWindow.height,
    x: savedWindow.x,
    y: savedWindow.y,
    icon: appIcon || undefined,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      nodeIntegration: false,
      contextIsolation: true,
    },
  });

  if (appIcon && app.dock) {
    app.dock.setIcon(appIcon);
  }

  attachWindowPlacementMemory("mainWindow", mainWindow);
  if (savedWindow.isMaximized) {
    try { mainWindow.maximize(); } catch {}
  }
  if (savedWindow.isFullScreen) {
    try { mainWindow.setFullScreen(true); } catch {}
  }

  mainWindow.loadFile("index.html");
  mainWindow.webContents.on("did-finish-load", async () => {
    try {
      // Wyślij do renderer ostatnio użyte ścieżki (żeby ustawiło się automatycznie przy starcie)
      mainWindow.webContents.send("wb-last-question-paths", {
        manual: MANUAL_QUESTIONS_FILE_PATH,
        auto: AUTO_QUESTIONS_FILE_PATH,
      });
    } catch {}

    // AUTOSTART: odpal tunel cloudflared i pokaż URL w UI
    try {
      startQuickTunnel();
    } catch {}
  });


  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}
app.whenReady().then(() => {
  const _startPkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
  const _snap0 = getPerformanceSnapshot();
  diagInfo(`=== KVRINA_SHOW v${_startPkg.version || "?"} start === platform=${process.platform}/${process.arch} electron=${process.versions.electron} RAM=${_snap0.rssMB}MB free=${_snap0.freeRamMB}/${_snap0.totalRamMB}MB`);
  setInterval(() => {
    const s = getPerformanceSnapshot();
    diagInfo(`[PERF] heap=${s.heapUsedMB}/${s.heapTotalMB}MB rss=${s.rssMB}MB cpu=${s.cpuPct}% freeRAM=${s.freeRamMB}MB uptime=${s.uptime}s load=${s.loadAvg}`);
  }, 5 * 60 * 1000);
  ensureOutputDir();
  ensureUpdatesDir();
  ensureUpdateBackupsDir();
  ensureCounterFilesExist();
  writeWidgetAssetFiles();

  // wczytaj ostatnie ustawienia (pliki TXT)
  loadPrefs();
  loadAppConfig();

  startTippedServer();
  startWidgetServer();
  createWindow();
  registerGlobalShortcuts();

  app.on("activate", () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on("before-quit", () => {
  try { resetTxtFilesOnExit(); } catch {}
  try { stopTunnel(); } catch {}
  try { if (widgetServer) widgetServer.close(); } catch {}
});

app.on("window-all-closed", () => {
  if (process.platform !== "darwin") {
    app.quit();
  }
});

// IPC: OUTPUT DIR
ipcMain.handle("wb-get-output-dir", async () => {
  try {
    const dir = ensureOutputDir();
    return dir;
  } catch (err) {
    console.error("wb-get-output-dir error:", err);
    throw err;
  }
});

// IPC: OPEN OUTPUT DIR (Explorer)
ipcMain.handle("wb-open-output-dir", async () => {
  try {
    const dir = ensureOutputDir();
    await shell.openPath(dir);
    return { ok: true };
  } catch (err) {
    console.error("wb-open-output-dir error:", err);
    return { ok: false, error: err.message };
  }
});




// IPC: OPEN WIDGETS DIR
ipcMain.handle("wb-open-widgets-dir", async () => {
  try {
    writeWidgetAssetFiles();
    const dir = getWidgetsDir();
    await shell.openPath(dir);
    return { ok: true, dir };
  } catch (err) {
    console.error("wb-open-widgets-dir error:", err);
    return { ok: false, error: err.message };
  }
});


// =========================
// IPC: AKTUALIZACJE Z ZIPA
// =========================
ipcMain.handle("wb-open-updates-dir", async () => {
  try {
    const dir = ensureUpdatesDir();
    await shell.openPath(dir);
    return { ok: true, dir };
  } catch (err) {
    console.error("wb-open-updates-dir error:", err);
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("wb-update-check", async () => {
  try {
    const dir = ensureUpdatesDir();
    const zips = listUpdateZips();
    return { ok: true, dir, zips, backups: listUpdateBackups() };
  } catch (err) {
    return { ok: false, error: err.message };
  }
});

ipcMain.handle("wb-update-install", async () => {
  return finalizeUpdateInstallResult(installNewestUpdateZip());
});

ipcMain.handle("wb-update-pick-install", async () => {
  const picked = await pickUpdateZipPath();
  if (!picked.ok) return picked;
  const copied = copyZipToUpdatesDir(picked.filePath);
  const result = installUpdateZipFromPath(copied.fullPath, copied.name);
  if (result.ok && copied.copied) {
    result.savedTo = copied.fullPath;
  }
  return finalizeUpdateInstallResult(result);
});

ipcMain.handle("wb-update-restore-previous", async () => {
  try {
    const backups = listUpdateBackups();
    if (!backups.length) return { ok: false, error: "Brak backupu poprzedniej wersji." };

    const ask = await dialog.showMessageBox(mainWindow, {
      type: "warning",
      title: "KVRINA_SHOW — cofnąć wersję?",
      message: "Przywrócić poprzednią wersję programu?",
      detail: `Zostanie użyty najnowszy backup: ${backups[0].name}\n\nObecna wersja też zostanie zabezpieczona, więc można wrócić później.`,
      buttons: ["Cofnij wersję", "Anuluj"],
      defaultId: 0,
      cancelId: 1,
    });
    if (ask.response !== 0) return { ok: false, cancelled: true, error: "Anulowano." };

    const result = restorePreviousUpdateBackup();
    if (!result.ok) return result;

    const choice = await dialog.showMessageBox(mainWindow, {
      type: "info",
      title: "KVRINA_SHOW — wersja przywrócona",
      message: `Przywrócono poprzednią wersję${result.version ? " (" + result.version + ")" : ""}.`,
      detail: `Backup: ${result.restoredFrom}\nZabezpieczenie obecnej wersji: ${result.beforeRestoreDir}\n\nZrestartować program teraz?`,
      buttons: ["Restart teraz", "Później"],
      defaultId: 0,
      cancelId: 1,
    });
    if (choice.response === 0) {
      app.relaunch({ execPath: process.execPath });
      app.exit(0);
    }
    return result;
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// =========================
// IPC: GITHUB AUTO-AKTUALIZACJE
// =========================
ipcMain.handle("wb-github-check", async () => {
  try {
    return await checkGitHubRelease();
  } catch (e) {
    return { available: false, error: e.message };
  }
});

ipcMain.handle("wb-github-download-install", async (event, { downloadUrl, assetName }) => {
  const send = (status, detail) => {
    if (mainWindow && !mainWindow.isDestroyed())
      mainWindow.webContents.send("wb-github-progress", { status, detail });
    console.log(`[AKTUALIZACJA] ${status}${detail ? ": " + detail : ""}`);
  };
  try {
    if (!downloadUrl) return { ok: false, error: "Brak URL do pobrania." };

    // KROK 1 — pobieranie
    send("downloading", downloadUrl);
    const tmpDir = path.join(os.tmpdir(), `kvrina_github_${Date.now()}`);
    fs.mkdirSync(tmpDir, { recursive: true });
    const tmpZip = path.join(tmpDir, assetName || "github_update.zip");
    await downloadFileToPath(downloadUrl, tmpZip);

    const zipSize = fs.statSync(tmpZip).size;
    if (zipSize < 1000) return { ok: false, error: `ZIP za mały (${zipSize} bajtów) — pobieranie nie powiodło się.` };
    send("downloaded", `${(zipSize/1024).toFixed(0)} KB`);

    // KROK 2 — instalacja
    send("installing", `cel: ${getAppBaseDir()}`);
    const result = installUpdateZipFromPath(tmpZip, assetName || "github_update.zip");
    try { fs.rmSync(tmpDir, { recursive: true, force: true }); } catch {}

    if (!result.ok) {
      send("error", result.error);
      return result;
    }
    send("installed", `wersja: ${result.version || "?"}`);

    // KROK 3 — dialog restartu
    if (mainWindow && !mainWindow.isDestroyed()) mainWindow.focus();
    return await finalizeUpdateInstallResult(result);
  } catch (e) {
    send("error", e.message);
    return { ok: false, error: e.message };
  }
});

// =========================
// IPC: CLOUDLFARED QUICK TUNNEL (HTTPS)
// =========================
ipcMain.handle("wb-tunnel-start", async () => {
  const r = startQuickTunnel();
  return { ...r, url: tunnelUrl, webhookUrl: tunnelUrl ? `${tunnelUrl}/webhook` : null };
});

ipcMain.handle("wb-tunnel-stop", async () => {
  stopTunnel();
  return { ok: true };
});

ipcMain.handle("wb-tunnel-get", async () => {
  return { ok: true, url: tunnelUrl, webhookUrl: tunnelUrl ? `${tunnelUrl}/webhook` : null, running: !!tunnelProc };
});

ipcMain.handle("wb-webhook-get-status", async () => {
  return {
    ok: true,
    running: !!tippedServer,
    port: tippedPort,
    pending: tippedPending.length,
    autoFile: AUTO_QUESTIONS_FILE_PATH || null,
    tunnelRunning: !!tunnelProc,
    tunnelUrl: tunnelUrl || null,
    widgetPort,
    widgetUrl: `http://127.0.0.1:${widgetPort}/demo.html`,
    tippedHash: TIPPED_HASH,
    expectedTippedHash: DEFAULT_TIPPED_HASH,
    hashOk: TIPPED_HASH === DEFAULT_TIPPED_HASH,
  };
});


ipcMain.handle("wb-clipboard-copy", async (event, { text }) => {
  try {
    clipboard.writeText(String(text || ""));
    savePrefs();
    savePrefs();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  }
});

// IPC: WRITE FILE (do katalogu OUTPUT_DIR)
ipcMain.handle("wb-write-file", async (event, { name, data }) => {
  const dir = ensureOutputDir();
  const fullPath = safeJoin(dir, name);
  try {
    if (!fullPath) return { ok: false, error: "Invalid path" };
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.writeFileSync(fullPath, data ?? "", "utf8");
    return { ok: true, fullPath };
  } catch (err) {
    console.error("wb-write-file error:", err);
    return { ok: false, error: err.message };
  }
});


// IPC: APPEND FILE (do katalogu OUTPUT_DIR) — dopisuje na koniec, nie nadpisuje
ipcMain.handle("wb-append-file", async (event, { name, data }) => {
  try {
    const dir = ensureOutputDir();
    const fullPath = safeJoin(dir, name);
    if (!fullPath) return { ok: false, error: "Invalid path" };
    fs.mkdirSync(path.dirname(fullPath), { recursive: true });
    fs.appendFileSync(fullPath, data ?? "", "utf-8");
    return { ok: true };
  } catch (err) {
    console.error("wb-append-file error:", err);
    return { ok: false, error: err.message };
  }
});


// IPC: READ FILE (z OUTPUT_DIR)
ipcMain.handle("wb-read-file", async (event, { name }) => {
  const dir = ensureOutputDir();
  const fullPath = safeJoin(dir, name);
  try {
    if (!fullPath) return { ok: false, error: "Invalid path" };
    if (!fs.existsSync(fullPath)) {
      return { ok: true, data: "", fullPath };
    }
    const data = fs.readFileSync(fullPath, "utf8");
    return { ok: true, data, fullPath };
  } catch (err) {
    console.error("wb-read-file error:", err);
    return { ok: false, error: err.message };
  }
});

// IPC: READ ABSOLUTE FILE (do pliku z pytaniami)
ipcMain.handle("wb-read-absolute-file", async (event, { fullPath }) => {
  try {
    if (!fs.existsSync(fullPath)) {
      return { ok: false, error: "File not found" };
    }
    const stat = fs.statSync(fullPath);
    const data = fs.readFileSync(fullPath, "utf8");
    return { ok: true, data, mtimeMs: stat.mtimeMs };
  } catch (err) {
    console.error("wb-read-absolute-file error:", err);
    return { ok: false, error: err.message };
  }
});

// IPC: OPEN QUESTION FILE DIALOG
// IPC: OPEN QUESTION FILE DIALOG (manual/auto)
ipcMain.handle("wb-open-question-file", async (event, { mode } = {}) => {
  try {
    const m = String(mode || "").toLowerCase();
    const title = m === "auto" ? "Wybierz plik TXT (AUTO – donejty)" : m === "manual" ? "Wybierz plik TXT (RĘCZNE pytania)" : "Wybierz plik z pytaniami";
    const result = await dialog.showOpenDialog({
      title,
      properties: ["openFile"],
      filters: [{ name: "Pliki tekstowe", extensions: ["txt"] }],
    });
    if (result.canceled || !result.filePaths || !result.filePaths[0]) {
      return { ok: true, canceled: true };
    }
    const fullPath = result.filePaths[0];
    const stat = fs.statSync(fullPath);
    const data = fs.readFileSync(fullPath, "utf8");
    return {
      ok: true,
      canceled: false,
      fullPath,
      data,
      mtimeMs: stat.mtimeMs,
    };
  } catch (err) {
    console.error("wb-open-question-file error:", err);
    return { ok: false, error: err.message };
  }
});

// IPC: SET CURRENT QUESTIONS FILE PATH
// mode: "manual" | "auto" (default: "auto" for backward compatibility)
ipcMain.handle("wb-set-questions-file-path", async (event, { fullPath, mode } = {}) => {
  try {
    if (!fullPath || typeof fullPath !== "string") return { ok: false, error: "Invalid path" };
    const m = String(mode || "auto").toLowerCase();
    if (m === "manual") {
      MANUAL_QUESTIONS_FILE_PATH = fullPath;
      savePrefs();
      return { ok: true };
    }

    AUTO_QUESTIONS_FILE_PATH = fullPath;

    // Flush pending questions captured before file was selected.
    if (tippedPending.length) {
      const pending = tippedPending;
      tippedPending = [];
      for (const it of pending) {
        if (it && it.nick && it.question) {
          appendQuestionBlockToFile(AUTO_QUESTIONS_FILE_PATH, it.nick, it.question);
        }
      }
    }
    savePrefs();
    return { ok: true };

  } catch (e) {
    return { ok: false, error: e.message };
  }
});


// IPC: GET LAST QUESTIONS FILE PATHS (manual + auto)
ipcMain.handle("wb-get-last-questions-file-paths", async () => {
  return {
    ok: true,
    manual: MANUAL_QUESTIONS_FILE_PATH,
    auto: AUTO_QUESTIONS_FILE_PATH,
  };
});

// =========================
// CHAT POP-OUT WINDOW
// =========================
function createChatWindow() {
  if (chatWindow && !chatWindow.isDestroyed()) {
    try { chatWindow.focus(); } catch {}
    return chatWindow;
  }

  const savedChatWindow = getSavedWindowOptions("chatWindow", { width: 460, height: 820 });

  chatWindow = new BrowserWindow({
    width: savedChatWindow.width,
    height: savedChatWindow.height,
    x: savedChatWindow.x,
    y: savedChatWindow.y,
    title: "WB Chat",
    backgroundColor: "#020308",
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  attachWindowPlacementMemory("chatWindow", chatWindow);
  if (savedChatWindow.isMaximized) {
    try { chatWindow.maximize(); } catch {}
  }
  if (savedChatWindow.isFullScreen) {
    try { chatWindow.setFullScreen(true); } catch {}
  }

  chatWindow.setMenuBarVisibility(false);

  try {
    chatWindow.loadFile(path.join(__dirname, "chat.html"));
  } catch (err) {
    console.error("Failed to load chat.html:", err);
  }

  chatWindow.on("closed", () => {
    chatWindow = null;
  });

  return chatWindow;
}


// ===== Chat pop-out IPC =====
ipcMain.handle("wb-open-chat-window", async () => {
  try {
    createChatWindow();
    return { ok: true };
  } catch (err) {
    console.error("wb-open-chat-window error:", err);
    return { ok: false, error: err.message };
  }
});

ipcMain.on("wb-chat-line", (evt, payload) => {
  try {
    if (chatWindow && !chatWindow.isDestroyed()) {
      chatWindow.webContents.send("wb-chat-line", payload || {});
    }
  } catch (err) {
    // ignore
  }
});


// ===== DIAGNOSTYKA IPC =====
ipcMain.handle("diag-get-log", async () => {
  let fileLines = [];
  try {
    const raw = fs.readFileSync(path.join(__dirname, DIAG_LOG_FILE), "utf8");
    fileLines = raw.split("\n").filter(Boolean).slice(-300);
  } catch {}
  const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
  return {
    log: _diagLog.slice(-150),
    fileLines,
    version: pkg.version || "?",
    platform: `${process.platform} ${process.arch}`,
    electron: process.versions.electron,
    node: process.versions.node,
    perf: getPerformanceSnapshot(),
  };
});

ipcMain.handle("diag-send-report", async (event, { message, type = "raport" } = {}) => {
  try {
    const pkg = (() => { try { return JSON.parse(fs.readFileSync(path.join(__dirname, "package.json"), "utf8")); } catch { return {}; } })();
    const version = pkg.version || "?";
    const logSnippet = _diagLog.slice(-60).map(e => `[${e.ts}] [${e.level}] ${e.msg}`).join("\n");
    const emoji = type === "crash" ? "🔴" : type === "bug" ? "🐛" : type === "suggestion" ? "💡" : "💬";
    const label = type === "crash" ? "auto-crash" : type === "bug" ? "diagnostics" : "kvrina-report";
    const title = `${emoji} [v${version}] ${(message || "(brak treści)").slice(0, 80)}`;
    const body = [
      `## Wiadomość od Kvriny`,
      "",
      message || "(brak wiadomości)",
      "",
      `## Informacje systemowe`,
      `| | |`,
      `|---|---|`,
      `| Wersja | ${version} |`,
      `| System | ${process.platform} ${process.arch} |`,
      `| Electron | ${process.versions.electron} |`,
      `| Node | ${process.versions.node} |`,
      `| Data | ${new Date().toISOString()} |`,
      ``,
      `## Wydajność (snapshot)`,
      (() => { const p = getPerformanceSnapshot(); return `| | |\n|---|---|\n| Heap | ${p.heapUsedMB} / ${p.heapTotalMB} MB |\n| RSS | ${p.rssMB} MB |\n| CPU (proc) | ${p.cpuPct}% |\n| RAM wolna | ${p.freeRamMB} / ${p.totalRamMB} MB |\n| Load avg | ${p.loadAvg} |\n| Uptime apki | ${p.uptime}s |`; })(),
      "",
      `## Ostatnie logi`,
      "```",
      logSnippet || "(brak)",
      "```",
    ].join("\n");

    const result = await _sendDiagIssue(title, body, [label]);
    if (result.ok) {
      diagInfo(`Raport wysłany: #${result.data.number} ${result.data.html_url}`);
      return { ok: true, url: result.data.html_url, number: result.data.number };
    } else {
      diagError(`Błąd raportu: HTTP ${result.status}`);
      return { ok: false, error: `HTTP ${result.status}` };
    }
  } catch (e) {
    diagError(`diag-send-report error: ${e.message}`);
    return { ok: false, error: e.message };
  }
});

ipcMain.handle("diag-get-reports", async (event, { state = "open" } = {}) => {
  return new Promise((resolve) => {
    const options = {
      hostname: "api.github.com",
      path: `/repos/${_db}/issues?state=${state}&per_page=50&sort=created&direction=desc`,
      method: "GET",
      headers: {
        "Authorization": `Bearer ${_da.join("")}`,
        "User-Agent": "KVRINA_SHOW",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
      },
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try { resolve({ ok: res.statusCode < 300, issues: JSON.parse(buf) }); }
        catch { resolve({ ok: false, issues: [], error: buf }); }
      });
    });
    req.on("error", (e) => resolve({ ok: false, issues: [], error: e.message }));
    req.end();
  });
});

ipcMain.handle("diag-close-issue", async (event, { number } = {}) => {
  return new Promise((resolve) => {
    const data = JSON.stringify({ state: "closed" });
    const options = {
      hostname: "api.github.com",
      path: `/repos/${_db}/issues/${number}`,
      method: "PATCH",
      headers: {
        "Authorization": `Bearer ${_da.join("")}`,
        "Content-Type": "application/json",
        "User-Agent": "KVRINA_SHOW",
        "Accept": "application/vnd.github+json",
        "Content-Length": Buffer.byteLength(data),
        "X-GitHub-Api-Version": "2022-11-28",
      },
    };
    const req = https.request(options, (res) => {
      let buf = "";
      res.on("data", (c) => buf += c);
      res.on("end", () => {
        try { resolve({ ok: res.statusCode < 300, issue: JSON.parse(buf) }); }
        catch { resolve({ ok: false }); }
      });
    });
    req.on("error", (e) => resolve({ ok: false, error: e.message }));
    req.write(data);
    req.end();
  });
});

ipcMain.handle("diag-clear-log", async () => {
  _diagLog = [];
  try { fs.writeFileSync(path.join(__dirname, DIAG_LOG_FILE), ""); } catch {}
  return { ok: true };
});

app.on("will-quit", () => {
  try { globalShortcut.unregisterAll(); } catch (e) {}
  try { stopTunnel(); } catch (e) {}
  try { if (tippedServer) tippedServer.close(); } catch (e) {}
  diagInfo("App zamknięty.");
});
