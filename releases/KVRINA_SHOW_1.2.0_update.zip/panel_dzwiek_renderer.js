// =========================
// KVRINA_SHOW — panel_dzwiek_renderer.js
// Okienko DŹWIĘK: włączniki, suwaki głośności i wybór plików.
// Samo nic nie odtwarza — to tylko pilot. Dźwiękiem zajmuje się główne (ukryte)
// okno, dzięki czemu muzyka gra także po zamknięciu tego panelu.
// =========================

let _sndFirstLoad = true;

function pct(v) {
  return `${Math.round((Number(v) || 0) * 100)}%`;
}

async function sndPush(patch) {
  if (!window.wbApi || typeof window.wbApi.soundSetSettings !== "function") return;
  try { await window.wbApi.soundSetSettings(patch); } catch (e) { console.error("soundSetSettings:", e); }
}

async function sndControl(action) {
  if (!window.wbApi || typeof window.wbApi.soundControl !== "function") return;
  try { await window.wbApi.soundControl({ action }); } catch (e) { console.error("soundControl:", e); }
}

function fillNotifySelect(files, selected) {
  const sel = document.getElementById("snd-notify-file");
  if (!sel) return;
  const current = selected || (files[0] || "");
  // Nie przebudowujemy listy w trakcie wybierania — to gubiłoby zaznaczenie.
  const sig = files.join("|");
  if (sel.dataset.sig !== sig) {
    sel.dataset.sig = sig;
    sel.innerHTML = "";
    if (!files.length) {
      const o = document.createElement("option");
      o.value = "";
      o.textContent = "— brak plików w folderze —";
      sel.appendChild(o);
    } else {
      files.forEach((f) => {
        const o = document.createElement("option");
        o.value = f;
        o.textContent = f;
        sel.appendChild(o);
      });
    }
  }
  if (files.length && sel.value !== current) sel.value = current;
}

async function loadSound() {
  if (!window.wbApi || typeof window.wbApi.soundGetState !== "function") return;
  let r;
  try { r = await window.wbApi.soundGetState(); } catch { return; }
  if (!r || !r.ok) return;

  const s = r.settings || {};
  const notifyFiles = r.notifyFiles || [];
  const musicFiles = r.musicFiles || [];

  const setChecked = (id, val) => {
    const el = document.getElementById(id);
    if (el && el.checked !== !!val) el.checked = !!val;
  };
  const setRange = (id, valId, val) => {
    const el = document.getElementById(id);
    const lab = document.getElementById(valId);
    // Nie nadpisujemy suwaka, który użytkownik właśnie przeciąga.
    if (el && document.activeElement !== el) el.value = Math.round((Number(val) || 0) * 100);
    if (lab) lab.textContent = pct(val);
  };

  setChecked("snd-notify-on", s.notifyEnabled);
  setChecked("snd-music-on", s.musicEnabled);
  setChecked("snd-music-shuffle", s.musicShuffle);
  setRange("snd-notify-vol", "snd-notify-vol-val", s.notifyVolume);
  setRange("snd-music-vol", "snd-music-vol-val", s.musicVolume);

  fillNotifySelect(notifyFiles, s.notifyFile);

  const nc = document.getElementById("snd-notify-count");
  if (nc) nc.textContent = notifyFiles.length ? `${notifyFiles.length} plik(ów)` : "folder pusty — wrzuć dźwięk";
  const mc = document.getElementById("snd-music-count");
  if (mc) mc.textContent = musicFiles.length ? `${musicFiles.length} utwór(ów)` : "folder pusty — wrzuć muzykę";

  const now = document.getElementById("snd-now");
  if (now) {
    const np = r.nowPlaying || {};
    if (np.playing && np.track) {
      now.textContent = `♪  ${np.track}`;
      now.classList.add("is-playing");
    } else {
      now.textContent = s.musicEnabled ? (musicFiles.length ? "uruchamiam…" : "brak plików") : "zatrzymana";
      now.classList.remove("is-playing");
    }
  }

  if (_sndFirstLoad) {
    _sndFirstLoad = false;
    // Świeżo otwarty panel — każ silnikowi przejrzeć foldery na nowo.
    sndControl("rescan");
  }
}

function setupSoundPanel() {
  const notifyOn = document.getElementById("snd-notify-on");
  if (notifyOn) notifyOn.addEventListener("change", () => sndPush({ notifyEnabled: notifyOn.checked }));

  const musicOn = document.getElementById("snd-music-on");
  if (musicOn) musicOn.addEventListener("change", () => sndPush({ musicEnabled: musicOn.checked }));

  const shuffle = document.getElementById("snd-music-shuffle");
  if (shuffle) shuffle.addEventListener("change", () => sndPush({ musicShuffle: shuffle.checked }));

  // input = podgląd na żywo (słychać od razu), change = zapis po puszczeniu suwaka.
  const nVol = document.getElementById("snd-notify-vol");
  if (nVol) {
    const lab = document.getElementById("snd-notify-vol-val");
    nVol.addEventListener("input", () => { if (lab) lab.textContent = `${nVol.value}%`; });
    nVol.addEventListener("change", () => sndPush({ notifyVolume: Number(nVol.value) / 100 }));
  }

  const mVol = document.getElementById("snd-music-vol");
  if (mVol) {
    const lab = document.getElementById("snd-music-vol-val");
    mVol.addEventListener("input", () => {
      if (lab) lab.textContent = `${mVol.value}%`;
      sndPush({ musicVolume: Number(mVol.value) / 100 }); // muzyka: słychać zmianę natychmiast
    });
  }

  const file = document.getElementById("snd-notify-file");
  if (file) file.addEventListener("change", () => { if (file.value) sndPush({ notifyFile: file.value }); });

  const test = document.getElementById("snd-notify-test");
  if (test) test.addEventListener("click", () => sndControl("test-notify"));

  const next = document.getElementById("snd-music-next");
  if (next) next.addEventListener("click", () => sndControl("next"));

  const openN = document.getElementById("snd-open-notify");
  if (openN) openN.addEventListener("click", () => window.wbApi && window.wbApi.soundOpenFolder("powiadomienia"));

  const openM = document.getElementById("snd-open-music");
  if (openM) openM.addEventListener("click", () => window.wbApi && window.wbApi.soundOpenFolder("muzyka"));
}

window.addEventListener("DOMContentLoaded", () => {
  setupSoundPanel();
  loadSound();
  setInterval(loadSound, 1500);
});
window.addEventListener("keydown", (e) => { if (e.key === "Escape") window.close(); });
